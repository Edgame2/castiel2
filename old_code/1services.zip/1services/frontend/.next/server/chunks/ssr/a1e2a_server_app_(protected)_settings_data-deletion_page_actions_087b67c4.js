module.exports=[46872,(a,b,c)=>{}];

//# sourceMappingURL=a1e2a_server_app_%28protected%29_settings_data-deletion_page_actions_087b67c4.js.map