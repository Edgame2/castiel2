/**
 * Field Security Service
 * 
 * Handles field-level security, encryption, masking, and access control
 */

import type { Redis } from 'ioredis';
import type { FastifyInstance } from 'fastify';
import crypto from 'crypto';
import {
  FieldAccessLevel,
  DataClassification,
  FieldSecurityConfig,
  ShardTypeSecurityConfig,
  FieldAccessResult,
  SecureFieldValue,
  FieldAccessAudit,
  FieldMasking,
  MaskingStrategy,
  CreateFieldSecurityConfigInput,
  UpdateFieldSecurityConfigInput,
  ApplySecurityOptions,
} from '../types/field-security.types.js';
import type { Shard, StructuredData } from '../types/shard.types.js';

// Redis keys
const SECURITY_CONFIG_PREFIX = 'field_security:';
const AUDIT_PREFIX = 'field_audit:';

// Role hierarchy for access checks
const ROLE_HIERARCHY: Record<string, number> = {
  'super-admin': 100,
  'admin': 90,
  'tenant-admin': 80,
  'owner': 70,
  'editor': 50,
  'viewer': 30,
  'guest': 10,
};

/**
 * Field Security Service
 */
export class FieldSecurityService {
  private readonly encryptionKey: Buffer;

  constructor(
    private readonly redis: Redis,
    encryptionKeyHex?: string,
    private readonly server?: FastifyInstance
  ) {
    // Use provided key or generate one (in production, use key management service)
    this.encryptionKey = encryptionKeyHex
      ? Buffer.from(encryptionKeyHex, 'hex')
      : crypto.randomBytes(32);
  }

  // =====================================
  // SECURITY CONFIGURATION
  // =====================================

  /**
   * Create security config for a shard type
   */
  async createSecurityConfig(
    tenantId: string,
    userId: string,
    input: CreateFieldSecurityConfigInput
  ): Promise<ShardTypeSecurityConfig> {
    const id = crypto.randomUUID();

    const config: ShardTypeSecurityConfig = {
      id,
      shardTypeId: input.shardTypeId,
      tenantId,
      defaultAccessLevel: input.defaultAccessLevel || FieldAccessLevel.PRIVATE,
      defaultClassification: input.defaultClassification || DataClassification.INTERNAL,
      fields: input.fields.map((f, i) => ({
        ...f,
        fieldPath: f.fieldPath || `field_${i}`,
      })) as FieldSecurityConfig[],
      encryptAllPII: input.encryptAllPII ?? true,
      auditAllAccess: input.auditAllAccess ?? false,
      createdAt: new Date(),
      createdBy: userId,
    };

    const key = `${SECURITY_CONFIG_PREFIX}${tenantId}:${input.shardTypeId}`;
    await this.redis.set(key, JSON.stringify(config));

    this.server?.log.info({ configId: id, shardTypeId: input.shardTypeId }, 'Security config created');

    return config;
  }

  /**
   * Get security config for a shard type
   */
  async getSecurityConfig(
    tenantId: string,
    shardTypeId: string
  ): Promise<ShardTypeSecurityConfig | null> {
    const key = `${SECURITY_CONFIG_PREFIX}${tenantId}:${shardTypeId}`;
    const data = await this.redis.get(key);
    return data ? JSON.parse(data) : null;
  }

  /**
   * Update security config
   */
  async updateSecurityConfig(
    tenantId: string,
    shardTypeId: string,
    input: UpdateFieldSecurityConfigInput
  ): Promise<ShardTypeSecurityConfig | null> {
    const existing = await this.getSecurityConfig(tenantId, shardTypeId);
    if (!existing) return null;

    const updated: ShardTypeSecurityConfig = {
      ...existing,
      ...input,
      updatedAt: new Date(),
    };

    const key = `${SECURITY_CONFIG_PREFIX}${tenantId}:${shardTypeId}`;
    await this.redis.set(key, JSON.stringify(updated));

    return updated;
  }

  /**
   * Delete security config
   */
  async deleteSecurityConfig(tenantId: string, shardTypeId: string): Promise<boolean> {
    const key = `${SECURITY_CONFIG_PREFIX}${tenantId}:${shardTypeId}`;
    const deleted = await this.redis.del(key);
    return deleted > 0;
  }

  // =====================================
  // FIELD ACCESS CONTROL
  // =====================================

  /**
   * Check if user can access a field
   */
  async checkFieldAccess(
    config: FieldSecurityConfig | null,
    options: ApplySecurityOptions
  ): Promise<FieldAccessResult> {
    // No config = default allow
    if (!config) {
      return { allowed: true };
    }

    const { userId, userRoles, operation } = options;

    // System fields are never accessible via API
    if (config.accessLevel === FieldAccessLevel.SYSTEM) {
      return { allowed: false, reason: 'System field' };
    }

    // Public fields are always readable
    if (config.accessLevel === FieldAccessLevel.PUBLIC && operation === 'read') {
      return { allowed: true };
    }

    // Check role-based access
    const requiredRoles = operation === 'read' ? config.readRoles : config.writeRoles;
    
    if (requiredRoles && requiredRoles.length > 0) {
      const hasRole = userRoles.some((role) => requiredRoles.includes(role));
      if (!hasRole) {
        return { allowed: false, reason: 'Insufficient role permissions' };
      }
    }

    // Check access level
    if (config.accessLevel === FieldAccessLevel.RESTRICTED) {
      // For restricted fields, user must have explicit role access
      if (!requiredRoles || requiredRoles.length === 0) {
        return { allowed: false, reason: 'Restricted field requires explicit role' };
      }
    }

    // Admin bypass for private fields
    if (config.accessLevel === FieldAccessLevel.PRIVATE) {
      const isAdmin = userRoles.some((role) => 
        ROLE_HIERARCHY[role] >= ROLE_HIERARCHY['admin']
      );
      if (!isAdmin) {
        return { allowed: false, reason: 'Private field requires admin access' };
      }
    }

    return { allowed: true };
  }

  /**
   * Apply security transformations to shard data for read operations
   */
  async applyReadSecurity(
    shard: Shard,
    options: ApplySecurityOptions
  ): Promise<StructuredData> {
    const config = await this.getSecurityConfig(shard.tenantId, shard.shardTypeId);
    if (!config) {
      return shard.structuredData;
    }

    const result = { ...shard.structuredData };

    for (const fieldConfig of config.fields) {
      const accessResult = await this.checkFieldAccess(fieldConfig, options);

      if (!accessResult.allowed) {
        // Remove or mask the field
        if (fieldConfig.masking?.enabled) {
          const originalValue = this.getNestedValue(result, fieldConfig.fieldPath);
          const maskedValue = this.maskValue(originalValue, fieldConfig.masking);
          this.setNestedValue(result, fieldConfig.fieldPath, maskedValue);
        } else {
          this.deleteNestedValue(result, fieldConfig.fieldPath);
        }

        // Audit denied access
        if (config.auditAllAccess || fieldConfig.auditReads) {
          await this.logFieldAccess({
            tenantId: shard.tenantId,
            shardId: shard.id,
            fieldPath: fieldConfig.fieldPath,
            accessType: 'read',
            userId: options.userId,
            userRoles: options.userRoles,
            allowed: false,
            masked: fieldConfig.masking?.enabled || false,
          });
        }
      } else {
        // Decrypt if encrypted
        if (fieldConfig.encryption?.enabled) {
          const encryptedValue = this.getNestedValue(result, fieldConfig.fieldPath);
          if (encryptedValue && typeof encryptedValue === 'object' && encryptedValue.encrypted) {
            const decrypted = this.decryptValue(encryptedValue as SecureFieldValue);
            this.setNestedValue(result, fieldConfig.fieldPath, decrypted);
          }
        }

        // Audit allowed access
        if (config.auditAllAccess || fieldConfig.auditReads) {
          await this.logFieldAccess({
            tenantId: shard.tenantId,
            shardId: shard.id,
            fieldPath: fieldConfig.fieldPath,
            accessType: 'read',
            userId: options.userId,
            userRoles: options.userRoles,
            allowed: true,
            masked: false,
          });
        }
      }
    }

    return result;
  }

  /**
   * Apply security transformations to shard data for write operations
   */
  async applyWriteSecurity(
    tenantId: string,
    shardTypeId: string,
    data: StructuredData,
    options: ApplySecurityOptions
  ): Promise<{ data: StructuredData; errors: string[] }> {
    const config = await this.getSecurityConfig(tenantId, shardTypeId);
    if (!config) {
      return { data, errors: [] };
    }

    const result = { ...data };
    const errors: string[] = [];

    for (const fieldConfig of config.fields) {
      const fieldValue = this.getNestedValue(result, fieldConfig.fieldPath);
      
      // Skip if field not in input
      if (fieldValue === undefined) continue;

      // Check write access
      const accessResult = await this.checkFieldAccess(fieldConfig, {
        ...options,
        operation: 'write',
      });

      if (!accessResult.allowed) {
        errors.push(`Cannot write to field '${fieldConfig.fieldPath}': ${accessResult.reason}`);
        this.deleteNestedValue(result, fieldConfig.fieldPath);
        continue;
      }

      // Validate field
      if (fieldConfig.validationRules) {
        for (const rule of fieldConfig.validationRules) {
          const validationError = this.validateField(fieldValue, rule);
          if (validationError) {
            errors.push(`Validation failed for '${fieldConfig.fieldPath}': ${validationError}`);
          }
        }
      }

      // Encrypt if needed
      if (fieldConfig.encryption?.enabled || 
          (config.encryptAllPII && fieldConfig.classification === DataClassification.PII)) {
        const encrypted = this.encryptValue(fieldValue);
        this.setNestedValue(result, fieldConfig.fieldPath, encrypted);
      }

      // Audit write
      if (config.auditAllAccess || fieldConfig.auditWrites) {
        await this.logFieldAccess({
          tenantId,
          shardId: 'pending', // Will be set after creation
          fieldPath: fieldConfig.fieldPath,
          accessType: 'write',
          userId: options.userId,
          userRoles: options.userRoles,
          allowed: true,
          masked: false,
        });
      }
    }

    return { data: result, errors };
  }

  // =====================================
  // ENCRYPTION
  // =====================================

  /**
   * Encrypt a field value
   */
  encryptValue(value: any): SecureFieldValue {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-gcm', this.encryptionKey, iv);
    
    const plaintext = JSON.stringify(value);
    let ciphertext = cipher.update(plaintext, 'utf8', 'base64');
    ciphertext += cipher.final('base64');
    
    const tag = cipher.getAuthTag();

    return {
      encrypted: true,
      algorithm: 'AES-256-GCM',
      keyId: 'default',
      iv: iv.toString('base64'),
      ciphertext,
      tag: tag.toString('base64'),
    };
  }

  /**
   * Decrypt a field value
   */
  decryptValue(secure: SecureFieldValue): any {
    const iv = Buffer.from(secure.iv, 'base64');
    const decipher = crypto.createDecipheriv('aes-256-gcm', this.encryptionKey, iv);
    
    if (secure.tag) {
      decipher.setAuthTag(Buffer.from(secure.tag, 'base64'));
    }

    let plaintext = decipher.update(secure.ciphertext, 'base64', 'utf8');
    plaintext += decipher.final('utf8');

    return JSON.parse(plaintext);
  }

  // =====================================
  // MASKING
  // =====================================

  /**
   * Mask a value based on configuration
   */
  maskValue(value: any, config: FieldMasking): any {
    if (value === null || value === undefined) return value;

    const str = String(value);
    const maskChar = config.maskChar || '*';
    const visibleChars = config.visibleChars || 4;

    switch (config.strategy) {
      case MaskingStrategy.FULL:
        return config.preserveLength 
          ? maskChar.repeat(str.length) 
          : maskChar.repeat(8);

      case MaskingStrategy.PARTIAL:
        if (str.length <= visibleChars) {
          return maskChar.repeat(str.length);
        }
        
        switch (config.visiblePosition) {
          case 'start':
            return str.slice(0, visibleChars) + maskChar.repeat(str.length - visibleChars);
          case 'end':
            return maskChar.repeat(str.length - visibleChars) + str.slice(-visibleChars);
          case 'both':
            const halfVisible = Math.floor(visibleChars / 2);
            return str.slice(0, halfVisible) + 
                   maskChar.repeat(str.length - visibleChars) + 
                   str.slice(-halfVisible);
          default:
            return str.slice(0, visibleChars) + maskChar.repeat(str.length - visibleChars);
        }

      case MaskingStrategy.HASH:
        const hash = crypto.createHash('sha256').update(str).digest('hex');
        return hash.slice(0, 8) + '...';

      case MaskingStrategy.REDACT:
        return '[REDACTED]';

      case MaskingStrategy.TOKEN:
        // Generate deterministic token for same value
        const tokenHash = crypto.createHmac('sha256', this.encryptionKey)
          .update(str)
          .digest('hex');
        return `tok_${tokenHash.slice(0, 16)}`;

      case MaskingStrategy.NONE:
      default:
        return value;
    }
  }

  // =====================================
  // VALIDATION
  // =====================================

  private validateField(value: any, rule: FieldSecurityConfig['validationRules'][0]): string | null {
    switch (rule.type) {
      case 'required':
        if (value === null || value === undefined || value === '') {
          return rule.message || 'Field is required';
        }
        break;

      case 'pattern':
        if (rule.value && !new RegExp(rule.value).test(String(value))) {
          return rule.message || 'Value does not match required pattern';
        }
        break;

      case 'minLength':
        if (String(value).length < rule.value) {
          return rule.message || `Minimum length is ${rule.value}`;
        }
        break;

      case 'maxLength':
        if (String(value).length > rule.value) {
          return rule.message || `Maximum length is ${rule.value}`;
        }
        break;

      case 'enum':
        if (Array.isArray(rule.value) && !rule.value.includes(value)) {
          return rule.message || `Value must be one of: ${rule.value.join(', ')}`;
        }
        break;
    }

    return null;
  }

  // =====================================
  // AUDIT LOGGING
  // =====================================

  private async logFieldAccess(entry: Omit<FieldAccessAudit, 'id' | 'timestamp'>): Promise<void> {
    const audit: FieldAccessAudit = {
      ...entry,
      id: crypto.randomUUID(),
      timestamp: new Date(),
    };

    const key = `${AUDIT_PREFIX}${entry.tenantId}:${Date.now()}:${audit.id}`;
    await this.redis.setex(key, 90 * 24 * 60 * 60, JSON.stringify(audit)); // 90 days
  }

  /**
   * Get field access audit logs
   */
  async getFieldAccessAudit(
    tenantId: string,
    options?: {
      shardId?: string;
      fieldPath?: string;
      userId?: string;
      limit?: number;
    }
  ): Promise<FieldAccessAudit[]> {
    const pattern = `${AUDIT_PREFIX}${tenantId}:*`;
    const keys = await this.redis.keys(pattern);
    const audits: FieldAccessAudit[] = [];

    for (const key of keys) {
      const data = await this.redis.get(key);
      if (data) {
        const audit = JSON.parse(data) as FieldAccessAudit;
        
        // Apply filters
        if (options?.shardId && audit.shardId !== options.shardId) continue;
        if (options?.fieldPath && audit.fieldPath !== options.fieldPath) continue;
        if (options?.userId && audit.userId !== options.userId) continue;
        
        audits.push(audit);
      }
    }

    // Sort by timestamp descending
    audits.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    return audits.slice(0, options?.limit || 100);
  }

  // =====================================
  // UTILITY METHODS
  // =====================================

  private getNestedValue(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => current?.[key], obj);
  }

  private setNestedValue(obj: any, path: string, value: any): void {
    const keys = path.split('.');
    const lastKey = keys.pop()!;
    const target = keys.reduce((current, key) => {
      if (current[key] === undefined) {
        current[key] = {};
      }
      return current[key];
    }, obj);
    target[lastKey] = value;
  }

  private deleteNestedValue(obj: any, path: string): void {
    const keys = path.split('.');
    const lastKey = keys.pop()!;
    const target = keys.reduce((current, key) => current?.[key], obj);
    if (target) {
      delete target[lastKey];
    }
  }
}


