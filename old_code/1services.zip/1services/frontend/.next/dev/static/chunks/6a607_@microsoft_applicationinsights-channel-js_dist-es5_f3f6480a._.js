(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/InternalConstants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Channel, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ // ###################################################################################################################################################
// Note: DON'T Export these const from the package as we are still targeting IE/ES5 this will export a mutable variables that someone could change ###
// ###################################################################################################################################################
// Generally you should only put values that are used more than 2 times and then only if not already exposed as a constant (such as SdkCoreNames)
// as when using "short" named values from here they will be will be minified smaller than the SdkCoreNames[eSdkCoreNames.xxxx] value.
__turbopack_context__.s([
    "STR_DURATION",
    ()=>STR_DURATION
]);
var STR_DURATION = "duration"; //# sourceMappingURL=InternalConstants.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Channel, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ // @skip-file-minify
// ##############################################################
// AUTO GENERATED FILE: This file is Auto Generated during build.
// ##############################################################
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// Note: DON'T Export these const from the package as we are still targeting ES5 which can result in a mutable variables that someone could change!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
__turbopack_context__.s([
    "_DYN_ALWAYS_USE_XHR_OVERR4",
    ()=>_DYN_ALWAYS_USE_XHR_OVERR4,
    "_DYN_BASE_TYPE",
    ()=>_DYN_BASE_TYPE,
    "_DYN_BUFFER_OVERRIDE",
    ()=>_DYN_BUFFER_OVERRIDE,
    "_DYN_CLEAR",
    ()=>_DYN_CLEAR,
    "_DYN_CLEAR_SENT",
    ()=>_DYN_CLEAR_SENT,
    "_DYN_CONCAT",
    ()=>_DYN_CONCAT,
    "_DYN_COUNT",
    ()=>_DYN_COUNT,
    "_DYN_CUSTOM_HEADERS",
    ()=>_DYN_CUSTOM_HEADERS,
    "_DYN_DATA",
    ()=>_DYN_DATA,
    "_DYN_DATA_TYPE",
    ()=>_DYN_DATA_TYPE,
    "_DYN_DEVICE_TYPE",
    ()=>_DYN_DEVICE_TYPE,
    "_DYN_DIAG_LOG",
    ()=>_DYN_DIAG_LOG,
    "_DYN_DISABLE_SEND_BEACON_7",
    ()=>_DYN_DISABLE_SEND_BEACON_7,
    "_DYN_EMIT_LINE_DELIMITED_0",
    ()=>_DYN_EMIT_LINE_DELIMITED_0,
    "_DYN_ENABLE_SESSION_STORA5",
    ()=>_DYN_ENABLE_SESSION_STORA5,
    "_DYN_ENDPOINT_URL",
    ()=>_DYN_ENDPOINT_URL,
    "_DYN_ENQUEUE",
    ()=>_DYN_ENQUEUE,
    "_DYN_ENVELOPE_TYPE",
    ()=>_DYN_ENVELOPE_TYPE,
    "_DYN_GET_HASH_CODE_SCORE",
    ()=>_DYN_GET_HASH_CODE_SCORE,
    "_DYN_GET_SENDER_INST",
    ()=>_DYN_GET_SENDER_INST,
    "_DYN_INITIALIZE",
    ()=>_DYN_INITIALIZE,
    "_DYN_INSTRUMENTATION_KEY",
    ()=>_DYN_INSTRUMENTATION_KEY,
    "_DYN_IS_BEACON_API_DISABL3",
    ()=>_DYN_IS_BEACON_API_DISABL3,
    "_DYN_ITEMS_ACCEPTED",
    ()=>_DYN_ITEMS_ACCEPTED,
    "_DYN_ITEMS_RECEIVED",
    ()=>_DYN_ITEMS_RECEIVED,
    "_DYN_LENGTH",
    ()=>_DYN_LENGTH,
    "_DYN_MARK_AS_SENT",
    ()=>_DYN_MARK_AS_SENT,
    "_DYN_MAX_BATCH_SIZE_IN_BY1",
    ()=>_DYN_MAX_BATCH_SIZE_IN_BY1,
    "_DYN_MEASUREMENTS",
    ()=>_DYN_MEASUREMENTS,
    "_DYN_NAME",
    ()=>_DYN_NAME,
    "_DYN_ONUNLOAD_DISABLE_BEA2",
    ()=>_DYN_ONUNLOAD_DISABLE_BEA2,
    "_DYN_ONUNLOAD_DISABLE_FET6",
    ()=>_DYN_ONUNLOAD_DISABLE_FET6,
    "_DYN_PUSH",
    ()=>_DYN_PUSH,
    "_DYN_SAMPLE_RATE",
    ()=>_DYN_SAMPLE_RATE,
    "_DYN_STRINGIFY",
    ()=>_DYN_STRINGIFY,
    "_DYN_TAGS",
    ()=>_DYN_TAGS,
    "_DYN_TO_STRING",
    ()=>_DYN_TO_STRING,
    "_DYN_TRACE_ID",
    ()=>_DYN_TRACE_ID,
    "_DYN_TRIGGER_SEND",
    ()=>_DYN_TRIGGER_SEND,
    "_DYN__BUFFER",
    ()=>_DYN__BUFFER,
    "_DYN__BUFFER__KEY",
    ()=>_DYN__BUFFER__KEY,
    "_DYN__MAX__BUFFER__SIZE",
    ()=>_DYN__MAX__BUFFER__SIZE,
    "_DYN__ON_ERROR",
    ()=>_DYN__ON_ERROR,
    "_DYN__ON_PARTIAL_SUCCESS",
    ()=>_DYN__ON_PARTIAL_SUCCESS,
    "_DYN__ON_SUCCESS",
    ()=>_DYN__ON_SUCCESS,
    "_DYN__SENDER",
    ()=>_DYN__SENDER,
    "_DYN__SENT__BUFFER__KEY",
    ()=>_DYN__SENT__BUFFER__KEY
]);
var _DYN_TAGS = "tags"; // Count: 17
var _DYN_DEVICE_TYPE = "deviceType"; // Count: 3
var _DYN_DATA = "data"; // Count: 13
var _DYN_NAME = "name"; // Count: 8
var _DYN_TRACE_ID = "traceID"; // Count: 5
var _DYN_LENGTH = "length"; // Count: 38
var _DYN_STRINGIFY = "stringify"; // Count: 5
var _DYN_MEASUREMENTS = "measurements"; // Count: 7
var _DYN_DATA_TYPE = "dataType"; // Count: 10
var _DYN_ENVELOPE_TYPE = "envelopeType"; // Count: 7
var _DYN_TO_STRING = "toString"; // Count: 7
var _DYN_ENQUEUE = "enqueue"; // Count: 7
var _DYN_COUNT = "count"; // Count: 7
var _DYN_PUSH = "push"; // Count: 9
var _DYN_EMIT_LINE_DELIMITED_0 = "emitLineDelimitedJson"; // Count: 3
var _DYN_CLEAR = "clear"; // Count: 6
var _DYN_MARK_AS_SENT = "markAsSent"; // Count: 4
var _DYN_CLEAR_SENT = "clearSent"; // Count: 5
var _DYN_BUFFER_OVERRIDE = "bufferOverride"; // Count: 3
var _DYN__BUFFER__KEY = "BUFFER_KEY"; // Count: 5
var _DYN__SENT__BUFFER__KEY = "SENT_BUFFER_KEY"; // Count: 8
var _DYN_CONCAT = "concat"; // Count: 6
var _DYN__MAX__BUFFER__SIZE = "MAX_BUFFER_SIZE"; // Count: 5
var _DYN_TRIGGER_SEND = "triggerSend"; // Count: 5
var _DYN_DIAG_LOG = "diagLog"; // Count: 16
var _DYN_INITIALIZE = "initialize"; // Count: 3
var _DYN__SENDER = "_sender"; // Count: 5
var _DYN_ENDPOINT_URL = "endpointUrl"; // Count: 5
var _DYN_INSTRUMENTATION_KEY = "instrumentationKey"; // Count: 5
var _DYN_CUSTOM_HEADERS = "customHeaders"; // Count: 3
var _DYN_MAX_BATCH_SIZE_IN_BY1 = "maxBatchSizeInBytes"; // Count: 2
var _DYN_ONUNLOAD_DISABLE_BEA2 = "onunloadDisableBeacon"; // Count: 3
var _DYN_IS_BEACON_API_DISABL3 = "isBeaconApiDisabled"; // Count: 3
var _DYN_ALWAYS_USE_XHR_OVERR4 = "alwaysUseXhrOverride"; // Count: 2
var _DYN_ENABLE_SESSION_STORA5 = "enableSessionStorageBuffer"; // Count: 2
var _DYN__BUFFER = "_buffer"; // Count: 9
var _DYN_ONUNLOAD_DISABLE_FET6 = "onunloadDisableFetch"; // Count: 2
var _DYN_DISABLE_SEND_BEACON_7 = "disableSendBeaconSplit"; // Count: 2
var _DYN_GET_SENDER_INST = "getSenderInst"; // Count: 4
var _DYN__ON_ERROR = "_onError"; // Count: 7
var _DYN__ON_PARTIAL_SUCCESS = "_onPartialSuccess"; // Count: 3
var _DYN__ON_SUCCESS = "_onSuccess"; // Count: 6
var _DYN_ITEMS_RECEIVED = "itemsReceived"; // Count: 3
var _DYN_ITEMS_ACCEPTED = "itemsAccepted"; // Count: 3
var _DYN_BASE_TYPE = "baseType"; // Count: 4
var _DYN_SAMPLE_RATE = "sampleRate"; // Count: 4
var _DYN_GET_HASH_CODE_SCORE = "getHashCodeScore"; // Count: 4
 //# sourceMappingURL=__DynamicConstants.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/EnvelopeCreator.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Channel, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "DependencyEnvelopeCreator",
    ()=>DependencyEnvelopeCreator,
    "EnvelopeCreator",
    ()=>EnvelopeCreator,
    "EventEnvelopeCreator",
    ()=>EventEnvelopeCreator,
    "ExceptionEnvelopeCreator",
    ()=>ExceptionEnvelopeCreator,
    "MetricEnvelopeCreator",
    ()=>MetricEnvelopeCreator,
    "PageViewEnvelopeCreator",
    ()=>PageViewEnvelopeCreator,
    "PageViewPerformanceEnvelopeCreator",
    ()=>PageViewPerformanceEnvelopeCreator,
    "TraceEnvelopeCreator",
    ()=>TraceEnvelopeCreator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-shims@3.0.1/node_modules/@microsoft/applicationinsights-shims/dist-es5/TsLibShims.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Interfaces/PartAExtensions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$Data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Common/Data.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$Envelope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Common/Envelope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Event.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Exception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Exception.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Metric$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Metric.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/PageView.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageViewPerformance$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/PageViewPerformance.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$RemoteDependencyData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/RemoteDependencyData.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Trace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Trace.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$DataSanitizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Common/DataSanitizer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EnvUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/InternalConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
;
;
;
;
// these two constants are used to filter out properties not needed when trying to extract custom properties and measurements from the incoming payload
var strBaseType = "baseType";
var strBaseData = "baseData";
var strProperties = "properties";
var strTrue = "true";
function _setValueIf(target, field, value) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(target, field, value, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTruthy"]);
}
/*
 * Maps Part A data from CS 4.0
 */ function _extractPartAExtensions(logger, item, env) {
    // todo: switch to keys from common in this method
    var envTags = env[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ] = env[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ] || {};
    var itmExt = item.ext = item.ext || {};
    var itmTags = item[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ] = item[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ] || [];
    var extUser = itmExt.user;
    if (extUser) {
        _setValueIf(envTags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].userAuthUserId, extUser.authId);
        _setValueIf(envTags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].userId, extUser.id || extUser.localId);
    }
    var extApp = itmExt.app;
    if (extApp) {
        _setValueIf(envTags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].sessionId, extApp.sesId);
    }
    var extDevice = itmExt.device;
    if (extDevice) {
        _setValueIf(envTags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].deviceId, extDevice.id || extDevice.localId);
        _setValueIf(envTags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DEVICE_TYPE"] /* @min:%2edeviceType */ ], extDevice.deviceClass);
        _setValueIf(envTags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].deviceIp, extDevice.ip);
        _setValueIf(envTags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].deviceModel, extDevice.model);
        _setValueIf(envTags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DEVICE_TYPE"] /* @min:%2edeviceType */ ], extDevice[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DEVICE_TYPE"] /* @min:%2edeviceType */ ]);
    }
    var web = item.ext.web;
    if (web) {
        _setValueIf(envTags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].deviceLanguage, web.browserLang);
        _setValueIf(envTags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].deviceBrowserVersion, web.browserVer);
        _setValueIf(envTags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].deviceBrowser, web.browser);
        var envData = env[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ] = env[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ] || {};
        var envBaseData = envData[strBaseData] = envData[strBaseData] || {};
        var envProps = envBaseData[strProperties] = envBaseData[strProperties] || {};
        _setValueIf(envProps, "domain", web.domain);
        _setValueIf(envProps, "isManual", web.isManual ? strTrue : null);
        _setValueIf(envProps, "screenRes", web.screenRes);
        _setValueIf(envProps, "userConsent", web.userConsent ? strTrue : null);
    }
    var extOs = itmExt.os;
    if (extOs) {
        _setValueIf(envTags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].deviceOS, extOs[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ]);
        _setValueIf(envTags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].deviceOSVersion, extOs.osVer);
    }
    // No support for mapping Trace.traceState to 2.0 as it is currently empty
    var extTrace = itmExt.trace;
    if (extTrace) {
        _setValueIf(envTags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].operationParentId, extTrace.parentID);
        _setValueIf(envTags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].operationName, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$DataSanitizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dataSanitizeString"])(logger, extTrace[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ]));
        _setValueIf(envTags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].operationId, extTrace[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_ID"] /* @min:%2etraceID */ ]);
    }
    // Sample 4.0 schema
    //  {
    //     "time" : "2018-09-05T22:51:22.4936Z",
    //     "name" : "MetricWithNamespace",
    //     "iKey" : "ABC-5a4cbd20-e601-4ef5-a3c6-5d6577e4398e",
    //     "ext": {  "cloud": {
    //          "role": "WATSON3",
    //          "roleInstance": "CO4AEAP00000260"
    //      },
    //      "device": {}, "correlation": {} },
    //      "tags": [
    //        { "amazon.region" : "east2" },
    //        { "os.expid" : "wp:02df239" }
    //     ]
    //   }
    var tgs = {};
    // deals with tags.push({object})
    for(var i = itmTags[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] - 1; i >= 0; i--){
        var tg = itmTags[i];
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(tg, function(key, value) {
            tgs[key] = value;
        });
        itmTags.splice(i, 1);
    }
    // deals with tags[key]=value (and handles hasOwnProperty)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(itmTags, function(tg, value) {
        tgs[tg] = value;
    });
    var theTags = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assignFn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assignFn"])({}, envTags), tgs);
    if (!theTags[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].internalSdkVersion]) {
        // Append a version in case it is not already set
        theTags[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].internalSdkVersion] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$DataSanitizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dataSanitizeString"])(logger, "javascript:".concat(EnvelopeCreator.Version), 64);
    }
    env[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optimizeObject"])(theTags);
}
function _extractPropsAndMeasurements(data, properties, measurements) {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(data)) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(data, function(key, value) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNumber"])(value)) {
                measurements[key] = value;
            } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(value)) {
                properties[key] = value;
            } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasJSON"])()) {
                properties[key] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getJSON"])()[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STRINGIFY"] /* @min:%2estringify */ ](value);
            }
        });
    }
}
function _convertPropsUndefinedToCustomDefinedValue(properties, customUndefinedValue) {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(properties)) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(properties, function(key, value) {
            properties[key] = value || customUndefinedValue;
        });
    }
}
// TODO: Do we want this to take logger as arg or use this._logger as nonstatic?
function _createEnvelope(logger, envelopeType, telemetryItem, data) {
    var envelope = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$Envelope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Envelope"](logger, data, envelopeType);
    _setValueIf(envelope, "sampleRate", telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SampleRate"]]);
    if ((telemetryItem[strBaseData] || {}).startTime) {
        // Starting from Version 3.0.3, the time property will be assigned by the startTime value,
        // which records the loadEvent time for the pageView event.
        envelope.time = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toISOString"])(telemetryItem[strBaseData].startTime);
    }
    envelope.iKey = telemetryItem.iKey;
    var iKeyNoDashes = telemetryItem.iKey.replace(/-/g, "");
    envelope[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ] = envelope[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ].replace("{0}", iKeyNoDashes);
    // extract all extensions from ctx
    _extractPartAExtensions(logger, telemetryItem, envelope);
    // loop through the envelope tags (extension of Part A) and pick out the ones that should go in outgoing envelope tags
    telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ] = telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ] || [];
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optimizeObject"])(envelope);
}
function EnvelopeCreatorInit(logger, telemetryItem) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(telemetryItem[strBaseData])) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 1 /* eLoggingSeverity.CRITICAL */ , 46 /* _eInternalMessageId.TelemetryEnvelopeInvalid */ , "telemetryItem.baseData cannot be null.");
    }
}
var EnvelopeCreator = {
    Version: '3.3.10'
};
function DependencyEnvelopeCreator(logger, telemetryItem, customUndefinedValue) {
    EnvelopeCreatorInit(logger, telemetryItem);
    var customMeasurements = telemetryItem[strBaseData][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MEASUREMENTS"] /* @min:%2emeasurements */ ] || {};
    var customProperties = telemetryItem[strBaseData][strProperties] || {};
    _extractPropsAndMeasurements(telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ], customProperties, customMeasurements);
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(customUndefinedValue)) {
        _convertPropsUndefinedToCustomDefinedValue(customProperties, customUndefinedValue);
    }
    var bd = telemetryItem[strBaseData];
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(bd)) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_warnToConsole"])(logger, "Invalid input for dependency data");
        return null;
    }
    var method = bd[strProperties] && bd[strProperties][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpMethod"]] ? bd[strProperties][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpMethod"]] : "GET";
    var remoteDepData = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$RemoteDependencyData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RemoteDependencyData"](logger, bd.id, bd.target, bd[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ], bd[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_DURATION"] /* @min:%2eduration */ ], bd.success, bd.responseCode, method, bd.type, bd.correlationContext, customProperties, customMeasurements);
    var data = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$Data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Data"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$RemoteDependencyData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RemoteDependencyData"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ], remoteDepData);
    return _createEnvelope(logger, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$RemoteDependencyData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RemoteDependencyData"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENVELOPE_TYPE"] /* @min:%2eenvelopeType */ ], telemetryItem, data);
}
function EventEnvelopeCreator(logger, telemetryItem, customUndefinedValue) {
    EnvelopeCreatorInit(logger, telemetryItem);
    var customProperties = {};
    var customMeasurements = {};
    if (telemetryItem[strBaseType] !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Event"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ]) {
        customProperties["baseTypeSource"] = telemetryItem[strBaseType]; // save the passed in base type as a property
    }
    if (telemetryItem[strBaseType] === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Event"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ]) {
        customProperties = telemetryItem[strBaseData][strProperties] || {};
        customMeasurements = telemetryItem[strBaseData][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MEASUREMENTS"] /* @min:%2emeasurements */ ] || {};
    } else {
        if (telemetryItem[strBaseData]) {
            _extractPropsAndMeasurements(telemetryItem[strBaseData], customProperties, customMeasurements);
        }
    }
    // Extract root level properties from part C telemetryItem.data
    _extractPropsAndMeasurements(telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ], customProperties, customMeasurements);
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(customUndefinedValue)) {
        _convertPropsUndefinedToCustomDefinedValue(customProperties, customUndefinedValue);
    }
    var eventName = telemetryItem[strBaseData][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ];
    var eventData = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Event"](logger, eventName, customProperties, customMeasurements);
    var data = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$Data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Data"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Event"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ], eventData);
    return _createEnvelope(logger, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Event"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENVELOPE_TYPE"] /* @min:%2eenvelopeType */ ], telemetryItem, data);
}
function ExceptionEnvelopeCreator(logger, telemetryItem, customUndefinedValue) {
    EnvelopeCreatorInit(logger, telemetryItem);
    // Extract root level properties from part C telemetryItem.data
    var customMeasurements = telemetryItem[strBaseData][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MEASUREMENTS"] /* @min:%2emeasurements */ ] || {};
    var customProperties = telemetryItem[strBaseData][strProperties] || {};
    _extractPropsAndMeasurements(telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ], customProperties, customMeasurements);
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(customUndefinedValue)) {
        _convertPropsUndefinedToCustomDefinedValue(customProperties, customUndefinedValue);
    }
    var bd = telemetryItem[strBaseData];
    var exData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Exception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Exception"].CreateFromInterface(logger, bd, customProperties, customMeasurements);
    var data = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$Data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Data"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Exception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Exception"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ], exData);
    return _createEnvelope(logger, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Exception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Exception"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENVELOPE_TYPE"] /* @min:%2eenvelopeType */ ], telemetryItem, data);
}
function MetricEnvelopeCreator(logger, telemetryItem, customUndefinedValue) {
    EnvelopeCreatorInit(logger, telemetryItem);
    var baseData = telemetryItem[strBaseData];
    var props = baseData[strProperties] || {};
    var measurements = baseData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MEASUREMENTS"] /* @min:%2emeasurements */ ] || {};
    _extractPropsAndMeasurements(telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ], props, measurements);
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(customUndefinedValue)) {
        _convertPropsUndefinedToCustomDefinedValue(props, customUndefinedValue);
    }
    var baseMetricData = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Metric$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metric"](logger, baseData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ], baseData.average, baseData.sampleCount, baseData.min, baseData.max, baseData.stdDev, props, measurements);
    var data = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$Data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Data"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Metric$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metric"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ], baseMetricData);
    return _createEnvelope(logger, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Metric$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metric"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENVELOPE_TYPE"] /* @min:%2eenvelopeType */ ], telemetryItem, data);
}
function PageViewEnvelopeCreator(logger, telemetryItem, customUndefinedValue) {
    EnvelopeCreatorInit(logger, telemetryItem);
    // Since duration is not part of the domain properties in Common Schema, extract it from part C
    var duration;
    var baseData = telemetryItem[strBaseData];
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(baseData) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(baseData[strProperties]) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(baseData[strProperties][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_DURATION"]])) {
        duration = baseData[strProperties][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_DURATION"]];
        delete baseData[strProperties][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_DURATION"]];
    } else if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ]) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_DURATION"]])) {
        duration = telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_DURATION"]];
        delete telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_DURATION"]];
    }
    var bd = telemetryItem[strBaseData];
    // special case: pageview.id is grabbed from current operation id. Analytics plugin is decoupled from properties plugin, so this is done here instead. This can be made a default telemetry intializer instead if needed to be decoupled from channel
    var currentContextId;
    if (((telemetryItem.ext || {}).trace || {})[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_ID"] /* @min:%2etraceID */ ]) {
        currentContextId = telemetryItem.ext.trace[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_ID"] /* @min:%2etraceID */ ];
    }
    var id = bd.id || currentContextId;
    var name = bd[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ];
    var url = bd.uri;
    var properties = bd[strProperties] || {};
    var measurements = bd[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MEASUREMENTS"] /* @min:%2emeasurements */ ] || {};
    // refUri is a field that Breeze still does not recognize as part of Part B. For now, put it in Part C until it supports it as a domain property
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(bd.refUri)) {
        properties["refUri"] = bd.refUri;
    }
    // pageType is a field that Breeze still does not recognize as part of Part B. For now, put it in Part C until it supports it as a domain property
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(bd.pageType)) {
        properties["pageType"] = bd.pageType;
    }
    // isLoggedIn is a field that Breeze still does not recognize as part of Part B. For now, put it in Part C until it supports it as a domain property
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(bd.isLoggedIn)) {
        properties["isLoggedIn"] = bd.isLoggedIn[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_STRING"] /* @min:%2etoString */ ]();
    }
    // pageTags is a field that Breeze still does not recognize as part of Part B. For now, put it in Part C until it supports it as a domain property
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(bd[strProperties])) {
        var pageTags = bd[strProperties];
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(pageTags, function(key, value) {
            properties[key] = value;
        });
    }
    _extractPropsAndMeasurements(telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ], properties, measurements);
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(customUndefinedValue)) {
        _convertPropsUndefinedToCustomDefinedValue(properties, customUndefinedValue);
    }
    var pageViewData = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageView"](logger, name, url, duration, properties, measurements, id);
    var data = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$Data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Data"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageView"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ], pageViewData);
    return _createEnvelope(logger, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageView"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENVELOPE_TYPE"] /* @min:%2eenvelopeType */ ], telemetryItem, data);
}
function PageViewPerformanceEnvelopeCreator(logger, telemetryItem, customUndefinedValue) {
    EnvelopeCreatorInit(logger, telemetryItem);
    var bd = telemetryItem[strBaseData];
    var name = bd[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ];
    var url = bd.uri || bd.url;
    var properties = bd[strProperties] || {};
    var measurements = bd[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MEASUREMENTS"] /* @min:%2emeasurements */ ] || {};
    _extractPropsAndMeasurements(telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ], properties, measurements);
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(customUndefinedValue)) {
        _convertPropsUndefinedToCustomDefinedValue(properties, customUndefinedValue);
    }
    var baseData = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageViewPerformance$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageViewPerformance"](logger, name, url, undefined, properties, measurements, bd);
    var data = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$Data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Data"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageViewPerformance$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageViewPerformance"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ], baseData);
    return _createEnvelope(logger, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageViewPerformance$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageViewPerformance"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENVELOPE_TYPE"] /* @min:%2eenvelopeType */ ], telemetryItem, data);
}
function TraceEnvelopeCreator(logger, telemetryItem, customUndefinedValue) {
    EnvelopeCreatorInit(logger, telemetryItem);
    var message = telemetryItem[strBaseData].message;
    var severityLevel = telemetryItem[strBaseData].severityLevel;
    var props = telemetryItem[strBaseData][strProperties] || {};
    var measurements = telemetryItem[strBaseData][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MEASUREMENTS"] /* @min:%2emeasurements */ ] || {};
    _extractPropsAndMeasurements(telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ], props, measurements);
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(customUndefinedValue)) {
        _convertPropsUndefinedToCustomDefinedValue(props, customUndefinedValue);
    }
    var baseData = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Trace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trace"](logger, message, severityLevel, props, measurements);
    var data = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$Data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Data"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Trace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trace"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ], baseData);
    return _createEnvelope(logger, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Trace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trace"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENVELOPE_TYPE"] /* @min:%2eenvelopeType */ ], telemetryItem, data);
} //# sourceMappingURL=EnvelopeCreator.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/SendBuffer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Channel, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "ArraySendBuffer",
    ()=>ArraySendBuffer,
    "SessionStorageSendBuffer",
    ()=>SessionStorageSendBuffer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-shims@3.0.1/node_modules/@microsoft/applicationinsights-shims/dist-es5/TsLibShims.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/StorageHelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EnvUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
;
;
;
;
var BaseSendBuffer = function() {
    function BaseSendBuffer(logger, config) {
        var _buffer = [];
        var _bufferFullMessageSent = false;
        var _maxRetryCnt = config.maxRetryCnt;
        this._get = function() {
            return _buffer;
        };
        this._set = function(buffer) {
            _buffer = buffer;
            return _buffer;
        };
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(BaseSendBuffer, this, function(_self) {
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENQUEUE"] /* @min:%2eenqueue */ ] = function(payload) {
                if (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_COUNT"] /* @min:%2ecount */ ]() >= config.eventsLimitInMem) {
                    // sent internal log only once per page view
                    if (!_bufferFullMessageSent) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 2 /* eLoggingSeverity.WARNING */ , 105 /* _eInternalMessageId.InMemoryStorageBufferFull */ , "Maximum in-memory buffer size reached: " + _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_COUNT"] /* @min:%2ecount */ ](), true);
                        _bufferFullMessageSent = true;
                    }
                    return;
                }
                payload.cnt = payload.cnt || 0;
                // max retry is defined, and max retry is reached, do not add the payload to buffer
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(_maxRetryCnt)) {
                    if (payload.cnt > _maxRetryCnt) {
                        // TODO: add log here on dropping payloads
                        // will log statsbeat exception later here
                        return;
                    }
                }
                _buffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](payload);
                return;
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_COUNT"] /* @min:%2ecount */ ] = function() {
                return _buffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
            };
            _self.size = function() {
                var size = _buffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
                for(var lp = 0; lp < _buffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; lp++){
                    size += _buffer[lp].item[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
                }
                if (!config[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_EMIT_LINE_DELIMITED_0"] /* @min:%2eemitLineDelimitedJson */ ]) {
                    size += 2;
                }
                return size;
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CLEAR"] /* @min:%2eclear */ ] = function() {
                _buffer = [];
                _bufferFullMessageSent = false;
            };
            _self.getItems = function() {
                return _buffer.slice(0);
            };
            _self.batchPayloads = function(payloads) {
                if (payloads && payloads[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                    var payloadStr_1 = [];
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(payloads, function(payload) {
                        payloadStr_1[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](payload.item);
                    });
                    var batch = config[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_EMIT_LINE_DELIMITED_0"] /* @min:%2eemitLineDelimitedJson */ ] ? payloadStr_1.join("\n") : "[" + payloadStr_1.join(",") + "]";
                    return batch;
                }
                return null;
            };
            _self.createNew = function(newLogger, newConfig, canUseSessionStorage) {
                var items = _buffer.slice(0);
                newLogger = newLogger || logger;
                newConfig = newConfig || {};
                var newBuffer = !!canUseSessionStorage ? new SessionStorageSendBuffer(newLogger, newConfig) : new ArraySendBuffer(newLogger, newConfig);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(items, function(payload) {
                    newBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENQUEUE"] /* @min:%2eenqueue */ ](payload);
                });
                return newBuffer;
            };
        });
    }
    // Removed Stub for BaseSendBuffer.prototype.enqueue.
    // Removed Stub for BaseSendBuffer.prototype.count.
    // Removed Stub for BaseSendBuffer.prototype.size.
    // Removed Stub for BaseSendBuffer.prototype.clear.
    // Removed Stub for BaseSendBuffer.prototype.getItems.
    // Removed Stub for BaseSendBuffer.prototype.batchPayloads.
    // Removed Stub for BaseSendBuffer.prototype.createNew.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    BaseSendBuffer.__ieDyn = 1;
    return BaseSendBuffer;
}();
/*
 * An array based send buffer.
 */ var ArraySendBuffer = function(_super) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__extendsFn"])(ArraySendBuffer, _super);
    function ArraySendBuffer(logger, config) {
        var _this = _super.call(this, logger, config) || this;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ArraySendBuffer, _this, function(_self, _base) {
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MARK_AS_SENT"] /* @min:%2emarkAsSent */ ] = function(payload) {
                _base[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CLEAR"] /* @min:%2eclear */ ]();
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CLEAR_SENT"] /* @min:%2eclearSent */ ] = function(payload) {
            // not supported
            };
        });
        return _this;
    }
    // Removed Stub for ArraySendBuffer.prototype.markAsSent.
    // Removed Stub for ArraySendBuffer.prototype.clearSent.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    ArraySendBuffer.__ieDyn = 1;
    return ArraySendBuffer;
}(BaseSendBuffer);
;
var PREVIOUS_KEYS = [
    "AI_buffer",
    "AI_sentBuffer"
];
/*
 * Session storage buffer holds a copy of all unsent items in the browser session storage.
 */ var SessionStorageSendBuffer = function(_super) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__extendsFn"])(SessionStorageSendBuffer, _super);
    function SessionStorageSendBuffer(logger, config) {
        var _this = _super.call(this, logger, config) || this;
        var _bufferFullMessageSent = false;
        //Note: should not use config.namePrefix directly, because it will always refers to the latest namePrefix
        var _namePrefix = config === null || config === void 0 ? void 0 : config.namePrefix;
        // TODO: add remove buffer override as well
        var _b = config[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_BUFFER_OVERRIDE"] /* @min:%2ebufferOverride */ ] || {
            getItem: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlGetSessionStorage"],
            setItem: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlSetSessionStorage"]
        }, getItem = _b.getItem, setItem = _b.setItem;
        var _maxRetryCnt = config.maxRetryCnt;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(SessionStorageSendBuffer, _this, function(_self, _base) {
            var bufferItems = _getBuffer(SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__BUFFER__KEY"] /* @min:%2eBUFFER_KEY */ ]);
            var itemsInSentBuffer = _getBuffer(SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__SENT__BUFFER__KEY"] /* @min:%2eSENT_BUFFER_KEY */ ]);
            var previousItems = _getPreviousEvents();
            var notDeliveredItems = itemsInSentBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONCAT"] /* @min:%2econcat */ ](previousItems);
            var buffer = _self._set(bufferItems[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONCAT"] /* @min:%2econcat */ ](notDeliveredItems));
            // If the buffer has too many items, drop items from the end.
            if (buffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__MAX__BUFFER__SIZE"] /* @min:%2eMAX_BUFFER_SIZE */ ]) {
                buffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] = SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__MAX__BUFFER__SIZE"] /* @min:%2eMAX_BUFFER_SIZE */ ];
            }
            _setBuffer(SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__SENT__BUFFER__KEY"] /* @min:%2eSENT_BUFFER_KEY */ ], []);
            _setBuffer(SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__BUFFER__KEY"] /* @min:%2eBUFFER_KEY */ ], buffer);
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENQUEUE"] /* @min:%2eenqueue */ ] = function(payload) {
                if (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_COUNT"] /* @min:%2ecount */ ]() >= SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__MAX__BUFFER__SIZE"] /* @min:%2eMAX_BUFFER_SIZE */ ]) {
                    // sent internal log only once per page view
                    if (!_bufferFullMessageSent) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 2 /* eLoggingSeverity.WARNING */ , 67 /* _eInternalMessageId.SessionStorageBufferFull */ , "Maximum buffer size reached: " + _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_COUNT"] /* @min:%2ecount */ ](), true);
                        _bufferFullMessageSent = true;
                    }
                    return;
                }
                payload.cnt = payload.cnt || 0;
                // max retry is defined, and max retry is reached, do not add the payload to buffer
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(_maxRetryCnt)) {
                    if (payload.cnt > _maxRetryCnt) {
                        // TODO: add log here on dropping payloads
                        return;
                    }
                }
                _base[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENQUEUE"] /* @min:%2eenqueue */ ](payload);
                _setBuffer(SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__BUFFER__KEY"] /* @min:%2eBUFFER_KEY */ ], _self._get());
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CLEAR"] /* @min:%2eclear */ ] = function() {
                _base[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CLEAR"] /* @min:%2eclear */ ]();
                _setBuffer(SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__BUFFER__KEY"] /* @min:%2eBUFFER_KEY */ ], _self._get());
                _setBuffer(SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__SENT__BUFFER__KEY"] /* @min:%2eSENT_BUFFER_KEY */ ], []);
                _bufferFullMessageSent = false;
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MARK_AS_SENT"] /* @min:%2emarkAsSent */ ] = function(payload) {
                _setBuffer(SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__BUFFER__KEY"] /* @min:%2eBUFFER_KEY */ ], _self._set(_removePayloadsFromBuffer(payload, _self._get())));
                var sentElements = _getBuffer(SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__SENT__BUFFER__KEY"] /* @min:%2eSENT_BUFFER_KEY */ ]);
                if (sentElements instanceof Array && payload instanceof Array) {
                    sentElements = sentElements[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONCAT"] /* @min:%2econcat */ ](payload);
                    if (sentElements[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__MAX__BUFFER__SIZE"] /* @min:%2eMAX_BUFFER_SIZE */ ]) {
                        // We send telemetry normally. If the SENT_BUFFER is too big we don't add new elements
                        // until we receive a response from the backend and the buffer has free space again (see clearSent method)
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 1 /* eLoggingSeverity.CRITICAL */ , 67 /* _eInternalMessageId.SessionStorageBufferFull */ , "Sent buffer reached its maximum size: " + sentElements[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ], true);
                        sentElements[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] = SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__MAX__BUFFER__SIZE"] /* @min:%2eMAX_BUFFER_SIZE */ ];
                    }
                    _setBuffer(SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__SENT__BUFFER__KEY"] /* @min:%2eSENT_BUFFER_KEY */ ], sentElements);
                }
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CLEAR_SENT"] /* @min:%2eclearSent */ ] = function(payload) {
                var sentElements = _getBuffer(SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__SENT__BUFFER__KEY"] /* @min:%2eSENT_BUFFER_KEY */ ]);
                sentElements = _removePayloadsFromBuffer(payload, sentElements);
                _setBuffer(SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__SENT__BUFFER__KEY"] /* @min:%2eSENT_BUFFER_KEY */ ], sentElements);
            };
            _self.createNew = function(newLogger, newConfig, canUseSessionStorage) {
                canUseSessionStorage = !!canUseSessionStorage;
                var unsentItems = _self._get().slice(0);
                var sentItems = _getBuffer(SessionStorageSendBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__SENT__BUFFER__KEY"] /* @min:%2eSENT_BUFFER_KEY */ ]).slice(0);
                newLogger = newLogger || logger;
                newConfig = newConfig || {};
                // to make sure that we do not send duplicated payloads when it is switched back to previous one
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CLEAR"] /* @min:%2eclear */ ]();
                var newBuffer = canUseSessionStorage ? new SessionStorageSendBuffer(newLogger, newConfig) : new ArraySendBuffer(newLogger, newConfig);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(unsentItems, function(payload) {
                    newBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENQUEUE"] /* @min:%2eenqueue */ ](payload);
                });
                if (canUseSessionStorage) {
                    // arr buffer will clear all payloads if markAsSent() is called
                    newBuffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MARK_AS_SENT"] /* @min:%2emarkAsSent */ ](sentItems);
                }
                return newBuffer;
            };
            function _removePayloadsFromBuffer(payloads, buffer) {
                var remaining = [];
                var payloadStr = [];
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(payloads, function(payload) {
                    payloadStr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](payload.item);
                });
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(buffer, function(value) {
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(value) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrIndexOf"])(payloadStr, value.item) === -1) {
                        remaining[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](value);
                    }
                });
                return remaining;
            }
            function _getBuffer(key) {
                var prefixedKey = key;
                prefixedKey = _namePrefix ? _namePrefix + "_" + prefixedKey : prefixedKey;
                return _getBufferBase(prefixedKey);
            }
            function _getBufferBase(key) {
                try {
                    var bufferJson = getItem(logger, key);
                    if (bufferJson) {
                        var buffer_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getJSON"])().parse(bufferJson);
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(buffer_1)) {
                            // When using some version prototype.js the stringify / parse cycle does not decode array's correctly
                            buffer_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getJSON"])().parse(buffer_1);
                        }
                        if (buffer_1 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(buffer_1)) {
                            return buffer_1;
                        }
                    }
                } catch (e) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 1 /* eLoggingSeverity.CRITICAL */ , 42 /* _eInternalMessageId.FailedToRestoreStorageBuffer */ , " storage key: " + key + ", " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                        exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                    });
                }
                return [];
            }
            function _setBuffer(key, buffer) {
                var prefixedKey = key;
                try {
                    prefixedKey = _namePrefix ? _namePrefix + "_" + prefixedKey : prefixedKey;
                    var bufferJson = JSON[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STRINGIFY"] /* @min:%2estringify */ ](buffer);
                    setItem(logger, prefixedKey, bufferJson);
                } catch (e) {
                    // if there was an error, clear the buffer
                    // telemetry is stored in the _buffer array so we won't loose any items
                    setItem(logger, prefixedKey, JSON[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STRINGIFY"] /* @min:%2estringify */ ]([]));
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 2 /* eLoggingSeverity.WARNING */ , 41 /* _eInternalMessageId.FailedToSetStorageBuffer */ , " storage key: " + prefixedKey + ", " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e) + ". Buffer cleared", {
                        exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                    });
                }
            }
            // this removes buffer with prefix+key
            function _getPreviousEvents() {
                var items = [];
                try {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(PREVIOUS_KEYS, function(key) {
                        var events = _getItemsFromPreviousKey(key);
                        items = items[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONCAT"] /* @min:%2econcat */ ](events);
                        // to make sure that we also transfer items from old prefixed + key buffer
                        if (_namePrefix) {
                            var prefixedKey = _namePrefix + "_" + key;
                            var prefixEvents = _getItemsFromPreviousKey(prefixedKey);
                            items = items[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONCAT"] /* @min:%2econcat */ ](prefixEvents);
                        }
                    });
                    return items;
                } catch (e) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 2 /* eLoggingSeverity.WARNING */ , 41 /* _eInternalMessageId.FailedToSetStorageBuffer */ , "Transfer events from previous buffers: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e) + ". previous Buffer items can not be removed", {
                        exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                    });
                }
                return [];
            }
            // transform string[] to IInternalStorageItem[]
            function _getItemsFromPreviousKey(key) {
                try {
                    var items = _getBufferBase(key);
                    var transFormedItems_1 = [];
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(items, function(item) {
                        var internalItem = {
                            item: item,
                            cnt: 0 // previous events will be default to 0 count
                        };
                        transFormedItems_1[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](internalItem);
                    });
                    // remove the session storage if we can add events back
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlRemoveSessionStorage"])(logger, key);
                    return transFormedItems_1;
                } catch (e) {
                // eslint-disable-next-line no-empty
                }
                return [];
            }
        });
        return _this;
    }
    // Removed Stub for SessionStorageSendBuffer.prototype.enqueue.
    // Removed Stub for SessionStorageSendBuffer.prototype.clear.
    // Removed Stub for SessionStorageSendBuffer.prototype.markAsSent.
    // Removed Stub for SessionStorageSendBuffer.prototype.clearSent.
    // Removed Stub for SessionStorageSendBuffer.prototype.createNew.
    var _a;
    _a = SessionStorageSendBuffer;
    SessionStorageSendBuffer.VERSION = "_1";
    SessionStorageSendBuffer.BUFFER_KEY = "AI_buffer" + _a.VERSION;
    SessionStorageSendBuffer.SENT_BUFFER_KEY = "AI_sentBuffer" + _a.VERSION;
    // Maximum number of payloads stored in the buffer. If the buffer is full, new elements will be dropped.
    SessionStorageSendBuffer.MAX_BUFFER_SIZE = 2000;
    return SessionStorageSendBuffer;
}(BaseSendBuffer);
;
 //# sourceMappingURL=SendBuffer.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/Serializer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Channel, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "Serializer",
    ()=>Serializer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EnvUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
;
;
var Serializer = function() {
    function Serializer(logger) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(Serializer, this, function(_self) {
            /**
             * Serializes the current object to a JSON string.
             */ _self.serialize = function(input) {
                var output = _serializeObject(input, "root");
                try {
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getJSON"])()[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STRINGIFY"] /* @min:%2estringify */ ](output);
                } catch (e) {
                    // if serialization fails return an empty string
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 1 /* eLoggingSeverity.CRITICAL */ , 48 /* _eInternalMessageId.CannotSerializeObject */ , e && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(e[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_STRING"] /* @min:%2etoString */ ]) ? e[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_STRING"] /* @min:%2etoString */ ]() : "Error serializing object", null, true);
                }
            };
            function _serializeObject(source, name) {
                var circularReferenceCheck = "__aiCircularRefCheck";
                var output = {};
                if (!source) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 1 /* eLoggingSeverity.CRITICAL */ , 48 /* _eInternalMessageId.CannotSerializeObject */ , "cannot serialize object because it is null or undefined", {
                        name: name
                    }, true);
                    return output;
                }
                if (source[circularReferenceCheck]) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 2 /* eLoggingSeverity.WARNING */ , 50 /* _eInternalMessageId.CircularReferenceDetected */ , "Circular reference detected while serializing object", {
                        name: name
                    }, true);
                    return output;
                }
                if (!source.aiDataContract) {
                    // special case for measurements/properties/tags
                    if (name === "measurements") {
                        output = _serializeStringMap(source, "number", name);
                    } else if (name === "properties") {
                        output = _serializeStringMap(source, "string", name);
                    } else if (name === "tags") {
                        output = _serializeStringMap(source, "string", name);
                    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(source)) {
                        output = _serializeArray(source, name);
                    } else {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 2 /* eLoggingSeverity.WARNING */ , 49 /* _eInternalMessageId.CannotSerializeObjectNonSerializable */ , "Attempting to serialize an object which does not implement ISerializable", {
                            name: name
                        }, true);
                        try {
                            // verify that the object can be stringified
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getJSON"])()[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STRINGIFY"] /* @min:%2estringify */ ](source);
                            output = source;
                        } catch (e) {
                            // if serialization fails return an empty string
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 1 /* eLoggingSeverity.CRITICAL */ , 48 /* _eInternalMessageId.CannotSerializeObject */ , e && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(e[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_STRING"] /* @min:%2etoString */ ]) ? e[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_STRING"] /* @min:%2etoString */ ]() : "Error serializing object", null, true);
                        }
                    }
                    return output;
                }
                source[circularReferenceCheck] = true;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(source.aiDataContract, function(field, contract) {
                    var isRequired = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(contract) ? contract() & 1 /* FieldType.Required */  : contract & 1 /* FieldType.Required */ ;
                    var isHidden = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(contract) ? contract() & 4 /* FieldType.Hidden */  : contract & 4 /* FieldType.Hidden */ ;
                    var isArray = contract & 2 /* FieldType.Array */ ;
                    var isPresent = source[field] !== undefined;
                    var isObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(source[field]) && source[field] !== null;
                    if (isRequired && !isPresent && !isArray) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 1 /* eLoggingSeverity.CRITICAL */ , 24 /* _eInternalMessageId.MissingRequiredFieldSpecification */ , "Missing required field specification. The field is required but not present on source", {
                            field: field,
                            name: name
                        });
                    // If not in debug mode, continue and hope the error is permissible
                    } else if (!isHidden) {
                        var value = void 0;
                        if (isObj) {
                            if (isArray) {
                                // special case; recurse on each object in the source array
                                value = _serializeArray(source[field], field);
                            } else {
                                // recurse on the source object in this field
                                value = _serializeObject(source[field], field);
                            }
                        } else {
                            // assign the source field to the output even if undefined or required
                            value = source[field];
                        }
                        // only emit this field if the value is defined
                        if (value !== undefined) {
                            output[field] = value;
                        }
                    }
                });
                delete source[circularReferenceCheck];
                return output;
            }
            function _serializeArray(sources, name) {
                var output;
                if (!!sources) {
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(sources)) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 1 /* eLoggingSeverity.CRITICAL */ , 54 /* _eInternalMessageId.ItemNotInArray */ , "This field was specified as an array in the contract but the item is not an array.\r\n", {
                            name: name
                        }, true);
                    } else {
                        output = [];
                        for(var i = 0; i < sources[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; i++){
                            var source = sources[i];
                            var item = _serializeObject(source, name + "[" + i + "]");
                            output[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](item);
                        }
                    }
                }
                return output;
            }
            function _serializeStringMap(map, expectedType, name) {
                var output;
                if (map) {
                    output = {};
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(map, function(field, value) {
                        if (expectedType === "string") {
                            if (value === undefined) {
                                output[field] = "undefined";
                            } else if (value === null) {
                                output[field] = "null";
                            } else if (!value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_STRING"] /* @min:%2etoString */ ]) {
                                output[field] = "invalid field: toString() is not defined.";
                            } else {
                                output[field] = value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_STRING"] /* @min:%2etoString */ ]();
                            }
                        } else if (expectedType === "number") {
                            if (value === undefined) {
                                output[field] = "undefined";
                            } else if (value === null) {
                                output[field] = "null";
                            } else {
                                var num = parseFloat(value);
                                output[field] = num;
                            }
                        } else {
                            output[field] = "invalid field: " + name + " is of unknown type.";
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 1 /* eLoggingSeverity.CRITICAL */ , output[field], null, true);
                        }
                    });
                }
                return output;
            }
        });
    }
    // Removed Stub for Serializer.prototype.serialize.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    Serializer.__ieDyn = 1;
    return Serializer;
}();
;
 //# sourceMappingURL=Serializer.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/TelemetryProcessors/SamplingScoreGenerators/HashCodeScoreGenerator.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Channel, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "HashCodeScoreGenerator",
    ()=>HashCodeScoreGenerator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
// (Magic number) DJB algorithm can't work on shorter strings (results in poor distribution
var MIN_INPUT_LENGTH = 8;
var HashCodeScoreGenerator = function() {
    function HashCodeScoreGenerator() {}
    HashCodeScoreGenerator.prototype.getHashCodeScore = function(key) {
        var score = this.getHashCode(key) / HashCodeScoreGenerator.INT_MAX_VALUE;
        return score * 100;
    };
    HashCodeScoreGenerator.prototype.getHashCode = function(input) {
        if (input === "") {
            return 0;
        }
        while(input[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] < MIN_INPUT_LENGTH){
            input = input[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONCAT"] /* @min:%2econcat */ ](input);
        }
        // 5381 is a magic number: http://stackoverflow.com/questions/10696223/reason-for-5381-number-in-djb-hash-function
        var hash = 5381;
        for(var i = 0; i < input[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; ++i){
            hash = (hash << 5) + hash + input.charCodeAt(i);
            // 'hash' is of number type which means 53 bit integer (http://www.ecma-international.org/ecma-262/6.0/#sec-ecmascript-language-types-number-type)
            // 'hash & hash' will keep it 32 bit integer - just to make it clearer what the result is.
            hash = hash & hash;
        }
        return Math.abs(hash);
    };
    // We're using 32 bit math, hence max value is (2^31 - 1)
    HashCodeScoreGenerator.INT_MAX_VALUE = 2147483647;
    return HashCodeScoreGenerator;
}();
;
 //# sourceMappingURL=HashCodeScoreGenerator.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/TelemetryProcessors/SamplingScoreGenerators/SamplingScoreGenerator.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Channel, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "SamplingScoreGenerator",
    ()=>SamplingScoreGenerator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$Contracts$2f$ContextTagKeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Interfaces/Contracts/ContextTagKeys.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$TelemetryProcessors$2f$SamplingScoreGenerators$2f$HashCodeScoreGenerator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/TelemetryProcessors/SamplingScoreGenerators/HashCodeScoreGenerator.js [app-client] (ecmascript)");
;
;
;
var SamplingScoreGenerator = function() {
    function SamplingScoreGenerator() {
        var _self = this;
        var hashCodeGenerator = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$TelemetryProcessors$2f$SamplingScoreGenerators$2f$HashCodeScoreGenerator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HashCodeScoreGenerator"]();
        var keys = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$Contracts$2f$ContextTagKeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContextTagKeys"]();
        _self.getSamplingScore = function(item) {
            var score = 0;
            if (item[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ] && item[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ][keys.userId]) {
                score = hashCodeGenerator.getHashCodeScore(item[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ][keys.userId]);
            } else if (item.ext && item.ext.user && item.ext.user.id) {
                score = hashCodeGenerator[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_HASH_CODE_SCORE"] /* @min:%2egetHashCodeScore */ ](item.ext.user.id);
            } else if (item[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ] && item[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ][keys.operationId]) {
                score = hashCodeGenerator.getHashCodeScore(item[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ][keys.operationId]);
            } else if (item.ext && item.ext.telemetryTrace && item.ext.telemetryTrace[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_ID"] /* @min:%2etraceID */ ]) {
                score = hashCodeGenerator.getHashCodeScore(item.ext.telemetryTrace[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_ID"] /* @min:%2etraceID */ ]);
            } else {
                // tslint:disable-next-line:insecure-random
                score = Math.random() * 100;
            }
            return score;
        };
    }
    return SamplingScoreGenerator;
}();
;
 //# sourceMappingURL=SamplingScoreGenerator.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/TelemetryProcessors/Sample.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Channel, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "Sample",
    ()=>Sample
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Metric$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Metric.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$TelemetryProcessors$2f$SamplingScoreGenerators$2f$SamplingScoreGenerator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/TelemetryProcessors/SamplingScoreGenerators/SamplingScoreGenerator.js [app-client] (ecmascript)");
;
;
;
;
var Sample = function() {
    function Sample(sampleRate, logger) {
        // We're using 32 bit math, hence max value is (2^31 - 1)
        this.INT_MAX_VALUE = 2147483647;
        var _logger = logger || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeGetLogger"])(null);
        if (sampleRate > 100 || sampleRate < 0) {
            _logger.throwInternal(2 /* eLoggingSeverity.WARNING */ , 58 /* _eInternalMessageId.SampleRateOutOfRange */ , "Sampling rate is out of range (0..100). Sampling will be disabled, you may be sending too much data which may affect your AI service level.", {
                samplingRate: sampleRate
            }, true);
            sampleRate = 100;
        }
        this[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SAMPLE_RATE"] /* @min:%2esampleRate */ ] = sampleRate;
        this.samplingScoreGenerator = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$TelemetryProcessors$2f$SamplingScoreGenerators$2f$SamplingScoreGenerator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SamplingScoreGenerator"]();
    }
    /**
    * Determines if an envelope is sampled in (i.e. will be sent) or not (i.e. will be dropped).
    */ Sample.prototype.isSampledIn = function(envelope) {
        var samplingPercentage = this[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SAMPLE_RATE"] /* @min:%2esampleRate */ ]; // 0 - 100
        var isSampledIn = false;
        if (samplingPercentage === null || samplingPercentage === undefined || samplingPercentage >= 100) {
            return true;
        } else if (envelope.baseType === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Metric$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metric"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ]) {
            // exclude MetricData telemetry from sampling
            return true;
        }
        isSampledIn = this.samplingScoreGenerator.getSamplingScore(envelope) < samplingPercentage;
        return isSampledIn;
    };
    return Sample;
}();
;
 //# sourceMappingURL=Sample.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/Sender.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Channel, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "Sender",
    ()=>Sender
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-shims@3.0.1/node_modules/@microsoft/applicationinsights-shims/dist-es5/TsLibShims.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$applicationinsights$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/applicationinsights-common.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Event.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Exception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Exception.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Metric$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Metric.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/PageView.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageViewPerformance$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/PageViewPerformance.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$RemoteDependencyData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/RemoteDependencyData.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/RequestResponseHeaders.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Trace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Trace.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Offline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Offline.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/StorageHelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2e$Enums$2f$InitActiveStatusEnum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK.Enums/InitActiveStatusEnum.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$BaseTelemetryPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/BaseTelemetryPlugin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$SenderPostManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/SenderPostManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/ConfigDefaultHelpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/ProcessTelemetryContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DataCacheHelper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__utcNow__as__dateNow$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript) <export utcNow as dateNow>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EnvUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EventHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EventHelpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicConfig.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ResponseHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/ResponseHelpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$AsyncUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/AsyncUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-async@0.5.4/node_modules/@nevware21/ts-async/dist/es5/mod/ts-async.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$EnvelopeCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/EnvelopeCreator.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$SendBuffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/SendBuffer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$Serializer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/Serializer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$TelemetryProcessors$2f$Sample$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/TelemetryProcessors/Sample.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-channel-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-channel-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var _a, _b;
;
;
;
;
;
;
;
;
;
;
;
var UNDEFINED_VALUE = undefined;
var EMPTY_STR = "";
var FetchSyncRequestSizeLimitBytes = 65000; // approx 64kb (the current Edge, Firefox and Chrome max limit)
function _getResponseText(xhr) {
    try {
        return xhr.responseText;
    } catch (e) {
    // Best effort, as XHR may throw while XDR wont so just ignore
    }
    return null;
}
function isOverrideFn(httpXHROverride) {
    return httpXHROverride && httpXHROverride.sendPOST;
}
var defaultAppInsightsChannelConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDeepFreeze"])((_a = {
    // Use the default value (handles empty string in the configuration)
    endpointUrl: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfValidate"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTruthy"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_BREEZE_ENDPOINT"] + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_BREEZE_PATH"])
}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_EMIT_LINE_DELIMITED_0"] /* @min:emitLineDelimitedJson */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(), _a.maxBatchInterval = 15000, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MAX_BATCH_SIZE_IN_BY1"] /* @min:maxBatchSizeInBytes */ ] = 102400, _a.disableTelemetry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLE_SESSION_STORA5"] /* @min:enableSessionStorageBuffer */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(true), _a.isRetryDisabled = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_BEACON_API_DISABL3"] /* @min:isBeaconApiDisabled */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(true), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DISABLE_SEND_BEACON_7"] /* @min:disableSendBeaconSplit */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(true), _a.disableXhr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ONUNLOAD_DISABLE_FET6"] /* @min:onunloadDisableFetch */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ONUNLOAD_DISABLE_BEA2"] /* @min:onunloadDisableBeacon */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INSTRUMENTATION_KEY"] /* @min:instrumentationKey */ ] = UNDEFINED_VALUE, _a.namePrefix = UNDEFINED_VALUE, _a.samplingPercentage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfValidate"])(_chkSampling, 100), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CUSTOM_HEADERS"] /* @min:customHeaders */ ] = UNDEFINED_VALUE, _a.convertUndefined = UNDEFINED_VALUE, _a.eventsLimitInMem = 10000, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_BUFFER_OVERRIDE"] /* @min:bufferOverride */ ] = false, _a.httpXHROverride = {
    isVal: isOverrideFn,
    v: UNDEFINED_VALUE
}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ALWAYS_USE_XHR_OVERR4"] /* @min:alwaysUseXhrOverride */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(), _a.transports = UNDEFINED_VALUE, _a.retryCodes = UNDEFINED_VALUE, _a.corsPolicy = UNDEFINED_VALUE, _a.maxRetryCnt = {
    isVal: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNumber"],
    v: 10
}, _a));
var CrossOriginResourcePolicyHeader = "X-Set-Cross-Origin-Resource-Policy";
function _chkSampling(value) {
    return !isNaN(value) && value > 0 && value <= 100;
}
var EnvelopeTypeCreator = (_b = {}, _b[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Event"].dataType] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$EnvelopeCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EventEnvelopeCreator"], _b[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Trace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trace"].dataType] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$EnvelopeCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TraceEnvelopeCreator"], _b[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageView"].dataType] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$EnvelopeCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageViewEnvelopeCreator"], _b[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageViewPerformance$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageViewPerformance"].dataType] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$EnvelopeCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageViewPerformanceEnvelopeCreator"], _b[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Exception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Exception"].dataType] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$EnvelopeCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ExceptionEnvelopeCreator"], _b[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Metric$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metric"].dataType] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$EnvelopeCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MetricEnvelopeCreator"], _b[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$RemoteDependencyData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RemoteDependencyData"].dataType] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$EnvelopeCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DependencyEnvelopeCreator"], _b);
var Sender = function(_super) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__extendsFn"])(Sender, _super);
    function Sender() {
        var _this = _super.call(this) || this;
        _this.priority = 1001;
        _this.identifier = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$applicationinsights$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["BreezeChannelIdentifier"];
        // Don't set the defaults here, set them in the _initDefaults() as this is also called during unload
        var _consecutiveErrors; // How many times in a row a retryable error condition has occurred.
        var _retryAt; // The time to retry at in milliseconds from 1970/01/01 (this makes the timer calculation easy).
        var _lastSend; // The time of the last send operation.
        var _paused; // Flag indicating that the sending should be paused
        var _timeoutHandle; // Handle to the timer for delayed sending of batches of data.
        var _serializer;
        var _stamp_specific_redirects;
        var _headers;
        var _syncFetchPayload = 0; // Keep track of the outstanding sync fetch payload total (as sync fetch has limits)
        var _syncUnloadSender; // The identified sender to use for the synchronous unload stage
        var _offlineListener;
        var _evtNamespace;
        var _endpointUrl;
        var _orgEndpointUrl;
        var _maxBatchSizeInBytes;
        var _beaconSupported;
        var _beaconOnUnloadSupported;
        var _beaconNormalSupported;
        var _customHeaders;
        var _disableTelemetry;
        var _instrumentationKey;
        var _convertUndefined;
        var _isRetryDisabled;
        var _maxBatchInterval;
        var _sessionStorageUsed;
        var _bufferOverrideUsed;
        var _namePrefix;
        var _enableSendPromise;
        var _alwaysUseCustomSend;
        var _disableXhr;
        var _fetchKeepAlive;
        var _xhrSend;
        var _fallbackSend;
        var _disableBeaconSplit;
        var _sendPostMgr;
        var _retryCodes;
        var _zipPayload;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(Sender, _this, function(_self, _base) {
            _initDefaults();
            _self.pause = function() {
                _clearScheduledTimer();
                _paused = true;
            };
            _self.resume = function() {
                if (_paused) {
                    _paused = false;
                    _retryAt = null;
                    // flush if we have exceeded the max-size already
                    _checkMaxSize();
                    _setupTimer();
                }
            };
            _self.flush = function(isAsync, callBack, sendReason) {
                if (isAsync === void 0) {
                    isAsync = true;
                }
                if (!_paused) {
                    // Clear the normal schedule timer as we are going to try and flush ASAP
                    _clearScheduledTimer();
                    try {
                        var result_1 = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRIGGER_SEND"] /* @min:%2etriggerSend */ ](isAsync, null, sendReason || 1 /* SendRequestReason.ManualFlush */ );
                        // Handles non-promise and always called if the returned promise resolves or rejects
                        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doAwaitResponse"])(result_1, function(rsp) {
                            if (callBack) {
                                callBack(!rsp.rejected);
                                return true;
                            }
                            // When async=true and no callback, return a promise
                            if (isAsync) {
                                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPromise"])(function(resolve) {
                                    resolve(!rsp.rejected);
                                });
                            }
                            return result_1;
                        });
                    } catch (e) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), 1 /* eLoggingSeverity.CRITICAL */ , 22 /* _eInternalMessageId.FlushFailed */ , "flush failed, telemetry will not be collected: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                            exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                        });
                    }
                }
            };
            _self.onunloadFlush = function() {
                if (!_paused) {
                    if (_beaconSupported || _alwaysUseCustomSend) {
                        try {
                            return _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRIGGER_SEND"] /* @min:%2etriggerSend */ ](true, _doUnloadSend, 2 /* SendRequestReason.Unload */ );
                        } catch (e) {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), 1 /* eLoggingSeverity.CRITICAL */ , 20 /* _eInternalMessageId.FailedToSendQueuedTelemetry */ , "failed to flush with beacon sender on page unload, telemetry will not be collected: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                                exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                            });
                        }
                    } else {
                        _self.flush(false);
                    }
                }
            };
            _self.addHeader = function(name, value) {
                _headers[name] = value;
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INITIALIZE"] /* @min:%2einitialize */ ] = function(config, core, extensions, pluginChain) {
                if (_self.isInitialized()) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), 1 /* eLoggingSeverity.CRITICAL */ , 28 /* _eInternalMessageId.SenderNotInitialized */ , "Sender is already initialized");
                }
                _base[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INITIALIZE"] /* @min:%2einitialize */ ](config, core, extensions, pluginChain);
                var identifier = _self.identifier;
                _serializer = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$Serializer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Serializer"](core.logger);
                _consecutiveErrors = 0;
                _retryAt = null;
                _lastSend = 0;
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__SENDER"] /* @min:%2e_sender */ ] = null;
                _stamp_specific_redirects = 0;
                var diagLog = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ]();
                _evtNamespace = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EventHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeEvtNamespace"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUniqueNamespace"])("Sender"), core.evtNamespace && core.evtNamespace());
                _offlineListener = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Offline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createOfflineListener"])(_evtNamespace);
                // This function will be re-called whenever any referenced configuration is changed
                _self._addHook((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onConfigChange"])(config, function(details) {
                    var config = details.cfg;
                    if (config.storagePrefix) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlSetStoragePrefix"])(config.storagePrefix);
                    }
                    var ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProcessTelemetryContext"])(null, config, core);
                    // getExtCfg only finds undefined values from core
                    var senderConfig = ctx.getExtCfg(identifier, defaultAppInsightsChannelConfig);
                    var curExtUrl = senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENDPOINT_URL"] /* @min:%2eendpointUrl */ ];
                    // if it is not inital change (_endpointUrl has value)
                    // if current sender endpoint url is not changed directly
                    // means ExtCfg is not changed directly
                    // then we need to monitor endpoint url changes from core
                    if (_endpointUrl && curExtUrl === _endpointUrl) {
                        var coreUrl = config[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENDPOINT_URL"] /* @min:%2eendpointUrl */ ];
                        // if core endpoint url is changed
                        if (coreUrl && coreUrl !== curExtUrl) {
                            // and endpoint promise changes is handled by this as well
                            senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENDPOINT_URL"] /* @min:%2eendpointUrl */ ] = coreUrl;
                        }
                    }
                    var csStream = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInst"])("CompressionStream");
                    // Determine whether to enable payload compression (zipping).
                    _zipPayload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFeatureEnabled"])("zipPayload", config, false);
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(csStream)) {
                        _zipPayload = false;
                    }
                    var corsPolicy = senderConfig.corsPolicy;
                    if (corsPolicy) {
                        if (corsPolicy === "same-origin" || corsPolicy === "same-site" || corsPolicy === "cross-origin") {
                            _this.addHeader(CrossOriginResourcePolicyHeader, corsPolicy);
                        }
                    } else {
                        delete _headers[CrossOriginResourcePolicyHeader];
                    }
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPromiseLike"])(senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INSTRUMENTATION_KEY"] /* @min:%2einstrumentationKey */ ])) {
                        // if it is promise, means the endpoint url is from core.endpointurl
                        senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INSTRUMENTATION_KEY"] /* @min:%2einstrumentationKey */ ] = config[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INSTRUMENTATION_KEY"] /* @min:%2einstrumentationKey */ ];
                    }
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "_senderConfig", {
                        g: function() {
                            return senderConfig;
                        }
                    });
                    // Only update the endpoint if the original config !== the current config
                    // This is so any redirect endpointUrl is not overwritten
                    if (_orgEndpointUrl !== senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENDPOINT_URL"] /* @min:%2eendpointUrl */ ]) {
                        if (_orgEndpointUrl) {
                        // TODO: add doc to remind users to flush before changing endpoint, otherwise all unsent payload will be sent to new endpoint
                        }
                        _endpointUrl = _orgEndpointUrl = senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENDPOINT_URL"] /* @min:%2eendpointUrl */ ];
                    }
                    // or is not string
                    if (core.activeStatus() === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2e$Enums$2f$InitActiveStatusEnum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActiveStatus"].PENDING) {
                        // waiting for core promises to be resolved
                        // NOTE: if active status is set to pending, stop sending, clear timer here
                        _self.pause();
                    } else if (core.activeStatus() === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2e$Enums$2f$InitActiveStatusEnum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActiveStatus"].ACTIVE) {
                        // core status changed from pending to other status
                        _self.resume();
                    }
                    if (_customHeaders && _customHeaders !== senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CUSTOM_HEADERS"] /* @min:%2ecustomHeaders */ ]) {
                        // Removing any previously defined custom headers as they have changed
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(_customHeaders, function(customHeader) {
                            delete _headers[customHeader.header];
                        });
                    }
                    _maxBatchSizeInBytes = senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MAX_BATCH_SIZE_IN_BY1"] /* @min:%2emaxBatchSizeInBytes */ ];
                    _beaconSupported = (senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ONUNLOAD_DISABLE_BEA2"] /* @min:%2eonunloadDisableBeacon */ ] === false || senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_BEACON_API_DISABL3"] /* @min:%2eisBeaconApiDisabled */ ] === false) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isBeaconsSupported"])();
                    _beaconOnUnloadSupported = senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ONUNLOAD_DISABLE_BEA2"] /* @min:%2eonunloadDisableBeacon */ ] === false && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isBeaconsSupported"])();
                    _beaconNormalSupported = senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_BEACON_API_DISABL3"] /* @min:%2eisBeaconApiDisabled */ ] === false && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isBeaconsSupported"])();
                    _alwaysUseCustomSend = senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ALWAYS_USE_XHR_OVERR4"] /* @min:%2ealwaysUseXhrOverride */ ];
                    _disableXhr = !!senderConfig.disableXhr;
                    _retryCodes = senderConfig.retryCodes;
                    var bufferOverride = senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_BUFFER_OVERRIDE"] /* @min:%2ebufferOverride */ ];
                    var canUseSessionStorage = !!senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLE_SESSION_STORA5"] /* @min:%2eenableSessionStorageBuffer */ ] && (!!bufferOverride || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlCanUseSessionStorage"])());
                    var namePrefix = senderConfig.namePrefix;
                    //Note: emitLineDelimitedJson and eventsLimitInMem is directly accessed via config in senderBuffer
                    //Therefore, if canUseSessionStorage is not changed, we do not need to re initialize a new one
                    var shouldUpdate = canUseSessionStorage !== _sessionStorageUsed || canUseSessionStorage && _namePrefix !== namePrefix || canUseSessionStorage && _bufferOverrideUsed !== bufferOverride;
                    if (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__BUFFER"] /* @min:%2e_buffer */ ]) {
                        // case1 (Pre and Now enableSessionStorageBuffer settings are same)
                        // if namePrefix changes, transfer current buffer to new buffer
                        // else no action needed
                        //case2 (Pre and Now enableSessionStorageBuffer settings are changed)
                        // transfer current buffer to new buffer
                        if (shouldUpdate) {
                            try {
                                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__BUFFER"] /* @min:%2e_buffer */ ] = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__BUFFER"] /* @min:%2e_buffer */ ].createNew(diagLog, senderConfig, canUseSessionStorage);
                            } catch (e) {
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), 1 /* eLoggingSeverity.CRITICAL */ , 12 /* _eInternalMessageId.FailedAddingTelemetryToBuffer */ , "failed to transfer telemetry to different buffer storage, telemetry will be lost: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                                    exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                                });
                            }
                        }
                        _checkMaxSize();
                    } else {
                        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__BUFFER"] /* @min:%2e_buffer */ ] = canUseSessionStorage ? new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$SendBuffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SessionStorageSendBuffer"](diagLog, senderConfig) : new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$SendBuffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArraySendBuffer"](diagLog, senderConfig);
                    }
                    _namePrefix = namePrefix;
                    _sessionStorageUsed = canUseSessionStorage;
                    _bufferOverrideUsed = bufferOverride;
                    _fetchKeepAlive = !senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ONUNLOAD_DISABLE_FET6"] /* @min:%2eonunloadDisableFetch */ ] && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFetchSupported"])(true);
                    _disableBeaconSplit = !!senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DISABLE_SEND_BEACON_7"] /* @min:%2edisableSendBeaconSplit */ ];
                    _self._sample = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$TelemetryProcessors$2f$Sample$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Sample"](senderConfig.samplingPercentage, diagLog);
                    _instrumentationKey = senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INSTRUMENTATION_KEY"] /* @min:%2einstrumentationKey */ ];
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPromiseLike"])(_instrumentationKey) && !_validateInstrumentationKey(_instrumentationKey, config)) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(diagLog, 1 /* eLoggingSeverity.CRITICAL */ , 100 /* _eInternalMessageId.InvalidInstrumentationKey */ , "Invalid Instrumentation key " + _instrumentationKey);
                    }
                    _customHeaders = senderConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CUSTOM_HEADERS"] /* @min:%2ecustomHeaders */ ];
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(_endpointUrl) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInternalApplicationInsightsEndpoint"])(_endpointUrl) && _customHeaders && _customHeaders[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(_customHeaders, function(customHeader) {
                            _this.addHeader(customHeader.header, customHeader.value);
                        });
                    } else {
                        _customHeaders = null;
                    }
                    _enableSendPromise = senderConfig.enableSendPromise;
                    var sendPostConfig = _getSendPostMgrConfig();
                    // only init it once
                    if (!_sendPostMgr) {
                        _sendPostMgr = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$SenderPostManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SenderPostManager"]();
                        _sendPostMgr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INITIALIZE"] /* @min:%2einitialize */ ](sendPostConfig, diagLog);
                    } else {
                        _sendPostMgr.SetConfig(sendPostConfig);
                    }
                    var customInterface = senderConfig.httpXHROverride;
                    var httpInterface = null;
                    var syncInterface = null;
                    // User requested transport(s) values > Beacon > Fetch > XHR
                    // Beacon would be filtered out if user has set disableBeaconApi to true at _getSenderInterface
                    var theTransports = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prependTransports"])([
                        3 /* TransportType.Beacon */ ,
                        1 /* TransportType.Xhr */ ,
                        2 /* TransportType.Fetch */ 
                    ], senderConfig.transports);
                    httpInterface = _sendPostMgr && _sendPostMgr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_SENDER_INST"] /* @min:%2egetSenderInst */ ](theTransports, false);
                    var xhrInterface = _sendPostMgr && _sendPostMgr.getFallbackInst();
                    _xhrSend = function(payload, isAsync) {
                        return _doSend(xhrInterface, payload, isAsync);
                    };
                    _fallbackSend = function(payload, isAsync) {
                        return _doSend(xhrInterface, payload, isAsync, false);
                    };
                    httpInterface = _alwaysUseCustomSend ? customInterface : httpInterface || customInterface || xhrInterface;
                    _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__SENDER"] /* @min:%2e_sender */ ] = function(payload, isAsync) {
                        return _doSend(httpInterface, payload, isAsync);
                    };
                    if (_fetchKeepAlive) {
                        // Try and use the fetch with keepalive
                        _syncUnloadSender = _fetchKeepAliveSender;
                    }
                    var syncTransports = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prependTransports"])([
                        3 /* TransportType.Beacon */ ,
                        1 /* TransportType.Xhr */ 
                    ], senderConfig.unloadTransports);
                    if (!_fetchKeepAlive) {
                        // remove fetch from theTransports
                        syncTransports = syncTransports.filter(function(transport) {
                            return transport !== 2 /* TransportType.Fetch */ ;
                        });
                    }
                    syncInterface = _sendPostMgr && _sendPostMgr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_SENDER_INST"] /* @min:%2egetSenderInst */ ](syncTransports, true);
                    syncInterface = _alwaysUseCustomSend ? customInterface : syncInterface || customInterface;
                    if ((_alwaysUseCustomSend || senderConfig.unloadTransports || !_syncUnloadSender) && syncInterface) {
                        _syncUnloadSender = function(payload, isAsync) {
                            return _doSend(syncInterface, payload, isAsync);
                        };
                    }
                    if (!_syncUnloadSender) {
                        _syncUnloadSender = _xhrSend;
                    }
                    _disableTelemetry = senderConfig.disableTelemetry;
                    _convertUndefined = senderConfig.convertUndefined || UNDEFINED_VALUE;
                    _isRetryDisabled = senderConfig.isRetryDisabled;
                    _maxBatchInterval = senderConfig.maxBatchInterval;
                }));
            };
            _self.processTelemetry = function(telemetryItem, itemCtx) {
                itemCtx = _self._getTelCtx(itemCtx);
                var diagLogger = itemCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ]();
                try {
                    var isValidate = _validate(telemetryItem, diagLogger);
                    if (!isValidate) {
                        return;
                    }
                    var aiEnvelope = _getEnvelope(telemetryItem, diagLogger);
                    if (!aiEnvelope) {
                        return;
                    }
                    // check if the incoming payload is too large, truncate if necessary
                    var payload = _serializer.serialize(aiEnvelope);
                    // flush if we would exceed the max-size limit by adding this item
                    var buffer = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__BUFFER"] /* @min:%2e_buffer */ ];
                    _checkMaxSize(payload);
                    var payloadItem = {
                        item: payload,
                        cnt: 0 // inital cnt will always be 0
                    };
                    // enqueue the payload
                    buffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENQUEUE"] /* @min:%2eenqueue */ ](payloadItem);
                    // ensure an invocation timeout is set
                    _setupTimer();
                } catch (e) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(diagLogger, 2 /* eLoggingSeverity.WARNING */ , 12 /* _eInternalMessageId.FailedAddingTelemetryToBuffer */ , "Failed adding telemetry to the sender's buffer, some telemetry will be lost: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                        exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                    });
                }
                // hand off the telemetry item to the next plugin
                _self.processNext(telemetryItem, itemCtx);
            };
            _self.isCompletelyIdle = function() {
                return !_paused && _syncFetchPayload === 0 && _self._buffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_COUNT"] /* @min:%2ecount */ ]() === 0;
            };
            _self.getOfflineListener = function() {
                return _offlineListener;
            };
            /**
             * xhr state changes
             */ _self._xhrReadyStateChange = function(xhr, payload, countOfItemsInPayload) {
                // since version 3.2.0, this function is no-op
                if (_isStringArr(payload)) {
                    return;
                }
                return _xhrReadyStateChange(xhr, payload, countOfItemsInPayload);
            };
            /**
             * Immediately send buffered data
             * @param isAsync - Indicates if the events should be sent asynchronously
             * @param forcedSender - Indicates the forcedSender, undefined if not passed
             */ _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRIGGER_SEND"] /* @min:%2etriggerSend */ ] = function(isAsync, forcedSender, sendReason) {
                if (isAsync === void 0) {
                    isAsync = true;
                }
                var result;
                if (!_paused) {
                    try {
                        var buffer = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__BUFFER"] /* @min:%2e_buffer */ ];
                        // Send data only if disableTelemetry is false
                        if (!_disableTelemetry) {
                            if (buffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_COUNT"] /* @min:%2ecount */ ]() > 0) {
                                var payload = buffer.getItems();
                                _notifySendRequest(sendReason || 0 /* SendRequestReason.Undefined */ , isAsync);
                                // invoke send
                                if (forcedSender) {
                                    result = forcedSender.call(_self, payload, isAsync);
                                } else {
                                    result = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__SENDER"] /* @min:%2e_sender */ ](payload, isAsync);
                                }
                            }
                            // update lastSend time to enable throttling
                            _lastSend = +new Date;
                        } else {
                            buffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CLEAR"] /* @min:%2eclear */ ]();
                        }
                        _clearScheduledTimer();
                    } catch (e) {
                        /* Ignore this error for IE under v10 */ var ieVer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIEVersion"])();
                        if (!ieVer || ieVer > 9) {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), 1 /* eLoggingSeverity.CRITICAL */ , 40 /* _eInternalMessageId.TransmissionFailed */ , "Telemetry transmission failed, some telemetry will be lost: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                                exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                            });
                        }
                    // potential place to call countException q3
                    }
                }
                return result;
            };
            _self.getOfflineSupport = function() {
                return {
                    getUrl: function() {
                        return _endpointUrl;
                    },
                    createPayload: _createPayload,
                    serialize: _serialize,
                    batch: _batch,
                    shouldProcess: function(evt) {
                        return !!_validate(evt);
                    }
                };
            };
            _self._doTeardown = function(unloadCtx, unloadState) {
                _self.onunloadFlush();
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$AsyncUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["runTargetUnload"])(_offlineListener, false);
                _initDefaults();
            };
            /**
             * error handler
             */ _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ON_ERROR"] /* @min:%2e_onError */ ] = function(payload, message, event) {
                // since version 3.1.3, string[] is no-op
                if (_isStringArr(payload)) {
                    return;
                }
                return _onError(payload, message, event);
            };
            /**
             * partial success handler
             */ _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ON_PARTIAL_SUCCESS"] /* @min:%2e_onPartialSuccess */ ] = function(payload, results) {
                // since version 3.1.3, string[] is no-op
                if (_isStringArr(payload)) {
                    return;
                }
                return _onPartialSuccess(payload, results);
            };
            /**
             * success handler
             */ _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ON_SUCCESS"] /* @min:%2e_onSuccess */ ] = function(payload, countOfItemsInPayload) {
                // since version 3.1.3, string[] is no-op
                if (_isStringArr(payload)) {
                    return;
                }
                return _onSuccess(payload, countOfItemsInPayload);
            //_self._buffer && _self._buffer.clearSent(payload);
            };
            /**
             * xdr state changes
             */ _self._xdrOnLoad = function(xdr, payload) {
                // since version 3.1.3, string[] is no-op
                if (_isStringArr(payload)) {
                    return;
                }
                return _xdrOnLoad(xdr, payload);
            };
            // function _getStatsBeat() {
            //     let statsBeatConfig: IStatsBeatState = {
            //         cKey: _self._senderConfig.instrumentationKey,
            //         endpoint: _endpointUrl,
            //         sdkVer: EnvelopeCreator.Version,
            //         type: eStatsType.SDK
            //     };
            //     let core = _self.core;
            //     // During page unload the core may have been cleared and some async events may not have been sent yet
            //     // resulting in the core being null. In this case we don't want to create a statsbeat instance
            //     return core ? core.getStatsBeat(statsBeatConfig) : null;
            // }
            function _xdrOnLoad(xdr, payload) {
                var responseText = _getResponseText(xdr);
                if (xdr && (responseText + "" === "200" || responseText === "")) {
                    _consecutiveErrors = 0;
                    _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ON_SUCCESS"] /* @min:%2e_onSuccess */ ](payload, 0);
                } else {
                    var results = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ResponseHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseResponse"])(responseText);
                    if (results && results[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ITEMS_RECEIVED"] /* @min:%2eitemsReceived */ ] && results[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ITEMS_RECEIVED"] /* @min:%2eitemsReceived */ ] > results[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ITEMS_ACCEPTED"] /* @min:%2eitemsAccepted */ ] && !_isRetryDisabled) {
                        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ON_PARTIAL_SUCCESS"] /* @min:%2e_onPartialSuccess */ ](payload, results);
                    } else {
                        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ON_ERROR"] /* @min:%2e_onError */ ](payload, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatErrorMessageXdr"])(xdr));
                    }
                }
            }
            function _getSendPostMgrConfig() {
                try {
                    var onCompleteFuncs = {
                        xdrOnComplete: function(xdr, oncomplete, payload) {
                            var payloadArr = _getPayloadArr(payload);
                            if (!payloadArr) {
                                return;
                            }
                            //const responseText = _getResponseText(xdr);
                            // let statsbeat = _getStatsBeat();
                            // if (statsbeat) {
                            //     if (xdr && (responseText + "" === "200" || responseText === "")) {
                            //         _consecutiveErrors = 0;
                            //         statsbeat.count(200, payload, _endpointUrl);
                            //     } else {
                            //         const results = parseResponse(responseText);
                            //         if (results && results.itemsReceived && results.itemsReceived > results.itemsAccepted
                            //             && !_isRetryDisabled) {
                            //             statsbeat.count(206, payload, _endpointUrl);
                            //         } else {
                            //             statsbeat.count(499, payload, _endpointUrl);
                            //         }
                            //     }
                            // }
                            return _xdrOnLoad(xdr, payloadArr);
                        },
                        fetchOnComplete: function(response, onComplete, resValue, payload) {
                            var payloadArr = _getPayloadArr(payload);
                            if (!payloadArr) {
                                return;
                            }
                            // let statsbeat = _getStatsBeat();
                            // if (statsbeat) {
                            //     statsbeat.count(response.status, payload, _endpointUrl);
                            // }
                            return _checkResponsStatus(response.status, payloadArr, response.url, payloadArr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ], response.statusText, resValue || "");
                        },
                        xhrOnComplete: function(request, oncomplete, payload) {
                            var payloadArr = _getPayloadArr(payload);
                            if (!payloadArr) {
                                return;
                            }
                            // let statsbeat = _getStatsBeat();
                            // if (statsbeat && request.readyState === 4) {
                            //     statsbeat.count(request.status, payload, _endpointUrl);
                            // }
                            return _xhrReadyStateChange(request, payloadArr, payloadArr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]);
                        },
                        beaconOnRetry: function(data, onComplete, canSend) {
                            // let statsbeat = _getStatsBeat();
                            // if (statsbeat) {
                            //     statsbeat.count(499, data, _endpointUrl);
                            // }
                            return _onBeaconRetry(data, onComplete, canSend);
                        }
                    };
                    var config = {
                        enableSendPromise: _enableSendPromise,
                        isOneDs: false,
                        disableCredentials: false,
                        disableXhr: _disableXhr,
                        disableBeacon: !_beaconNormalSupported,
                        disableBeaconSync: !_beaconOnUnloadSupported,
                        senderOnCompleteCallBack: onCompleteFuncs
                    };
                    return config;
                } catch (e) {
                // eslint-disable-next-line no-empty
                }
                return null;
            }
            /**
             * xhr state changes
             */ function _xhrReadyStateChange(xhr, payload, countOfItemsInPayload) {
                if (xhr.readyState === 4) {
                    _checkResponsStatus(xhr.status, payload, xhr.responseURL, countOfItemsInPayload, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatErrorMessageXhr"])(xhr), _getResponseText(xhr) || xhr.response);
                }
            }
            /**
             * error handler
             */ function _onError(payload, message, event) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), 2 /* eLoggingSeverity.WARNING */ , 26 /* _eInternalMessageId.OnError */ , "Failed to send telemetry.", {
                    message: message
                });
                _self._buffer && _self._buffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CLEAR_SENT"] /* @min:%2eclearSent */ ](payload);
            }
            /**
             * partial success handler
             */ function _onPartialSuccess(payload, results) {
                var failed = [];
                var retry = [];
                // Iterate through the reversed array of errors so that splicing doesn't have invalid indexes after the first item.
                var errors = results.errors.reverse();
                for(var _i = 0, errors_1 = errors; _i < errors_1.length; _i++){
                    var error = errors_1[_i];
                    var extracted = payload.splice(error.index, 1)[0];
                    if (_isRetriable(error.statusCode)) {
                        retry[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](extracted);
                    } else {
                        // All other errors, including: 402 (Monthly quota exceeded) and 439 (Too many requests and refresh cache).
                        failed[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](extracted);
                    }
                }
                if (payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                    _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ON_SUCCESS"] /* @min:%2e_onSuccess */ ](payload, results[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ITEMS_ACCEPTED"] /* @min:%2eitemsAccepted */ ]);
                }
                if (failed[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                    _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ON_ERROR"] /* @min:%2e_onError */ ](failed, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatErrorMessageXhr"])(null, [
                        "partial success",
                        results[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ITEMS_ACCEPTED"] /* @min:%2eitemsAccepted */ ],
                        "of",
                        results.itemsReceived
                    ].join(" ")));
                }
                if (retry[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                    _resendPayload(retry);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), 2 /* eLoggingSeverity.WARNING */ , 40 /* _eInternalMessageId.TransmissionFailed */ , "Partial success. " + "Delivered: " + payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] + ", Failed: " + failed[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] + ". Will retry to send " + retry[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] + " our of " + results[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ITEMS_RECEIVED"] /* @min:%2eitemsReceived */ ] + " items");
                }
            }
            /**
             * success handler
             */ function _onSuccess(payload, countOfItemsInPayload) {
                _self._buffer && _self._buffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CLEAR_SENT"] /* @min:%2eclearSent */ ](payload);
            }
            function _getPayloadArr(payload) {
                try {
                    if (payload) {
                        var internalPayload = payload;
                        var arr = internalPayload.oriPayload;
                        if (arr && arr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]) {
                            return arr;
                        }
                        return null;
                    }
                } catch (e) {
                // eslint-disable-next-line no-empty
                }
                return null;
            }
            function _validate(telemetryItem, diagLogger) {
                if (_disableTelemetry) {
                    // Do not send/save data
                    return false;
                }
                // validate input
                if (!telemetryItem) {
                    diagLogger && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(diagLogger, 1 /* eLoggingSeverity.CRITICAL */ , 7 /* _eInternalMessageId.CannotSendEmptyTelemetry */ , "Cannot send empty telemetry");
                    return false;
                }
                // validate event
                if (telemetryItem.baseData && !telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_BASE_TYPE"] /* @min:%2ebaseType */ ]) {
                    diagLogger && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(diagLogger, 1 /* eLoggingSeverity.CRITICAL */ , 70 /* _eInternalMessageId.InvalidEvent */ , "Cannot send telemetry without baseData and baseType");
                    return false;
                }
                if (!telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_BASE_TYPE"] /* @min:%2ebaseType */ ]) {
                    // Default
                    telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_BASE_TYPE"] /* @min:%2ebaseType */ ] = "EventData";
                }
                // ensure a sender was constructed
                if (!_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__SENDER"] /* @min:%2e_sender */ ]) {
                    diagLogger && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(diagLogger, 1 /* eLoggingSeverity.CRITICAL */ , 28 /* _eInternalMessageId.SenderNotInitialized */ , "Sender was not initialized");
                    return false;
                }
                // check if this item should be sampled in, else add sampleRate tag
                if (!_isSampledIn(telemetryItem)) {
                    // Item is sampled out, do not send it
                    diagLogger && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(diagLogger, 2 /* eLoggingSeverity.WARNING */ , 33 /* _eInternalMessageId.TelemetrySampledAndNotSent */ , "Telemetry item was sampled out and not sent", {
                        SampleRate: _self._sample[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SAMPLE_RATE"] /* @min:%2esampleRate */ ]
                    });
                    return false;
                } else {
                    telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SampleRate"]] = _self._sample[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SAMPLE_RATE"] /* @min:%2esampleRate */ ];
                }
                return true;
            }
            function _getEnvelope(telemetryItem, diagLogger) {
                // construct an envelope that Application Insights endpoint can understand
                // if ikey of telemetry is provided and not empty, envelope will use this iKey instead of senderConfig iKey
                var defaultEnvelopeIkey = telemetryItem.iKey || _instrumentationKey;
                var aiEnvelope = Sender.constructEnvelope(telemetryItem, defaultEnvelopeIkey, diagLogger, _convertUndefined);
                if (!aiEnvelope) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(diagLogger, 1 /* eLoggingSeverity.CRITICAL */ , 47 /* _eInternalMessageId.CreateEnvelopeError */ , "Unable to create an AppInsights envelope");
                    return;
                }
                var doNotSendItem = false;
                // this is for running in legacy mode, where customer may already have a custom initializer present
                if (telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ] && telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProcessLegacy"]]) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProcessLegacy"]], function(callBack) {
                        try {
                            if (callBack && callBack(aiEnvelope) === false) {
                                doNotSendItem = true;
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_warnToConsole"])(diagLogger, "Telemetry processor check returns false");
                            }
                        } catch (e) {
                            // log error but dont stop executing rest of the telemetry initializers
                            // doNotSendItem = true;
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(diagLogger, 1 /* eLoggingSeverity.CRITICAL */ , 64 /* _eInternalMessageId.TelemetryInitializerFailed */ , "One of telemetry initializers failed, telemetry item will not be sent: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                                exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                            }, true);
                        }
                    });
                    delete telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TAGS"] /* @min:%2etags */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProcessLegacy"]];
                }
                if (doNotSendItem) {
                    return; // do not send, no need to execute next plugin
                }
                return aiEnvelope;
            }
            function _serialize(item) {
                var rlt = EMPTY_STR;
                var diagLogger = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ]();
                try {
                    var valid = _validate(item, diagLogger);
                    var envelope = null;
                    if (valid) {
                        envelope = _getEnvelope(item, diagLogger);
                    }
                    if (envelope) {
                        rlt = _serializer.serialize(envelope);
                    }
                } catch (e) {
                // eslint-disable-next-line no-empty
                }
                return rlt;
            }
            function _batch(arr) {
                var rlt = EMPTY_STR;
                if (arr && arr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]) {
                    rlt = "[" + arr.join(",") + "]";
                }
                return rlt;
            }
            function _createPayload(data) {
                var headers = _getHeaders();
                return {
                    urlString: _endpointUrl,
                    data: data,
                    headers: headers
                };
            }
            function _isSampledIn(envelope) {
                return _self._sample.isSampledIn(envelope);
            }
            function _getOnComplete(payload, status, headers, response) {
                // ***********************************************************************************************
                //TODO: handle other status codes
                if (status === 200 && payload) {
                    _self._onSuccess(payload, payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]);
                } else {
                    response && _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ON_ERROR"] /* @min:%2e_onError */ ](payload, response);
                }
            }
            function _doSend(sendInterface, payload, isAsync, markAsSent) {
                if (markAsSent === void 0) {
                    markAsSent = true;
                }
                var onComplete = function(status, headers, response) {
                    // let statsbeat = _getStatsBeat();
                    // if (statsbeat) {
                    //     statsbeat.count(status, payloadData, _endpointUrl);
                    // }
                    return _getOnComplete(payload, status, headers, response);
                };
                var payloadData = _getPayload(payload);
                // if (payloadData) {
                //     payloadData.statsBeatData = {startTime: dateNow()};
                // }
                var sendPostFunc = sendInterface && sendInterface.sendPOST;
                if (sendPostFunc && payloadData) {
                    // ***********************************************************************************************
                    // mark payload as sent at the beginning of calling each send function
                    if (markAsSent) {
                        _self._buffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MARK_AS_SENT"] /* @min:%2emarkAsSent */ ](payload);
                    }
                    var result_2;
                    var callbackExecuted_1 = false;
                    var resolveFn_1;
                    var rejectFn_1;
                    _sendPostMgr.preparePayload(function(processedPayload) {
                        result_2 = sendPostFunc(processedPayload, onComplete, !isAsync);
                        callbackExecuted_1 = true;
                        if (resolveFn_1) {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doAwait"])(result_2, resolveFn_1, rejectFn_1);
                        }
                    }, _zipPayload, payloadData, !isAsync);
                    if (callbackExecuted_1) {
                        return result_2;
                    }
                    // Callback was not executed synchronously, so we need to return a promise
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPromise"])(function(resolve, reject) {
                        resolveFn_1 = resolve;
                        rejectFn_1 = reject;
                    });
                }
                return null;
            }
            function _getPayload(payload) {
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(payload) && payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                    var batch = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__BUFFER"] /* @min:%2e_buffer */ ].batchPayloads(payload);
                    var headers = _getHeaders();
                    var payloadData = {
                        data: batch,
                        urlString: _endpointUrl,
                        headers: headers,
                        disableXhrSync: _disableXhr,
                        disableFetchKeepAlive: !_fetchKeepAlive,
                        oriPayload: payload
                    };
                    return payloadData;
                }
                return null;
            }
            function _getHeaders() {
                try {
                    var headers = _headers || {};
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInternalApplicationInsightsEndpoint"])(_endpointUrl)) {
                        headers[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][6 /* eRequestHeaders.sdkContextHeader */ ]] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][7 /* eRequestHeaders.sdkContextHeaderAppIdRequest */ ];
                    }
                    return headers;
                } catch (e) {
                // eslint-disable-next-line no-empty
                }
                return null;
            }
            function _checkMaxSize(incomingPayload) {
                var incomingSize = incomingPayload ? incomingPayload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] : 0;
                if (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__BUFFER"] /* @min:%2e_buffer */ ].size() + incomingSize > _maxBatchSizeInBytes) {
                    if (!_offlineListener || _offlineListener.isOnline()) {
                        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRIGGER_SEND"] /* @min:%2etriggerSend */ ](true, null, 10 /* SendRequestReason.MaxBatchSize */ );
                    }
                    return true;
                }
                return false;
            }
            function _checkResponsStatus(status, payload, responseUrl, countOfItemsInPayload, errorMessage, res) {
                var response = null;
                if (!_self._appId) {
                    response = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ResponseHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseResponse"])(res);
                    if (response && response.appId) {
                        _self._appId = response.appId;
                    }
                }
                if ((status < 200 || status >= 300) && status !== 0) {
                    // Update End Point url if permanent redirect or moved permanently
                    // Updates the end point url before retry
                    if (status === 301 || status === 307 || status === 308) {
                        if (!_checkAndUpdateEndPointUrl(responseUrl)) {
                            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ON_ERROR"] /* @min:%2e_onError */ ](payload, errorMessage);
                            return;
                        }
                    }
                    if (_offlineListener && !_offlineListener.isOnline()) {
                        // Note: Don't check for status == 0, since adblock gives this code
                        if (!_isRetryDisabled) {
                            var offlineBackOffMultiplier = 10; // arbritrary number
                            _resendPayload(payload, offlineBackOffMultiplier);
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), 2 /* eLoggingSeverity.WARNING */ , 40 /* _eInternalMessageId.TransmissionFailed */ , ". Offline - Response Code: ".concat(status, ". Offline status: ").concat(!_offlineListener.isOnline(), ". Will retry to send ").concat(payload.length, " items."));
                        }
                        return;
                    }
                    if (!_isRetryDisabled && _isRetriable(status)) {
                        _resendPayload(payload);
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), 2 /* eLoggingSeverity.WARNING */ , 40 /* _eInternalMessageId.TransmissionFailed */ , ". " + "Response code " + status + ". Will retry to send " + payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] + " items.");
                    } else {
                        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ON_ERROR"] /* @min:%2e_onError */ ](payload, errorMessage);
                    }
                } else {
                    // check if the xhr's responseURL or fetch's response.url is same as endpoint url
                    // TODO after 10 redirects force send telemetry with 'redirect=false' as query parameter.
                    _checkAndUpdateEndPointUrl(responseUrl);
                    if (status === 206) {
                        if (!response) {
                            response = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ResponseHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseResponse"])(res);
                        }
                        if (response && !_isRetryDisabled) {
                            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ON_PARTIAL_SUCCESS"] /* @min:%2e_onPartialSuccess */ ](payload, response);
                        } else {
                            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ON_ERROR"] /* @min:%2e_onError */ ](payload, errorMessage);
                        }
                    } else {
                        _consecutiveErrors = 0;
                        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ON_SUCCESS"] /* @min:%2e_onSuccess */ ](payload, countOfItemsInPayload);
                    }
                }
            }
            function _checkAndUpdateEndPointUrl(responseUrl) {
                // Maximum stamp specific redirects allowed(uncomment this when breeze is ready with not allowing redirects feature)
                if (_stamp_specific_redirects >= 10) {
                    //  _self._senderConfig.endpointUrl = () => Sender._getDefaultAppInsightsChannelConfig().endpointUrl()+"/?redirect=false";
                    //  _stamp_specific_redirects = 0;
                    return false;
                }
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(responseUrl) && responseUrl !== "") {
                    if (responseUrl !== _endpointUrl) {
                        _endpointUrl = responseUrl;
                        ++_stamp_specific_redirects;
                        return true;
                    }
                }
                return false;
            }
            function _doUnloadSend(payload, isAsync) {
                if (_syncUnloadSender) {
                    // We are unloading so always call the sender with sync set to false
                    _syncUnloadSender(payload, false);
                } else {
                    // Fallback to the previous beacon Sender (which causes a CORB warning on chrome now)
                    var beaconInst = _sendPostMgr && _sendPostMgr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_SENDER_INST"] /* @min:%2egetSenderInst */ ]([
                        3 /* TransportType.Beacon */ 
                    ], true);
                    return _doSend(beaconInst, payload, isAsync);
                }
            }
            function _onBeaconRetry(payload, onComplete, canSend) {
                var internalPayload = payload;
                var data = internalPayload && internalPayload.oriPayload;
                if (!_disableBeaconSplit) {
                    // Failed to send entire payload so try and split data and try to send as much events as possible
                    var droppedPayload = [];
                    for(var lp = 0; lp < data[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; lp++){
                        var thePayload = data[lp];
                        var arr = [
                            thePayload
                        ];
                        var item = _getPayload(arr);
                        if (!canSend(item, onComplete)) {
                            // Can't send anymore, so split the batch and drop the rest
                            droppedPayload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](thePayload);
                        } else {
                            _self._onSuccess(arr, arr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]);
                        }
                    }
                    if (droppedPayload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                        _fallbackSend && _fallbackSend(droppedPayload, true);
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), 2 /* eLoggingSeverity.WARNING */ , 40 /* _eInternalMessageId.TransmissionFailed */ , ". " + "Failed to send telemetry with Beacon API, retried with normal sender.");
                    }
                } else {
                    _fallbackSend && _fallbackSend(data, true);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), 2 /* eLoggingSeverity.WARNING */ , 40 /* _eInternalMessageId.TransmissionFailed */ , ". " + "Failed to send telemetry with Beacon API, retried with normal sender.");
                }
            }
            function _isStringArr(arr) {
                try {
                    if (arr && arr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]) {
                        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(arr[0]);
                    }
                } catch (e) {
                //TODO: log, sender use IInternalStorageItem instead of string since 3.1.3
                }
                return null;
            }
            function _fetchKeepAliveSender(payload, isAsync) {
                var transport = null;
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(payload)) {
                    var payloadSize = payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
                    for(var lp = 0; lp < payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; lp++){
                        payloadSize += payload[lp].item[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
                    }
                    var syncFetchPayload = _sendPostMgr.getSyncFetchPayload();
                    if (syncFetchPayload + payloadSize <= FetchSyncRequestSizeLimitBytes) {
                        transport = 2 /* TransportType.Fetch */ ;
                    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isBeaconsSupported"])()) {
                        // Fallback to beacon sender as we at least get told which events can't be scheduled
                        transport = 3 /* TransportType.Beacon */ ;
                    } else {
                        // Payload is going to be too big so just try and send via XHR
                        transport = 1 /* TransportType.Xhr */ ;
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), 2 /* eLoggingSeverity.WARNING */ , 40 /* _eInternalMessageId.TransmissionFailed */ , ". " + "Failed to send telemetry with Beacon API, retried with xhrSender.");
                    }
                    var inst = _sendPostMgr && _sendPostMgr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_SENDER_INST"] /* @min:%2egetSenderInst */ ]([
                        transport
                    ], true);
                    return _doSend(inst, payload, isAsync);
                }
                return null;
            }
            /**
             * Resend payload. Adds payload back to the send buffer and setup a send timer (with exponential backoff).
             * @param payload
             */ function _resendPayload(payload, linearFactor) {
                if (linearFactor === void 0) {
                    linearFactor = 1;
                }
                if (!payload || payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] === 0) {
                    return;
                }
                var buffer = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__BUFFER"] /* @min:%2e_buffer */ ];
                buffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CLEAR_SENT"] /* @min:%2eclearSent */ ](payload);
                _consecutiveErrors++;
                for(var _i = 0, payload_1 = payload; _i < payload_1.length; _i++){
                    var item = payload_1[_i];
                    item.cnt = item.cnt || 0; // to make sure we have cnt for each payload
                    item.cnt++; // when resend, increase cnt
                    buffer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENQUEUE"] /* @min:%2eenqueue */ ](item);
                }
                // setup timer
                _setRetryTime(linearFactor);
                _setupTimer();
            }
            /**
             * Calculates the time to wait before retrying in case of an error based on
             * http://en.wikipedia.org/wiki/Exponential_backoff
             */ function _setRetryTime(linearFactor) {
                var SlotDelayInSeconds = 10;
                var delayInSeconds;
                if (_consecutiveErrors <= 1) {
                    delayInSeconds = SlotDelayInSeconds;
                } else {
                    var backOffSlot = (Math.pow(2, _consecutiveErrors) - 1) / 2;
                    // tslint:disable-next-line:insecure-random
                    var backOffDelay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mathFloor"])(Math.random() * backOffSlot * SlotDelayInSeconds) + 1;
                    backOffDelay = linearFactor * backOffDelay;
                    delayInSeconds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mathMax"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mathMin"])(backOffDelay, 3600), SlotDelayInSeconds);
                }
                // TODO: Log the backoff time like the C# version does.
                var retryAfterTimeSpan = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__utcNow__as__dateNow$3e$__["dateNow"])() + delayInSeconds * 1000;
                // TODO: Log the retry at time like the C# version does.
                _retryAt = retryAfterTimeSpan;
            }
            /**
             * Sets up the timer which triggers actually sending the data.
             */ function _setupTimer() {
                if (!_timeoutHandle && !_paused) {
                    var retryInterval = _retryAt ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mathMax"])(0, _retryAt - (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__utcNow__as__dateNow$3e$__["dateNow"])()) : 0;
                    var timerValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mathMax"])(_maxBatchInterval, retryInterval);
                    _timeoutHandle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["scheduleTimeout"])(function() {
                        _timeoutHandle = null;
                        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRIGGER_SEND"] /* @min:%2etriggerSend */ ](true, null, 1 /* SendRequestReason.NormalSchedule */ );
                    }, timerValue);
                }
            }
            function _clearScheduledTimer() {
                _timeoutHandle && _timeoutHandle.cancel();
                _timeoutHandle = null;
                _retryAt = null;
            }
            /**
             * Checks if the SDK should resend the payload after receiving this status code from the backend.
             * @param statusCode
             */ function _isRetriable(statusCode) {
                // retryCodes = [] means should not retry
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(_retryCodes)) {
                    return _retryCodes[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] && _retryCodes.indexOf(statusCode) > -1;
                }
                return statusCode === 401 // Unauthorized
                 || statusCode === 408 // Timeout
                 || statusCode === 429 // Too many requests.
                 || statusCode === 500 // Internal server error.
                 || statusCode === 502 // Bad Gateway.
                 || statusCode === 503 // Service unavailable.
                 || statusCode === 504; // Gateway timeout.
            }
            // Using function lookups for backward compatibility as the getNotifyMgr() did not exist until after v2.5.6
            function _getNotifyMgr() {
                var func = "getNotifyMgr";
                var result;
                var core = _self.core;
                if (core) {
                    // During page unload the core may have been cleared and some async events may not have been sent yet
                    // resulting in the core being null. In this case we don't want to create a statsbeat instance
                    if (core[func]) {
                        result = core[func]();
                    } else {
                        // using _self.core['_notificationManager'] for backward compatibility
                        result = core["_notificationManager"];
                    }
                }
                return result;
            }
            function _notifySendRequest(sendRequest, isAsync) {
                var manager = _getNotifyMgr();
                if (manager && manager.eventsSendRequest) {
                    try {
                        manager.eventsSendRequest(sendRequest, isAsync);
                    } catch (e) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), 1 /* eLoggingSeverity.CRITICAL */ , 74 /* _eInternalMessageId.NotificationException */ , "send request notification failed: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                            exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                        });
                    }
                }
            }
            /**
             * Validate UUID Format
             * Specs taken from https://tools.ietf.org/html/rfc4122 and breeze repo
             */ function _validateInstrumentationKey(instrumentationKey, config) {
                var disableValidation = config.disableInstrumentationKeyValidation;
                var disableIKeyValidationFlag = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(disableValidation) ? false : disableValidation;
                if (disableIKeyValidationFlag) {
                    return true;
                }
                var UUID_Regex = "^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$";
                var regexp = new RegExp(UUID_Regex);
                return regexp.test(instrumentationKey);
            }
            function _initDefaults() {
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__SENDER"] /* @min:%2e_sender */ ] = null;
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__BUFFER"] /* @min:%2e_buffer */ ] = null;
                _self._appId = null;
                _self._sample = null;
                _headers = {};
                _offlineListener = null;
                _consecutiveErrors = 0;
                _retryAt = null;
                _lastSend = null;
                _paused = false;
                _timeoutHandle = null;
                _serializer = null;
                _stamp_specific_redirects = 0;
                _syncFetchPayload = 0;
                _syncUnloadSender = null;
                _evtNamespace = null;
                _endpointUrl = null;
                _orgEndpointUrl = null;
                _maxBatchSizeInBytes = 0;
                _beaconSupported = false;
                _customHeaders = null;
                _disableTelemetry = false;
                _instrumentationKey = null;
                _convertUndefined = UNDEFINED_VALUE;
                _isRetryDisabled = false;
                _sessionStorageUsed = null;
                _namePrefix = UNDEFINED_VALUE;
                _disableXhr = false;
                _fetchKeepAlive = false;
                _disableBeaconSplit = false;
                _xhrSend = null;
                _fallbackSend = null;
                _sendPostMgr = null;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "_senderConfig", {
                    g: function() {
                        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objExtend"])({}, defaultAppInsightsChannelConfig);
                    }
                });
            }
        });
        return _this;
    }
    Sender.constructEnvelope = function(orig, iKey, logger, convertUndefined) {
        var envelope;
        if (iKey !== orig.iKey && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(iKey)) {
            envelope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assignFn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assignFn"])({}, orig), {
                iKey: iKey
            });
        } else {
            envelope = orig;
        }
        var creator = EnvelopeTypeCreator[envelope.baseType] || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$channel$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$channel$2d$js$2f$dist$2d$es5$2f$EnvelopeCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EventEnvelopeCreator"];
        return creator(logger, envelope, convertUndefined);
    };
    // Removed Stub for Sender.prototype.pause.
    // Removed Stub for Sender.prototype.resume.
    // Removed Stub for Sender.prototype.flush.
    // Removed Stub for Sender.prototype.onunloadFlush.
    // Removed Stub for Sender.prototype.initialize.
    // Removed Stub for Sender.prototype.processTelemetry.
    // Removed Stub for Sender.prototype._xhrReadyStateChange.
    // Removed Stub for Sender.prototype.triggerSend.
    // Removed Stub for Sender.prototype._onError.
    // Removed Stub for Sender.prototype._onPartialSuccess.
    // Removed Stub for Sender.prototype._onSuccess.
    // Removed Stub for Sender.prototype._xdrOnLoad.
    // Removed Stub for Sender.prototype.addHeader.
    // Removed Stub for Sender.prototype.isCompletelyIdle.
    // Removed Stub for Sender.prototype.getOfflineSupport.
    // Removed Stub for Sender.prototype.getOfflineListener.
    return Sender;
}(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$BaseTelemetryPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseTelemetryPlugin"]);
;
 //# sourceMappingURL=Sender.js.map
}),
]);

//# sourceMappingURL=6a607_%40microsoft_applicationinsights-channel-js_dist-es5_f3f6480a._.js.map