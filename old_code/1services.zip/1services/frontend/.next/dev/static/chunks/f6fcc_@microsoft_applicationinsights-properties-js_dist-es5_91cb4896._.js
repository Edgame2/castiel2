(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/Context/Application.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Properties Plugin, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "Application",
    ()=>Application
]);
var Application = function() {
    function Application() {}
    return Application;
}();
;
 //# sourceMappingURL=Application.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/Context/Device.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Properties Plugin, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "Device",
    ()=>Device
]);
var Device = function() {
    /**
     * Constructs a new instance of the Device class
     */ function Device() {
        // don't attempt to fingerprint browsers
        this.id = "browser";
        // Device type is a dimension in our data platform
        // Setting it to 'Browser' allows to separate client and server dependencies/exceptions
        this.deviceClass = "Browser";
    }
    return Device;
}();
;
 //# sourceMappingURL=Device.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/Context/Internal.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Properties Plugin, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "Internal",
    ()=>Internal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicConfig.js [app-client] (ecmascript)");
;
var Version = '3.3.10';
var Internal = function() {
    /**
     * Constructs a new instance of the internal telemetry data class.
     */ function Internal(config, unloadHookContainer) {
        var _this = this;
        var unloadHook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onConfigChange"])(config, function() {
            var prefix = config.sdkExtension;
            _this.sdkVersion = (prefix ? prefix + "_" : "") + "javascript:" + Version;
        });
        unloadHookContainer && unloadHookContainer.add(unloadHook);
    }
    return Internal;
}();
;
 //# sourceMappingURL=Internal.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/Context/Location.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Properties Plugin, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "Location",
    ()=>Location
]);
var Location = function() {
    function Location() {}
    return Location;
}();
;
 //# sourceMappingURL=Location.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Properties Plugin, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ // @skip-file-minify
// ##############################################################
// AUTO GENERATED FILE: This file is Auto Generated during build.
// ##############################################################
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// Note: DON'T Export these const from the package as we are still targeting ES5 which can result in a mutable variables that someone could change!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
__turbopack_context__.s([
    "_DYN_ACCOUNT_ID",
    ()=>_DYN_ACCOUNT_ID,
    "_DYN_ACQUISITION_DATE",
    ()=>_DYN_ACQUISITION_DATE,
    "_DYN_APPLY_APPLICATION_CO1",
    ()=>_DYN_APPLY_APPLICATION_CO1,
    "_DYN_APPLY_INTERNAL_CONTE5",
    ()=>_DYN_APPLY_INTERNAL_CONTE5,
    "_DYN_APPLY_LOCATION_CONTE4",
    ()=>_DYN_APPLY_LOCATION_CONTE4,
    "_DYN_APPLY_OPERATING_SYST3",
    ()=>_DYN_APPLY_OPERATING_SYST3,
    "_DYN_APPLY_OPERATION_CONT2",
    ()=>_DYN_APPLY_OPERATION_CONT2,
    "_DYN_APPLY_SESSION_CONTEX0",
    ()=>_DYN_APPLY_SESSION_CONTEX0,
    "_DYN_AUTHENTICATED_ID",
    ()=>_DYN_AUTHENTICATED_ID,
    "_DYN_AUTH_USER_COOKIE_NAM7",
    ()=>_DYN_AUTH_USER_COOKIE_NAM7,
    "_DYN_AUTOMATIC_SESSION",
    ()=>_DYN_AUTOMATIC_SESSION,
    "_DYN_COOKIE_SEPARATOR",
    ()=>_DYN_COOKIE_SEPARATOR,
    "_DYN_GET_SESSION_ID",
    ()=>_DYN_GET_SESSION_ID,
    "_DYN_GET_TRACE_CTX",
    ()=>_DYN_GET_TRACE_CTX,
    "_DYN_IS_NEW_USER",
    ()=>_DYN_IS_NEW_USER,
    "_DYN_IS_USER_COOKIE_SET",
    ()=>_DYN_IS_USER_COOKIE_SET,
    "_DYN_RENEWAL_DATE",
    ()=>_DYN_RENEWAL_DATE,
    "_DYN_SESSION",
    ()=>_DYN_SESSION,
    "_DYN_SESSION_COOKIE_POSTF6",
    ()=>_DYN_SESSION_COOKIE_POSTF6,
    "_DYN_SESSION_MANAGER",
    ()=>_DYN_SESSION_MANAGER,
    "_DYN_TELEMETRY_TRACE",
    ()=>_DYN_TELEMETRY_TRACE
]);
var _DYN_SESSION = "session"; // Count: 4
var _DYN_SESSION_MANAGER = "sessionManager"; // Count: 3
var _DYN_IS_USER_COOKIE_SET = "isUserCookieSet"; // Count: 4
var _DYN_IS_NEW_USER = "isNewUser"; // Count: 4
var _DYN_GET_TRACE_CTX = "getTraceCtx"; // Count: 3
var _DYN_TELEMETRY_TRACE = "telemetryTrace"; // Count: 3
var _DYN_APPLY_SESSION_CONTEX0 = "applySessionContext"; // Count: 2
var _DYN_APPLY_APPLICATION_CO1 = "applyApplicationContext"; // Count: 2
var _DYN_APPLY_OPERATION_CONT2 = "applyOperationContext"; // Count: 2
var _DYN_APPLY_OPERATING_SYST3 = "applyOperatingSystemContxt"; // Count: 2
var _DYN_APPLY_LOCATION_CONTE4 = "applyLocationContext"; // Count: 2
var _DYN_APPLY_INTERNAL_CONTE5 = "applyInternalContext"; // Count: 2
var _DYN_GET_SESSION_ID = "getSessionId"; // Count: 4
var _DYN_SESSION_COOKIE_POSTF6 = "sessionCookiePostfix"; // Count: 2
var _DYN_AUTOMATIC_SESSION = "automaticSession"; // Count: 6
var _DYN_ACCOUNT_ID = "accountId"; // Count: 6
var _DYN_AUTHENTICATED_ID = "authenticatedId"; // Count: 6
var _DYN_ACQUISITION_DATE = "acquisitionDate"; // Count: 5
var _DYN_RENEWAL_DATE = "renewalDate"; // Count: 4
var _DYN_COOKIE_SEPARATOR = "cookieSeparator"; // Count: 5
var _DYN_AUTH_USER_COOKIE_NAM7 = "authUserCookieName"; // Count: 3
 //# sourceMappingURL=__DynamicConstants.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/Context/Session.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Properties Plugin, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "Session",
    ()=>Session,
    "_SessionManager",
    ()=>_SessionManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/StorageHelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__utcNow__as__dateNow$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript) <export utcNow as dateNow>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$RandomHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/RandomHelper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicConfig.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CookieMgr$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/CookieMgr.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
;
;
;
var SESSION_COOKIE_NAME = "ai_session";
var ACQUISITION_SPAN = 86400000; // 24 hours in ms
var RENEWAL_SPAN = 1800000; // 30 minutes in ms
var COOKIE_UPDATE_INTERVAL = 60000; // 1 minute in ms
var Session = function() {
    function Session() {}
    return Session;
}();
;
var _SessionManager = function() {
    function _SessionManager(config, core, unloadHookContainer) {
        var self = this;
        var _storageNamePrefix;
        var _cookieUpdatedTimestamp;
        var _logger = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeGetLogger"])(core);
        var _cookieManager = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CookieMgr$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeGetCookieMgr"])(core);
        var _sessionExpirationMs;
        var _sessionRenewalMs;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_SessionManager, self, function(_self) {
            if (!config) {
                config = {};
            }
            var unloadHook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onConfigChange"])(config, function(details) {
                _sessionExpirationMs = config.sessionExpirationMs || ACQUISITION_SPAN;
                _sessionRenewalMs = config.sessionRenewalMs || RENEWAL_SPAN;
                // sessionCookiePostfix takes the preference if it is configured, otherwise takes namePrefix if configured.
                var sessionCookiePostfix = config[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SESSION_COOKIE_POSTF6"] /* @min:%2esessionCookiePostfix */ ] || config.namePrefix || "";
                _storageNamePrefix = SESSION_COOKIE_NAME + sessionCookiePostfix;
            });
            unloadHookContainer && unloadHookContainer.add(unloadHook);
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTOMATIC_SESSION"] /* @min:%2eautomaticSession */ ] = new Session();
            _self.update = function() {
                // Always using Date getTime() as there is a bug in older IE instances that causes the performance timings to have the hi-bit set eg 0x800000000 causing
                // the number to be incorrect.
                var nowMs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__utcNow__as__dateNow$3e$__["dateNow"])();
                var isExpired = false;
                var session = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTOMATIC_SESSION"] /* @min:%2eautomaticSession */ ];
                if (!session.id) {
                    isExpired = !_initializeAutomaticSession(session, nowMs);
                }
                if (!isExpired && _sessionExpirationMs > 0) {
                    var timeSinceAcqMs = nowMs - session[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ACQUISITION_DATE"] /* @min:%2eacquisitionDate */ ];
                    var timeSinceRenewalMs = nowMs - session[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RENEWAL_DATE"] /* @min:%2erenewalDate */ ];
                    isExpired = timeSinceAcqMs < 0 || timeSinceRenewalMs < 0; // expired if the acquisition or last renewal are in the future
                    isExpired = isExpired || timeSinceAcqMs > _sessionExpirationMs; // expired if the time since acquisition is more than session Expiration
                    isExpired = isExpired || timeSinceRenewalMs > _sessionRenewalMs; // expired if the time since last renewal is more than renewal period
                }
                // renew if acquisitionSpan or renewalSpan has elapsed
                if (isExpired) {
                    // update automaticSession so session state has correct id
                    _renew(nowMs);
                } else {
                    // do not update the cookie more often than cookieUpdateInterval
                    if (!_cookieUpdatedTimestamp || nowMs - _cookieUpdatedTimestamp > COOKIE_UPDATE_INTERVAL) {
                        _setCookie(session, nowMs);
                    }
                }
            };
            /**
             *  Record the current state of the automatic session and store it in our cookie string format
             *  into the browser's local storage. This is used to restore the session data when the cookie
             *  expires.
             */ _self.backup = function() {
                var session = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTOMATIC_SESSION"] /* @min:%2eautomaticSession */ ];
                _setStorage(session.id, session[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ACQUISITION_DATE"] /* @min:%2eacquisitionDate */ ], session[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RENEWAL_DATE"] /* @min:%2erenewalDate */ ]);
            };
            /**
             * Use config.namePrefix + ai_session cookie data or local storage data (when the cookie is unavailable) to
             * initialize the automatic session.
             * @returns true if values set otherwise false
             */ function _initializeAutomaticSession(session, now) {
                var isValid = false;
                var cookieValue = _cookieManager.get(_storageNamePrefix);
                if (cookieValue && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(cookieValue.split)) {
                    isValid = _initializeAutomaticSessionWithData(session, cookieValue);
                } else {
                    // There's no cookie, but we might have session data in local storage
                    // This can happen if the session expired or the user actively deleted the cookie
                    // We only want to recover data if the cookie is missing from expiry. We should respect the user's wishes if the cookie was deleted actively.
                    // The User class handles this for us and deletes our local storage object if the persistent user cookie was removed.
                    var storageValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlGetLocalStorage"])(_logger, _storageNamePrefix);
                    if (storageValue) {
                        isValid = _initializeAutomaticSessionWithData(session, storageValue);
                    }
                }
                return isValid || !!session.id;
            }
            /**
             * Extract id, acquisitionDate, and renewalDate from an ai_session payload string and
             * use this data to initialize automaticSession.
             *
             * @param sessionData - The string stored in an ai_session cookie or local storage backup
             * @returns true if values set otherwise false
             */ function _initializeAutomaticSessionWithData(session, sessionData) {
                var isValid = false;
                var sessionReset = ", session will be reset";
                var tokens = sessionData.split("|");
                if (tokens.length >= 2) {
                    try {
                        var acqMs = +tokens[1] || 0;
                        var renewalMs = +tokens[2] || 0;
                        if (isNaN(acqMs) || acqMs <= 0) {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_logger, 2 /* eLoggingSeverity.WARNING */ , 27 /* _eInternalMessageId.SessionRenewalDateIsZero */ , "AI session acquisition date is 0" + sessionReset);
                        } else if (isNaN(renewalMs) || renewalMs <= 0) {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_logger, 2 /* eLoggingSeverity.WARNING */ , 27 /* _eInternalMessageId.SessionRenewalDateIsZero */ , "AI session renewal date is 0" + sessionReset);
                        } else if (tokens[0]) {
                            // Everything looks valid so set the values
                            session.id = tokens[0];
                            session[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ACQUISITION_DATE"] /* @min:%2eacquisitionDate */ ] = acqMs;
                            session[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RENEWAL_DATE"] /* @min:%2erenewalDate */ ] = renewalMs;
                            isValid = true;
                        }
                    } catch (e) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_logger, 1 /* eLoggingSeverity.CRITICAL */ , 9 /* _eInternalMessageId.ErrorParsingAISessionCookie */ , "Error parsing ai_session value [" + (sessionData || "") + "]" + sessionReset + " - " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                            exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                        });
                    }
                }
                return isValid;
            }
            function _renew(nowMs) {
                var getNewId = config.getNewId || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$RandomHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newId"];
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTOMATIC_SESSION"] /* @min:%2eautomaticSession */ ].id = getNewId(config.idLength || 22);
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTOMATIC_SESSION"] /* @min:%2eautomaticSession */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ACQUISITION_DATE"] /* @min:%2eacquisitionDate */ ] = nowMs;
                _setCookie(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTOMATIC_SESSION"] /* @min:%2eautomaticSession */ ], nowMs);
                // If this browser does not support local storage, fire an internal log to keep track of it at this point
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlCanUseLocalStorage"])()) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_logger, 2 /* eLoggingSeverity.WARNING */ , 0 /* _eInternalMessageId.BrowserDoesNotSupportLocalStorage */ , "Browser does not support local storage. Session durations will be inaccurate.");
                }
            }
            function _setCookie(session, nowMs) {
                var acq = session[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ACQUISITION_DATE"] /* @min:%2eacquisitionDate */ ];
                session[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RENEWAL_DATE"] /* @min:%2erenewalDate */ ] = nowMs;
                var renewalPeriodMs = _sessionRenewalMs;
                // Set cookie to expire after the session expiry time passes or the session renewal deadline, whichever is sooner
                // Expiring the cookie will cause the session to expire even if the user isn't on the page
                var acqTimeLeftMs = acq + _sessionExpirationMs - nowMs;
                var cookie = [
                    session.id,
                    acq,
                    nowMs
                ];
                var maxAgeSec = 0;
                if (acqTimeLeftMs < renewalPeriodMs) {
                    maxAgeSec = acqTimeLeftMs / 1000;
                } else {
                    maxAgeSec = renewalPeriodMs / 1000;
                }
                var cookieDomain = config.cookieDomain || null;
                // if sessionExpirationMs is set to 0, it means the expiry is set to 0 for this session cookie
                // A cookie with 0 expiry in the session cookie will never expire for that browser session.  If the browser is closed the cookie expires.
                // Depending on the browser, another instance does not inherit this cookie, however, another tab will
                _cookieManager.set(_storageNamePrefix, cookie.join("|"), _sessionExpirationMs > 0 ? maxAgeSec : null, cookieDomain);
                _cookieUpdatedTimestamp = nowMs;
            }
            function _setStorage(guid, acq, renewal) {
                // Keep data in local storage to retain the last session id, allowing us to cleanly end the session when it expires
                // Browsers that don't support local storage won't be able to end sessions cleanly from the client
                // The server will notice this and end the sessions itself, with loss of accurate session duration
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlSetLocalStorage"])(_logger, _storageNamePrefix, [
                    guid,
                    acq,
                    renewal
                ].join("|"));
            }
        });
    }
    // Removed Stub for _SessionManager.prototype.update.
    // Removed Stub for _SessionManager.prototype.backup.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    _SessionManager.__ieDyn = 1;
    return _SessionManager;
}();
;
 //# sourceMappingURL=Session.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/Context/TelemetryTrace.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Properties Plugin, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "TelemetryTrace",
    ()=>TelemetryTrace
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$DataSanitizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Common/DataSanitizer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EnvUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CoreUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/CoreUtils.js [app-client] (ecmascript)");
;
;
var TelemetryTrace = function() {
    function TelemetryTrace(id, parentId, name, logger, config) {
        var _self = this;
        _self.traceID = id || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CoreUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateW3CId"])();
        _self.parentID = parentId;
        var location = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLocation"])();
        if (!name && location && location.pathname) {
            name = location.pathname;
            if (config) {
                name = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fieldRedaction"])(name, config);
            }
        }
        _self.name = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$DataSanitizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dataSanitizeString"])(logger, name);
    }
    return TelemetryTrace;
}();
;
 //# sourceMappingURL=TelemetryTrace.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/Context/User.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Properties Plugin, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "User",
    ()=>User
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/StorageHelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$RandomHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/RandomHelper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicConfig.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CookieMgr$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/CookieMgr.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
;
;
;
;
function _validateUserInput(id) {
    // Validate:
    // 1. Id is a non-empty string.
    // 2. It does not contain special characters for cookies.
    if (typeof id !== "string" || !id || id.match(/,|;|=| |\|/)) {
        return false;
    }
    return true;
}
var User = function() {
    function User(config, core, unloadHookContainer) {
        /**
         * A flag indicating whether this represents a new user
         */ this.isNewUser = false;
        /**
         * A flag indicating whether the user cookie has been set
         */ this.isUserCookieSet = false;
        var _logger = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeGetLogger"])(core);
        var _cookieManager = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CookieMgr$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeGetCookieMgr"])(core);
        var _storageNamePrefix;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(User, this, function(_self) {
            // Define _self.config
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "config", {
                g: function() {
                    return config;
                }
            });
            var unloadHook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onConfigChange"])(config, function() {
                var userCookiePostfix = config.userCookiePostfix || "";
                _storageNamePrefix = User.userCookieName + userCookiePostfix;
                // get userId or create new one if none exists
                var cookie = _cookieManager.get(_storageNamePrefix);
                if (cookie) {
                    _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_NEW_USER"] /* @min:%2eisNewUser */ ] = false;
                    var params = cookie.split(User[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_COOKIE_SEPARATOR"] /* @min:%2ecookieSeparator */ ]);
                    if (params.length > 0) {
                        _self.id = params[0];
                        // we already have a cookie
                        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_USER_COOKIE_SET"] /* @min:%2eisUserCookieSet */ ] = !!_self.id;
                    }
                }
                if (!_self.id) {
                    _self.id = _generateNewId();
                    var newCookie = _generateNewCookie(_self.id);
                    _setUserCookie(newCookie.join(User[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_COOKIE_SEPARATOR"] /* @min:%2ecookieSeparator */ ]));
                    // If we have an config.namePrefix() + ai_session in local storage this means the user actively removed our cookies.
                    // We should respect their wishes and clear ourselves from local storage
                    var name_1 = (config.namePrefix || "") + "ai_session";
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlRemoveStorage"])(_logger, name_1);
                }
                // We still take the account id from the ctor param for backward compatibility.
                // But if the the customer set the accountId through the newer setAuthenticatedUserContext API, we will override it.
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ACCOUNT_ID"] /* @min:%2eaccountId */ ] = config[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ACCOUNT_ID"] /* @min:%2eaccountId */ ] || undefined;
                // Get the auth user id and account id from the cookie if exists
                // Cookie is in the pattern: <authenticatedId>|<accountId>
                var authCookie = _cookieManager.get(User[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTH_USER_COOKIE_NAM7"] /* @min:%2eauthUserCookieName */ ]);
                if (authCookie) {
                    authCookie = decodeURI(authCookie);
                    var authCookieString = authCookie.split(User[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_COOKIE_SEPARATOR"] /* @min:%2ecookieSeparator */ ]);
                    if (authCookieString[0]) {
                        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTHENTICATED_ID"] /* @min:%2eauthenticatedId */ ] = authCookieString[0];
                    }
                    if (authCookieString.length > 1 && authCookieString[1]) {
                        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ACCOUNT_ID"] /* @min:%2eaccountId */ ] = authCookieString[1];
                    }
                }
            });
            unloadHookContainer && unloadHookContainer.add(unloadHook);
            function _generateNewId() {
                var theConfig = config || {};
                var getNewId = theConfig.getNewId || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$RandomHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newId"];
                var id = getNewId(theConfig.idLength ? config.idLength : 22);
                return id;
            }
            function _generateNewCookie(userId) {
                var acqStr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toISOString"])(new Date());
                _self.accountAcquisitionDate = acqStr;
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_NEW_USER"] /* @min:%2eisNewUser */ ] = true;
                var newCookie = [
                    userId,
                    acqStr
                ];
                return newCookie;
            }
            function _setUserCookie(cookie) {
                // without expiration, cookies expire at the end of the session
                // set it to 365 days from now
                // 365 * 24 * 60 * 60 = 31536000
                var oneYear = 31536000;
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_USER_COOKIE_SET"] /* @min:%2eisUserCookieSet */ ] = _cookieManager.set(_storageNamePrefix, cookie, oneYear);
            }
            _self.setAuthenticatedUserContext = function(authenticatedUserId, accountId, storeInCookie) {
                if (storeInCookie === void 0) {
                    storeInCookie = false;
                }
                // Validate inputs to ensure no cookie control characters.
                var isInvalidInput = !_validateUserInput(authenticatedUserId) || accountId && !_validateUserInput(accountId);
                if (isInvalidInput) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_logger, 2 /* eLoggingSeverity.WARNING */ , 60 /* _eInternalMessageId.SetAuthContextFailedAccountName */ , "Setting auth user context failed. " + "User auth/account id should be of type string, and not contain commas, semi-colons, equal signs, spaces, or vertical-bars.", true);
                    return;
                }
                // Create cookie string.
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTHENTICATED_ID"] /* @min:%2eauthenticatedId */ ] = authenticatedUserId;
                var authCookie = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTHENTICATED_ID"] /* @min:%2eauthenticatedId */ ];
                if (accountId) {
                    _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ACCOUNT_ID"] /* @min:%2eaccountId */ ] = accountId;
                    authCookie = [
                        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTHENTICATED_ID"] /* @min:%2eauthenticatedId */ ],
                        _self.accountId
                    ].join(User[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_COOKIE_SEPARATOR"] /* @min:%2ecookieSeparator */ ]);
                }
                if (storeInCookie) {
                    // Set the cookie. No expiration date because this is a session cookie (expires when browser closed).
                    // Encoding the cookie to handle unexpected unicode characters.
                    _cookieManager.set(User[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTH_USER_COOKIE_NAM7"] /* @min:%2eauthUserCookieName */ ], encodeURI(authCookie));
                }
            };
            /**
             * Clears the authenticated user id and the account id from the user context.
             * @returns {}
             */ _self.clearAuthenticatedUserContext = function() {
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTHENTICATED_ID"] /* @min:%2eauthenticatedId */ ] = null;
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ACCOUNT_ID"] /* @min:%2eaccountId */ ] = null;
                _cookieManager.del(User[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTH_USER_COOKIE_NAM7"] /* @min:%2eauthUserCookieName */ ]);
            };
            _self.update = function(userId) {
                // Optimizations to avoid setting and processing the cookie when not needed
                if (_self.id !== userId || !_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_USER_COOKIE_SET"] /* @min:%2eisUserCookieSet */ ]) {
                    var user_id = userId ? userId : _generateNewId();
                    var user_cookie = _generateNewCookie(user_id);
                    _setUserCookie(user_cookie.join(User[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_COOKIE_SEPARATOR"] /* @min:%2ecookieSeparator */ ]));
                }
            };
        });
    }
    // Removed Stub for User.prototype.setAuthenticatedUserContext.
    // Removed Stub for User.prototype.clearAuthenticatedUserContext.
    // Removed Stub for User.prototype.update.
    User.cookieSeparator = "|";
    User.userCookieName = "ai_user";
    User.authUserCookieName = "ai_authUser";
    return User;
}();
;
 //# sourceMappingURL=User.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/TelemetryContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Properties Plugin, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ /**
* TelemetryContext.ts
* @copyright Microsoft 2018
*/ __turbopack_context__.s([
    "TelemetryContext",
    ()=>TelemetryContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Interfaces/PartAExtensions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/PageView.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$DataSanitizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Common/DataSanitizer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$Context$2f$Application$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/Context/Application.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$Context$2f$Device$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/Context/Device.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$Context$2f$Internal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/Context/Internal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$Context$2f$Location$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/Context/Location.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$Context$2f$Session$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/Context/Session.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$Context$2f$TelemetryTrace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/Context/TelemetryTrace.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$Context$2f$User$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/Context/User.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
var strExt = "ext";
var strTags = "tags";
function _removeEmpty(target, name) {
    if (target && target[name] && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objKeys"])(target[name]).length === 0) {
        delete target[name];
    }
}
function _nullResult() {
    return null;
}
var TelemetryContext = function() {
    function TelemetryContext(core, defaultConfig, previousTraceCtx, unloadHookContainer) {
        var _this = this;
        var logger = core.logger;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(TelemetryContext, this, function(_self) {
            _self.appId = _nullResult;
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_SESSION_ID"] /* @min:%2egetSessionId */ ] = _nullResult;
            _self.application = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$Context$2f$Application$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Application"]();
            _self.internal = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$Context$2f$Internal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Internal"](defaultConfig, unloadHookContainer);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasWindow"])()) {
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SESSION_MANAGER"] /* @min:%2esessionManager */ ] = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$Context$2f$Session$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_SessionManager"](defaultConfig, core, unloadHookContainer);
                _self.device = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$Context$2f$Device$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Device"]();
                _self.location = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$Context$2f$Location$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Location"]();
                _self.user = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$Context$2f$User$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["User"](defaultConfig, core, unloadHookContainer);
                var traceId = void 0;
                var parentId = void 0;
                var name_1;
                if (previousTraceCtx) {
                    traceId = previousTraceCtx.getTraceId();
                    parentId = previousTraceCtx.getSpanId();
                    name_1 = previousTraceCtx.getName();
                }
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TELEMETRY_TRACE"] /* @min:%2etelemetryTrace */ ] = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$Context$2f$TelemetryTrace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TelemetryTrace"](traceId, parentId, name_1, logger);
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SESSION"] /* @min:%2esession */ ] = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$Context$2f$Session$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Session"]();
            }
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_SESSION_ID"] /* @min:%2egetSessionId */ ] = function() {
                var session = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SESSION"] /* @min:%2esession */ ];
                var sesId = null;
                // If customer set session info, apply their context; otherwise apply context automatically generated
                if (session && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(session.id)) {
                    sesId = session.id;
                } else {
                    // Gets the automatic session if it exists or an empty object
                    var autoSession = (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SESSION_MANAGER"] /* @min:%2esessionManager */ ] || {})[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTOMATIC_SESSION"] /* @min:%2eautomaticSession */ ];
                    sesId = autoSession && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(autoSession.id) ? autoSession.id : null;
                }
                return sesId;
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY_SESSION_CONTEX0"] /* @min:%2eapplySessionContext */ ] = function(evt, itemCtx) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSetValue"])(evt.ext, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extensions"].AppExt), "sesId", _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_SESSION_ID"] /* @min:%2egetSessionId */ ](), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"]);
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY_OPERATING_SYST3"] /* @min:%2eapplyOperatingSystemContxt */ ] = function(evt, itemCtx) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(evt.ext, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extensions"].OSExt, _self.os);
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY_APPLICATION_CO1"] /* @min:%2eapplyApplicationContext */ ] = function(evt, itemCtx) {
                var application = _self.application;
                if (application) {
                    // evt.ext.app
                    var tags = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSetValue"])(evt, strTags);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(tags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].applicationVersion, application.ver, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"]);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(tags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].applicationBuild, application.build, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"]);
                }
            };
            _self.applyDeviceContext = function(evt, itemCtx) {
                var device = _self.device;
                if (device) {
                    // evt.ext.device
                    var extDevice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSetValue"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSetValue"])(evt, strExt), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extensions"].DeviceExt);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(extDevice, "localId", device.id, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"]);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(extDevice, "ip", device.ip, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"]);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(extDevice, "model", device.model, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"]);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(extDevice, "deviceClass", device.deviceClass, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"]);
                }
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY_INTERNAL_CONTE5"] /* @min:%2eapplyInternalContext */ ] = function(evt, itemCtx) {
                var internal = _self.internal;
                if (internal) {
                    var tags = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSetValue"])(evt, strTags);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(tags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].internalAgentVersion, internal.agentVersion, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"]); // not mapped in CS 4.0
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(tags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].internalSdkVersion, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$DataSanitizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dataSanitizeString"])(logger, internal.sdkVersion, 64), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"]);
                    if (evt.baseType === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_InternalLogMessage"].dataType || evt.baseType === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageView"].dataType) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(tags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].internalSnippet, internal.snippetVer, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"]);
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(tags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].internalSdkSrc, internal.sdkSrc, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"]);
                    }
                }
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY_LOCATION_CONTE4"] /* @min:%2eapplyLocationContext */ ] = function(evt, itemCtx) {
                var location = _this.location;
                if (location) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSetValue"])(evt, strTags, []), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].locationIp, location.ip, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"]);
                }
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY_OPERATION_CONT2"] /* @min:%2eapplyOperationContext */ ] = function(evt, itemCtx) {
                var telemetryTrace = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TELEMETRY_TRACE"] /* @min:%2etelemetryTrace */ ];
                if (telemetryTrace) {
                    var extTrace = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSetValue"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSetValue"])(evt, strExt), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extensions"].TraceExt, {
                        traceID: undefined,
                        parentID: undefined
                    });
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(extTrace, "traceID", telemetryTrace.traceID, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"]);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(extTrace, "name", telemetryTrace.name, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"]);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(extTrace, "parentID", telemetryTrace.parentID, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"]);
                }
            };
            _self.applyWebContext = function(evt, itemCtx) {
                var web = _this.web;
                if (web) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSetValue"])(evt, strExt), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extensions"].WebExt, web);
                }
            };
            _self.applyUserContext = function(evt, itemCtx) {
                var user = _self.user;
                if (user) {
                    var tags = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSetValue"])(evt, strTags, []);
                    // stays in tags
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(tags, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtxTagKeys"].userAccountId, user[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ACCOUNT_ID"] /* @min:%2eaccountId */ ], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"]);
                    // CS 4.0
                    var extUser = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSetValue"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSetValue"])(evt, strExt), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extensions"].UserExt);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(extUser, "id", user.id, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"]);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(extUser, "authId", user[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTHENTICATED_ID"] /* @min:%2eauthenticatedId */ ], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"]);
                }
            };
            _self.cleanUp = function(evt, itemCtx) {
                var ext = evt.ext;
                if (ext) {
                    _removeEmpty(ext, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extensions"].DeviceExt);
                    _removeEmpty(ext, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extensions"].UserExt);
                    _removeEmpty(ext, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extensions"].WebExt);
                    _removeEmpty(ext, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extensions"].OSExt);
                    _removeEmpty(ext, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extensions"].AppExt);
                    _removeEmpty(ext, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extensions"].TraceExt);
                }
            };
        });
    }
    // Removed Stub for TelemetryContext.prototype.applySessionContext.
    // Removed Stub for TelemetryContext.prototype.applyOperatingSystemContxt.
    // Removed Stub for TelemetryContext.prototype.applyApplicationContext.
    // Removed Stub for TelemetryContext.prototype.applyDeviceContext.
    // Removed Stub for TelemetryContext.prototype.applyInternalContext.
    // Removed Stub for TelemetryContext.prototype.applyLocationContext.
    // Removed Stub for TelemetryContext.prototype.applyOperationContext.
    // Removed Stub for TelemetryContext.prototype.applyWebContext.
    // Removed Stub for TelemetryContext.prototype.applyUserContext.
    // Removed Stub for TelemetryContext.prototype.cleanUp.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    TelemetryContext.__ieDyn = 1;
    return TelemetryContext;
}();
;
 //# sourceMappingURL=TelemetryContext.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/PropertiesPlugin.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Properties Plugin, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ /**
* PropertiesPlugin.ts
* @copyright Microsoft 2018
*/ __turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-shims@3.0.1/node_modules/@microsoft/applicationinsights-shims/dist-es5/TsLibShims.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$applicationinsights$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/applicationinsights-common.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/PageView.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/StorageHelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$BaseTelemetryPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/BaseTelemetryPlugin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/ProcessTelemetryContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicConfig.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$TelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/TelemetryContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var _a;
;
;
;
;
;
;
;
var undefString;
var nullValue = null;
var _defaultConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDeepFreeze"])((_a = {
    accountId: nullValue,
    sessionRenewalMs: 30 * 60 * 1000,
    samplingPercentage: 100,
    sessionExpirationMs: 24 * 60 * 60 * 1000,
    cookieDomain: nullValue,
    sdkExtension: nullValue,
    isBrowserLinkTrackingEnabled: false,
    appId: nullValue
}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_SESSION_ID"] /* @min:getSessionId */ ] = nullValue, _a.namePrefix = undefString, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SESSION_COOKIE_POSTF6"] /* @min:sessionCookiePostfix */ ] = undefString, _a.userCookiePostfix = undefString, _a.idLength = 22, _a.getNewId = nullValue, _a));
var PropertiesPlugin = function(_super) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__extendsFn"])(PropertiesPlugin, _super);
    function PropertiesPlugin() {
        var _this = _super.call(this) || this;
        _this.priority = 110;
        _this.identifier = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$applicationinsights$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PropertiesPluginIdentifier"];
        var _extensionConfig;
        var _distributedTraceCtx;
        var _previousTraceCtx;
        var _context;
        var _disableUserInitMessage;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(PropertiesPlugin, _this, function(_self, _base) {
            _initDefaults();
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "context", {
                g: function() {
                    return _context;
                }
            });
            _self.initialize = function(config, core, extensions, pluginChain) {
                _base.initialize(config, core, extensions, pluginChain);
                _populateDefaults(config);
            };
            /**
             * Add Part A fields to the event
             * @param event - The event that needs to be processed
             */ _self.processTelemetry = function(event, itemCtx) {
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(event)) {
                    itemCtx = _self._getTelCtx(itemCtx);
                    // If the envelope is PageView, reset the internal message count so that we can send internal telemetry for the new page.
                    if (event.name === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageView"].envelopeType) {
                        itemCtx.diagLog().resetInternalMessageCount();
                    }
                    var theContext = _context || {};
                    if (theContext[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SESSION"] /* @min:%2esession */ ]) {
                        // If customer did not provide custom session id update the session manager
                        if (typeof _context[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SESSION"] /* @min:%2esession */ ].id !== "string" && theContext[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SESSION_MANAGER"] /* @min:%2esessionManager */ ]) {
                            theContext[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SESSION_MANAGER"] /* @min:%2esessionManager */ ].update();
                        }
                    }
                    var userCtx = theContext.user;
                    if (userCtx && !userCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_USER_COOKIE_SET"] /* @min:%2eisUserCookieSet */ ]) {
                        userCtx.update(theContext.user.id);
                    }
                    _processTelemetryInternal(event, itemCtx);
                    if (userCtx && userCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_NEW_USER"] /* @min:%2eisNewUser */ ]) {
                        userCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_NEW_USER"] /* @min:%2eisNewUser */ ] = false;
                        if (!_disableUserInitMessage) {
                            var message = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_InternalLogMessage"](72 /* _eInternalMessageId.SendBrowserInfoOnUserInit */ , ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNavigator"])() || {}).userAgent || "");
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_logInternalMessage"])(itemCtx.diagLog(), 1 /* eLoggingSeverity.CRITICAL */ , message);
                        }
                    }
                    _self.processNext(event, itemCtx);
                }
            };
            _self._doTeardown = function(unloadCtx, unloadState) {
                var core = (unloadCtx || {}).core();
                if (core && core[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_TRACE_CTX"] /* @min:%2egetTraceCtx */ ]) {
                    var traceCtx = core[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_TRACE_CTX"] /* @min:%2egetTraceCtx */ ](false);
                    if (traceCtx === _distributedTraceCtx) {
                        core.setTraceCtx(_previousTraceCtx);
                    }
                }
                _initDefaults();
            };
            function _initDefaults() {
                _extensionConfig = null;
                _distributedTraceCtx = null;
                _previousTraceCtx = null;
                _context = null;
                _disableUserInitMessage = true;
            }
            function _populateDefaults(config) {
                var identifier = _self.identifier;
                var core = _self.core;
                // This function will be re-called whenever any referenced configuration is changed
                _self._addHook((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onConfigChange"])(config, function() {
                    var ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProcessTelemetryContext"])(null, config, core);
                    if (config.storagePrefix) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlSetStoragePrefix"])(config.storagePrefix);
                    }
                    _disableUserInitMessage = config.disableUserInitMessage === false ? false : true;
                    _extensionConfig = ctx.getExtCfg(identifier, _defaultConfig);
                    // Test hook to allow accessing the internal values -- explicitly not defined as an available property on the class
                    _self["_extConfig"] = _extensionConfig;
                }));
                // This is outside of the onConfigChange as we don't want to update (replace) these values whenever a referenced config item changes
                _previousTraceCtx = core[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_TRACE_CTX"] /* @min:%2egetTraceCtx */ ](false);
                _context = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$TelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TelemetryContext"](core, _extensionConfig, _previousTraceCtx, _self._unloadHooks);
                _distributedTraceCtx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDistributedTraceContextFromTrace"])(_self.context[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TELEMETRY_TRACE"] /* @min:%2etelemetryTrace */ ], _previousTraceCtx);
                core.setTraceCtx(_distributedTraceCtx);
                _self.context.appId = function() {
                    var breezeChannel = core.getPlugin(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$applicationinsights$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["BreezeChannelIdentifier"]);
                    return breezeChannel ? breezeChannel.plugin["_appId"] : null;
                };
            }
            function _processTelemetryInternal(evt, itemCtx) {
                // Set Part A fields
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSetValue"])(evt, "tags", []);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSetValue"])(evt, "ext", {});
                var ctx = _self.context;
                ctx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY_SESSION_CONTEX0"] /* @min:%2eapplySessionContext */ ](evt, itemCtx);
                ctx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY_APPLICATION_CO1"] /* @min:%2eapplyApplicationContext */ ](evt, itemCtx);
                ctx.applyDeviceContext(evt, itemCtx);
                ctx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY_OPERATION_CONT2"] /* @min:%2eapplyOperationContext */ ](evt, itemCtx);
                ctx.applyUserContext(evt, itemCtx);
                ctx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY_OPERATING_SYST3"] /* @min:%2eapplyOperatingSystemContxt */ ](evt, itemCtx);
                ctx.applyWebContext(evt, itemCtx);
                ctx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY_LOCATION_CONTE4"] /* @min:%2eapplyLocationContext */ ](evt, itemCtx); // legacy tags
                ctx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY_INTERNAL_CONTE5"] /* @min:%2eapplyInternalContext */ ](evt, itemCtx); // legacy tags
                ctx.cleanUp(evt, itemCtx);
            }
        });
        return _this;
    }
    // Removed Stub for PropertiesPlugin.prototype.initialize.
    // Removed Stub for PropertiesPlugin.prototype.processTelemetry.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    PropertiesPlugin.__ieDyn = 1;
    return PropertiesPlugin;
}(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$BaseTelemetryPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseTelemetryPlugin"]);
const __TURBOPACK__default__export__ = PropertiesPlugin;
 //# sourceMappingURL=PropertiesPlugin.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/PropertiesPlugin.js [app-client] (ecmascript) <export default as PropertiesPlugin>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PropertiesPlugin",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$PropertiesPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$properties$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$properties$2d$js$2f$dist$2d$es5$2f$PropertiesPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-properties-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-properties-js/dist-es5/PropertiesPlugin.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=f6fcc_%40microsoft_applicationinsights-properties-js_dist-es5_91cb4896._.js.map