import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

/**
 * Service configuration interface
 */
interface OAuthProviderConfig {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
  authorizationUrl: string;
  tokenUrl: string;
  userInfoUrl: string;
  scope: string;
}

export interface ServiceConfig {
  // Server
  port: number;
  host: string;
  nodeEnv: 'development' | 'staging' | 'production';
  logLevel: 'fatal' | 'error' | 'warn' | 'info' | 'debug' | 'trace';

  // API
  api: {
    publicUrl: string;
  };

  // Frontend (used for invitation links)
  frontend: {
    baseUrl: string;
  };

  // Redis
  redis: {
    host: string;
    port: number;
    username?: string;
    password?: string;
    tls: boolean;
    db: number;
    maxRetriesPerRequest: number;
    connectTimeout: number;
    retryStrategy?: (times: number) => number | void;
  };

  // JWT Configuration
  jwt: {
    validationCacheEnabled: boolean;
    validationCacheTTL: number;
    accessTokenSecret: string;
    accessTokenExpiry: string;
    refreshTokenSecret: string;
    refreshTokenExpiry: string;
    issuer: string;
    audience?: string;
  };

  oauth: {
    google: OAuthProviderConfig;
    github: OAuthProviderConfig;
    microsoft: OAuthProviderConfig;
  };

  // Cosmos DB
  cosmosDb: {
    endpoint: string;
    key: string;
    databaseId: string;
    containers: {
      shards: string;
      shardTypes: string;
      revisions: string;
      roles: string;
      users: string;
      tenants: string;
      ssoConfigs: string;
      oauth2Clients: string;
        joinRequests: string;
        tenantInvitations: string;
    };
  };

  // Monitoring
  monitoring: {
    enabled: boolean;
    provider: 'application-insights' | 'mock';
    instrumentationKey?: string;
    samplingRate: number;
  };

  // CORS
  cors: {
    origin: string | string[] | boolean;
    credentials: boolean;
  };

  // GraphQL
  graphql: {
    enabled: boolean;
    playground: boolean;
    path: string;
  };

  // Email settings
  email: {
    provider: 'console' | 'resend' | 'azure-acs';
    fromEmail: string;
    fromName: string;
    resend?: { apiKey: string };
    azureAcs?: { connectionString: string };
  };

  // Resend email settings (legacy - use email config instead)
  resend: {
    apiKey: string;
    fromEmail: string;
    fromName: string;
  };

  // Tenant membership / invitation settings
  membership: {
    invitations: {
      defaultExpiryDays: number;
      minExpiryDays: number;
      maxExpiryDays: number;
      reminderLeadHours: number;
      lifecycleIntervalMs: number;
      perTenantDailyLimit: number;
      perAdminDailyLimit: number;
      expiringSoonHours: number;
    };
  };

  // Embedding Job Configuration
  embeddingJob: {
    enabled: boolean;
    ignoredShardTypes: string[];
  };

  // Azure Service Bus
  serviceBus?: {
    connectionString: string;
    embeddingQueueName: string;
    useAdministrationClient: boolean;
  };
}

/**
 * Load and validate environment configuration
 */
export function loadConfig(): ServiceConfig {
  const defaultApiBaseUrl = process.env.PUBLIC_API_BASE_URL || `http://localhost:${process.env.PORT || '3000'}`;

  const config: ServiceConfig = {
    // Server configuration
    port: parseInt(process.env.PORT || '3000', 10),
    host: process.env.HOST || '0.0.0.0',
    nodeEnv: (process.env.NODE_ENV as any) || 'development',
    logLevel: (process.env.LOG_LEVEL as any) || 'info',

    api: {
      publicUrl: process.env.PUBLIC_API_BASE_URL || defaultApiBaseUrl,
    },

    frontend: {
      baseUrl:
        process.env.FRONTEND_URL ||
        process.env.PUBLIC_APP_BASE_URL ||
        process.env.NEXT_PUBLIC_APP_URL ||
        process.env.NEXT_PUBLIC_SITE_URL ||
        defaultApiBaseUrl,
    },

    // Redis configuration
    redis: {
      host: process.env.REDIS_HOST || 'localhost',
      port: parseInt(process.env.REDIS_PORT || '6379', 10),
      username: process.env.REDIS_USERNAME,
      password: process.env.REDIS_PASSWORD,
      tls: process.env.REDIS_TLS === 'true',
      db: parseInt(process.env.REDIS_DB || '0', 10),
      maxRetriesPerRequest: 3,
      connectTimeout: 10000,
      retryStrategy: (times: number) => {
        if (times > 10) {
          return undefined; // Stop retrying
        }
        return Math.min(times * 50, 2000);
      },
    },

    // JWT configuration
    jwt: {
      validationCacheEnabled: process.env.JWT_VALIDATION_CACHE_ENABLED !== 'false',
      validationCacheTTL: parseInt(process.env.JWT_VALIDATION_CACHE_TTL || '300', 10), // 5 minutes
      accessTokenSecret: process.env.JWT_ACCESS_SECRET || '',
      accessTokenExpiry: process.env.JWT_ACCESS_TOKEN_EXPIRY || '15m',
      refreshTokenSecret: process.env.JWT_REFRESH_SECRET || process.env.JWT_REFRESH_TOKEN_SECRET || '',
      refreshTokenExpiry: process.env.JWT_REFRESH_TOKEN_EXPIRY || '7d',
      issuer: process.env.JWT_ISSUER || 'castiel',
      audience: process.env.JWT_AUDIENCE,
    },

    oauth: {
      google: {
        clientId:
          process.env.GOOGLE_CLIENT_ID ||
          process.env.OAUTH_GOOGLE_CLIENT_ID ||
          '',
        clientSecret:
          process.env.GOOGLE_CLIENT_SECRET ||
          process.env.OAUTH_GOOGLE_CLIENT_SECRET ||
          '',
        redirectUri:
          process.env.GOOGLE_REDIRECT_URI ||
          process.env.OAUTH_GOOGLE_REDIRECT_URI ||
          `${defaultApiBaseUrl}/auth/google/callback`,
        authorizationUrl:
          process.env.GOOGLE_AUTHORIZATION_URL ||
          'https://accounts.google.com/o/oauth2/v2/auth',
        tokenUrl:
          process.env.GOOGLE_TOKEN_URL ||
          'https://oauth2.googleapis.com/token',
        userInfoUrl:
          process.env.GOOGLE_USERINFO_URL ||
          'https://openidconnect.googleapis.com/v1/userinfo',
        scope: process.env.GOOGLE_OAUTH_SCOPE || 'openid email profile',
      },
      github: {
        clientId:
          process.env.GITHUB_CLIENT_ID ||
          process.env.OAUTH_GITHUB_CLIENT_ID ||
          '',
        clientSecret:
          process.env.GITHUB_CLIENT_SECRET ||
          process.env.OAUTH_GITHUB_CLIENT_SECRET ||
          '',
        redirectUri:
          process.env.GITHUB_REDIRECT_URI ||
          process.env.OAUTH_GITHUB_REDIRECT_URI ||
          `${defaultApiBaseUrl}/auth/github/callback`,
        authorizationUrl:
          process.env.GITHUB_AUTHORIZATION_URL ||
          'https://github.com/login/oauth/authorize',
        tokenUrl:
          process.env.GITHUB_TOKEN_URL ||
          'https://github.com/login/oauth/access_token',
        userInfoUrl:
          process.env.GITHUB_USERINFO_URL ||
          'https://api.github.com/user',
        scope: process.env.GITHUB_OAUTH_SCOPE || 'read:user user:email',
      },
      microsoft: {
        clientId:
          process.env.MICROSOFT_CLIENT_ID ||
          process.env.OAUTH_MICROSOFT_CLIENT_ID ||
          '',
        clientSecret:
          process.env.MICROSOFT_CLIENT_SECRET ||
          process.env.OAUTH_MICROSOFT_CLIENT_SECRET ||
          '',
        redirectUri:
          process.env.MICROSOFT_REDIRECT_URI ||
          process.env.OAUTH_MICROSOFT_REDIRECT_URI ||
          `${defaultApiBaseUrl}/auth/microsoft/callback`,
        authorizationUrl:
          process.env.MICROSOFT_AUTHORIZATION_URL ||
          'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
        tokenUrl:
          process.env.MICROSOFT_TOKEN_URL ||
          'https://login.microsoftonline.com/common/oauth2/v2.0/token',
        userInfoUrl:
          process.env.MICROSOFT_USERINFO_URL ||
          'https://graph.microsoft.com/v1.0/me',
        scope: process.env.MICROSOFT_OAUTH_SCOPE || 'openid email profile User.Read',
      },
    },

    // Cosmos DB configuration
    cosmosDb: {
      endpoint: process.env.COSMOS_DB_ENDPOINT || '',
      key: process.env.COSMOS_DB_KEY || '',
      databaseId: process.env.COSMOS_DB_DATABASE_ID || 'castiel',
      containers: {
        shards: process.env.COSMOS_DB_SHARDS_CONTAINER || 'shards',
        shardTypes: process.env.COSMOS_DB_SHARD_TYPES_CONTAINER || 'shard-types',
        revisions: process.env.COSMOS_DB_REVISIONS_CONTAINER || 'revisions',
        roles: process.env.COSMOS_DB_ROLES_CONTAINER || 'roles',
        users: process.env.COSMOS_DB_USERS_CONTAINER || 'users',
        tenants: process.env.COSMOS_DB_TENANTS_CONTAINER || 'tenants',
        ssoConfigs: process.env.COSMOS_DB_SSO_CONFIGS_CONTAINER || 'sso-configs',
        oauth2Clients: process.env.COSMOS_DB_OAUTH2_CLIENTS_CONTAINER || 'oauth2-clients',
        joinRequests: process.env.COSMOS_DB_JOIN_REQUESTS_CONTAINER || 'tenant-join-requests',
        tenantInvitations: process.env.COSMOS_DB_TENANT_INVITATIONS_CONTAINER || 'tenant-invitations',
      },
    },

    // Monitoring configuration
    monitoring: {
      enabled: process.env.MONITORING_ENABLED === 'true',
      provider: (process.env.MONITORING_PROVIDER as any) || 'mock',
      instrumentationKey: process.env.APPINSIGHTS_INSTRUMENTATION_KEY,
      samplingRate: parseFloat(process.env.MONITORING_SAMPLING_RATE || '1.0'),
    },

    // CORS configuration
    cors: {
      origin: process.env.CORS_ORIGIN || true,
      credentials: process.env.CORS_CREDENTIALS === 'true',
    },

    // GraphQL configuration
    graphql: {
      enabled: process.env.GRAPHQL_ENABLED !== 'false',
      playground: process.env.GRAPHQL_PLAYGROUND !== 'false',
      path: process.env.GRAPHQL_PATH || '/graphql',
    },

    // Unified email configuration
    email: {
      provider: (process.env.EMAIL_PROVIDER as any) || 'console',
      fromEmail: process.env.EMAIL_FROM_ADDRESS || process.env.RESEND_FROM_EMAIL || 'no-reply@castiel.local',
      fromName: process.env.EMAIL_FROM_NAME || process.env.RESEND_FROM_NAME || 'Castiel',
      resend: process.env.RESEND_API_KEY ? {
        apiKey: process.env.RESEND_API_KEY,
      } : undefined,
      azureAcs: process.env.AZURE_ACS_CONNECTION_STRING ? {
        connectionString: process.env.AZURE_ACS_CONNECTION_STRING,
      } : undefined,
    },

    // Legacy resend config (for backward compatibility)
    resend: {
      apiKey: process.env.RESEND_API_KEY || '',
      fromEmail: process.env.RESEND_FROM_EMAIL || 'no-reply@castiel.local',
      fromName: process.env.RESEND_FROM_NAME || 'Castiel',
    },

    membership: {
      invitations: {
        defaultExpiryDays: parseInt(process.env.INVITE_DEFAULT_EXPIRY_DAYS || '7', 10),
        minExpiryDays: parseInt(process.env.INVITE_MIN_EXPIRY_DAYS || '1', 10),
        maxExpiryDays: parseInt(process.env.INVITE_MAX_EXPIRY_DAYS || '30', 10),
        reminderLeadHours: parseInt(process.env.INVITE_REMINDER_LEAD_HOURS || '48', 10),
        lifecycleIntervalMs: parseInt(process.env.INVITE_LIFECYCLE_INTERVAL_MS || `${15 * 60 * 1000}`, 10),
        perTenantDailyLimit: parseInt(process.env.INVITE_PER_TENANT_DAILY_LIMIT || '100', 10),
        perAdminDailyLimit: parseInt(process.env.INVITE_PER_ADMIN_DAILY_LIMIT || '20', 10),
        expiringSoonHours: parseInt(process.env.INVITE_EXPIRING_SOON_HOURS || '72', 10),
      },
    },

    // Embedding Job configuration
    embeddingJob: {
      enabled: process.env.EMBEDDING_JOB_ENABLED !== 'false',
      ignoredShardTypes: (process.env.EMBEDDING_JOB_IGNORED_SHARD_TYPES || 'c_dashboardVersion,c_dashboard')
        .split(',')
        .map(t => t.trim())
        .filter(Boolean),
    },

    // Azure Service Bus configuration
    serviceBus: process.env.AZURE_SERVICE_BUS_CONNECTION_STRING ? {
      connectionString: process.env.AZURE_SERVICE_BUS_CONNECTION_STRING,
      embeddingQueueName: process.env.AZURE_SERVICE_BUS_EMBEDDING_QUEUE || 'embedding-jobs',
      useAdministrationClient: process.env.AZURE_SERVICE_BUS_USE_ADMIN_CLIENT === 'true',
    } : undefined,
  };

  // Validate required configuration
  validateConfig(config);

  return config;
}

/**
 * Validate configuration
 */
function validateConfig(config: ServiceConfig): void {
  const errors: string[] = [];

  // Validate port
  if (isNaN(config.port) || config.port < 1 || config.port > 65535) {
    errors.push('Invalid PORT: must be between 1 and 65535');
  }

  // Validate Redis configuration
  if (!config.redis.host) {
    errors.push('REDIS_HOST is required');
  }

  if (isNaN(config.redis.port) || config.redis.port < 1 || config.redis.port > 65535) {
    errors.push('Invalid REDIS_PORT: must be between 1 and 65535');
  }

  // Validate JWT secrets
  if (!config.jwt.accessTokenSecret) {
    errors.push('JWT_ACCESS_SECRET is required');
  }

  // Validate Cosmos DB configuration
  if (!config.cosmosDb.endpoint) {
    errors.push('COSMOS_DB_ENDPOINT is required');
  }

  if (!config.cosmosDb.key) {
    errors.push('COSMOS_DB_KEY is required');
  }

  if (!config.cosmosDb.containers.users) {
    errors.push('COSMOS_DB_USERS_CONTAINER is required');
  }

  if (!config.cosmosDb.containers.roles) {
    errors.push('COSMOS_DB_ROLES_CONTAINER is required');
  }

  if (!config.cosmosDb.containers.tenants) {
    errors.push('COSMOS_DB_TENANTS_CONTAINER is required');
  }

  if (!config.cosmosDb.containers.joinRequests) {
    errors.push('COSMOS_DB_JOIN_REQUESTS_CONTAINER is required');
  }

  if (!config.cosmosDb.containers.tenantInvitations) {
    errors.push('COSMOS_DB_TENANT_INVITATIONS_CONTAINER is required');
  }

  // Validate monitoring configuration
  if (config.monitoring.enabled && config.monitoring.provider === 'application-insights') {
    if (!config.monitoring.instrumentationKey) {
      errors.push('APPINSIGHTS_INSTRUMENTATION_KEY is required when monitoring is enabled');
    }
  }

  if (errors.length > 0) {
    throw new Error(`Configuration validation failed:\n${errors.join('\n')}`);
  }

  const invitationConfig = config.membership.invitations;
  if (invitationConfig.minExpiryDays <= 0) {
    throw new Error('INVITE_MIN_EXPIRY_DAYS must be greater than 0');
  }
  if (invitationConfig.maxExpiryDays < invitationConfig.minExpiryDays) {
    throw new Error('INVITE_MAX_EXPIRY_DAYS must be >= INVITE_MIN_EXPIRY_DAYS');
  }
  if (invitationConfig.defaultExpiryDays < invitationConfig.minExpiryDays || invitationConfig.defaultExpiryDays > invitationConfig.maxExpiryDays) {
    throw new Error('INVITE_DEFAULT_EXPIRY_DAYS must be between INVITE_MIN_EXPIRY_DAYS and INVITE_MAX_EXPIRY_DAYS');
  }
  if (invitationConfig.perTenantDailyLimit <= 0) {
    throw new Error('INVITE_PER_TENANT_DAILY_LIMIT must be greater than 0');
  }
  if (invitationConfig.perAdminDailyLimit <= 0) {
    throw new Error('INVITE_PER_ADMIN_DAILY_LIMIT must be greater than 0');
  }
}

/**
 * Export singleton instance
 */
export const config = loadConfig();
