module.exports=[88915,(a,b,c)=>{}];

//# sourceMappingURL=c2a1c_frontend__next-internal_server_app_%28protected%29_audit_page_actions_93178ab7.js.map