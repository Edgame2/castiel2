# Continuous Learning for Risk Analysis ML

## Overview

The continuous learning system enables the Risk Analysis ML models to improve over time by collecting feedback, tracking outcomes, and automatically retraining models when performance degrades. This document describes the feedback loops, learning processes, and improvement mechanisms.

## Continuous Learning Architecture

```mermaid
flowchart TB
    subgraph "Feedback Collection"
        UF[User Feedback]
        OC[Outcome Tracking]
        MA[Mitigation Actions]
        PR[Prediction Results]
    end
    
    subgraph "Feedback Processing"
        FP[Feedback Processor]
        VA[Validation & Aggregation]
        FS[Feedback Storage]
    end
    
    subgraph "Learning Engine"
        PA[Pattern Analysis]
        PM[Performance Monitoring]
        DT[Drift Detection]
        RT[Retraining Trigger]
    end
    
    subgraph "Model Improvement"
        TR[Training Retrigger]
        HP[Hyperparameter Optimization]
        FE[Feature Engineering Updates]
        MD[Model Deployment]
    end
    
    UF --> FP
    OC --> FP
    MA --> FP
    PR --> FP
    
    FP --> VA
    VA --> FS
    
    FS --> PA
    FS --> PM
    PM --> DT
    DT --> RT
    
    RT --> TR
    TR --> HP
    HP --> FE
    FE --> MD
    
    MD --> PR
```

## Feedback Collection

### User Feedback Types

```typescript
interface RiskFeedback {
  id: string;
  tenantId: string;
  userId: string;
  opportunityId: string;
  riskId: string;
  
  // Feedback type
  feedbackType: 'acknowledge' | 'dismiss' | 'correct' | 'mitigate' | 'rating';
  
  // Feedback data
  action: 'acknowledged' | 'dismissed' | 'corrected' | 'mitigated';
  rating?: number;                  // 1-5 rating
  comment?: string;
  
  // Context
  predictedRisk: DetectedRisk;      // What was predicted
  actualRisk?: DetectedRisk;        // What was actual (if corrected)
  mitigationAction?: string;        // Mitigation action taken
  
  // Metadata
  timestamp: Date;
  modelVersion: string;             // Model version that made prediction
}
```

### Outcome Tracking

```typescript
interface RiskOutcome {
  id: string;
  opportunityId: string;
  tenantId: string;
  
  // Outcome
  outcome: 'won' | 'lost' | 'cancelled';
  outcomeDate: Date;
  finalValue?: number;              // Final deal value
  finalRevenue?: number;            // Final revenue
  
  // Risk predictions at different stages
  riskPredictions: Array<{
    snapshotDate: Date;
    predictedRiskScore: number;
    predictedOutcome: 'won' | 'lost' | null;
    modelVersion: string;
  }>;
  
  // Actual risk factors
  actualRisks: string[];             // Risk IDs that actually materialized
  actualRiskScore?: number;          // Actual risk score (calculated post-outcome)
  
  // Mitigation effectiveness
  mitigationEffectiveness: Record<string, number>; // Action -> effectiveness (0-1)
  
  createdAt: Date;
}
```

### Feedback Collection Service

```typescript
class RiskFeedbackService {
  async recordRiskFeedback(feedback: RiskFeedback): Promise<void> {
    // Store feedback
    await this.storeFeedback(feedback);
    
    // Update feedback statistics
    await this.updateFeedbackStats(feedback);
    
    // Check if enough feedback collected for learning
    if (await this.shouldTriggerLearning(feedback.riskId)) {
      await this.triggerLearning(feedback.riskId);
    }
  }
  
  async recordOutcome(outcome: RiskOutcome): Promise<void> {
    // Store outcome
    await this.storeOutcome(outcome);
    
    // Link to risk predictions
    await this.linkPredictionsToOutcome(outcome);
    
    // Calculate prediction accuracy
    await this.calculatePredictionAccuracy(outcome);
    
    // Check if retraining needed
    if (await this.shouldRetrain(outcome)) {
      await this.triggerRetraining();
    }
  }
  
  async getFeedbackForTraining(
    options: FeedbackTrainingOptions
  ): Promise<TrainingFeedback[]> {
    const feedback = await this.queryFeedback({
      startDate: options.startDate,
      endDate: options.endDate,
      tenantId: options.tenantId,
      minRating: options.minRating
    });
    
    const outcomes = await this.queryOutcomes({
      startDate: options.startDate,
      endDate: options.endDate,
      tenantId: options.tenantId
    });
    
    // Combine feedback and outcomes
    return this.combineFeedbackAndOutcomes(feedback, outcomes);
  }
}
```

## Performance Monitoring

### Model Performance Tracking

```typescript
interface ModelPerformance {
  modelId: string;
  modelType: ModelType;
  period: {
    startDate: Date;
    endDate: Date;
  };
  
  // Prediction metrics
  totalPredictions: number;
  accuratePredictions: number;
  inaccuratePredictions: number;
  
  // Accuracy metrics
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  
  // Error metrics
  mae: number;                       // Mean absolute error
  rmse: number;                      // Root mean squared error
  
  // Performance metrics
  avgLatency: number;
  p95Latency: number;
  errorRate: number;
  
  // Comparison with baseline
  improvementOverBaseline: number;
  
  calculatedAt: Date;
}

async function calculateModelPerformance(
  modelId: string,
  period: { startDate: Date; endDate: Date }
): Promise<ModelPerformance> {
  // Get predictions in period
  const predictions = await getPredictions(modelId, period);
  
  // Get actual outcomes
  const outcomes = await getOutcomesForPredictions(predictions);
  
  // Calculate metrics
  const metrics = calculateMetrics(predictions, outcomes);
  
  // Compare with baseline
  const baseline = await getBaselineModel(modelId);
  const baselineMetrics = await calculateModelPerformance(
    baseline.id,
    period
  );
  
  return {
    modelId,
    modelType: (await getModel(modelId)).modelType,
    period,
    ...metrics,
    improvementOverBaseline: calculateImprovement(metrics, baselineMetrics),
    calculatedAt: new Date()
  };
}
```

### Performance Degradation Detection

```typescript
async function detectPerformanceDegradation(
  modelId: string
): Promise<DegradationAlert | null> {
  const model = await getModel(modelId);
  
  // Get recent performance
  const recent = await calculateModelPerformance(modelId, {
    startDate: subDays(new Date(), 7),
    endDate: new Date()
  });
  
  // Get historical performance
  const historical = await calculateModelPerformance(modelId, {
    startDate: subDays(new Date(), 30),
    endDate: subDays(new Date(), 7)
  });
  
  // Check for degradation
  const accuracyDrop = historical.accuracy - recent.accuracy;
  const errorIncrease = recent.errorRate - historical.errorRate;
  
  if (accuracyDrop > 0.05 || errorIncrease > 0.1) {
    return {
      modelId,
      severity: accuracyDrop > 0.1 ? 'high' : 'medium',
      metrics: {
        accuracyDrop,
        errorIncrease,
        recent,
        historical
      },
      recommendation: 'Retrain model with recent data',
      detectedAt: new Date()
    };
  }
  
  return null;
}
```

## Model Drift Detection

### Data Drift Detection

```typescript
interface DataDrift {
  featureName: string;
  driftScore: number;                // 0-1, higher = more drift
  driftType: 'distribution' | 'mean' | 'variance' | 'correlation';
  pValue: number;                     // Statistical significance
  detectedAt: Date;
}

async function detectDataDrift(
  modelId: string
): Promise<DataDrift[]> {
  const model = await getModel(modelId);
  
  // Get training data distribution
  const trainingDistribution = await getTrainingDistribution(model);
  
  // Get recent production data
  const recentData = await getRecentProductionData(model, {
    days: 7
  });
  
  // Compare distributions for each feature
  const drifts: DataDrift[] = [];
  
  for (const feature of model.featureList) {
    const trainingDist = trainingDistribution[feature];
    const productionDist = getDistribution(recentData, feature);
    
    // Kolmogorov-Smirnov test
    const ksResult = kolmogorovSmirnovTest(
      trainingDist,
      productionDist
    );
    
    if (ksResult.pValue < 0.05) {
      drifts.push({
        featureName: feature,
        driftScore: ksResult.statistic,
        driftType: 'distribution',
        pValue: ksResult.pValue,
        detectedAt: new Date()
      });
    }
  }
  
  return drifts;
}
```

### Concept Drift Detection

```typescript
interface ConceptDrift {
  modelId: string;
  driftScore: number;
  detectedAt: Date;
  evidence: {
    accuracyDrop: number;
    errorPattern: string;
    affectedFeatures: string[];
  };
}

async function detectConceptDrift(
  modelId: string
): Promise<ConceptDrift | null> {
  // Get predictions and outcomes
  const predictions = await getRecentPredictions(modelId, { days: 14 });
  const outcomes = await getOutcomesForPredictions(predictions);
  
  // Calculate accuracy over time (sliding window)
  const accuracyOverTime = calculateAccuracyOverTime(
    predictions,
    outcomes,
    { windowSize: 7 }
  );
  
  // Detect trend
  const trend = calculateTrend(accuracyOverTime);
  
  if (trend.slope < -0.01 && trend.r2 > 0.7) {
    // Significant decreasing trend
    const affectedFeatures = await identifyAffectedFeatures(
      modelId,
      predictions,
      outcomes
    );
    
    return {
      modelId,
      driftScore: Math.abs(trend.slope),
      detectedAt: new Date(),
      evidence: {
        accuracyDrop: accuracyOverTime[0] - accuracyOverTime[accuracyOverTime.length - 1],
        errorPattern: analyzeErrorPattern(predictions, outcomes),
        affectedFeatures
      }
    };
  }
  
  return null;
}
```

## Learning from Feedback

### Weighted Training Examples

```typescript
function weightTrainingExamples(
  examples: TrainingExample[],
  feedback: RiskFeedback[]
): WeightedTrainingExample[] {
  // Create feedback map
  const feedbackMap = new Map<string, RiskFeedback[]>();
  for (const fb of feedback) {
    const key = `${fb.opportunityId}:${fb.riskId}`;
    if (!feedbackMap.has(key)) {
      feedbackMap.set(key, []);
    }
    feedbackMap.get(key)!.push(fb);
  }
  
  // Weight examples based on feedback
  return examples.map(example => {
    const key = `${example.opportunityId}:${example.riskId}`;
    const exampleFeedback = feedbackMap.get(key) || [];
    
    // Calculate weight
    let weight = 1.0;
    
    for (const fb of exampleFeedback) {
      switch (fb.action) {
        case 'acknowledged':
          // Increase weight for correct predictions
          weight *= 1.2;
          break;
        case 'dismissed':
          // Decrease weight for incorrect predictions
          weight *= 0.8;
          break;
        case 'corrected':
          // Significantly increase weight for corrections
          weight *= 1.5;
          break;
      }
      
      // Adjust based on rating
      if (fb.rating) {
        weight *= fb.rating / 3.0; // Normalize to 1.0
      }
    }
    
    return {
      ...example,
      weight: Math.max(0.1, Math.min(2.0, weight)) // Cap between 0.1 and 2.0
    };
  });
}
```

### Active Learning

```typescript
async function identifyUncertainPredictions(
  modelId: string,
  limit: number = 100
): Promise<UncertainPrediction[]> {
  // Get recent predictions with low confidence
  const predictions = await getRecentPredictions(modelId, {
    days: 7,
    minConfidence: 0,
    maxConfidence: 0.7 // Low confidence threshold
  });
  
  // Sort by uncertainty (distance from decision boundary)
  const uncertain = predictions
    .map(p => ({
      ...p,
      uncertainty: Math.abs(p.confidence - 0.5) // Distance from 0.5
    }))
    .sort((a, b) => a.uncertainty - b.uncertainty)
    .slice(0, limit);
  
  return uncertain;
}

async function requestFeedbackForUncertain(
  predictions: UncertainPrediction[]
): Promise<void> {
  // For each uncertain prediction, request expert feedback
  for (const prediction of predictions) {
    await createFeedbackRequest({
      opportunityId: prediction.opportunityId,
      riskId: prediction.riskId,
      prediction: prediction,
      reason: 'low_confidence',
      priority: 'high'
    });
  }
}
```

## Automatic Retraining

### Retraining Triggers

```typescript
interface RetrainingTrigger {
  type: 'scheduled' | 'performance_degradation' | 'data_drift' | 'concept_drift' | 'manual';
  modelId: string;
  reason: string;
  severity: 'low' | 'medium' | 'high';
  triggeredAt: Date;
}

async function checkRetrainingTriggers(): Promise<RetrainingTrigger[]> {
  const triggers: RetrainingTrigger[] = [];
  
  // Check all active models
  const models = await getActiveModels();
  
  for (const model of models) {
    // Check performance degradation
    const degradation = await detectPerformanceDegradation(model.id);
    if (degradation) {
      triggers.push({
        type: 'performance_degradation',
        modelId: model.id,
        reason: `Accuracy dropped by ${degradation.metrics.accuracyDrop}`,
        severity: degradation.severity,
        triggeredAt: new Date()
      });
    }
    
    // Check data drift
    const dataDrift = await detectDataDrift(model.id);
    if (dataDrift.length > 0 && dataDrift.some(d => d.driftScore > 0.3)) {
      triggers.push({
        type: 'data_drift',
        modelId: model.id,
        reason: `Data drift detected in ${dataDrift.length} features`,
        severity: 'medium',
        triggeredAt: new Date()
      });
    }
    
    // Check concept drift
    const conceptDrift = await detectConceptDrift(model.id);
    if (conceptDrift) {
      triggers.push({
        type: 'concept_drift',
        modelId: model.id,
        reason: `Concept drift detected: ${conceptDrift.evidence.accuracyDrop} accuracy drop`,
        severity: 'high',
        triggeredAt: new Date()
      });
    }
  }
  
  return triggers;
}
```

### Scheduled Retraining

```typescript
// Weekly retraining schedule
async function scheduleWeeklyRetraining(): Promise<void> {
  const models = await getActiveModels();
  
  for (const model of models) {
    // Check if enough new data
    const newDataCount = await getNewDataCount(model, {
      days: 7
    });
    
    if (newDataCount >= MIN_TRAINING_EXAMPLES) {
      await trainingService.scheduleTraining(model.modelType, {
        startDate: subDays(new Date(), 7),
        endDate: new Date(),
        trigger: 'scheduled',
        incremental: true // Use incremental training if supported
      });
    }
  }
}
```

### Incremental Learning

```typescript
async function incrementalRetrain(
  modelId: string,
  newData: TrainingExample[]
): Promise<TrainedModel> {
  const currentModel = await getModel(modelId);
  
  // Load current model
  const model = await loadModelById(modelId);
  
  // Prepare new data
  const preparedData = await prepareTrainingData(newData);
  
  // Incremental update (if model supports it)
  if (model.supportsIncrementalLearning) {
    await model.partialFit(preparedData.features, preparedData.labels);
  } else {
    // Full retrain with combined data
    const existingData = await getTrainingData(currentModel);
    const combinedData = [...existingData, ...newData];
    return await trainModel(currentModel.modelType, combinedData);
  }
  
  return model;
}
```

## Feedback Loop Metrics

### Learning Metrics

```typescript
interface LearningMetrics {
  period: {
    startDate: Date;
    endDate: Date;
  };
  
  // Feedback collection
  totalFeedback: number;
  feedbackByType: Record<string, number>;
  feedbackQuality: number;           // Average rating
  
  // Model improvement
  modelImprovements: Array<{
    modelId: string;
    improvement: number;
    metric: string;
  }>;
  
  // Retraining
  retrainingCount: number;
  retrainingTriggers: Record<string, number>;
  averageRetrainingTime: number;
  
  // Performance
  averageAccuracy: number;
  accuracyTrend: 'improving' | 'stable' | 'degrading';
  
  calculatedAt: Date;
}

async function calculateLearningMetrics(
  period: { startDate: Date; endDate: Date }
): Promise<LearningMetrics> {
  // Collect feedback statistics
  const feedback = await getFeedback(period);
  const outcomes = await getOutcomes(period);
  
  // Calculate model improvements
  const models = await getActiveModels();
  const improvements = await Promise.all(
    models.map(async model => {
      const improvement = await calculateModelImprovement(
        model.id,
        period
      );
      return {
        modelId: model.id,
        improvement: improvement.accuracyImprovement,
        metric: 'accuracy'
      };
    })
  );
  
  // Calculate retraining statistics
  const retrainingJobs = await getRetrainingJobs(period);
  
  return {
    period,
    totalFeedback: feedback.length,
    feedbackByType: groupBy(feedback, 'feedbackType'),
    feedbackQuality: calculateAverageRating(feedback),
    modelImprovements: improvements,
    retrainingCount: retrainingJobs.length,
    retrainingTriggers: groupBy(retrainingJobs, 'trigger'),
    averageRetrainingTime: calculateAverageTime(retrainingJobs),
    averageAccuracy: calculateAverageAccuracy(models, period),
    accuracyTrend: determineTrend(improvements),
    calculatedAt: new Date()
  };
}
```

## Best Practices

1. **Feedback Quality**: Prioritize high-quality feedback (expert corrections)
2. **Balanced Learning**: Balance new data with historical data
3. **Gradual Updates**: Use incremental learning when possible
4. **Validation**: Always validate improvements before deployment
5. **Monitoring**: Continuously monitor for drift and degradation
6. **Documentation**: Document all learning events and improvements
