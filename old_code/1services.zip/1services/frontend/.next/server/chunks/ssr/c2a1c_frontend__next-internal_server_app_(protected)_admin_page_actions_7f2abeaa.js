module.exports=[91136,(a,b,c)=>{}];

//# sourceMappingURL=c2a1c_frontend__next-internal_server_app_%28protected%29_admin_page_actions_7f2abeaa.js.map