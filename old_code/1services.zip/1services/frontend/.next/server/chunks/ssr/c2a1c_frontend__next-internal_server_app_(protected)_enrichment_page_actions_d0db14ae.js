module.exports=[88405,(a,b,c)=>{}];

//# sourceMappingURL=c2a1c_frontend__next-internal_server_app_%28protected%29_enrichment_page_actions_d0db14ae.js.map