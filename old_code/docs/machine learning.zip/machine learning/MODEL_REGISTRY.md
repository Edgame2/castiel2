# Model Registry and Versioning

## Overview

The Model Registry manages ML model versions, metadata, deployment status, and A/B testing configurations. This document describes the model versioning system, metadata management, and deployment procedures.

## Model Registry Architecture

```mermaid
flowchart TB
    subgraph "Model Storage"
        BLOB[Azure Blob Storage<br/>Model Artifacts]
        COSMOS[(Cosmos DB<br/>Model Metadata)]
        CACHE[Redis Cache<br/>Active Models]
    end
    
    subgraph "Model Service"
        REG[Model Registry]
        LOAD[Model Loader]
        VER[Version Manager]
        AB[A/B Test Manager]
    end
    
    subgraph "Deployment"
        PROD[Production Models]
        STAGING[Staging Models]
        TEST[Test Models]
    end
    
    BLOB --> REG
    COSMOS --> REG
    REG --> LOAD
    REG --> VER
    REG --> AB
    LOAD --> CACHE
    LOAD --> PROD
    AB --> STAGING
    VER --> TEST
```

## Model Metadata Schema

```typescript
interface RiskMLModel {
  // Identity
  id: string;                        // Unique model ID
  modelType: ModelType;              // 'risk_scoring' | 'outcome_prediction' | 'mitigation_recommendation' | 'llm_fine_tuned'
  version: string;                   // Semantic version (e.g., '1.2.3')
  name: string;                      // Human-readable name
  
  // Scope
  tenantId?: string;                 // null for global models
  scope: 'global' | 'tenant' | 'industry';
  industryId?: string;               // For industry-specific models
  
  // Training Information
  trainingDate: Date;
  trainingJobId: string;
  trainingExamples: number;
  validationExamples: number;
  testExamples: number;
  trainingDurationMs: number;
  
  // Model Artifacts
  artifactPath: string;              // Azure Blob Storage path
  artifactSize: number;               // Size in bytes
  artifactFormat: 'onnx' | 'pickle' | 'h5' | 'pkl' | 'jsonl'; // For LLMs
  checksum: string;                  // SHA-256 checksum
  
  // Performance Metrics
  metrics: {
    // Regression metrics (for risk_scoring)
    mse?: number;
    mae?: number;
    rmse?: number;
    r2Score?: number;
    
    // Classification metrics (for outcome_prediction)
    accuracy?: number;
    precision?: number;
    recall?: number;
    f1Score?: number;
    auc?: number;
    
    // Ranking metrics (for mitigation_recommendation)
    ndcg?: number;
    map?: number;
    
    // LLM metrics
    perplexity?: number;
    bleu?: number;
    
    // Common
    validationScore: number;          // Primary metric for comparison
    testScore: number;
  };
  
  // Feature Information
  featureSchema: FeatureSchema;      // Feature schema version
  featureList: string[];              // List of features used
  featureImportance?: Record<string, number>; // Feature importance scores
  
  // Status
  status: 'training' | 'evaluating' | 'staging' | 'active' | 'deprecated' | 'failed';
  isDefault: boolean;                 // Is this the default model for its type?
  
  // A/B Testing
  abTestTraffic: number;             // Percentage of traffic (0-100)
  abTestStartDate?: Date;
  abTestEndDate?: Date;
  abTestMetrics?: ABTestMetrics;
  
  // Deployment
  deployedAt?: Date;
  deployedBy?: string;
  deploymentEnvironment: 'test' | 'staging' | 'production';
  
  // Metadata
  description?: string;
  tags: string[];
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
  
  // Relationships
  parentModelId?: string;             // Parent model (for fine-tuned models)
  baseModel?: string;                 // Base model (for LLM fine-tuning)
}
```

## Model Versioning

### Semantic Versioning

Models use semantic versioning: `MAJOR.MINOR.PATCH`

- **MAJOR**: Breaking changes (incompatible feature schema, major algorithm change)
- **MINOR**: New features (new features added, performance improvements)
- **PATCH**: Bug fixes (bug fixes, minor improvements)

```typescript
function generateVersion(
  previousVersion: string | null,
  changeType: 'major' | 'minor' | 'patch'
): string {
  if (!previousVersion) {
    return '1.0.0';
  }
  
  const [major, minor, patch] = previousVersion.split('.').map(Number);
  
  switch (changeType) {
    case 'major':
      return `${major + 1}.0.0`;
    case 'minor':
      return `${major}.${minor + 1}.0`;
    case 'patch':
      return `${major}.${minor}.${patch + 1}`;
  }
}
```

### Version Comparison

```typescript
function compareVersions(v1: string, v2: string): number {
  const [m1, i1, p1] = v1.split('.').map(Number);
  const [m2, i2, p2] = v2.split('.').map(Number);
  
  if (m1 !== m2) return m1 - m2;
  if (i1 !== i2) return i1 - i2;
  return p1 - p2;
}

function getLatestVersion(models: RiskMLModel[]): RiskMLModel | null {
  if (models.length === 0) return null;
  
  return models.reduce((latest, current) => {
    return compareVersions(current.version, latest.version) > 0
      ? current
      : latest;
  });
}
```

## Model Registration

### Register New Model

```typescript
async function registerModel(
  model: TrainedModel,
  metadata: ModelMetadata
): Promise<RiskMLModel> {
  // Generate version
  const previousModel = await getLatestModel(model.modelType, metadata.tenantId);
  const version = generateVersion(
    previousModel?.version || null,
    metadata.changeType || 'minor'
  );
  
  // Upload model artifact
  const artifactPath = await uploadModelArtifact(model.artifact, {
    modelType: model.modelType,
    version,
    tenantId: metadata.tenantId
  });
  
  // Calculate checksum
  const checksum = await calculateChecksum(model.artifact);
  
  // Create model record
  const modelRecord: RiskMLModel = {
    id: generateId(),
    modelType: model.modelType,
    version,
    name: `${model.modelType}_${version}`,
    tenantId: metadata.tenantId,
    scope: metadata.tenantId ? 'tenant' : 'global',
    trainingDate: new Date(),
    trainingJobId: metadata.trainingJobId,
    trainingExamples: metadata.trainingExamples,
    validationExamples: metadata.validationExamples,
    testExamples: metadata.testExamples,
    trainingDurationMs: metadata.trainingDurationMs,
    artifactPath,
    artifactSize: model.artifact.length,
    artifactFormat: model.format,
    checksum,
    metrics: model.metrics,
    featureSchema: model.featureSchema,
    featureList: model.featureList,
    featureImportance: model.featureImportance,
    status: 'evaluating',
    isDefault: false,
    abTestTraffic: 0,
    deploymentEnvironment: 'test',
    tags: metadata.tags || [],
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: metadata.createdBy || 'system',
    parentModelId: metadata.parentModelId,
    baseModel: metadata.baseModel
  };
  
  // Store in Cosmos DB
  await cosmosService.create('c_risk_ml_model', modelRecord);
  
  // Update default model if this is better
  if (shouldSetAsDefault(modelRecord, previousModel)) {
    await setAsDefault(modelRecord.id);
  }
  
  return modelRecord;
}
```

### Upload Model Artifact

```typescript
async function uploadModelArtifact(
  artifact: Buffer,
  metadata: { modelType: string; version: string; tenantId?: string }
): Promise<string> {
  const path = `models/${metadata.modelType}/${metadata.version}/${metadata.tenantId || 'global'}/model.${getFormat(artifact)}`;
  
  await blobStorage.upload(path, artifact, {
    contentType: getContentType(artifact),
    metadata: {
      modelType: metadata.modelType,
      version: metadata.version,
      tenantId: metadata.tenantId || 'global',
      uploadedAt: new Date().toISOString()
    }
  });
  
  return path;
}
```

## Model Loading

### Load Model for Inference

```typescript
async function loadModel(
  modelType: ModelType,
  tenantId?: string,
  version?: string
): Promise<LoadedModel> {
  // Get model from registry
  const model = version
    ? await getModelByVersion(modelType, version, tenantId)
    : await getDefaultModel(modelType, tenantId);
  
  if (!model) {
    throw new Error(`Model not found: ${modelType}`);
  }
  
  // Check cache
  const cacheKey = `model:${model.id}`;
  const cached = await redis.get(cacheKey);
  if (cached) {
    return deserializeModel(cached);
  }
  
  // Download artifact
  const artifact = await blobStorage.download(model.artifactPath);
  
  // Load model based on format
  let loadedModel: LoadedModel;
  switch (model.artifactFormat) {
    case 'onnx':
      loadedModel = await loadONNXModel(artifact);
      break;
    case 'pickle':
    case 'pkl':
      loadedModel = await loadPickleModel(artifact);
      break;
    case 'h5':
      loadedModel = await loadKerasModel(artifact);
      break;
    case 'jsonl':
      loadedModel = await loadLLMModel(artifact);
      break;
    default:
      throw new Error(`Unsupported format: ${model.artifactFormat}`);
  }
  
  // Cache model
  await redis.setex(
    cacheKey,
    3600, // 1 hour TTL
    serializeModel(loadedModel)
  );
  
  return loadedModel;
}
```

### Model Caching Strategy

```typescript
// Cache active models in Redis
const CACHE_TTL = 3600; // 1 hour

async function cacheModel(model: RiskMLModel, loadedModel: LoadedModel): Promise<void> {
  const key = `model:${model.id}`;
  const value = serializeModel(loadedModel);
  
  await redis.setex(key, CACHE_TTL, value);
  
  // Also cache model metadata
  await redis.setex(
    `model:meta:${model.id}`,
    CACHE_TTL,
    JSON.stringify(model)
  );
}

async function getCachedModel(modelId: string): Promise<LoadedModel | null> {
  const cached = await redis.get(`model:${modelId}`);
  return cached ? deserializeModel(cached) : null;
}
```

## A/B Testing

### Setup A/B Test

```typescript
async function setupABTest(
  newModelId: string,
  trafficPercentage: number,
  options: ABTestOptions
): Promise<ABTest> {
  // Get current default model
  const currentModel = await getDefaultModel(
    options.modelType,
    options.tenantId
  );
  
  if (!currentModel) {
    throw new Error('No default model found');
  }
  
  // Get new model
  const newModel = await getModel(newModelId);
  
  if (newModel.modelType !== currentModel.modelType) {
    throw new Error('Model types must match');
  }
  
  // Create A/B test
  const abTest: ABTest = {
    id: generateId(),
    modelType: options.modelType,
    tenantId: options.tenantId,
    controlModelId: currentModel.id,
    treatmentModelId: newModelId,
    trafficPercentage,
    startDate: new Date(),
    endDate: options.endDate || addDays(new Date(), options.durationDays || 7),
    status: 'active',
    metrics: {
      control: {
        requestCount: 0,
        errorCount: 0,
        avgLatency: 0,
        performance: {}
      },
      treatment: {
        requestCount: 0,
        errorCount: 0,
        avgLatency: 0,
        performance: {}
      }
    },
    createdAt: new Date()
  };
  
  // Update models
  await updateModel(currentModel.id, {
    abTestTraffic: 100 - trafficPercentage,
    abTestStartDate: abTest.startDate
  });
  
  await updateModel(newModelId, {
    abTestTraffic: trafficPercentage,
    abTestStartDate: abTest.startDate,
    status: 'staging'
  });
  
  // Store A/B test
  await cosmosService.create('c_risk_ml_ab_test', abTest);
  
  return abTest;
}
```

### Route Traffic for A/B Test

```typescript
async function getModelForInference(
  modelType: ModelType,
  tenantId?: string,
  userId?: string
): Promise<LoadedModel> {
  // Check for A/B test
  const abTest = await getActiveABTest(modelType, tenantId);
  
  if (abTest) {
    // Use consistent hashing to route traffic
    const hash = hashUserId(userId || 'anonymous');
    const percentage = hash % 100;
    
    if (percentage < abTest.trafficPercentage) {
      // Route to treatment (new model)
      return await loadModelById(abTest.treatmentModelId);
    } else {
      // Route to control (current model)
      return await loadModelById(abTest.controlModelId);
    }
  }
  
  // No A/B test, use default model
  return await loadModel(modelType, tenantId);
}
```

### Track A/B Test Metrics

```typescript
async function trackABTestMetrics(
  abTestId: string,
  modelId: string,
  metrics: {
    latency: number;
    error: boolean;
    prediction?: any;
    actual?: any;
  }
): Promise<void> {
  const abTest = await getABTest(abTestId);
  const isControl = abTest.controlModelId === modelId;
  
  const modelMetrics = isControl ? abTest.metrics.control : abTest.metrics.treatment;
  
  // Update metrics
  modelMetrics.requestCount++;
  if (metrics.error) {
    modelMetrics.errorCount++;
  }
  
  // Update average latency (exponential moving average)
  modelMetrics.avgLatency = modelMetrics.avgLatency * 0.9 + metrics.latency * 0.1;
  
  // Track prediction accuracy if actual value available
  if (metrics.prediction && metrics.actual) {
    const error = Math.abs(metrics.prediction - metrics.actual);
    if (!modelMetrics.performance.errors) {
      modelMetrics.performance.errors = [];
    }
    modelMetrics.performance.errors.push(error);
    modelMetrics.performance.mae = calculateMAE(
      modelMetrics.performance.errors
    );
  }
  
  // Update A/B test
  await updateABTest(abTestId, { metrics: abTest.metrics });
}
```

### Evaluate A/B Test Results

```typescript
async function evaluateABTest(abTestId: string): Promise<ABTestResults> {
  const abTest = await getABTest(abTestId);
  
  // Calculate statistical significance
  const controlMetrics = abTest.metrics.control;
  const treatmentMetrics = abTest.metrics.treatment;
  
  // Perform statistical test (e.g., t-test, chi-square)
  const significance = performStatisticalTest(
    controlMetrics,
    treatmentMetrics
  );
  
  // Determine winner
  let winner: 'control' | 'treatment' | 'inconclusive';
  if (significance.pValue < 0.05) {
    if (treatmentMetrics.performance.mae < controlMetrics.performance.mae) {
      winner = 'treatment';
    } else {
      winner = 'control';
    }
  } else {
    winner = 'inconclusive';
  }
  
  const results: ABTestResults = {
    abTestId,
    winner,
    significance,
    controlMetrics,
    treatmentMetrics,
    recommendation: winner === 'treatment' 
      ? 'Promote treatment model to default'
      : winner === 'control'
      ? 'Keep control model as default'
      : 'Extend test or investigate further',
    evaluatedAt: new Date()
  };
  
  return results;
}
```

## Model Deployment

### Deploy to Production

```typescript
async function deployModel(
  modelId: string,
  environment: 'staging' | 'production'
): Promise<void> {
  const model = await getModel(modelId);
  
  // Validate model
  if (model.status !== 'evaluating' && model.status !== 'staging') {
    throw new Error(`Model status must be evaluating or staging, got ${model.status}`);
  }
  
  // Check metrics meet threshold
  if (!meetsDeploymentThreshold(model)) {
    throw new Error('Model metrics do not meet deployment threshold');
  }
  
  // Update model status
  await updateModel(modelId, {
    status: environment === 'production' ? 'active' : 'staging',
    deploymentEnvironment: environment,
    deployedAt: new Date(),
    deployedBy: 'system' // or current user
  });
  
  // If deploying to production and this is better, set as default
  if (environment === 'production') {
    const currentDefault = await getDefaultModel(model.modelType, model.tenantId);
    if (!currentDefault || isBetterModel(model, currentDefault)) {
      await setAsDefault(modelId);
    }
  }
  
  // Invalidate cache to force reload
  await invalidateModelCache(modelId);
}
```

### Rollback Model

```typescript
async function rollbackModel(
  modelType: ModelType,
  tenantId?: string
): Promise<void> {
  const currentModel = await getDefaultModel(modelType, tenantId);
  if (!currentModel) {
    throw new Error('No default model found');
  }
  
  // Get previous version
  const previousModel = await getPreviousModel(currentModel);
  if (!previousModel) {
    throw new Error('No previous model version found');
  }
  
  // Deprecate current model
  await updateModel(currentModel.id, {
    status: 'deprecated',
    isDefault: false
  });
  
  // Set previous as default
  await setAsDefault(previousModel.id);
  
  // Invalidate cache
  await invalidateModelCache(currentModel.id);
  await invalidateModelCache(previousModel.id);
}
```

## Model Queries

### Query Models

```typescript
async function queryModels(
  filters: {
    modelType?: ModelType;
    tenantId?: string;
    status?: ModelStatus;
    version?: string;
    tags?: string[];
  },
  options: {
    limit?: number;
    offset?: number;
    orderBy?: string;
    orderDirection?: 'asc' | 'desc';
  }
): Promise<RiskMLModel[]> {
  const query = {
    shardTypeId: 'c_risk_ml_model',
    filters: {
      ...(filters.modelType && { modelType: filters.modelType }),
      ...(filters.tenantId && { tenantId: filters.tenantId }),
      ...(filters.status && { status: filters.status }),
      ...(filters.version && { version: filters.version }),
      ...(filters.tags && { tags: { $in: filters.tags } })
    },
    orderBy: options.orderBy || 'createdAt',
    orderDirection: options.orderDirection || 'desc',
    limit: options.limit || 100,
    offset: options.offset || 0
  };
  
  return await shardRepository.query(query);
}
```

### Get Model History

```typescript
async function getModelHistory(
  modelType: ModelType,
  tenantId?: string
): Promise<RiskMLModel[]> {
  return await queryModels(
    { modelType, tenantId },
    { orderBy: 'createdAt', orderDirection: 'desc' }
  );
}
```

## Best Practices

1. **Version Control**: Always use semantic versioning
2. **Artifact Validation**: Verify checksums before deployment
3. **Gradual Rollout**: Use A/B testing before full deployment
4. **Monitoring**: Monitor model performance in production
5. **Rollback Plan**: Always have a rollback strategy
6. **Documentation**: Document model changes and improvements
7. **Testing**: Test models in staging before production
