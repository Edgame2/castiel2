(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/services_frontend_src_7ad9f257._.js",
  "static/chunks/275fa_@tanstack_table-core_build_lib_index_mjs_6f1bc5e2._.js",
  "static/chunks/3ad0e_@radix-ui_react-select_dist_index_mjs_fabcf722._.js",
  "static/chunks/16716_@dnd-kit_core_dist_core_esm_cc9a58d0.js",
  "static/chunks/77b74_axios_lib_3ffa8d91._.js",
  "static/chunks/node_modules__pnpm_ecc01fc1._.js"
],
    source: "dynamic"
});
