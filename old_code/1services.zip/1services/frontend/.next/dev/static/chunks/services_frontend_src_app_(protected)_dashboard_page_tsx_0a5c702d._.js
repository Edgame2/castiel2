(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/services_frontend_src_5bfa1abe._.js",
  "static/chunks/node_modules__pnpm_db2005a4._.js"
],
    source: "dynamic"
});
