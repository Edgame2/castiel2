module.exports = [
"[project]/services/frontend/.next-internal/server/app/api/auth/refresh/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=c2a1c_frontend__next-internal_server_app_api_auth_refresh_route_actions_b9b4f03d.js.map