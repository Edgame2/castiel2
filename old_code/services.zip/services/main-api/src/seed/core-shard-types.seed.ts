/**
 * Core Shard Types Seed Data
 * 
 * Defines the built-in shard types for common use cases
 */

import type { ShardType } from '../types/shard-type.types.js';

/**
 * c_task - Task/Todo Shard Type
 */
export const TASK_SHARD_TYPE: Omit<ShardType, 'id' | 'createdAt' | 'updatedAt'> = {
  name: 'c_task',
  displayName: 'Task',
  description: 'Tasks, todos, and action items with due dates, priorities, and assignments',
  category: 'productivity',
  version: 1,
  isSystem: true,
  isGlobal: true,
  isActive: true,
  icon: 'check-square',
  color: '#10b981', // Emerald
  tags: ['task', 'todo', 'action', 'productivity'],
  schema: {
    $schema: 'http://json-schema.org/draft-07/schema#',
    type: 'object',
    required: ['title', 'status'],
    properties: {
      title: {
        type: 'string',
        title: 'Title',
        description: 'Task title or summary',
        minLength: 1,
        maxLength: 200,
      },
      description: {
        type: 'string',
        title: 'Description',
        description: 'Detailed description of the task',
        maxLength: 5000,
      },
      status: {
        type: 'string',
        title: 'Status',
        enum: ['todo', 'in_progress', 'blocked', 'review', 'done', 'cancelled'],
        default: 'todo',
      },
      priority: {
        type: 'string',
        title: 'Priority',
        enum: ['low', 'medium', 'high', 'urgent'],
        default: 'medium',
      },
      dueDate: {
        type: 'string',
        format: 'date-time',
        title: 'Due Date',
        description: 'When the task should be completed',
      },
      startDate: {
        type: 'string',
        format: 'date-time',
        title: 'Start Date',
        description: 'When work on the task should begin',
      },
      completedAt: {
        type: 'string',
        format: 'date-time',
        title: 'Completed At',
        description: 'When the task was completed',
      },
      assignees: {
        type: 'array',
        title: 'Assignees',
        description: 'Users assigned to this task',
        items: {
          type: 'object',
          properties: {
            userId: { type: 'string' },
            name: { type: 'string' },
            email: { type: 'string' },
          },
        },
      },
      estimatedHours: {
        type: 'number',
        title: 'Estimated Hours',
        description: 'Estimated time to complete',
        minimum: 0,
      },
      actualHours: {
        type: 'number',
        title: 'Actual Hours',
        description: 'Actual time spent',
        minimum: 0,
      },
      projectId: {
        type: 'string',
        title: 'Project',
        description: 'Associated project ID',
      },
      labels: {
        type: 'array',
        title: 'Labels',
        items: { type: 'string' },
      },
      checklist: {
        type: 'array',
        title: 'Checklist',
        items: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            text: { type: 'string' },
            completed: { type: 'boolean', default: false },
          },
        },
      },
      recurrence: {
        type: 'object',
        title: 'Recurrence',
        properties: {
          frequency: { type: 'string', enum: ['daily', 'weekly', 'monthly', 'yearly'] },
          interval: { type: 'integer', minimum: 1 },
          endDate: { type: 'string', format: 'date' },
        },
      },
    },
  },
  uiSchema: {
    description: { 'ui:widget': 'textarea', 'ui:options': { rows: 4 } },
    status: { 'ui:widget': 'select' },
    priority: { 'ui:widget': 'radio' },
    dueDate: { 'ui:widget': 'datetime' },
    'ui:order': ['title', 'description', 'status', 'priority', 'dueDate', 'assignees', '*'],
  },
};

/**
 * c_event - Calendar Event Shard Type
 */
export const EVENT_SHARD_TYPE: Omit<ShardType, 'id' | 'createdAt' | 'updatedAt'> = {
  name: 'c_event',
  displayName: 'Event',
  description: 'Calendar events, meetings, and scheduled activities',
  category: 'productivity',
  version: 1,
  isSystem: true,
  isGlobal: true,
  isActive: true,
  icon: 'calendar',
  color: '#6366f1', // Indigo
  tags: ['event', 'calendar', 'meeting', 'schedule'],
  schema: {
    $schema: 'http://json-schema.org/draft-07/schema#',
    type: 'object',
    required: ['title', 'startTime'],
    properties: {
      title: {
        type: 'string',
        title: 'Title',
        description: 'Event title',
        minLength: 1,
        maxLength: 200,
      },
      description: {
        type: 'string',
        title: 'Description',
        description: 'Event details and agenda',
        maxLength: 5000,
      },
      eventType: {
        type: 'string',
        title: 'Event Type',
        enum: ['meeting', 'call', 'webinar', 'workshop', 'conference', 'reminder', 'deadline', 'other'],
        default: 'meeting',
      },
      startTime: {
        type: 'string',
        format: 'date-time',
        title: 'Start Time',
      },
      endTime: {
        type: 'string',
        format: 'date-time',
        title: 'End Time',
      },
      allDay: {
        type: 'boolean',
        title: 'All Day Event',
        default: false,
      },
      timezone: {
        type: 'string',
        title: 'Timezone',
        description: 'IANA timezone identifier',
      },
      location: {
        type: 'object',
        title: 'Location',
        properties: {
          type: { type: 'string', enum: ['physical', 'virtual', 'hybrid'] },
          address: { type: 'string' },
          room: { type: 'string' },
          meetingUrl: { type: 'string', format: 'uri' },
          dialIn: { type: 'string' },
          coordinates: {
            type: 'object',
            properties: {
              lat: { type: 'number' },
              lng: { type: 'number' },
            },
          },
        },
      },
      organizer: {
        type: 'object',
        title: 'Organizer',
        properties: {
          userId: { type: 'string' },
          name: { type: 'string' },
          email: { type: 'string' },
        },
      },
      attendees: {
        type: 'array',
        title: 'Attendees',
        items: {
          type: 'object',
          properties: {
            userId: { type: 'string' },
            name: { type: 'string' },
            email: { type: 'string' },
            status: { type: 'string', enum: ['pending', 'accepted', 'declined', 'tentative'] },
            required: { type: 'boolean', default: true },
          },
        },
      },
      recurrence: {
        type: 'object',
        title: 'Recurrence',
        properties: {
          rrule: { type: 'string', description: 'iCal RRULE format' },
          exceptions: { type: 'array', items: { type: 'string', format: 'date' } },
        },
      },
      reminders: {
        type: 'array',
        title: 'Reminders',
        items: {
          type: 'object',
          properties: {
            type: { type: 'string', enum: ['email', 'push', 'sms'] },
            minutesBefore: { type: 'integer', minimum: 0 },
          },
        },
      },
      status: {
        type: 'string',
        title: 'Status',
        enum: ['confirmed', 'tentative', 'cancelled'],
        default: 'confirmed',
      },
      visibility: {
        type: 'string',
        title: 'Visibility',
        enum: ['public', 'private', 'confidential'],
        default: 'public',
      },
      conferenceData: {
        type: 'object',
        title: 'Conference Data',
        properties: {
          provider: { type: 'string', enum: ['zoom', 'teams', 'meet', 'webex', 'other'] },
          meetingId: { type: 'string' },
          password: { type: 'string' },
          joinUrl: { type: 'string', format: 'uri' },
        },
      },
      attachments: {
        type: 'array',
        title: 'Attachments',
        items: {
          type: 'object',
          properties: {
            name: { type: 'string' },
            url: { type: 'string', format: 'uri' },
            mimeType: { type: 'string' },
          },
        },
      },
    },
  },
  uiSchema: {
    description: { 'ui:widget': 'textarea', 'ui:options': { rows: 4 } },
    startTime: { 'ui:widget': 'datetime' },
    endTime: { 'ui:widget': 'datetime' },
    'ui:order': ['title', 'eventType', 'startTime', 'endTime', 'allDay', 'location', 'description', '*'],
  },
};

/**
 * c_email - Email Thread Shard Type
 */
export const EMAIL_SHARD_TYPE: Omit<ShardType, 'id' | 'createdAt' | 'updatedAt'> = {
  name: 'c_email',
  displayName: 'Email',
  description: 'Email messages and threads for communication tracking',
  category: 'communication',
  version: 1,
  isSystem: true,
  isGlobal: true,
  isActive: true,
  icon: 'mail',
  color: '#f59e0b', // Amber
  tags: ['email', 'communication', 'message', 'thread'],
  schema: {
    $schema: 'http://json-schema.org/draft-07/schema#',
    type: 'object',
    required: ['subject', 'from'],
    properties: {
      messageId: {
        type: 'string',
        title: 'Message ID',
        description: 'Unique email message identifier',
      },
      threadId: {
        type: 'string',
        title: 'Thread ID',
        description: 'Email thread/conversation identifier',
      },
      subject: {
        type: 'string',
        title: 'Subject',
        description: 'Email subject line',
        maxLength: 500,
      },
      from: {
        type: 'object',
        title: 'From',
        required: ['email'],
        properties: {
          name: { type: 'string' },
          email: { type: 'string', format: 'email' },
        },
      },
      to: {
        type: 'array',
        title: 'To',
        items: {
          type: 'object',
          properties: {
            name: { type: 'string' },
            email: { type: 'string', format: 'email' },
          },
        },
      },
      cc: {
        type: 'array',
        title: 'CC',
        items: {
          type: 'object',
          properties: {
            name: { type: 'string' },
            email: { type: 'string', format: 'email' },
          },
        },
      },
      bcc: {
        type: 'array',
        title: 'BCC',
        items: {
          type: 'object',
          properties: {
            name: { type: 'string' },
            email: { type: 'string', format: 'email' },
          },
        },
      },
      replyTo: {
        type: 'object',
        title: 'Reply To',
        properties: {
          name: { type: 'string' },
          email: { type: 'string', format: 'email' },
        },
      },
      date: {
        type: 'string',
        format: 'date-time',
        title: 'Date',
        description: 'When the email was sent',
      },
      receivedAt: {
        type: 'string',
        format: 'date-time',
        title: 'Received At',
        description: 'When the email was received',
      },
      bodyText: {
        type: 'string',
        title: 'Body (Plain Text)',
        description: 'Plain text version of the email body',
      },
      bodyHtml: {
        type: 'string',
        title: 'Body (HTML)',
        description: 'HTML version of the email body',
      },
      snippet: {
        type: 'string',
        title: 'Snippet',
        description: 'Preview snippet of the email',
        maxLength: 300,
      },
      labels: {
        type: 'array',
        title: 'Labels',
        items: { type: 'string' },
      },
      folder: {
        type: 'string',
        title: 'Folder',
        enum: ['inbox', 'sent', 'drafts', 'spam', 'trash', 'archive', 'custom'],
      },
      isRead: {
        type: 'boolean',
        title: 'Read',
        default: false,
      },
      isStarred: {
        type: 'boolean',
        title: 'Starred',
        default: false,
      },
      isImportant: {
        type: 'boolean',
        title: 'Important',
        default: false,
      },
      isDraft: {
        type: 'boolean',
        title: 'Draft',
        default: false,
      },
      hasAttachments: {
        type: 'boolean',
        title: 'Has Attachments',
        default: false,
      },
      attachments: {
        type: 'array',
        title: 'Attachments',
        items: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            filename: { type: 'string' },
            mimeType: { type: 'string' },
            size: { type: 'integer' },
            url: { type: 'string', format: 'uri' },
          },
        },
      },
      headers: {
        type: 'object',
        title: 'Headers',
        description: 'Email headers',
        additionalProperties: { type: 'string' },
      },
      inReplyTo: {
        type: 'string',
        title: 'In Reply To',
        description: 'Message ID this email replies to',
      },
      references: {
        type: 'array',
        title: 'References',
        description: 'Message IDs in the thread',
        items: { type: 'string' },
      },
      priority: {
        type: 'string',
        title: 'Priority',
        enum: ['low', 'normal', 'high'],
        default: 'normal',
      },
      provider: {
        type: 'string',
        title: 'Email Provider',
        enum: ['gmail', 'outlook', 'imap', 'other'],
      },
      externalId: {
        type: 'string',
        title: 'External ID',
        description: 'ID from the email provider',
      },
    },
  },
  uiSchema: {
    bodyText: { 'ui:widget': 'textarea', 'ui:options': { rows: 10 } },
    bodyHtml: { 'ui:widget': 'hidden' },
    headers: { 'ui:widget': 'hidden' },
    'ui:order': ['subject', 'from', 'to', 'cc', 'date', 'snippet', 'bodyText', '*'],
  },
};

/**
 * c_project - Project Shard Type
 */
export const PROJECT_SHARD_TYPE: Omit<ShardType, 'id' | 'createdAt' | 'updatedAt'> = {
  name: 'c_project',
  displayName: 'Project',
  description: 'Projects for organizing tasks, events, and resources',
  category: 'productivity',
  version: 1,
  isSystem: true,
  isGlobal: true,
  isActive: true,
  icon: 'folder-kanban',
  color: '#8b5cf6', // Violet
  tags: ['project', 'organization', 'planning'],
  schema: {
    $schema: 'http://json-schema.org/draft-07/schema#',
    type: 'object',
    required: ['name', 'status'],
    properties: {
      name: {
        type: 'string',
        title: 'Project Name',
        minLength: 1,
        maxLength: 200,
      },
      description: {
        type: 'string',
        title: 'Description',
        maxLength: 5000,
      },
      status: {
        type: 'string',
        title: 'Status',
        enum: ['planning', 'active', 'on_hold', 'completed', 'cancelled'],
        default: 'planning',
      },
      priority: {
        type: 'string',
        title: 'Priority',
        enum: ['low', 'medium', 'high', 'critical'],
        default: 'medium',
      },
      startDate: {
        type: 'string',
        format: 'date',
        title: 'Start Date',
      },
      targetDate: {
        type: 'string',
        format: 'date',
        title: 'Target Completion Date',
      },
      completedDate: {
        type: 'string',
        format: 'date',
        title: 'Actual Completion Date',
      },
      owner: {
        type: 'object',
        title: 'Project Owner',
        properties: {
          userId: { type: 'string' },
          name: { type: 'string' },
          email: { type: 'string' },
        },
      },
      team: {
        type: 'array',
        title: 'Team Members',
        items: {
          type: 'object',
          properties: {
            userId: { type: 'string' },
            name: { type: 'string' },
            role: { type: 'string' },
          },
        },
      },
      budget: {
        type: 'object',
        title: 'Budget',
        properties: {
          allocated: { type: 'number' },
          spent: { type: 'number' },
          currency: { type: 'string', default: 'USD' },
        },
      },
      progress: {
        type: 'integer',
        title: 'Progress',
        description: 'Completion percentage',
        minimum: 0,
        maximum: 100,
        default: 0,
      },
      milestones: {
        type: 'array',
        title: 'Milestones',
        items: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            name: { type: 'string' },
            dueDate: { type: 'string', format: 'date' },
            completed: { type: 'boolean' },
          },
        },
      },
      labels: {
        type: 'array',
        title: 'Labels',
        items: { type: 'string' },
      },
      color: {
        type: 'string',
        title: 'Color',
        description: 'Project color for UI',
      },
      visibility: {
        type: 'string',
        title: 'Visibility',
        enum: ['private', 'team', 'organization', 'public'],
        default: 'team',
      },
    },
  },
  uiSchema: {
    description: { 'ui:widget': 'textarea', 'ui:options': { rows: 4 } },
    progress: { 'ui:widget': 'range' },
    color: { 'ui:widget': 'color' },
    'ui:order': ['name', 'description', 'status', 'priority', 'startDate', 'targetDate', 'owner', 'progress', '*'],
  },
};

/**
 * c_document - Document Shard Type
 */
export const DOCUMENT_SHARD_TYPE: Omit<ShardType, 'id' | 'createdAt' | 'updatedAt'> = {
  name: 'c_document',
  displayName: 'Document',
  description: 'Documents, files, and rich text content',
  category: 'content',
  version: 1,
  isSystem: true,
  isGlobal: true,
  isActive: true,
  icon: 'file-text',
  color: '#3b82f6', // Blue
  tags: ['document', 'file', 'content', 'text'],
  schema: {
    $schema: 'http://json-schema.org/draft-07/schema#',
    type: 'object',
    required: ['title'],
    properties: {
      title: {
        type: 'string',
        title: 'Title',
        minLength: 1,
        maxLength: 300,
      },
      content: {
        type: 'string',
        title: 'Content',
        description: 'Document content (markdown or HTML)',
      },
      contentType: {
        type: 'string',
        title: 'Content Type',
        enum: ['markdown', 'html', 'plain', 'rich'],
        default: 'markdown',
      },
      summary: {
        type: 'string',
        title: 'Summary',
        description: 'Brief summary or abstract',
        maxLength: 500,
      },
      documentType: {
        type: 'string',
        title: 'Document Type',
        enum: ['note', 'article', 'report', 'specification', 'manual', 'template', 'other'],
        default: 'note',
      },
      author: {
        type: 'object',
        title: 'Author',
        properties: {
          userId: { type: 'string' },
          name: { type: 'string' },
        },
      },
      contributors: {
        type: 'array',
        title: 'Contributors',
        items: {
          type: 'object',
          properties: {
            userId: { type: 'string' },
            name: { type: 'string' },
            contribution: { type: 'string' },
          },
        },
      },
      publishedAt: {
        type: 'string',
        format: 'date-time',
        title: 'Published At',
      },
      version: {
        type: 'string',
        title: 'Version',
        default: '1.0',
      },
      wordCount: {
        type: 'integer',
        title: 'Word Count',
        minimum: 0,
      },
      readingTime: {
        type: 'integer',
        title: 'Reading Time (minutes)',
        minimum: 0,
      },
      language: {
        type: 'string',
        title: 'Language',
        description: 'ISO 639-1 language code',
        default: 'en',
      },
      visibility: {
        type: 'string',
        title: 'Visibility',
        enum: ['draft', 'private', 'shared', 'published'],
        default: 'draft',
      },
      tableOfContents: {
        type: 'array',
        title: 'Table of Contents',
        items: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            title: { type: 'string' },
            level: { type: 'integer' },
          },
        },
      },
      fileAttachment: {
        type: 'object',
        title: 'File Attachment',
        description: 'Attached file details',
        properties: {
          url: { type: 'string', format: 'uri' },
          filename: { type: 'string' },
          mimeType: { type: 'string' },
          size: { type: 'integer' },
        },
      },
    },
  },
  uiSchema: {
    content: { 'ui:widget': 'textarea', 'ui:options': { rows: 20 } },
    summary: { 'ui:widget': 'textarea', 'ui:options': { rows: 3 } },
    'ui:order': ['title', 'documentType', 'summary', 'content', 'author', 'visibility', '*'],
  },
};

/**
 * Get all core shard types
 */
export function getCoreShardTypes() {
  return [
    TASK_SHARD_TYPE,
    EVENT_SHARD_TYPE,
    EMAIL_SHARD_TYPE,
    PROJECT_SHARD_TYPE,
    DOCUMENT_SHARD_TYPE,
  ];
}

/**
 * Get shard type by name
 */
export function getCoreShardTypeByName(name: string) {
  const types = getCoreShardTypes();
  return types.find((t) => t.name === name);
}


