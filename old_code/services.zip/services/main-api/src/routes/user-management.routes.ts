import type { FastifyInstance } from 'fastify';
import { UserManagementController } from '../controllers/user-management.controller.js';
import { impersonateUserSchema, updateUserStatusSchema, bulkUserOperationSchema } from '../schemas/user-management.schemas.js';
import { requireAuth, requireRole, requireSameTenant, requireTenantOrGlobalAdmin } from '../middleware/authorization.js';

export async function registerUserManagementRoutes(server: FastifyInstance): Promise<void> {
  const controller = (server as FastifyInstance & { userManagementController?: UserManagementController })
    .userManagementController;

  if (!controller) {
    server.log.warn('⚠️  User management routes not registered - controller missing');
    return;
  }

  if (!(server as any).authenticate) {
    server.log.warn('⚠️  User management routes not registered - authentication decorator missing');
    return;
  }

  // Update user status
  server.patch(
    '/api/users/:userId/status',
    {
      schema: updateUserStatusSchema,
      onRequest: [
        (server as any).authenticate,
        requireAuth(),
        requireRole('admin', 'owner', 'global_admin', 'super-admin'),
      ],
    },
    (request, reply) => controller.updateUserStatus(request as any, reply)
  );

  server.post(
    '/api/tenants/:tenantId/users/:userId/impersonate',
    {
      schema: impersonateUserSchema,
      onRequest: [
        (server as any).authenticate,
        requireAuth(),
        requireRole('admin', 'owner', 'global_admin'),
        requireSameTenant(),
      ],
    },
    (request, reply) => controller.impersonateUser(request as any, reply)
  );

  // Bulk user operations
  server.post(
    '/api/tenants/:tenantId/users/bulk',
    {
      schema: bulkUserOperationSchema,
      onRequest: [
        (server as any).authenticate,
        requireAuth(),
        requireRole('admin', 'owner', 'global_admin', 'super-admin'),
        requireTenantOrGlobalAdmin(),
      ],
    },
    (request, reply) => controller.bulkOperation(request as any, reply)
  );

  server.log.info('✅ User management routes registered');
}
