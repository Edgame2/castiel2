module.exports = [
"[project]/services/frontend/src/components/admin/platform-stats.tsx [app-ssr] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules__pnpm_0ed2e4dd._.js",
  "server/chunks/ssr/[root-of-the-server]__2b3f19df._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/services/frontend/src/components/admin/platform-stats.tsx [app-ssr] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/services/frontend/src/components/admin/tenants-list.tsx [app-ssr] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/[root-of-the-server]__77033ac4._.js",
  "server/chunks/ssr/node_modules__pnpm_80bcaa66._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/services/frontend/src/components/admin/tenants-list.tsx [app-ssr] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/services/frontend/src/components/admin/system-health.tsx [app-ssr] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules__pnpm_55e312b6._.js",
  "server/chunks/ssr/[root-of-the-server]__c6b69d7e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/services/frontend/src/components/admin/system-health.tsx [app-ssr] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/services/frontend/src/components/admin/system-logs.tsx [app-ssr] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules__pnpm_a8eefb19._.js",
  "server/chunks/ssr/[root-of-the-server]__ec59a966._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/services/frontend/src/components/admin/system-logs.tsx [app-ssr] (ecmascript, next/dynamic entry)");
    });
});
}),
];