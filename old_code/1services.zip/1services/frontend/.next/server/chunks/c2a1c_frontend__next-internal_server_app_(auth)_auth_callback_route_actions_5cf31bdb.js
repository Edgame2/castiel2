module.exports=[31682,(e,o,d)=>{}];

//# sourceMappingURL=c2a1c_frontend__next-internal_server_app_%28auth%29_auth_callback_route_actions_5cf31bdb.js.map