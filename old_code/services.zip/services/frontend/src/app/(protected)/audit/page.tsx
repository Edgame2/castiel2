'use client'

import { useState, useCallback } from 'react'
import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import {
  Search,
  Filter,
  Download,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  Eye,
  Shield,
  AlertTriangle,
  AlertCircle,
  Info,
  CheckCircle,
  XCircle,
  Activity,
} from 'lucide-react'

interface AuditLogEntry {
  id: string
  tenantId: string
  category: string
  eventType: string
  severity: 'info' | 'warning' | 'error' | 'critical'
  outcome: 'success' | 'failure' | 'partial'
  timestamp: string
  actorId?: string
  actorEmail?: string
  actorType: string
  targetId?: string
  targetType?: string
  targetName?: string
  ipAddress?: string
  userAgent?: string
  message: string
  details?: Record<string, any>
  errorMessage?: string
}

interface AuditLogStats {
  totalEvents: number
  eventsByCategory: Record<string, number>
  eventsBySeverity: Record<string, number>
  eventsByOutcome: Record<string, number>
  topEventTypes: Array<{ type: string; count: number }>
  recentActivity: Array<{ date: string; count: number }>
}

interface AuditLogsResponse {
  logs: AuditLogEntry[]
  total: number
  limit: number
  offset: number
}

const severityConfig = {
  info: { color: 'bg-blue-100 text-blue-800', icon: Info },
  warning: { color: 'bg-yellow-100 text-yellow-800', icon: AlertTriangle },
  error: { color: 'bg-red-100 text-red-800', icon: AlertCircle },
  critical: { color: 'bg-red-200 text-red-900', icon: Shield },
}

const outcomeConfig = {
  success: { color: 'bg-green-100 text-green-800', icon: CheckCircle },
  failure: { color: 'bg-red-100 text-red-800', icon: XCircle },
  partial: { color: 'bg-yellow-100 text-yellow-800', icon: AlertTriangle },
}

const formatEventType = (type: string) => {
  return type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
}

export default function AuditLogsPage() {
  const { t } = useTranslation(['audit', 'common'])
  const [filters, setFilters] = useState({
    category: '',
    severity: '',
    outcome: '',
    search: '',
    startDate: '',
    endDate: '',
  })
  const [page, setPage] = useState(0)
  const [pageSize] = useState(20)
  const [selectedLog, setSelectedLog] = useState<AuditLogEntry | null>(null)
  const [showFilters, setShowFilters] = useState(false)

  const categoryLabels: Record<string, string> = {
    authentication: t('audit:categories.authentication'),
    authorization: t('audit:categories.authorization'),
    user_management: t('audit:categories.user_management'),
    tenant_management: t('audit:categories.tenant_management'),
    data_access: t('audit:categories.data_access'),
    data_modification: t('audit:categories.data_modification'),
    system: t('audit:categories.system'),
    security: t('audit:categories.security'),
    api: t('audit:categories.api'),
  }

  // Build query params
  const buildQueryParams = useCallback(() => {
    const params = new URLSearchParams()
    params.set('limit', pageSize.toString())
    params.set('offset', (page * pageSize).toString())
    
    if (filters.category && filters.category !== 'all') params.set('category', filters.category)
    if (filters.severity && filters.severity !== 'all') params.set('severity', filters.severity)
    if (filters.outcome && filters.outcome !== 'all') params.set('outcome', filters.outcome)
    if (filters.search) params.set('search', filters.search)
    if (filters.startDate) params.set('startDate', filters.startDate)
    if (filters.endDate) params.set('endDate', filters.endDate)
    
    return params.toString()
  }, [filters, page, pageSize])

  // Fetch audit logs
  const { data: logsData, isLoading, refetch } = useQuery<AuditLogsResponse>({
    queryKey: ['audit-logs', filters, page],
    queryFn: async () => {
      const response = await fetch(`/api/audit-logs?${buildQueryParams()}`)
      if (!response.ok) throw new Error('Failed to fetch audit logs')
      return response.json()
    },
  })

  // Fetch stats
  const { data: stats } = useQuery<AuditLogStats>({
    queryKey: ['audit-stats'],
    queryFn: async () => {
      const response = await fetch('/api/audit-logs/stats')
      if (!response.ok) throw new Error('Failed to fetch audit stats')
      return response.json()
    },
  })

  const handleExport = async (format: 'csv' | 'json') => {
    try {
      const params = new URLSearchParams()
      params.set('format', format)
      if (filters.category && filters.category !== 'all') params.set('category', filters.category)
      if (filters.severity && filters.severity !== 'all') params.set('severity', filters.severity)
      if (filters.startDate) params.set('startDate', filters.startDate)
      if (filters.endDate) params.set('endDate', filters.endDate)
      
      const response = await fetch(`/api/audit-logs/export?${params.toString()}`)
      if (!response.ok) throw new Error('Export failed')
      
      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `audit-logs-${new Date().toISOString().split('T')[0]}.${format}`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)
    } catch (error) {
      console.error('Export failed:', error)
    }
  }

  const totalPages = Math.ceil((logsData?.total || 0) / pageSize)

  return (
    <div className="container mx-auto py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t('audit:title')}</h1>
          <p className="text-muted-foreground">
            {t('audit:subtitle')}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" />
            {t('audit:refresh')}
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                {t('audit:export')}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={() => handleExport('csv')}>
                {t('audit:exportCsv')}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExport('json')}>
                {t('audit:exportJson')}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{t('audit:stats.totalEvents')}</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalEvents.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">{t('audit:stats.last30Days')}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{t('audit:stats.successRate')}</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {stats.totalEvents > 0
                  ? Math.round(((stats.eventsByOutcome.success || 0) / stats.totalEvents) * 100)
                  : 0}%
              </div>
              <p className="text-xs text-muted-foreground">
                {stats.eventsByOutcome.success || 0} {t('audit:stats.successfulEvents')}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{t('audit:stats.warnings')}</CardTitle>
              <AlertTriangle className="h-4 w-4 text-yellow-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {(stats.eventsBySeverity.warning || 0).toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground">{t('audit:stats.warningEvents')}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{t('audit:stats.critical')}</CardTitle>
              <Shield className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {((stats.eventsBySeverity.critical || 0) + (stats.eventsBySeverity.error || 0)).toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground">{t('audit:stats.criticalEvents')}</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">{t('audit:filters')}</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter className="mr-2 h-4 w-4" />
              {showFilters ? t('audit:hideFilters') : t('audit:showFilters')}
            </Button>
          </div>
        </CardHeader>
        {showFilters && (
          <CardContent>
            <div className="grid gap-4 md:grid-cols-6">
              <div className="md:col-span-2">
                <Label htmlFor="search">{t('audit:search')}</Label>
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="search"
                    placeholder={t('audit:searchPlaceholder')}
                    className="pl-8"
                    value={filters.search}
                    onChange={(e) => {
                      setFilters(f => ({ ...f, search: e.target.value }))
                      setPage(0)
                    }}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="category">{t('audit:category')}</Label>
                <Select
                  value={filters.category}
                  onValueChange={(value) => {
                    setFilters(f => ({ ...f, category: value }))
                    setPage(0)
                  }}
                >
                  <SelectTrigger id="category">
                    <SelectValue placeholder={t('audit:allCategories')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('audit:allCategories')}</SelectItem>
                    {Object.entries(categoryLabels).map(([value, label]) => (
                      <SelectItem key={value} value={value}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="severity">{t('audit:severity')}</Label>
                <Select
                  value={filters.severity}
                  onValueChange={(value) => {
                    setFilters(f => ({ ...f, severity: value }))
                    setPage(0)
                  }}
                >
                  <SelectTrigger id="severity">
                    <SelectValue placeholder={t('audit:allSeverities')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('audit:allSeverities')}</SelectItem>
                    <SelectItem value="info">{t('audit:severities.info')}</SelectItem>
                    <SelectItem value="warning">{t('audit:severities.warning')}</SelectItem>
                    <SelectItem value="error">{t('audit:severities.error')}</SelectItem>
                    <SelectItem value="critical">{t('audit:severities.critical')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="outcome">{t('audit:outcome')}</Label>
                <Select
                  value={filters.outcome}
                  onValueChange={(value) => {
                    setFilters(f => ({ ...f, outcome: value }))
                    setPage(0)
                  }}
                >
                  <SelectTrigger id="outcome">
                    <SelectValue placeholder={t('audit:allOutcomes')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('audit:allOutcomes')}</SelectItem>
                    <SelectItem value="success">{t('audit:outcomes.success')}</SelectItem>
                    <SelectItem value="failure">{t('audit:outcomes.failure')}</SelectItem>
                    <SelectItem value="partial">{t('audit:outcomes.partial')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button
                  variant="outline"
                  onClick={() => {
                    setFilters({
                      category: '',
                      severity: '',
                      outcome: '',
                      search: '',
                      startDate: '',
                      endDate: '',
                    })
                    setPage(0)
                  }}
                >
                  {t('audit:clearFilters')}
                </Button>
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      {/* Logs Table */}
      <Card>
        <CardHeader>
          <CardTitle>{t('audit:activityLog')}</CardTitle>
          <CardDescription>
            {logsData?.total || 0} {t('audit:totalEvents')}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[180px]">{t('audit:table.timestamp')}</TableHead>
                <TableHead>{t('audit:table.event')}</TableHead>
                <TableHead>{t('audit:table.actor')}</TableHead>
                <TableHead>{t('audit:table.category')}</TableHead>
                <TableHead>{t('audit:table.severity')}</TableHead>
                <TableHead>{t('audit:table.outcome')}</TableHead>
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">
                    {t('common:loading')}
                  </TableCell>
                </TableRow>
              ) : logsData?.logs?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    {t('audit:noLogs')}
                  </TableCell>
                </TableRow>
              ) : (
                logsData?.logs?.map((log) => {
                  const SeverityIcon = severityConfig[log.severity]?.icon || Info
                  const OutcomeIcon = outcomeConfig[log.outcome]?.icon || Info
                  
                  return (
                    <TableRow key={log.id}>
                      <TableCell className="font-mono text-sm">
                        {new Date(log.timestamp).toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-medium">
                            {formatEventType(log.eventType)}
                          </span>
                          <span className="text-sm text-muted-foreground truncate max-w-[300px]">
                            {log.message}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {log.actorEmail || log.actorType}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {categoryLabels[log.category] || log.category}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={severityConfig[log.severity]?.color}>
                          <SeverityIcon className="mr-1 h-3 w-3" />
                          {t(`audit:severities.${log.severity}`)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={outcomeConfig[log.outcome]?.color}>
                          <OutcomeIcon className="mr-1 h-3 w-3" />
                          {t(`audit:outcomes.${log.outcome}`)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setSelectedLog(log)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  )
                })
              )}
            </TableBody>
          </Table>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between mt-4">
              <p className="text-sm text-muted-foreground">
                {t('audit:pagination.showing')} {page * pageSize + 1} {t('audit:pagination.to')} {Math.min((page + 1) * pageSize, logsData?.total || 0)} {t('audit:pagination.of')} {logsData?.total || 0} {t('audit:pagination.entries')}
              </p>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPage(p => Math.max(0, p - 1))}
                  disabled={page === 0}
                >
                  <ChevronLeft className="h-4 w-4" />
                  {t('audit:pagination.previous')}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
                  disabled={page >= totalPages - 1}
                >
                  {t('audit:pagination.next')}
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Log Detail Sheet */}
      <Sheet open={!!selectedLog} onOpenChange={() => setSelectedLog(null)}>
        <SheetContent className="w-[500px] sm:w-[600px] overflow-y-auto">
          <SheetHeader>
            <SheetTitle>{t('audit:eventDetails')}</SheetTitle>
            <SheetDescription>
              {selectedLog && formatEventType(selectedLog.eventType)}
            </SheetDescription>
          </SheetHeader>
          {selectedLog && (
            <div className="mt-6 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">{t('audit:table.timestamp')}</Label>
                  <p className="font-mono text-sm">
                    {new Date(selectedLog.timestamp).toLocaleString()}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">{t('audit:detail.eventId')}</Label>
                  <p className="font-mono text-sm truncate">{selectedLog.id}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">{t('audit:table.category')}</Label>
                  <p>{categoryLabels[selectedLog.category] || selectedLog.category}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">{t('audit:detail.eventType')}</Label>
                  <p>{formatEventType(selectedLog.eventType)}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">{t('audit:table.severity')}</Label>
                  <Badge className={severityConfig[selectedLog.severity]?.color}>
                    {t(`audit:severities.${selectedLog.severity}`)}
                  </Badge>
                </div>
                <div>
                  <Label className="text-muted-foreground">{t('audit:table.outcome')}</Label>
                  <Badge className={outcomeConfig[selectedLog.outcome]?.color}>
                    {t(`audit:outcomes.${selectedLog.outcome}`)}
                  </Badge>
                </div>
              </div>

              <div>
                <Label className="text-muted-foreground">{t('audit:detail.message')}</Label>
                <p className="mt-1">{selectedLog.message}</p>
              </div>

              {selectedLog.actorEmail && (
                <div>
                  <Label className="text-muted-foreground">{t('audit:table.actor')}</Label>
                  <p>{selectedLog.actorEmail}</p>
                  <p className="text-sm text-muted-foreground">
                    Type: {selectedLog.actorType}
                  </p>
                </div>
              )}

              {selectedLog.targetId && (
                <div>
                  <Label className="text-muted-foreground">{t('audit:detail.target')}</Label>
                  <p>{selectedLog.targetName || selectedLog.targetId}</p>
                  {selectedLog.targetType && (
                    <p className="text-sm text-muted-foreground">
                      Type: {selectedLog.targetType}
                    </p>
                  )}
                </div>
              )}

              {selectedLog.ipAddress && (
                <div>
                  <Label className="text-muted-foreground">{t('audit:detail.ipAddress')}</Label>
                  <p className="font-mono text-sm">{selectedLog.ipAddress}</p>
                </div>
              )}

              {selectedLog.userAgent && (
                <div>
                  <Label className="text-muted-foreground">{t('audit:detail.userAgent')}</Label>
                  <p className="text-sm break-all">{selectedLog.userAgent}</p>
                </div>
              )}

              {selectedLog.errorMessage && (
                <div>
                  <Label className="text-muted-foreground text-red-500">{t('audit:detail.errorMessage')}</Label>
                  <p className="text-red-600">{selectedLog.errorMessage}</p>
                </div>
              )}

              {selectedLog.details && Object.keys(selectedLog.details).length > 0 && (
                <div>
                  <Label className="text-muted-foreground">{t('audit:detail.additionalDetails')}</Label>
                  <pre className="mt-1 p-3 bg-muted rounded-md text-sm overflow-auto max-h-[200px]">
                    {JSON.stringify(selectedLog.details, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  )
}
