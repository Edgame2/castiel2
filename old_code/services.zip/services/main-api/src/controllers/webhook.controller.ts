/**
 * Webhook Controller
 * 
 * HTTP handlers for webhook management
 */

import type { FastifyRequest, FastifyReply } from 'fastify';
import type { ShardEventService } from '../services/shard-event.service.js';
import type { AuthUser } from '../types/auth.types.js';
import type { CreateWebhookInput, UpdateWebhookInput } from '../types/shard-event.types.js';

const ADMIN_ROLES = ['owner', 'admin', 'tenant-admin'];

/**
 * Webhook Controller
 */
export class WebhookController {
  constructor(private readonly eventService: ShardEventService) {}

  /**
   * GET /api/v1/webhooks
   * List webhooks for tenant
   */
  async listWebhooks(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      if (!this.isAdmin(user)) {
        return reply.code(403).send({ error: 'Admin role required' });
      }

      const webhooks = await this.eventService.listWebhooks(user.tenantId);

      // Hide secrets in response
      const safeWebhooks = webhooks.map((w) => ({
        ...w,
        secret: '********',
      }));

      return reply.code(200).send({ webhooks: safeWebhooks });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to list webhooks');
      return reply.code(500).send({ error: 'Failed to list webhooks' });
    }
  }

  /**
   * GET /api/v1/webhooks/:id
   * Get a webhook by ID
   */
  async getWebhook(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      if (!this.isAdmin(user)) {
        return reply.code(403).send({ error: 'Admin role required' });
      }

      const { id } = request.params as { id: string };
      const webhook = await this.eventService.getWebhook(user.tenantId, id);

      if (!webhook) {
        return reply.code(404).send({ error: 'Webhook not found' });
      }

      // Hide secret
      return reply.code(200).send({
        webhook: { ...webhook, secret: '********' },
      });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to get webhook');
      return reply.code(500).send({ error: 'Failed to get webhook' });
    }
  }

  /**
   * POST /api/v1/webhooks
   * Create a new webhook
   */
  async createWebhook(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      if (!this.isAdmin(user)) {
        return reply.code(403).send({ error: 'Admin role required' });
      }

      const input = request.body as CreateWebhookInput;

      // Validate URL
      try {
        new URL(input.url);
      } catch {
        return reply.code(400).send({ error: 'Invalid webhook URL' });
      }

      // Validate events
      if (!input.events || input.events.length === 0) {
        return reply.code(400).send({ error: 'At least one event type is required' });
      }

      const webhook = await this.eventService.createWebhook(user.tenantId, user.id, input);

      request.log.info({ webhookId: webhook.id }, 'Webhook created');

      return reply.code(201).send({ webhook });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to create webhook');
      return reply.code(500).send({ error: 'Failed to create webhook' });
    }
  }

  /**
   * PUT /api/v1/webhooks/:id
   * Update a webhook
   */
  async updateWebhook(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      if (!this.isAdmin(user)) {
        return reply.code(403).send({ error: 'Admin role required' });
      }

      const { id } = request.params as { id: string };
      const input = request.body as UpdateWebhookInput;

      // Validate URL if provided
      if (input.url) {
        try {
          new URL(input.url);
        } catch {
          return reply.code(400).send({ error: 'Invalid webhook URL' });
        }
      }

      const webhook = await this.eventService.updateWebhook(user.tenantId, id, input);

      if (!webhook) {
        return reply.code(404).send({ error: 'Webhook not found' });
      }

      request.log.info({ webhookId: id }, 'Webhook updated');

      return reply.code(200).send({
        webhook: { ...webhook, secret: '********' },
      });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to update webhook');
      return reply.code(500).send({ error: 'Failed to update webhook' });
    }
  }

  /**
   * DELETE /api/v1/webhooks/:id
   * Delete a webhook
   */
  async deleteWebhook(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      if (!this.isAdmin(user)) {
        return reply.code(403).send({ error: 'Admin role required' });
      }

      const { id } = request.params as { id: string };
      const deleted = await this.eventService.deleteWebhook(user.tenantId, id);

      if (!deleted) {
        return reply.code(404).send({ error: 'Webhook not found' });
      }

      request.log.info({ webhookId: id }, 'Webhook deleted');

      return reply.code(200).send({ success: true });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to delete webhook');
      return reply.code(500).send({ error: 'Failed to delete webhook' });
    }
  }

  /**
   * POST /api/v1/webhooks/:id/regenerate-secret
   * Regenerate webhook secret
   */
  async regenerateSecret(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      if (!this.isAdmin(user)) {
        return reply.code(403).send({ error: 'Admin role required' });
      }

      const { id } = request.params as { id: string };
      const newSecret = await this.eventService.regenerateSecret(user.tenantId, id);

      if (!newSecret) {
        return reply.code(404).send({ error: 'Webhook not found' });
      }

      request.log.info({ webhookId: id }, 'Webhook secret regenerated');

      return reply.code(200).send({ secret: newSecret });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to regenerate secret');
      return reply.code(500).send({ error: 'Failed to regenerate secret' });
    }
  }

  /**
   * POST /api/v1/webhooks/:id/test
   * Test a webhook
   */
  async testWebhook(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      if (!this.isAdmin(user)) {
        return reply.code(403).send({ error: 'Admin role required' });
      }

      const { id } = request.params as { id: string };

      const delivery = await this.eventService.testWebhook(user.tenantId, id, user.id);

      return reply.code(200).send({ delivery });
    } catch (error: any) {
      if (error.message === 'Webhook not found') {
        return reply.code(404).send({ error: 'Webhook not found' });
      }
      request.log.error({ error }, 'Failed to test webhook');
      return reply.code(500).send({ error: 'Failed to test webhook' });
    }
  }

  /**
   * GET /api/v1/webhooks/:id/deliveries
   * Get delivery history
   */
  async getDeliveries(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      if (!this.isAdmin(user)) {
        return reply.code(403).send({ error: 'Admin role required' });
      }

      const { id } = request.params as { id: string };
      const { limit = '50' } = request.query as { limit?: string };

      const deliveries = await this.eventService.getDeliveryHistory(
        user.tenantId,
        id,
        parseInt(limit, 10)
      );

      return reply.code(200).send({ deliveries });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to get deliveries');
      return reply.code(500).send({ error: 'Failed to get delivery history' });
    }
  }

  private isAdmin(user: AuthUser): boolean {
    return ADMIN_ROLES.some((role) => user.roles?.includes(role));
  }
}


