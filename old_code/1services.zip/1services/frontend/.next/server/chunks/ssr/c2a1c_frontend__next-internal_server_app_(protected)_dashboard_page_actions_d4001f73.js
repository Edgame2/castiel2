module.exports=[66146,(a,b,c)=>{}];

//# sourceMappingURL=c2a1c_frontend__next-internal_server_app_%28protected%29_dashboard_page_actions_d4001f73.js.map