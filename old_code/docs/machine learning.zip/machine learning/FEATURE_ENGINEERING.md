# Feature Engineering for Risk Analysis ML

## Overview

Feature engineering is a critical component of the Risk Analysis ML system. This document describes the feature extraction, transformation, and storage processes that prepare data for ML model training and inference.

## Feature Categories

Features are organized into several categories based on their source and nature:

### 1. Opportunity Features

Direct features from the opportunity shard:

```typescript
interface OpportunityFeatures {
  // Numerical features
  dealValue: number;              // Deal value in base currency
  expectedRevenue: number;         // Expected revenue
  probability: number;              // Win probability (0-100)
  daysToClose: number;              // Days until expected close date
  daysSinceActivity: number;       // Days since last activity
  daysSinceCreated: number;         // Days since opportunity created
  daysInCurrentStage: number;       // Days in current stage
  
  // Categorical features (encoded)
  stage: string;                    // Current stage (one-hot encoded)
  industry: string;                 // Industry (one-hot encoded)
  currency: string;                  // Currency code
  ownerId: string;                  // Opportunity owner (embedding)
  accountId: string;                // Account ID (embedding)
  
  // Boolean features
  hasCloseDate: boolean;            // Whether close date is set
  hasExpectedRevenue: boolean;      // Whether expected revenue is set
  isRecurring: boolean;              // Whether deal is recurring
}
```

### 2. Risk Features

Features derived from detected risks:

```typescript
interface RiskFeatures {
  // Risk counts
  totalRisks: number;               // Total number of detected risks
  highConfidenceRisks: number;      // Risks with confidence > 0.7
  risksByCategory: Record<string, number>; // Count per category
  
  // Risk scores
  riskScore: number;                 // Overall risk score (0-1)
  categoryScores: Record<string, number>; // Score per category
  maxCategoryScore: number;          // Highest category score
  
  // Risk characteristics
  avgRiskConfidence: number;        // Average confidence across risks
  riskDiversity: number;             // Number of unique risk types
  criticalRisks: number;             // Number of critical risks
}
```

### 3. Historical Features

Features derived from historical data:

```typescript
interface HistoricalFeatures {
  // Owner performance
  ownerWinRate: number;             // Owner's historical win rate
  ownerAvgDealSize: number;         // Owner's average deal size
  ownerDealCount: number;            // Owner's total deal count
  ownerDaysToClose: number;         // Owner's average days to close
  
  // Account performance
  accountWinRate: number;            // Account's historical win rate
  accountDealCount: number;          // Account's total deal count
  accountAvgDealSize: number;        // Account's average deal size
  accountHealth: number;             // Account health score (0-1)
  
  // Industry/Stage patterns
  industryWinRate: number;          // Industry win rate
  stageWinRate: number;              // Stage win rate
  stageAvgDays: number;              // Average days in this stage
  
  // Similar opportunities
  similarDealsWinRate: number;      // Win rate of similar deals
  similarDealsAvgValue: number;     // Average value of similar deals
  similarDealsCount: number;        // Number of similar deals
}
```

### 4. Relationship Features

Features from related entities:

```typescript
interface RelationshipFeatures {
  // Stakeholder features
  stakeholderCount: number;        // Number of stakeholders
  stakeholderChangeCount: number;   // Number of stakeholder changes
  daysSinceStakeholderChange: number; // Days since last change
  
  // Activity features
  activityCount: number;             // Total activity count
  activityCountLast7Days: number;   // Activities in last 7 days
  activityCountLast30Days: number;  // Activities in last 30 days
  avgActivityInterval: number;       // Average days between activities
  
  // Document features
  documentCount: number;             // Number of documents
  documentCountLast30Days: number;   // Documents in last 30 days
  avgDocumentSize: number;           // Average document size
  
  // Communication features
  emailCount: number;                // Email count
  meetingCount: number;              // Meeting count
  callCount: number;                 // Call count
}
```

### 5. Temporal Features

Time-based features:

```typescript
interface TemporalFeatures {
  // Time of year
  month: number;                     // Month (1-12)
  quarter: number;                    // Quarter (1-4)
  dayOfWeek: number;                  // Day of week (0-6)
  isMonthEnd: boolean;                // Within 3 days of month end
  isQuarterEnd: boolean;              // Within 7 days of quarter end
  isYearEnd: boolean;                 // Within 30 days of year end
  
  // Time-based ratios
  daysToCloseRatio: number;          // daysToClose / daysSinceCreated
  activityRatio: number;              // activityCount / daysSinceCreated
  stageProgressRatio: number;         // Current stage index / total stages
}
```

### 6. Derived Features

Computed features from combinations:

```typescript
interface DerivedFeatures {
  // Value-based
  valueProbabilityRatio: number;    // dealValue * probability / 100
  revenueAtRisk: number;             // dealValue * riskScore
  riskAdjustedValue: number;          // dealValue - revenueAtRisk
  
  // Risk-based
  riskVelocity: number;               // Change in risk score over time
  riskAcceleration: number;          // Rate of change of risk velocity
  
  // Activity-based
  activityVelocity: number;           // Activities per day
  activityTrend: number;              // Trend in activity (increasing/decreasing)
  
  // Composite scores
  healthScore: number;               // Composite health score
  urgencyScore: number;               // Composite urgency score
}
```

## Feature Extraction Process

### Step 1: Data Collection

```typescript
async function extractFeatures(
  opportunityId: string,
  tenantId: string
): Promise<FeatureVector> {
  // 1. Load opportunity shard
  const opportunity = await shardRepository.get(opportunityId, tenantId);
  
  // 2. Load related shards
  const relatedShards = await relationshipService.getRelatedShards(
    opportunityId,
    tenantId
  );
  
  // 3. Load risk snapshot (if exists)
  const riskSnapshot = await getRiskSnapshot(opportunityId, tenantId);
  
  // 4. Load historical data
  const historicalData = await getHistoricalData(opportunity, tenantId);
  
  // 5. Extract features
  return {
    ...extractOpportunityFeatures(opportunity),
    ...extractRiskFeatures(riskSnapshot),
    ...extractHistoricalFeatures(opportunity, historicalData),
    ...extractRelationshipFeatures(relatedShards),
    ...extractTemporalFeatures(opportunity),
    ...computeDerivedFeatures(opportunity, riskSnapshot)
  };
}
```

### Step 2: Feature Transformation

#### Categorical Encoding

```typescript
function encodeCategorical(features: RawFeatures): EncodedFeatures {
  // One-hot encoding for stage
  const stageEncoded = oneHotEncode(features.stage, STAGE_VALUES);
  
  // One-hot encoding for industry
  const industryEncoded = oneHotEncode(features.industry, INDUSTRY_VALUES);
  
  // Embedding for owner (pre-trained embeddings)
  const ownerEmbedding = getOwnerEmbedding(features.ownerId);
  
  return {
    ...features,
    stageEncoded,
    industryEncoded,
    ownerEmbedding
  };
}
```

#### Numerical Normalization

```typescript
function normalizeNumerical(features: EncodedFeatures): NormalizedFeatures {
  // Min-max normalization for deal value
  const normalizedDealValue = minMaxNormalize(
    features.dealValue,
    MIN_DEAL_VALUE,
    MAX_DEAL_VALUE
  );
  
  // Z-score normalization for days to close
  const normalizedDaysToClose = zScoreNormalize(
    features.daysToClose,
    DAYS_TO_CLOSE_MEAN,
    DAYS_TO_CLOSE_STD
  );
  
  // Log transformation for skewed features
  const logDealValue = Math.log1p(features.dealValue);
  
  return {
    ...features,
    normalizedDealValue,
    normalizedDaysToClose,
    logDealValue
  };
}
```

#### Temporal Feature Engineering

```typescript
function extractTemporalFeatures(opportunity: Shard): TemporalFeatures {
  const now = new Date();
  const createdDate = new Date(opportunity.createdAt);
  const closeDate = opportunity.structuredData.closeDate 
    ? new Date(opportunity.structuredData.closeDate) 
    : null;
  
  return {
    month: now.getMonth() + 1,
    quarter: Math.floor(now.getMonth() / 3) + 1,
    dayOfWeek: now.getDay(),
    isMonthEnd: isWithinDays(now, getMonthEnd(now), 3),
    isQuarterEnd: isWithinDays(now, getQuarterEnd(now), 7),
    isYearEnd: isWithinDays(now, getYearEnd(now), 30),
    daysToCloseRatio: closeDate 
      ? daysBetween(now, closeDate) / daysBetween(createdDate, now)
      : 0
  };
}
```

### Step 3: Feature Selection

Not all features are used for all models. Feature selection is model-specific:

```typescript
const FEATURE_SETS = {
  riskScoring: [
    'dealValue',
    'probability',
    'daysToClose',
    'riskScore',
    'categoryScores',
    'ownerWinRate',
    'accountHealth',
    // ... more features
  ],
  outcomePrediction: [
    'riskScore',
    'dealValue',
    'probability',
    'daysToClose',
    'ownerWinRate',
    'accountWinRate',
    'activityCount',
    // ... more features
  ],
  mitigationRecommendation: [
    'detectedRisks',
    'riskCategories',
    'stage',
    'industry',
    'accountHealth',
    // ... more features
  ]
};
```

## Feature Store

### Storage

Features are stored in multiple locations:

1. **Redis Cache**: Cached features for quick access (TTL: 15 minutes)
2. **Cosmos DB**: Historical features for training data
3. **In-Memory**: During inference for performance

### Feature Versioning

Features are versioned to handle schema changes:

```typescript
interface FeatureSchema {
  version: string;                  // Schema version (e.g., "v1.0")
  features: Array<{
    name: string;
    type: 'numerical' | 'categorical' | 'boolean' | 'embedding';
    description: string;
    normalization?: 'minmax' | 'zscore' | 'log' | 'none';
    encoding?: 'onehot' | 'embedding' | 'label';
  }>;
  createdAt: Date;
  deprecatedAt?: Date;
}
```

### Feature Statistics

Track feature statistics for normalization and validation:

```typescript
interface FeatureStatistics {
  featureName: string;
  mean?: number;
  std?: number;
  min?: number;
  max?: number;
  median?: number;
  missingRate: number;
  uniqueValues?: number;
  lastUpdated: Date;
}
```

## Feature Engineering Pipeline

### Training Data Preparation

```typescript
async function prepareTrainingFeatures(
  riskSnapshots: RiskSnapshot[],
  outcomes: Map<string, 'won' | 'lost'>
): Promise<TrainingExample[]> {
  const examples: TrainingExample[] = [];
  
  for (const snapshot of riskSnapshots) {
    // Extract features at snapshot time
    const features = await extractFeaturesAtTime(
      snapshot.opportunityId,
      snapshot.tenantId,
      snapshot.snapshotDate
    );
    
    // Get labels from outcome
    const outcome = outcomes.get(snapshot.opportunityId);
    const labels = {
      actualRiskScore: snapshot.riskScore,
      actualOutcome: outcome || null,
      actualRevenueAtRisk: snapshot.revenueAtRisk
    };
    
    examples.push({
      id: snapshot.id,
      opportunityId: snapshot.opportunityId,
      tenantId: snapshot.tenantId,
      snapshotDate: snapshot.snapshotDate,
      features,
      labels,
      createdAt: snapshot.createdAt,
      outcomeDate: outcome ? getOutcomeDate(snapshot.opportunityId) : undefined
    });
  }
  
  return examples;
}
```

### Feature Validation

```typescript
function validateFeatures(features: FeatureVector): ValidationResult {
  const errors: string[] = [];
  
  // Check for missing required features
  const requiredFeatures = ['dealValue', 'probability', 'riskScore'];
  for (const feature of requiredFeatures) {
    if (features[feature] === undefined || features[feature] === null) {
      errors.push(`Missing required feature: ${feature}`);
    }
  }
  
  // Check for invalid ranges
  if (features.probability < 0 || features.probability > 100) {
    errors.push(`Invalid probability: ${features.probability}`);
  }
  
  // Check for NaN or Infinity
  for (const [key, value] of Object.entries(features)) {
    if (typeof value === 'number' && (isNaN(value) || !isFinite(value))) {
      errors.push(`Invalid numeric value for ${key}: ${value}`);
    }
  }
  
  return {
    valid: errors.length === 0,
    errors
  };
}
```

## Feature Importance

Track feature importance for model interpretability:

```typescript
interface FeatureImportance {
  featureName: string;
  importance: number;                // Importance score (0-1)
  modelType: string;                  // Model this applies to
  method: 'shap' | 'permutation' | 'coefficient';
  calculatedAt: Date;
}

// Example: Calculate SHAP values for feature importance
async function calculateFeatureImportance(
  model: Model,
  testData: FeatureVector[]
): Promise<FeatureImportance[]> {
  const shapValues = await calculateSHAP(model, testData);
  
  return Object.entries(shapValues).map(([feature, importance]) => ({
    featureName: feature,
    importance: Math.abs(importance),
    modelType: model.type,
    method: 'shap',
    calculatedAt: new Date()
  }));
}
```

## Best Practices

### 1. Handle Missing Values

```typescript
function handleMissingValues(features: FeatureVector): FeatureVector {
  return {
    ...features,
    // Use median for numerical features
    dealValue: features.dealValue ?? getMedian('dealValue'),
    // Use mode for categorical features
    stage: features.stage ?? getMode('stage'),
    // Use default for boolean features
    hasCloseDate: features.hasCloseDate ?? false
  };
}
```

### 2. Handle Outliers

```typescript
function handleOutliers(features: FeatureVector): FeatureVector {
  return {
    ...features,
    // Cap outliers at 99th percentile
    dealValue: Math.min(
      features.dealValue,
      getPercentile('dealValue', 99)
    ),
    // Use IQR method for days to close
    daysToClose: capOutlierIQR(features.daysToClose, 'daysToClose')
  };
}
```

### 3. Feature Scaling

Different models require different scaling:
- **XGBoost/LightGBM**: Tree-based models don't require scaling
- **Neural Networks**: Require normalization (min-max or z-score)
- **Linear Models**: Benefit from standardization

### 4. Feature Engineering for Time Series

For temporal patterns:
- Rolling averages (7-day, 30-day)
- Rate of change
- Seasonal patterns
- Trend detection

## Performance Optimization

### Caching Strategy

- **Feature Cache**: Cache extracted features for 15 minutes
- **Historical Cache**: Cache historical aggregations for 1 hour
- **Statistics Cache**: Cache feature statistics for 24 hours

### Batch Processing

- Extract features in batches for multiple opportunities
- Use parallel processing for independent features
- Pre-compute historical features during off-peak hours

## Monitoring

### Feature Quality Metrics

- **Missing Rate**: Percentage of missing values
- **Outlier Rate**: Percentage of outliers
- **Distribution Drift**: Changes in feature distributions over time
- **Correlation Changes**: Changes in feature correlations

### Alerts

- Alert when missing rate > 10%
- Alert when distribution drift detected
- Alert when feature statistics change significantly
