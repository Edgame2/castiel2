(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/services_frontend_src_components_settings_ea50f9cd._.js",
  "static/chunks/_232c767b._.js"
],
    source: "dynamic"
});
