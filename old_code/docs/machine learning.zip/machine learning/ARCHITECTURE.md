# Risk Analysis ML Architecture

## Overview

The Risk Analysis ML system uses a hybrid architecture combining fine-tuned Large Language Models (LLMs) for risk identification with traditional machine learning models for risk scoring, outcome prediction, and mitigation recommendations. The system is designed for continuous learning and improvement over time.

## High-Level Architecture

```mermaid
flowchart TB
    subgraph "Risk Detection Layer"
        RB[Rule-Based Detection]
        LLM[LLM Risk Identification<br/>Fine-tuned Models]
        HIST[Historical Pattern Matching]
    end
    
    subgraph "ML Prediction Layer"
        RS[Risk Scoring Model<br/>XGBoost/Neural Net]
        OP[Outcome Prediction Model<br/>Won/Lost Probability]
        MR[Mitigation Recommendation Model]
    end
    
    subgraph "Feature Engineering"
        FS[Feature Store]
        FE[Feature Engineering Pipeline]
    end
    
    subgraph "Learning & Training"
        FC[Feedback Collection]
        TP[Training Pipeline]
        LLMFT[LLM Fine-tuning Pipeline]
        MLT[ML Model Training]
        EVAL[Model Evaluation]
    end
    
    subgraph "Data Sources"
        OPP[Opportunities]
        RSNAP[Risk Snapshots]
        OUT[Outcomes Won/Lost]
        FB[User Feedback]
    end
    
    OPP --> RB
    OPP --> LLM
    OPP --> HIST
    OPP --> FE
    
    RB --> RS
    LLM --> RS
    HIST --> RS
    
    RS --> OP
    RS --> MR
    
    FE --> FS
    FS --> RS
    FS --> OP
    FS --> MR
    
    RSNAP --> TP
    OUT --> TP
    FB --> FC
    FC --> TP
    
    TP --> LLMFT
    TP --> MLT
    
    LLMFT --> LLM
    MLT --> RS
    MLT --> OP
    MLT --> MR
    
    EVAL --> TP
    RS --> EVAL
    OP --> EVAL
    MR --> EVAL
```

## Component Architecture

```mermaid
graph LR
    subgraph "API Layer"
        RE[RiskEvaluationService]
        RML[RiskMLService]
    end
    
    subgraph "ML Services"
        FS[FeatureStoreService]
        MS[ModelService]
        TS[TrainingService]
        ES[EvaluationService]
    end
    
    subgraph "Data Layer"
        COSMOS[(Cosmos DB<br/>Risk Snapshots<br/>Outcomes)]
        REDIS[(Redis<br/>Feature Cache)]
        BLOB[(Azure Blob<br/>Model Artifacts)]
    end
    
    subgraph "Training Infrastructure"
        AF[Azure Functions<br/>Training Workers]
        AML[Azure ML<br/>Optional]
    end
    
    RE --> RML
    RML --> FS
    RML --> MS
    MS --> REDIS
    MS --> BLOB
    TS --> FS
    TS --> MS
    TS --> COSMOS
    ES --> MS
    TS --> AF
    AF --> AML
```

## Core Components

### 1. Feature Store Service

**Location**: `apps/api/src/services/risk-ml/feature-store.service.ts`

**Purpose**: Extract, transform, and store features for ML models

**Responsibilities**:
- Extract features from opportunities, risk snapshots, and related shards
- Perform feature engineering (temporal, categorical, numerical transformations)
- Cache features for performance
- Provide feature versioning

**Key Methods**:
- `extractFeatures(opportunityId, tenantId)`: Extract all features for an opportunity
- `getHistoricalFeatures(opportunityId, tenantId)`: Get historical feature values
- `cacheFeatures(opportunityId, features)`: Cache features for quick access
- `getFeatureSchema()`: Return feature schema and metadata

### 2. Risk ML Service

**Location**: `apps/api/src/services/risk-ml/risk-ml.service.ts`

**Purpose**: Main orchestration service for ML-enhanced risk analysis

**Responsibilities**:
- Coordinate ML predictions with existing risk detection
- Combine LLM and ML predictions
- Provide ML-enhanced risk evaluations
- Manage prediction caching

**Key Methods**:
- `getMLEnhancedEvaluation(opportunityId, tenantId, userId)`: Get full ML-enhanced evaluation
- `predictRiskScore(features)`: Predict risk score using ML model
- `predictOutcome(features)`: Predict won/lost probability
- `recommendMitigations(risks, features)`: Get ML-based mitigation recommendations

### 3. Model Service

**Location**: `apps/api/src/services/risk-ml/model.service.ts`

**Purpose**: Manage ML model versions, loading, and inference

**Responsibilities**:
- Model versioning and registry
- Model loading and caching
- A/B testing between model versions
- Model metadata tracking

**Key Methods**:
- `loadModel(modelId, modelType)`: Load a specific model version
- `getModel(modelType, tenantId)`: Get active model for a type
- `registerModel(model)`: Register a new model version
- `getModelMetrics(modelId)`: Get performance metrics for a model
- `setABTestTraffic(modelId, percentage)`: Configure A/B testing

### 4. Training Service

**Location**: `apps/api/src/services/risk-ml/training.service.ts`

**Purpose**: Orchestrate model training and fine-tuning

**Responsibilities**:
- Schedule training jobs
- Prepare training datasets
- Trigger LLM fine-tuning jobs
- Train traditional ML models
- Coordinate hyperparameter optimization

**Key Methods**:
- `scheduleTraining(modelType, options)`: Schedule a training job
- `prepareTrainingData(modelType, options)`: Prepare training dataset
- `trainModel(modelType, trainingData)`: Train a model
- `fineTuneLLM(trainingData)`: Trigger LLM fine-tuning
- `getTrainingStatus(jobId)`: Get training job status

### 5. LLM Fine-tuning Service

**Location**: `apps/api/src/services/risk-ml/llm-fine-tuning.service.ts`

**Purpose**: Fine-tune LLMs specifically for risk identification

**Responsibilities**:
- Prepare fine-tuning datasets
- Format training data for LLM fine-tuning
- Trigger fine-tuning jobs
- Track fine-tuning job status
- Deploy fine-tuned models

**Key Methods**:
- `prepareFineTuningData(riskSnapshots)`: Prepare training data
- `startFineTuningJob(trainingData, options)`: Start fine-tuning
- `getFineTuningStatus(jobId)`: Check job status
- `deployFineTunedModel(jobId)`: Deploy completed model

### 6. Risk Feedback Service

**Location**: `apps/api/src/services/risk-ml/risk-feedback.service.ts`

**Purpose**: Collect and process risk-specific feedback

**Responsibilities**:
- Track user actions on risks
- Link risk predictions to outcomes
- Collect explicit feedback
- Store feedback for training

**Key Methods**:
- `recordRiskFeedback(feedback)`: Record user feedback on a risk
- `recordOutcome(opportunityId, outcome)`: Record won/lost outcome
- `getFeedbackForTraining(options)`: Get feedback data for training
- `getFeedbackStats(tenantId)`: Get feedback statistics

### 7. Evaluation Service

**Location**: `apps/api/src/services/risk-ml/evaluation.service.ts`

**Purpose**: Evaluate model performance and trigger retraining

**Responsibilities**:
- Calculate model metrics
- Track prediction vs. actual outcomes
- Monitor model drift
- Compare model versions
- Trigger retraining when needed

**Key Methods**:
- `evaluateModel(modelId, testData)`: Evaluate a model
- `calculateMetrics(predictions, actuals)`: Calculate performance metrics
- `detectModelDrift(modelId)`: Check for model drift
- `compareModels(modelIds)`: Compare model versions
- `shouldRetrain(modelId)`: Determine if retraining is needed

## Data Flow

### Risk Evaluation Flow (Enhanced)

```mermaid
sequenceDiagram
    participant User
    participant RE as RiskEvaluationService
    participant RML as RiskMLService
    participant FS as FeatureStore
    participant MS as ModelService
    participant LLM as Fine-tuned LLM
    participant ML as ML Models
    
    User->>RE: Evaluate Opportunity
    RE->>RE: Rule-based Detection
    RE->>FS: Extract Features
    FS->>FS: Feature Engineering
    FS->>RML: Return Features
    RML->>LLM: Identify Risks (Fine-tuned)
    LLM->>RML: Risk Identifications
    RML->>MS: Load Risk Scoring Model
    MS->>ML: Predict Risk Score
    ML->>RML: Risk Score
    RML->>MS: Load Outcome Model
    MS->>ML: Predict Outcome
    ML->>RML: Won/Lost Probability
    RML->>MS: Load Mitigation Model
    MS->>ML: Recommend Mitigations
    ML->>RML: Mitigation Recommendations
    RML->>RE: ML-Enhanced Evaluation
    RE->>RE: Create Risk Snapshot
    RE->>User: Return Evaluation
```

### Training Flow

```mermaid
sequenceDiagram
    participant Scheduler
    participant TS as TrainingService
    participant TDP as TrainingDataPipeline
    participant LLMFT as LLM Fine-tuning
    participant MLT as ML Training
    participant ES as EvaluationService
    participant MS as ModelService
    
    Scheduler->>TS: Trigger Training
    TS->>TDP: Prepare Training Data
    TDP->>TDP: Extract Features & Labels
    TDP->>TS: Training Dataset
    
    TS->>LLMFT: Fine-tune LLM
    LLMFT->>LLMFT: Training Job
    LLMFT->>TS: Fine-tuned Model
    
    TS->>MLT: Train ML Models
    MLT->>MLT: Train Risk Scoring Model
    MLT->>MLT: Train Outcome Model
    MLT->>MLT: Train Mitigation Model
    MLT->>TS: Trained Models
    
    TS->>ES: Evaluate Models
    ES->>ES: Calculate Metrics
    ES->>TS: Evaluation Results
    
    alt Models Meet Threshold
        TS->>MS: Register New Models
        MS->>MS: Version Models
        MS->>MS: Enable A/B Testing
    else Models Below Threshold
        TS->>TS: Log Failure
        TS->>TS: Trigger Investigation
    end
```

## Data Models

### Risk Training Example

```typescript
interface RiskTrainingExample {
  id: string;
  opportunityId: string;
  tenantId: string;
  snapshotDate: Date;
  
  // Features
  features: {
    // Opportunity features
    dealValue: number;
    probability: number;
    daysToClose: number;
    daysSinceActivity: number;
    stage: string;
    industry: string;
    
    // Risk features
    detectedRisks: Array<{
      riskId: string;
      category: string;
      confidence: number;
    }>;
    riskScore: number;
    categoryScores: Record<string, number>;
    
    // Historical features
    ownerWinRate: number;
    accountHealth: number;
    similarDealsWinRate: number;
    
    // Relationship features
    stakeholderCount: number;
    activityCount: number;
    documentCount: number;
  };
  
  // Labels (actual outcomes)
  labels: {
    actualRiskScore: number;
    actualOutcome: 'won' | 'lost' | null;
    actualRevenueAtRisk: number;
    actualMitigationEffectiveness?: Record<string, number>;
  };
  
  createdAt: Date;
  outcomeDate?: Date;
}
```

### Model Metadata

```typescript
interface RiskMLModel {
  id: string;
  modelType: 'risk_scoring' | 'outcome_prediction' | 'mitigation_recommendation' | 'llm_fine_tuned';
  version: string;
  tenantId?: string;
  trainingDate: Date;
  
  // Performance metrics
  metrics: {
    accuracy?: number;
    precision?: number;
    recall?: number;
    f1Score?: number;
    mse?: number;
    r2Score?: number;
  };
  
  // Model artifacts
  artifactPath: string;
  artifactSize: number;
  
  // Training info
  trainingExamples: number;
  validationExamples: number;
  trainingDurationMs: number;
  
  // Status
  status: 'training' | 'evaluating' | 'active' | 'deprecated';
  isDefault: boolean;
  
  // A/B testing
  abTestTraffic: number;
  abTestStartDate?: Date;
  
  createdAt: Date;
  updatedAt: Date;
}
```

## Integration with Existing System

### RiskEvaluationService Integration

The ML system enhances the existing `RiskEvaluationService`:

1. **Before ML**: Rule-based → Historical → AI (LLM) → Risk Evaluation
2. **With ML**: Rule-based → Historical → AI (LLM) → **ML Enhancement** → Risk Evaluation

The ML enhancement step:
- Extracts features from the opportunity
- Uses fine-tuned LLM for risk identification
- Uses ML models for risk scoring and outcome prediction
- Combines predictions with existing methods using weighted ensemble

### Feedback Integration

The system extends `FeedbackLearningService` with risk-specific methods:
- Track risk acknowledgments/dismissals
- Link predictions to outcomes
- Collect mitigation effectiveness feedback
- Use feedback to improve models

## Storage Architecture

### Cosmos DB Collections

- **Risk Snapshots**: Historical risk evaluations (training data source)
- **Model Metadata**: Model versions, metrics, status
- **Training Jobs**: Training job status and results
- **Feedback**: Risk-specific feedback and outcomes

### Azure Blob Storage

- **Model Artifacts**: Trained model files (ONNX, pickle, etc.)
- **Training Data**: Exported training datasets
- **Fine-tuning Data**: LLM fine-tuning datasets

### Redis

- **Feature Cache**: Cached features for quick access
- **Model Cache**: Loaded models in memory
- **Prediction Cache**: Recent predictions

## Performance Considerations

### Caching Strategy

- **Features**: Cache for 15 minutes (opportunities change infrequently)
- **Models**: Keep in memory, reload on version change
- **Predictions**: Cache for 5 minutes (risk evaluations are cached)

### Inference Optimization

- **Batch Processing**: Process multiple opportunities in batch
- **Model Quantization**: Use quantized models for faster inference
- **ONNX Runtime**: Use ONNX for cross-platform model execution

### Training Optimization

- **Incremental Training**: Train on new data only when possible
- **Distributed Training**: Use distributed training for large datasets
- **Hyperparameter Tuning**: Use automated hyperparameter optimization

## Security & Compliance

### Data Privacy

- **Tenant Isolation**: Models can be tenant-specific or global
- **Data Encryption**: Training data encrypted at rest and in transit
- **Access Control**: Role-based access to models and training data

### Model Governance

- **Model Auditing**: Track all model changes and deployments
- **Explainability**: Maintain explainability for regulatory compliance
- **Bias Monitoring**: Monitor for bias in predictions across segments

## Monitoring & Observability

### Key Metrics

- **Model Performance**: Accuracy, precision, recall, F1 score
- **System Performance**: Latency, throughput, error rates
- **Business Metrics**: Risk detection improvement, prediction accuracy

### Alerts

- **Model Drift**: Alert when model performance degrades
- **Training Failures**: Alert on training job failures
- **High Error Rates**: Alert on prediction errors
- **Data Quality Issues**: Alert on training data problems

## Future Enhancements

1. **Real-time Learning**: Update models incrementally as new data arrives
2. **Multi-tenant Models**: Shared models with tenant-specific fine-tuning
3. **Ensemble Methods**: Combine multiple models for better predictions
4. **AutoML**: Automated model selection and hyperparameter tuning
5. **Causal Inference**: Understand causal relationships in risk factors
