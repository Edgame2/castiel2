(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_19844f15._.js",
  "static/chunks/services_frontend_src_08120db6._.js"
],
    source: "dynamic"
});
