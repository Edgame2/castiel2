import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:3001';

type TenantRouteParams = { params: Promise<{ tenantId: string }> };

async function getAuthHeader(): Promise<string | null> {
  const cookieStore = await cookies();
  const accessToken = cookieStore.get('access_token');
  return accessToken ? `Bearer ${accessToken.value}` : null;
}

export async function POST(request: NextRequest, context: TenantRouteParams) {
  try {
    const authHeader = await getAuthHeader();
    
    if (!authHeader) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const { tenantId } = await context.params;
    const response = await fetch(`${API_BASE_URL}/api/tenants/${tenantId}/activate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authHeader,
      },
    });

    const data = await response.json();
    return NextResponse.json(data, { status: response.status });
  } catch (error) {
    console.error('Tenant API error:', error);
    return NextResponse.json(
      { error: 'Failed to activate tenant' },
      { status: 500 }
    );
  }
}
