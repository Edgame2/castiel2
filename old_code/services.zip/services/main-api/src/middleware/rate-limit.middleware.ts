/**
 * Rate Limit Middleware
 * Fastify middleware for rate limiting requests
 */

import type { FastifyRequest, FastifyReply, FastifyInstance } from 'fastify';
import type { RateLimiterService, InMemoryRateLimiterService } from '../services/security/rate-limiter.service.js';

export interface RateLimitMiddlewareOptions {
  action: string;
  getIdentifier?: (request: FastifyRequest) => string;
  onRateLimited?: (request: FastifyRequest, reply: FastifyReply, result: any) => Promise<void>;
}

/**
 * Default identifier extractor - uses email from body or IP address
 */
function defaultGetIdentifier(request: FastifyRequest): string {
  const body = request.body as any;
  
  // Try to get email from body (for login/registration)
  if (body?.email) {
    return `email:${body.email.toLowerCase()}`;
  }
  
  // Fall back to IP address
  return `ip:${request.ip}`;
}

/**
 * Default rate limit handler
 */
async function defaultOnRateLimited(
  request: FastifyRequest,
  reply: FastifyReply,
  result: { resetAt: number; blockExpiresAt?: number }
): Promise<void> {
  const retryAfter = Math.ceil((result.resetAt - Date.now()) / 1000);
  
  reply
    .status(429)
    .header('Retry-After', retryAfter.toString())
    .header('X-RateLimit-Reset', result.resetAt.toString())
    .send({
      error: 'Too Many Requests',
      message: result.blockExpiresAt
        ? 'Too many failed attempts. Please try again later.'
        : 'Rate limit exceeded. Please slow down.',
      retryAfter,
      resetAt: new Date(result.resetAt).toISOString(),
    });
}

/**
 * Create rate limit middleware for a specific action
 */
export function createRateLimitMiddleware(
  rateLimiter: RateLimiterService | InMemoryRateLimiterService,
  options: RateLimitMiddlewareOptions
) {
  const getIdentifier = options.getIdentifier || defaultGetIdentifier;
  const onRateLimited = options.onRateLimited || defaultOnRateLimited;

  return async function rateLimitMiddleware(
    request: FastifyRequest,
    reply: FastifyReply
  ): Promise<void> {
    const identifier = getIdentifier(request);
    const result = await rateLimiter.checkAndRecord(options.action, identifier);

    // Add rate limit headers
    reply.header('X-RateLimit-Remaining', result.remaining.toString());
    reply.header('X-RateLimit-Reset', result.resetAt.toString());

    if (!result.allowed) {
      await onRateLimited(request, reply, result);
      return;
    }
  };
}

/**
 * Create rate limit check middleware (doesn't record, just checks)
 */
export function createRateLimitCheckMiddleware(
  rateLimiter: RateLimiterService | InMemoryRateLimiterService,
  options: RateLimitMiddlewareOptions
) {
  const getIdentifier = options.getIdentifier || defaultGetIdentifier;
  const onRateLimited = options.onRateLimited || defaultOnRateLimited;

  return async function rateLimitCheckMiddleware(
    request: FastifyRequest,
    reply: FastifyReply
  ): Promise<void> {
    const identifier = getIdentifier(request);
    const result = await rateLimiter.check(options.action, identifier);

    // Add rate limit headers
    reply.header('X-RateLimit-Remaining', result.remaining.toString());
    reply.header('X-RateLimit-Reset', result.resetAt.toString());

    if (!result.allowed) {
      await onRateLimited(request, reply, result);
      return;
    }
  };
}

/**
 * Register rate limiter on Fastify instance
 */
export function registerRateLimiter(
  server: FastifyInstance,
  rateLimiter: RateLimiterService | InMemoryRateLimiterService
): void {
  server.decorate('rateLimiter', rateLimiter);
}

/**
 * Reset rate limit after successful operation
 * Use this after successful login to clear failed attempt counts
 */
export async function resetRateLimit(
  rateLimiter: RateLimiterService | InMemoryRateLimiterService,
  action: string,
  identifier: string
): Promise<void> {
  await rateLimiter.reset(action, identifier);
}

/**
 * Pre-configured middleware for login rate limiting
 */
export function createLoginRateLimitMiddleware(
  rateLimiter: RateLimiterService | InMemoryRateLimiterService
) {
  return createRateLimitMiddleware(rateLimiter, {
    action: 'login',
    getIdentifier: (request) => {
      const body = request.body as any;
      // Rate limit by both email and IP
      const email = body?.email?.toLowerCase() || 'unknown';
      return `login:${email}:${request.ip}`;
    },
    onRateLimited: async (request, reply, result) => {
      const retryAfter = Math.ceil((result.resetAt - Date.now()) / 1000);
      
      request.log.warn({
        action: 'login_rate_limited',
        email: (request.body as any)?.email,
        ip: request.ip,
        retryAfter,
      }, 'Login rate limit exceeded');

      reply
        .status(429)
        .header('Retry-After', retryAfter.toString())
        .send({
          error: 'Too Many Requests',
          message: 'Too many login attempts. Please wait before trying again.',
          retryAfter,
          resetAt: new Date(result.resetAt).toISOString(),
        });
    },
  });
}

/**
 * Pre-configured middleware for password reset rate limiting
 */
export function createPasswordResetRateLimitMiddleware(
  rateLimiter: RateLimiterService | InMemoryRateLimiterService
) {
  return createRateLimitMiddleware(rateLimiter, {
    action: 'passwordReset',
    getIdentifier: (request) => {
      const body = request.body as any;
      return `reset:${body?.email?.toLowerCase() || request.ip}`;
    },
  });
}

/**
 * Pre-configured middleware for registration rate limiting
 */
export function createRegistrationRateLimitMiddleware(
  rateLimiter: RateLimiterService | InMemoryRateLimiterService
) {
  return createRateLimitMiddleware(rateLimiter, {
    action: 'registration',
    getIdentifier: (request) => {
      // Rate limit by IP for registration
      return `register:${request.ip}`;
    },
  });
}


