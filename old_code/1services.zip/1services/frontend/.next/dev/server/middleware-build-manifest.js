globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/9cd88_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_268e0fdb._.js",
    "static/chunks/9cd88_next_dist_compiled_react-dom_eb0758de._.js",
    "static/chunks/9cd88_next_dist_compiled_react-server-dom-turbopack_916cedd1._.js",
    "static/chunks/9cd88_next_dist_compiled_next-devtools_index_bbf159be.js",
    "static/chunks/9cd88_next_dist_compiled_2bb5dbe0._.js",
    "static/chunks/9cd88_next_dist_client_c7efba2e._.js",
    "static/chunks/9cd88_next_dist_c6b4bb04._.js",
    "static/chunks/69652_@swc_helpers_cjs_679851cc._.js",
    "static/chunks/services_frontend_a0ff3932._.js",
    "static/chunks/turbopack-services_frontend_9a3f89fc._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];