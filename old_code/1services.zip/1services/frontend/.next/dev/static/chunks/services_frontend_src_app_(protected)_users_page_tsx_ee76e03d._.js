(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/services_frontend_src_95dd9906._.js",
  "static/chunks/275fa_@tanstack_table-core_build_lib_index_mjs_6f1bc5e2._.js",
  "static/chunks/3ad0e_@radix-ui_react-select_dist_index_mjs_fabcf722._.js",
  "static/chunks/77b74_axios_lib_3ffa8d91._.js",
  "static/chunks/7d783_react-hook-form_dist_index_esm_mjs_d31afe53._.js",
  "static/chunks/37e87_zod_v4_9728400a._.js",
  "static/chunks/node_modules__pnpm_898254d9._.js"
],
    source: "dynamic"
});
