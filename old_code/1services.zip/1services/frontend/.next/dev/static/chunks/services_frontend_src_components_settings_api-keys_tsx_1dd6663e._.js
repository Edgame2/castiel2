(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_6c3df227._.js",
  "static/chunks/services_frontend_src_58064b2e._.js"
],
    source: "dynamic"
});
