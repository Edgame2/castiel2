/**
 * Field-Level Security Types
 * 
 * Types for per-field access control, encryption, and data classification
 */

/**
 * Field access level
 */
export enum FieldAccessLevel {
  PUBLIC = 'public',        // Anyone with shard access can view
  PRIVATE = 'private',      // Only owner and admins
  RESTRICTED = 'restricted', // Specific roles only
  SYSTEM = 'system',        // System fields, never exposed to API
}

/**
 * Data classification
 */
export enum DataClassification {
  PUBLIC = 'public',
  INTERNAL = 'internal',
  CONFIDENTIAL = 'confidential',
  RESTRICTED = 'restricted',
  PII = 'pii',              // Personally Identifiable Information
  PHI = 'phi',              // Protected Health Information
  PCI = 'pci',              // Payment Card Industry data
}

/**
 * Field encryption settings
 */
export interface FieldEncryption {
  enabled: boolean;
  algorithm?: 'AES-256-GCM' | 'AES-256-CBC';
  keyId?: string;           // Reference to encryption key
  atRest: boolean;          // Encrypt at rest
  inTransit?: boolean;      // Additional encryption in transit
}

/**
 * Field masking configuration
 */
export interface FieldMasking {
  enabled: boolean;
  strategy: MaskingStrategy;
  preserveLength?: boolean;
  maskChar?: string;
  visibleChars?: number;    // Number of chars to show
  visiblePosition?: 'start' | 'end' | 'both';
}

/**
 * Masking strategies
 */
export enum MaskingStrategy {
  FULL = 'full',            // Replace entire value: ********
  PARTIAL = 'partial',      // Show some chars: john****@example.com
  HASH = 'hash',            // Show hash: abc123...
  REDACT = 'redact',        // Replace with [REDACTED]
  TOKEN = 'token',          // Replace with reversible token
  NONE = 'none',            // No masking
}

/**
 * Field-level security configuration for a single field
 */
export interface FieldSecurityConfig {
  fieldPath: string;        // Path in structuredData (e.g., "personalInfo.ssn")
  accessLevel: FieldAccessLevel;
  classification: DataClassification;
  
  // Role-based access
  readRoles?: string[];     // Roles that can read this field
  writeRoles?: string[];    // Roles that can write this field
  
  // Encryption
  encryption?: FieldEncryption;
  
  // Masking
  masking?: FieldMasking;
  
  // Audit
  auditReads?: boolean;     // Log all read access
  auditWrites?: boolean;    // Log all write access
  
  // Validation
  validationRules?: FieldValidationRule[];
  
  // Retention
  retentionDays?: number;   // Auto-delete after N days
}

/**
 * Field validation rule
 */
export interface FieldValidationRule {
  type: 'required' | 'pattern' | 'minLength' | 'maxLength' | 'enum' | 'custom';
  value?: any;
  message?: string;
}

/**
 * ShardType field security configuration
 */
export interface ShardTypeSecurityConfig {
  id: string;
  shardTypeId: string;
  tenantId: string;
  
  // Default settings
  defaultAccessLevel: FieldAccessLevel;
  defaultClassification: DataClassification;
  
  // Per-field configurations
  fields: FieldSecurityConfig[];
  
  // Global settings
  encryptAllPII?: boolean;
  auditAllAccess?: boolean;
  
  // Metadata
  createdAt: Date;
  createdBy: string;
  updatedAt?: Date;
}

/**
 * Field access check result
 */
export interface FieldAccessResult {
  allowed: boolean;
  reason?: string;
  maskedValue?: any;
}

/**
 * Secure field value (for encrypted fields)
 */
export interface SecureFieldValue {
  encrypted: true;
  algorithm: string;
  keyId: string;
  iv: string;          // Initialization vector
  ciphertext: string;
  tag?: string;        // Auth tag for GCM
}

/**
 * Field access audit entry
 */
export interface FieldAccessAudit {
  id: string;
  tenantId: string;
  shardId: string;
  fieldPath: string;
  accessType: 'read' | 'write';
  userId: string;
  userRoles: string[];
  allowed: boolean;
  masked: boolean;
  timestamp: Date;
  ipAddress?: string;
  userAgent?: string;
}

/**
 * Create field security config input
 */
export interface CreateFieldSecurityConfigInput {
  shardTypeId: string;
  defaultAccessLevel?: FieldAccessLevel;
  defaultClassification?: DataClassification;
  fields: Omit<FieldSecurityConfig, 'fieldPath'>[];
  encryptAllPII?: boolean;
  auditAllAccess?: boolean;
}

/**
 * Update field security config input
 */
export interface UpdateFieldSecurityConfigInput {
  defaultAccessLevel?: FieldAccessLevel;
  defaultClassification?: DataClassification;
  fields?: FieldSecurityConfig[];
  encryptAllPII?: boolean;
  auditAllAccess?: boolean;
}

/**
 * Apply security to shard data
 */
export interface ApplySecurityOptions {
  userId: string;
  userRoles: string[];
  operation: 'read' | 'write';
  auditAccess?: boolean;
}


