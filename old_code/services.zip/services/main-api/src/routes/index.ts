import type { FastifyInstance } from 'fastify';
import type { Redis } from 'ioredis';
import { registerHealthRoutes } from './health.js';
import { registerProtectedRoutes } from './protected.js';
import { registerSSERoutes } from './sse.routes.js';
import { registerShardTypesRoutes } from './shard-types.routes.js';
import { registerShardsRoutes } from './shards.routes.js';
import { registerACLRoutes } from './acl.routes.js';
import { registerRevisionsRoutes } from './revisions.routes.js';
import { registerVectorSearchRoutes } from './vector-search.routes.js';
import { registerCacheAdminRoutes } from './cache-admin.routes.js';
import { MonitoringService } from '@castiel/monitoring';
import { registerAuthRoutes } from './auth.routes.js';
import { registerMFARoutes } from './mfa.routes.js';
import { registerMagicLinkRoutes } from './magic-link.routes.js';
import { registerSSORoutes } from './sso.routes.js';
import { registerSSOConfigRoutes } from './sso-config.routes.js';
import { registerAzureADB2CRoutes } from './azure-ad-b2c.routes.js';
import { registerOAuthRoutes } from './oauth.routes.js';
import { registerOAuth2Routes } from './oauth2.routes.js';
import { registerUserManagementRoutes } from './user-management.routes.js';
import { registerUserSecurityRoutes } from './user-security.routes.js';
import { registerSessionManagementRoutes } from './session-management.routes.js';
import { registerRoleManagementRoutes } from './role-management.routes.js';
import { registerTenantRoutes } from './tenant.routes.js';
import { registerTenantMembershipRoutes } from './tenant-membership.routes.js';
import { auditLogRoutes } from './audit-log.routes.js';

/**
 * Register all application routes
 */
export async function registerRoutes(
  server: FastifyInstance,
  redis: Redis | null
): Promise<void> {
  // Health check routes (public)
  await registerHealthRoutes(server, redis);

  // Core authentication routes
  if ((server as any).authController) {
    await registerAuthRoutes(server);
    server.log.info('✅ Auth routes registered');
  } else {
    server.log.warn('⚠️  Auth routes not registered - AuthController missing');
  }

  // MFA routes rely on decorated controller
  if ((server as any).mfaController) {
    await registerMFARoutes(server);
    server.log.info('✅ MFA routes registered');
  } else {
    server.log.warn('⚠️  MFA routes not registered - MFAController missing');
  }

  // Magic link routes (passwordless authentication)
  if ((server as any).magicLinkController) {
    await registerMagicLinkRoutes(server);
    server.log.info('✅ Magic link routes registered');
  } else {
    server.log.warn('⚠️  Magic link routes not registered - MagicLinkController missing');
  }

  // SSO/SAML routes
  if ((server as any).ssoController) {
    await registerSSORoutes(server);
    server.log.info('✅ SSO routes registered');
  } else {
    server.log.warn('⚠️  SSO routes not registered - SSOController missing');
  }

  // SSO Configuration routes (admin)
  if ((server as any).ssoConfigController) {
    registerSSOConfigRoutes(server, (server as any).ssoConfigController);
    server.log.info('✅ SSO config routes registered');
  } else {
    server.log.warn('⚠️  SSO config routes not registered - SSOConfigController missing');
  }

  // Azure AD B2C routes
  if ((server as any).azureADB2CController) {
    registerAzureADB2CRoutes(server, (server as any).azureADB2CController);
    server.log.info('✅ Azure AD B2C routes registered');
  } else {
    server.log.warn('⚠️  Azure AD B2C routes not registered - AzureADB2CController missing');
  }

  if ((server as any).oauthController) {
    await registerOAuthRoutes(server);
    server.log.info('✅ OAuth routes registered');
  } else {
    server.log.warn('⚠️  OAuth routes not registered - OAuthController missing');
  }

  if ((server as any).oauth2Controller) {
    await registerOAuth2Routes(server);
    server.log.info('✅ OAuth2 routes registered');
  } else {
    server.log.warn('⚠️  OAuth2 routes not registered - OAuth2Controller missing');
  }

  if ((server as any).userManagementController) {
    await registerUserManagementRoutes(server);
    server.log.info('✅ User management routes registered');
  } else {
    server.log.warn('⚠️  User management routes not registered - controller missing');
  }

  // User security routes (admin)
  if ((server as any).userSecurityController) {
    registerUserSecurityRoutes(server, (server as any).userSecurityController);
    server.log.info('✅ User security routes registered');
  } else {
    server.log.warn('⚠️  User security routes not registered - UserSecurityController missing');
  }

  if ((server as any).sessionManagementController) {
    await registerSessionManagementRoutes(server);
    server.log.info('✅ Session management routes registered');
  } else {
    server.log.warn('⚠️  Session management routes not registered - controller missing');
  }

  if ((server as any).roleManagementController) {
    await registerRoleManagementRoutes(server);
    server.log.info('✅ Role management routes registered');
  } else {
    server.log.warn('⚠️  Role management routes not registered - controller missing');
  }

  if ((server as any).tenantController) {
    await registerTenantRoutes(server);
    server.log.info('✅ Tenant routes registered');
  } else {
    server.log.warn('⚠️  Tenant routes not registered - controller missing');
  }

  if ((server as any).tenantMembershipController) {
    await registerTenantMembershipRoutes(server);
    server.log.info('✅ Tenant membership routes registered');
  } else {
    server.log.warn('⚠️  Tenant membership routes not registered - controller missing');
  }

  // Audit log routes (requires Cosmos DB)
  if ((server as any).cosmos) {
    try {
      await auditLogRoutes(server);
      server.log.info('✅ Audit log routes registered');
    } catch (err) {
      server.log.warn({ err }, '⚠️ Audit log routes not registered');
    }
  } else {
    server.log.warn('⚠️  Audit log routes not registered - Cosmos DB unavailable');
  }

  // Protected routes (require authentication)
  await registerProtectedRoutes(
    server,
    (server as any).tokenValidationCache || null
  );
  server.log.info('✅ Protected routes registered');

  // SSE routes (require authentication)
  await registerSSERoutes(
    server,
    (server as any).tokenValidationCache || null
  );
  server.log.info('✅ SSE routes registered');

  // Get monitoring service from server or create new instance
  const monitoring = MonitoringService.getInstance() || MonitoringService.initialize({
    enabled: false,
    provider: 'mock',
  });

  // ShardTypes API routes
  await registerShardTypesRoutes(server, monitoring);
  server.log.info('✅ ShardTypes routes registered');

  // Shards API routes (with caching)
  const cacheService = (server as any).cache;
  const cacheSubscriber = (server as any).cacheSubscriber;

  if (cacheService && cacheSubscriber) {
    await registerShardsRoutes(server, monitoring, cacheService, cacheSubscriber);
    server.log.info('✅ Shards routes registered (with caching)');
  } else {
    server.log.warn('⚠️  Shards routes not registered - cache services not available');
  }

  // ACL API routes (with caching)
  if (cacheService && cacheSubscriber) {
    await registerACLRoutes(server, monitoring, cacheService, cacheSubscriber);
    server.log.info('✅ ACL routes registered (with caching)');
  } else {
    await registerACLRoutes(server, monitoring);
    server.log.info('✅ ACL routes registered (without caching)');
  }

  // Revisions API routes (no caching - always fetch fresh)
  if (cacheService && cacheSubscriber) {
    await registerRevisionsRoutes(server, monitoring, cacheService, cacheSubscriber);
    server.log.info('✅ Revisions routes registered (with ACL and cache for shards)');
  } else {
    await registerRevisionsRoutes(server, monitoring);
    server.log.info('✅ Revisions routes registered (without caching)');
  }

  // Vector Search API routes (with caching)
  if (cacheService && cacheSubscriber) {
    await registerVectorSearchRoutes(server, monitoring, cacheService, cacheSubscriber);
    server.log.info('✅ Vector search routes registered (with caching)');
  } else {
    await registerVectorSearchRoutes(server, monitoring);
    server.log.info('✅ Vector search routes registered (without caching)');
  }

  // Cache Admin API routes (monitoring and warming)
  const cosmosContainer = (server as any).cosmosContainer;
  const shardCache = (server as any).shardCache;
  const aclCache = (server as any).aclCache;
  const vectorSearchCache = (server as any).vectorSearchCache;
  const tokenValidationCache = (server as any).tokenValidationCache;

  if (cosmosContainer && redis) {
    await registerCacheAdminRoutes(server, {
      cosmosContainer,
      redisClient: redis,
      monitoring,
      shardCache,
      aclCache,
      vectorSearchCache,
      tokenValidationCache,
    });
    server.log.info('✅ Cache admin routes registered (with monitoring and warming)');
  } else {
    server.log.warn('⚠️  Cache admin routes not registered - Cosmos DB or Redis not available');
  }

  // API routes will be added here
  // Example:
  // await registerUserRoutes(server);
  // await registerOrderRoutes(server);
}
