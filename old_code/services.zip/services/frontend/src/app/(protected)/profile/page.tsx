'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useTranslation } from 'react-i18next'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Loader2, User, Mail, Calendar, Shield } from 'lucide-react'
import { getProfile, updateProfile, UserProfile } from '@/lib/api/profile'
import { Badge } from '@/components/ui/badge'
import { TenantMembershipsCard } from '@/components/profile/tenant-memberships'

export default function ProfilePage() {
  const router = useRouter()
  const { t } = useTranslation(['profile', 'common'])
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
  })

  // Load profile on mount
  useEffect(() => {
    loadProfile()
  }, [])

  async function loadProfile() {
    try {
      setLoading(true)
      setError(null)
      const data = await getProfile()
      setProfile(data)
      setFormData({
        firstName: data.firstName || '',
        lastName: data.lastName || '',
      })
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errors:generic.message'))
    } finally {
      setLoading(false)
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setSuccess(false)
    setSaving(true)

    try {
      const updated = await updateProfile(formData)
      setProfile(updated)
      setSuccess(true)
      
      // Clear success message after 3 seconds
      setTimeout(() => setSuccess(false), 3000)
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errors:generic.message'))
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-sm text-muted-foreground">{t('profile:loading')}</p>
        </div>
      </div>
    )
  }

  if (!profile) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Alert variant="destructive" className="max-w-md">
          <AlertDescription>
            {error || t('errors:generic.message')}
          </AlertDescription>
        </Alert>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6 max-w-4xl">
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold">{t('profile:title')}</h1>
          <p className="text-muted-foreground mt-1">
            {t('profile:subtitle')}
          </p>
        </div>

        {/* Profile Information Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              {t('profile:personalInfo.title')}
            </CardTitle>
            <CardDescription>
              {t('profile:personalInfo.description')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {success && (
                <Alert>
                  <AlertDescription>{t('profile:personalInfo.success')}</AlertDescription>
                </Alert>
              )}

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="firstName">{t('profile:personalInfo.firstName')}</Label>
                  <Input
                    id="firstName"
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    placeholder={t('profile:personalInfo.firstNamePlaceholder')}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="lastName">{t('profile:personalInfo.lastName')}</Label>
                  <Input
                    id="lastName"
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    placeholder={t('profile:personalInfo.lastNamePlaceholder')}
                  />
                </div>
              </div>

              <div className="pt-4">
                <Button type="submit" disabled={saving}>
                  {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {saving ? t('profile:personalInfo.saving') : t('profile:personalInfo.saveChanges')}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Account Information Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mail className="h-5 w-5" />
              {t('profile:accountInfo.title')}
            </CardTitle>
            <CardDescription>
              {t('profile:accountInfo.description')}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-1">
                <Label className="text-muted-foreground text-xs">{t('profile:accountInfo.email')}</Label>
                <p className="font-medium">{profile.email}</p>
              </div>

              <div className="space-y-1">
                <Label className="text-muted-foreground text-xs">{t('profile:accountInfo.displayName')}</Label>
                <p className="font-medium">{profile.displayName}</p>
              </div>

              <div className="space-y-1">
                <Label className="text-muted-foreground text-xs">{t('profile:accountInfo.status')}</Label>
                <div>
                  <Badge variant={profile.status === 'active' ? 'default' : 'secondary'}>
                    {profile.status}
                  </Badge>
                </div>
              </div>

              <div className="space-y-1">
                <Label className="text-muted-foreground text-xs">{t('profile:accountInfo.emailVerified')}</Label>
                <div>
                  <Badge variant={profile.emailVerified ? 'default' : 'outline'}>
                    {profile.emailVerified ? t('profile:accountInfo.verified') : t('profile:accountInfo.notVerified')}
                  </Badge>
                </div>
              </div>
            </div>

            <div className="space-y-1">
              <Label className="text-muted-foreground text-xs flex items-center gap-1">
                <Shield className="h-3 w-3" />
                {t('profile:accountInfo.roles')}
              </Label>
              <div className="flex gap-2 flex-wrap">
                {profile.roles.map((role) => (
                  <Badge key={role} variant="secondary">
                    {role}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2 pt-2 border-t">
              <div className="space-y-1">
                <Label className="text-muted-foreground text-xs flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {t('profile:accountInfo.created')}
                </Label>
                <p className="text-sm">{new Date(profile.createdAt).toLocaleDateString()}</p>
              </div>

              <div className="space-y-1">
                <Label className="text-muted-foreground text-xs flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {t('profile:accountInfo.lastUpdated')}
                </Label>
                <p className="text-sm">{new Date(profile.updatedAt).toLocaleDateString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <TenantMembershipsCard />
      </div>
    </div>
  )
}
