(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/services/frontend/src/components/admin/platform-stats.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules__pnpm_67238c02._.js",
  "static/chunks/services_frontend_src_d8f04f2e._.js",
  "static/chunks/services_frontend_src_components_admin_platform-stats_tsx_7d8cd16b._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/services/frontend/src/components/admin/platform-stats.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/services/frontend/src/components/admin/tenants-list.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/services_frontend_src_5ed54fab._.js",
  "static/chunks/node_modules__pnpm_fc066d48._.js",
  "static/chunks/services_frontend_src_components_admin_tenants-list_tsx_7d8cd16b._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/services/frontend/src/components/admin/tenants-list.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/services/frontend/src/components/admin/system-health.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules__pnpm_19844f15._.js",
  "static/chunks/services_frontend_src_08120db6._.js",
  "static/chunks/services_frontend_src_components_admin_system-health_tsx_7d8cd16b._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/services/frontend/src/components/admin/system-health.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/services/frontend/src/components/admin/system-logs.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules__pnpm_d317fb56._.js",
  "static/chunks/services_frontend_src_5afd8e38._.js",
  "static/chunks/services_frontend_src_components_admin_system-logs_tsx_7d8cd16b._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/services/frontend/src/components/admin/system-logs.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);