import type { FastifyInstance } from 'fastify';
import { AuthController } from '../controllers/auth.controller.js';
import {
  registerSchema,
  loginSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
  verifyEmailSchema,
  refreshTokenSchema,
  revokeTokenSchema,
  introspectTokenSchema,
  mfaChallengeVerifySchema,
  getProfileSchema,
  updateProfileSchema,
  listUserTenantsSchema,
  updateDefaultTenantSchema,
  switchTenantSchema,
  checkRegistrationSchema,
  resendVerificationSchema,
} from '../schemas/auth.schemas.js';
import {
  createLoginRateLimitMiddleware,
  createPasswordResetRateLimitMiddleware,
  createRegistrationRateLimitMiddleware,
} from '../middleware/rate-limit.middleware.js';
import type { RateLimiterService, InMemoryRateLimiterService } from '../services/security/rate-limiter.service.js';

export async function registerAuthRoutes(server: FastifyInstance): Promise<void> {
  const authController = (server as FastifyInstance & { authController?: AuthController })
    .authController;

  if (!authController) {
    throw new Error('AuthController not found on server instance');
  }

  // Get rate limiter from server if available
  const rateLimiter = (server as any).rateLimiter as RateLimiterService | InMemoryRateLimiterService | undefined;

  // Create rate limit middlewares if rate limiter is available
  const loginRateLimit = rateLimiter ? createLoginRateLimitMiddleware(rateLimiter) : undefined;
  const passwordResetRateLimit = rateLimiter ? createPasswordResetRateLimitMiddleware(rateLimiter) : undefined;
  const registrationRateLimit = rateLimiter ? createRegistrationRateLimitMiddleware(rateLimiter) : undefined;

  // Registration with rate limiting
  server.post('/auth/register', {
    schema: registerSchema,
    preHandler: registrationRateLimit ? [registrationRateLimit] : undefined,
  }, (request, reply) =>
    authController.register(request, reply)
  );

  // Login with rate limiting
  server.post('/auth/login', {
    schema: loginSchema,
    preHandler: loginRateLimit ? [loginRateLimit] : undefined,
  }, (request, reply) =>
    authController.login(request, reply)
  );

  server.get('/auth/verify-email/:token', { schema: verifyEmailSchema }, (request, reply) =>
    authController.verifyEmail(request, reply)
  );

  // Resend verification email
  server.post('/auth/resend-verification', { schema: resendVerificationSchema }, (request, reply) =>
    authController.resendVerificationEmail(request, reply)
  );

  // Forgot password with rate limiting
  server.post('/auth/forgot-password', {
    schema: forgotPasswordSchema,
    preHandler: passwordResetRateLimit ? [passwordResetRateLimit] : undefined,
  }, (request, reply) =>
    authController.forgotPassword(request, reply)
  );

  server.post('/auth/reset-password', { schema: resetPasswordSchema }, (request, reply) =>
    authController.resetPassword(request, reply)
  );

  server.post('/auth/refresh', { schema: refreshTokenSchema }, (request, reply) =>
    authController.refreshToken(request, reply)
  );

  server.post('/auth/logout', (request, reply) => authController.logout(request, reply));

  server.post('/auth/revoke', { schema: revokeTokenSchema }, (request, reply) =>
    authController.revokeToken(request, reply)
  );

  server.post('/auth/introspect', { schema: introspectTokenSchema }, (request, reply) =>
    authController.introspectToken(request, reply)
  );

  server.post('/auth/mfa/verify', { schema: mfaChallengeVerifySchema }, (request, reply) =>
    authController.completeMFAChallenge(request, reply)
  );

  server.get('/auth/me', { schema: getProfileSchema }, (request, reply) =>
    authController.getProfile(request, reply)
  );

  server.patch('/auth/me', { schema: updateProfileSchema }, (request, reply) =>
    authController.updateProfile(request, reply)
  );

  server.get('/auth/tenants', { schema: listUserTenantsSchema }, (request, reply) =>
    authController.listUserTenants(request, reply)
  );

  server.patch('/auth/default-tenant', { schema: updateDefaultTenantSchema }, (request, reply) =>
    authController.updateDefaultTenant(request, reply)
  );

  server.post('/auth/switch-tenant', { schema: switchTenantSchema }, (request, reply) =>
    authController.switchTenant(request, reply)
  );

  // Pre-registration check endpoint - determines registration flow based on email
  server.post('/auth/check-registration', { schema: checkRegistrationSchema }, (request, reply) =>
    authController.checkRegistration(request, reply)
  );

  server.log.info('Authentication routes registered');
}
