module.exports=[35585,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},24420,a=>{"use strict";let b={src:a.i(35585).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=services_frontend_src_app_774abe10._.js.map