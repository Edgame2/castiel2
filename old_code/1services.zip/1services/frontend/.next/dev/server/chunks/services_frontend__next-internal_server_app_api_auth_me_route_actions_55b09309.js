module.exports = [
"[project]/services/frontend/.next-internal/server/app/api/auth/me/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=services_frontend__next-internal_server_app_api_auth_me_route_actions_55b09309.js.map