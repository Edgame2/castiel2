/**
 * Shard Relationship Repository
 * 
 * Handles Cosmos DB operations for shard relationships (knowledge graph edges)
 */

import { CosmosClient, Container, ContainerDefinition, IndexingPolicy } from '@azure/cosmos';
import type { IMonitoringProvider } from '@castiel/monitoring';
import { config } from '../config/env.js';
import {
  ShardRelationship,
  CreateRelationshipInput,
  UpdateRelationshipInput,
  RelationshipQueryFilter,
  RelationshipDirection,
  GraphTraversalOptions,
  GraphTraversalResult,
  GraphNode,
  GraphEdge,
  RelatedShardsResult,
} from '../types/shard-relationship.types.js';
import type { ShardRepository } from './shard.repository.js';
import { v4 as uuidv4 } from 'uuid';

/**
 * Container configuration for relationships
 */
const RELATIONSHIP_CONTAINER_CONFIG: ContainerDefinition = {
  id: 'shard-relationships',
  partitionKey: {
    paths: ['/tenantId'],
  },
  indexingPolicy: {
    automatic: true,
    indexingMode: 'consistent',
    includedPaths: [{ path: '/*' }],
    excludedPaths: [{ path: '/_etag/?' }],
    compositeIndexes: [
      [
        { path: '/tenantId', order: 'ascending' },
        { path: '/sourceShardId', order: 'ascending' },
        { path: '/type', order: 'ascending' },
      ],
      [
        { path: '/tenantId', order: 'ascending' },
        { path: '/targetShardId', order: 'ascending' },
        { path: '/type', order: 'ascending' },
      ],
      [
        { path: '/tenantId', order: 'ascending' },
        { path: '/createdAt', order: 'descending' },
      ],
    ],
  } as IndexingPolicy,
};

/**
 * Shard Relationship Repository
 */
export class ShardRelationshipRepository {
  private client: CosmosClient;
  private container: Container;

  constructor(
    private readonly monitoring: IMonitoringProvider,
    private readonly shardRepository?: ShardRepository
  ) {
    this.client = new CosmosClient({
      endpoint: config.cosmosDb.endpoint,
      key: config.cosmosDb.key,
    });
    this.container = this.client
      .database(config.cosmosDb.databaseId)
      .container('shard-relationships');
  }

  /**
   * Ensure container exists
   */
  async ensureContainer(): Promise<void> {
    try {
      const { database } = await this.client.databases.createIfNotExists({
        id: config.cosmosDb.databaseId,
      });

      await database.containers.createIfNotExists(RELATIONSHIP_CONTAINER_CONFIG);

      this.monitoring.trackEvent('cosmosdb.container.ensured', {
        container: 'shard-relationships',
      });
    } catch (error) {
      this.monitoring.trackException(error as Error, {
        operation: 'relationship.repository.ensureContainer',
      });
      throw error;
    }
  }

  /**
   * Create a new relationship
   */
  async create(tenantId: string, userId: string, input: CreateRelationshipInput): Promise<ShardRelationship> {
    const startTime = Date.now();

    try {
      // Check for existing relationship
      const existing = await this.findByPair(
        tenantId,
        input.sourceShardId,
        input.targetShardId,
        input.type
      );

      if (existing) {
        throw new Error('Relationship already exists');
      }

      // Prevent self-relationships
      if (input.sourceShardId === input.targetShardId) {
        throw new Error('Self-relationships are not allowed');
      }

      const relationship: ShardRelationship = {
        id: uuidv4(),
        tenantId,
        sourceShardId: input.sourceShardId,
        targetShardId: input.targetShardId,
        type: input.type,
        customType: input.customType,
        bidirectional: input.bidirectional ?? false,
        label: input.label,
        description: input.description,
        strength: input.strength,
        properties: input.properties,
        createdAt: new Date(),
        createdBy: userId,
      };

      const { resource } = await this.container.items.create(relationship);

      const duration = Date.now() - startTime;
      this.monitoring.trackDependency(
        'cosmosdb.relationship.create',
        'CosmosDB',
        config.cosmosDb.endpoint,
        duration,
        true
      );

      this.monitoring.trackEvent('relationship.created', {
        relationshipId: relationship.id,
        type: relationship.type,
        tenantId,
      });

      return resource as ShardRelationship;
    } catch (error) {
      const duration = Date.now() - startTime;
      this.monitoring.trackDependency(
        'cosmosdb.relationship.create',
        'CosmosDB',
        config.cosmosDb.endpoint,
        duration,
        false
      );
      throw error;
    }
  }

  /**
   * Find relationship by ID
   */
  async findById(id: string, tenantId: string): Promise<ShardRelationship | null> {
    try {
      const { resource } = await this.container.item(id, tenantId).read<ShardRelationship>();
      return resource || null;
    } catch (error: any) {
      if (error.code === 404) return null;
      throw error;
    }
  }

  /**
   * Find relationship by source/target pair
   */
  async findByPair(
    tenantId: string,
    sourceShardId: string,
    targetShardId: string,
    type?: string
  ): Promise<ShardRelationship | null> {
    let query = `
      SELECT * FROM c 
      WHERE c.tenantId = @tenantId 
      AND c.sourceShardId = @sourceShardId 
      AND c.targetShardId = @targetShardId
    `;
    const parameters: any[] = [
      { name: '@tenantId', value: tenantId },
      { name: '@sourceShardId', value: sourceShardId },
      { name: '@targetShardId', value: targetShardId },
    ];

    if (type) {
      query += ' AND c.type = @type';
      parameters.push({ name: '@type', value: type });
    }

    const { resources } = await this.container.items.query<ShardRelationship>({
      query,
      parameters,
    }).fetchAll();

    return resources[0] || null;
  }

  /**
   * Get relationships for a shard
   */
  async getRelationshipsForShard(
    filter: RelationshipQueryFilter
  ): Promise<ShardRelationship[]> {
    let query = 'SELECT * FROM c WHERE c.tenantId = @tenantId';
    const parameters: any[] = [{ name: '@tenantId', value: filter.tenantId }];

    if (filter.shardId) {
      switch (filter.direction) {
        case RelationshipDirection.OUTGOING:
          query += ' AND c.sourceShardId = @shardId';
          break;
        case RelationshipDirection.INCOMING:
          query += ' AND c.targetShardId = @shardId';
          break;
        case RelationshipDirection.BOTH:
        default:
          query += ' AND (c.sourceShardId = @shardId OR c.targetShardId = @shardId)';
          break;
      }
      parameters.push({ name: '@shardId', value: filter.shardId });
    }

    if (filter.types && filter.types.length > 0) {
      query += ` AND c.type IN (${filter.types.map((_, i) => `@type${i}`).join(', ')})`;
      filter.types.forEach((type, i) => {
        parameters.push({ name: `@type${i}`, value: type });
      });
    }

    if (filter.minStrength !== undefined) {
      query += ' AND c.strength.value >= @minStrength';
      parameters.push({ name: '@minStrength', value: filter.minStrength });
    }

    query += ' ORDER BY c.createdAt DESC';

    const { resources } = await this.container.items.query<ShardRelationship>({
      query,
      parameters,
    }).fetchAll();

    return resources;
  }

  /**
   * Get related shards with shard data
   */
  async getRelatedShards(
    tenantId: string,
    shardId: string,
    options?: {
      direction?: RelationshipDirection;
      types?: string[];
      limit?: number;
    }
  ): Promise<RelatedShardsResult> {
    const relationships = await this.getRelationshipsForShard({
      tenantId,
      shardId,
      direction: options?.direction || RelationshipDirection.BOTH,
      types: options?.types as any,
    });

    const shards: RelatedShardsResult['shards'] = [];

    for (const rel of relationships.slice(0, options?.limit || 50)) {
      const relatedShardId = rel.sourceShardId === shardId 
        ? rel.targetShardId 
        : rel.sourceShardId;
      
      const direction = rel.sourceShardId === shardId ? 'outgoing' : 'incoming';

      if (this.shardRepository) {
        const shard = await this.shardRepository.findById(relatedShardId, tenantId);
        if (shard) {
          shards.push({
            id: shard.id,
            shardTypeId: shard.shardTypeId,
            structuredData: shard.structuredData,
            relationship: {
              id: rel.id,
              type: rel.type,
              direction,
              strength: rel.strength?.value,
            },
          });
        }
      }
    }

    return {
      relationships,
      shards,
      total: relationships.length,
    };
  }

  /**
   * Traverse the graph from a starting shard
   */
  async traverseGraph(
    tenantId: string,
    options: GraphTraversalOptions
  ): Promise<GraphTraversalResult> {
    const nodes: Map<string, GraphNode> = new Map();
    const edges: GraphEdge[] = [];
    const visited = new Set<string>();
    const queue: Array<{ shardId: string; depth: number }> = [
      { shardId: options.startShardId, depth: 0 },
    ];

    while (queue.length > 0) {
      const { shardId, depth } = queue.shift()!;

      if (visited.has(shardId) || depth > options.maxDepth) continue;
      visited.add(shardId);

      // Get shard data
      if (options.includeShardData && this.shardRepository) {
        const shard = await this.shardRepository.findById(shardId, tenantId);
        if (shard) {
          nodes.set(shardId, {
            shardId,
            shardTypeId: shard.shardTypeId,
            structuredData: shard.structuredData,
            depth,
          });
        }
      } else {
        nodes.set(shardId, { shardId, shardTypeId: '', depth });
      }

      // Get relationships
      const relationships = await this.getRelationshipsForShard({
        tenantId,
        shardId,
        direction: options.direction,
        types: options.relationshipTypes,
      });

      let addedThisLevel = 0;
      for (const rel of relationships) {
        if (options.limitPerLevel && addedThisLevel >= options.limitPerLevel) break;

        const nextShardId = rel.sourceShardId === shardId 
          ? rel.targetShardId 
          : rel.sourceShardId;

        edges.push({
          relationshipId: rel.id,
          sourceShardId: rel.sourceShardId,
          targetShardId: rel.targetShardId,
          type: rel.type,
          label: rel.label,
          strength: rel.strength?.value,
        });

        if (!visited.has(nextShardId) && depth < options.maxDepth) {
          queue.push({ shardId: nextShardId, depth: depth + 1 });
          addedThisLevel++;
        }
      }
    }

    return {
      nodes: Array.from(nodes.values()),
      edges,
      totalNodes: nodes.size,
      totalEdges: edges.length,
      truncated: options.limitPerLevel !== undefined,
    };
  }

  /**
   * Update a relationship
   */
  async update(
    id: string,
    tenantId: string,
    input: UpdateRelationshipInput
  ): Promise<ShardRelationship | null> {
    const existing = await this.findById(id, tenantId);
    if (!existing) return null;

    const updated: ShardRelationship = {
      ...existing,
      ...input,
      updatedAt: new Date(),
    };

    const { resource } = await this.container.item(id, tenantId).replace(updated);
    return resource as ShardRelationship;
  }

  /**
   * Delete a relationship
   */
  async delete(id: string, tenantId: string): Promise<boolean> {
    try {
      await this.container.item(id, tenantId).delete();
      
      this.monitoring.trackEvent('relationship.deleted', {
        relationshipId: id,
        tenantId,
      });
      
      return true;
    } catch (error: any) {
      if (error.code === 404) return false;
      throw error;
    }
  }

  /**
   * Delete all relationships for a shard (when shard is deleted)
   */
  async deleteAllForShard(tenantId: string, shardId: string): Promise<number> {
    const relationships = await this.getRelationshipsForShard({
      tenantId,
      shardId,
      direction: RelationshipDirection.BOTH,
    });

    let deleted = 0;
    for (const rel of relationships) {
      const success = await this.delete(rel.id, tenantId);
      if (success) deleted++;
    }

    return deleted;
  }

  /**
   * Count relationships for a shard
   */
  async countForShard(tenantId: string, shardId: string): Promise<number> {
    const query = `
      SELECT VALUE COUNT(1) FROM c 
      WHERE c.tenantId = @tenantId 
      AND (c.sourceShardId = @shardId OR c.targetShardId = @shardId)
    `;

    const { resources } = await this.container.items.query<number>({
      query,
      parameters: [
        { name: '@tenantId', value: tenantId },
        { name: '@shardId', value: shardId },
      ],
    }).fetchAll();

    return resources[0] || 0;
  }
}


