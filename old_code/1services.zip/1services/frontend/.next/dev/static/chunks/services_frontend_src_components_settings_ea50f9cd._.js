(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/services/frontend/src/components/settings/organization-profile.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/7d783_react-hook-form_dist_index_esm_mjs_d31afe53._.js",
  "static/chunks/37e87_zod_v4_9728400a._.js",
  "static/chunks/77b74_axios_lib_3ffa8d91._.js",
  "static/chunks/node_modules__pnpm_a469eb33._.js",
  "static/chunks/services_frontend_src_28f88b4c._.js",
  "static/chunks/services_frontend_src_components_settings_organization-profile_tsx_1dd6663e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/services/frontend/src/components/settings/organization-profile.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/services/frontend/src/components/settings/feature-flags.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules__pnpm_caf12cf6._.js",
  "static/chunks/services_frontend_src_de088c0c._.js",
  "static/chunks/services_frontend_src_components_settings_feature-flags_tsx_1dd6663e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/services/frontend/src/components/settings/feature-flags.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/services/frontend/src/components/settings/api-keys.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules__pnpm_6c3df227._.js",
  "static/chunks/services_frontend_src_58064b2e._.js",
  "static/chunks/services_frontend_src_components_settings_api-keys_tsx_1dd6663e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/services/frontend/src/components/settings/api-keys.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/services/frontend/src/components/settings/usage-stats.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules__pnpm_f57bfbde._.js",
  "static/chunks/services_frontend_src_825e45f6._.js",
  "static/chunks/services_frontend_src_components_settings_usage-stats_tsx_1dd6663e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/services/frontend/src/components/settings/usage-stats.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/services/frontend/src/components/settings/sso-configuration.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/services_frontend_src_c4367df0._.js",
  "static/chunks/7d783_react-hook-form_dist_index_esm_mjs_d31afe53._.js",
  "static/chunks/37e87_zod_v4_30e9ca9b._.js",
  "static/chunks/77b74_axios_lib_3ffa8d91._.js",
  "static/chunks/node_modules__pnpm_171da87e._.js",
  "static/chunks/services_frontend_src_components_settings_sso-configuration_tsx_1dd6663e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/services/frontend/src/components/settings/sso-configuration.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/services/frontend/src/components/settings/cookie-preferences.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_670df90b._.js",
  "static/chunks/services_frontend_src_components_settings_cookie-preferences_tsx_1dd6663e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/services/frontend/src/components/settings/cookie-preferences.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/services/frontend/src/components/settings/data-privacy.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_46391658._.js",
  "static/chunks/services_frontend_src_components_settings_data-privacy_tsx_1dd6663e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/services/frontend/src/components/settings/data-privacy.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);