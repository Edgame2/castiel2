/**
 * Shard types for Cosmos DB
 * Shards are the core data entities in the system
 */

import type { EnrichmentResults } from './enrichment.types.js';

/**
 * Permission level for ACL entries
 */
export enum PermissionLevel {
  READ = 'read',
  WRITE = 'write',
  DELETE = 'delete',
  ADMIN = 'admin',
}

/**
 * ACL entry for shard access control
 */
export interface ACLEntry {
  userId?: string;
  roleId?: string; // For role-based permissions
  permissions: PermissionLevel[];
  grantedBy: string;
  grantedAt: Date;
}

/**
 * Enrichment configuration for AI processing
 */
export interface EnrichmentConfig {
  enabled: boolean;
  providers?: string[]; // e.g., ['openai', 'azure-openai']
  autoEnrich?: boolean;
  enrichmentTypes?: string[]; // e.g., ['summary', 'keywords', 'sentiment']
}

/**
 * Enrichment metadata
 */
export interface Enrichment {
  config: EnrichmentConfig;
  lastEnrichedAt?: Date;
  enrichmentData?: Record<string, any>;
  error?: string;
}

/**
 * Vector embedding for semantic search
 */
export interface VectorEmbedding {
  id: string;
  field: string; // Which field this embedding is for
  model: string; // e.g., 'text-embedding-ada-002'
  dimensions: number;
  embedding: number[];
  createdAt: Date;
}

/**
 * Shard status
 */
export enum ShardStatus {
  ACTIVE = 'active',
  ARCHIVED = 'archived',
  DELETED = 'deleted',
  DRAFT = 'draft',
}

/**
 * Source of shard creation
 */
export enum ShardSource {
  UI = 'ui',
  API = 'api',
  IMPORT = 'import',
  INTEGRATION = 'integration',
  SYSTEM = 'system',
}

/**
 * Source details for tracking origin
 */
export interface ShardSourceDetails {
  integrationName?: string;
  importJobId?: string;
  originalId?: string;
  syncedAt?: Date;
}

/**
 * Structured data (cacheable)
 * This is a flexible object that conforms to the ShardType's JSON Schema
 */
export type StructuredData = Record<string, any>;

/**
 * Unstructured data (not cached)
 * Can contain large text, files, etc.
 */
export interface UnstructuredData {
  text?: string;
  files?: Array<{
    id: string;
    name: string;
    url: string;
    mimeType: string;
    size: number;
  }>;
  rawData?: any;
}

/**
 * Shard metadata
 */
export interface ShardMetadata {
  tags?: string[];
  category?: string;
  priority?: number;
  customFields?: Record<string, any>;
  enrichment?: EnrichmentResults;
}

/**
 * Shard document stored in Cosmos DB
 */
export interface Shard {
  id: string;
  tenantId: string; // Partition key
  userId: string; // Creator/owner
  shardTypeId: string;
  parentShardId?: string; // For hierarchical shards
  
  // Schema version tracking
  schemaVersion?: number; // Version of the ShardType schema this conforms to
  
  // Data fields
  structuredData: StructuredData; // CACHEABLE - conforms to ShardType schema
  unstructuredData?: UnstructuredData; // NOT cached - can be large
  metadata?: ShardMetadata;
  
  // Access control
  acl: ACLEntry[]; // Access control list
  
  // AI enrichment
  enrichment?: Enrichment;
  lastEnrichedAt?: Date;
  
  // Vector embeddings for semantic search
  vectors?: VectorEmbedding[];
  
  // Revision tracking
  revisionId: string;
  revisionNumber: number;
  
  // Status
  status: ShardStatus;
  
  // Source tracking
  source: ShardSource; // How this shard was created
  sourceDetails?: ShardSourceDetails; // Additional source metadata
  
  // Timestamps
  createdAt: Date;
  updatedAt: Date;
  deletedAt?: Date; // For soft delete
  archivedAt?: Date; // When status changed to archived
  lastActivityAt?: Date; // Last significant activity (view, edit, relationship change)
  
  // Cosmos DB system fields (optional)
  _rid?: string;
  _self?: string;
  _etag?: string;
  _attachments?: string;
  _ts?: number;
}

/**
 * Shard creation input
 */
export interface CreateShardInput {
  tenantId: string;
  userId?: string; // Optional for backwards compatibility
  createdBy?: string; // Added for consistency
  shardTypeId: string;
  structuredData: StructuredData;
  unstructuredData?: UnstructuredData;
  metadata?: ShardMetadata;
  parentShardId?: string; // Added for hierarchical shards
  acl?: ACLEntry[];
  enrichment?: EnrichmentConfig;
  status?: ShardStatus;
  source?: ShardSource; // How this shard is being created
  sourceDetails?: ShardSourceDetails; // Additional source metadata
  skipEnqueueing?: boolean; // Skip Service Bus enqueuing
}

/**
 * Shard update input
 */
export interface UpdateShardInput {
  structuredData?: StructuredData;
  unstructuredData?: UnstructuredData;
  metadata?: ShardMetadata;
  acl?: ACLEntry[];
  enrichment?: Enrichment;
  status?: ShardStatus;
}

/**
 * Shard query filters
 */
export interface ShardQueryFilter {
  tenantId: string;
  userId?: string;
  shardTypeId?: string;
  parentShardId?: string; // Added for hierarchical filtering
  status?: ShardStatus;
  category?: string; // Added for metadata filtering
  priority?: number; // Added for metadata filtering
  tags?: string[];
  createdAfter?: Date;
  createdBefore?: Date;
  updatedAfter?: Date;
  updatedBefore?: Date;
}

/**
 * Shard list options
 */
export interface ShardListOptions {
  filter?: ShardQueryFilter;
  limit?: number;
  continuationToken?: string;
  orderBy?: 'createdAt' | 'updatedAt';
  orderDirection?: 'asc' | 'desc';
}

/**
 * Shard list result
 */
export interface ShardListResult {
  shards: Shard[];
  continuationToken?: string;
  count: number;
}

/**
 * Permission check result
 */
export interface PermissionCheckResult {
  hasAccess: boolean;
  permissions: PermissionLevel[];
}
