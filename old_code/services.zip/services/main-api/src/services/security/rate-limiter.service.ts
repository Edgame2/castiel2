/**
 * Rate Limiter Service
 * Tracks and limits request rates to protect against brute force attacks
 */

import type { Redis } from 'ioredis';

export interface RateLimitConfig {
  windowSizeMs: number;      // Time window in milliseconds
  maxAttempts: number;       // Maximum attempts within the window
  blockDurationMs: number;   // How long to block after exceeding limit
}

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetAt: number;
  isBlocked: boolean;
  blockExpiresAt?: number;
}

export interface RateLimitInfo {
  attempts: number;
  windowStart: number;
  isBlocked: boolean;
  blockExpiresAt?: number;
}

/**
 * Default rate limit configurations
 */
export const DEFAULT_RATE_LIMITS = {
  // Login attempts - 5 attempts per 15 minutes, 30 minute block
  login: {
    windowSizeMs: 15 * 60 * 1000,
    maxAttempts: 5,
    blockDurationMs: 30 * 60 * 1000,
  },
  // Password reset - 3 attempts per hour, 1 hour block
  passwordReset: {
    windowSizeMs: 60 * 60 * 1000,
    maxAttempts: 3,
    blockDurationMs: 60 * 60 * 1000,
  },
  // Registration - 5 attempts per hour, 1 hour block
  registration: {
    windowSizeMs: 60 * 60 * 1000,
    maxAttempts: 5,
    blockDurationMs: 60 * 60 * 1000,
  },
  // API calls - 100 per minute
  api: {
    windowSizeMs: 60 * 1000,
    maxAttempts: 100,
    blockDurationMs: 60 * 1000,
  },
};

/**
 * Rate Limiter Service using Redis
 */
export class RateLimiterService {
  private redis: Redis;
  private prefix: string;
  private configs: Map<string, RateLimitConfig>;

  constructor(redis: Redis, prefix: string = 'rate_limit') {
    this.redis = redis;
    this.prefix = prefix;
    this.configs = new Map();

    // Set default configurations
    Object.entries(DEFAULT_RATE_LIMITS).forEach(([key, config]) => {
      this.configs.set(key, config);
    });
  }

  /**
   * Configure rate limit for a specific action
   */
  setConfig(action: string, config: RateLimitConfig): void {
    this.configs.set(action, config);
  }

  /**
   * Get the config for an action
   */
  getConfig(action: string): RateLimitConfig | undefined {
    return this.configs.get(action);
  }

  /**
   * Check if action is allowed and record attempt
   * @param action - The action being rate limited (e.g., 'login', 'password_reset')
   * @param identifier - Unique identifier (e.g., email, IP address)
   * @returns Rate limit result
   */
  async checkAndRecord(action: string, identifier: string): Promise<RateLimitResult> {
    const config = this.configs.get(action);
    if (!config) {
      // No config - allow by default
      return {
        allowed: true,
        remaining: Infinity,
        resetAt: Date.now(),
        isBlocked: false,
      };
    }

    const key = this.getKey(action, identifier);
    const blockKey = this.getBlockKey(action, identifier);
    const now = Date.now();

    // Check if blocked
    const blockExpiry = await this.redis.get(blockKey);
    if (blockExpiry) {
      const expiresAt = parseInt(blockExpiry, 10);
      if (expiresAt > now) {
        return {
          allowed: false,
          remaining: 0,
          resetAt: expiresAt,
          isBlocked: true,
          blockExpiresAt: expiresAt,
        };
      }
      // Block expired, remove it
      await this.redis.del(blockKey);
    }

    // Get current rate limit info
    const info = await this.getRateLimitInfo(key, config, now);
    
    // Check if within window and limit
    if (info.attempts >= config.maxAttempts) {
      // Exceeded limit - block the identifier
      const blockExpiresAt = now + config.blockDurationMs;
      await this.redis.setex(
        blockKey,
        Math.ceil(config.blockDurationMs / 1000),
        blockExpiresAt.toString()
      );

      return {
        allowed: false,
        remaining: 0,
        resetAt: blockExpiresAt,
        isBlocked: true,
        blockExpiresAt,
      };
    }

    // Record this attempt
    await this.recordAttempt(key, config, now);

    return {
      allowed: true,
      remaining: config.maxAttempts - info.attempts - 1,
      resetAt: info.windowStart + config.windowSizeMs,
      isBlocked: false,
    };
  }

  /**
   * Check rate limit without recording (for info purposes)
   */
  async check(action: string, identifier: string): Promise<RateLimitResult> {
    const config = this.configs.get(action);
    if (!config) {
      return {
        allowed: true,
        remaining: Infinity,
        resetAt: Date.now(),
        isBlocked: false,
      };
    }

    const key = this.getKey(action, identifier);
    const blockKey = this.getBlockKey(action, identifier);
    const now = Date.now();

    // Check if blocked
    const blockExpiry = await this.redis.get(blockKey);
    if (blockExpiry) {
      const expiresAt = parseInt(blockExpiry, 10);
      if (expiresAt > now) {
        return {
          allowed: false,
          remaining: 0,
          resetAt: expiresAt,
          isBlocked: true,
          blockExpiresAt: expiresAt,
        };
      }
    }

    const info = await this.getRateLimitInfo(key, config, now);
    const allowed = info.attempts < config.maxAttempts;

    return {
      allowed,
      remaining: Math.max(0, config.maxAttempts - info.attempts),
      resetAt: info.windowStart + config.windowSizeMs,
      isBlocked: false,
    };
  }

  /**
   * Reset rate limit for an identifier
   * Useful after successful login or password reset
   */
  async reset(action: string, identifier: string): Promise<void> {
    const key = this.getKey(action, identifier);
    const blockKey = this.getBlockKey(action, identifier);
    
    await Promise.all([
      this.redis.del(key),
      this.redis.del(blockKey),
    ]);
  }

  /**
   * Clear all rate limit data for an identifier
   */
  async clearAll(identifier: string): Promise<void> {
    const actions = Array.from(this.configs.keys());
    await Promise.all(
      actions.flatMap(action => [
        this.redis.del(this.getKey(action, identifier)),
        this.redis.del(this.getBlockKey(action, identifier)),
      ])
    );
  }

  /**
   * Get rate limit info from Redis
   */
  private async getRateLimitInfo(
    key: string,
    config: RateLimitConfig,
    now: number
  ): Promise<RateLimitInfo> {
    const data = await this.redis.hgetall(key);
    
    if (!data || !data.windowStart) {
      return {
        attempts: 0,
        windowStart: now,
        isBlocked: false,
      };
    }

    const windowStart = parseInt(data.windowStart, 10);
    const attempts = parseInt(data.attempts || '0', 10);

    // Check if window has expired
    if (now - windowStart > config.windowSizeMs) {
      // Window expired, start fresh
      return {
        attempts: 0,
        windowStart: now,
        isBlocked: false,
      };
    }

    return {
      attempts,
      windowStart,
      isBlocked: false,
    };
  }

  /**
   * Record an attempt
   */
  private async recordAttempt(
    key: string,
    config: RateLimitConfig,
    now: number
  ): Promise<void> {
    const data = await this.redis.hgetall(key);
    const windowStart = data?.windowStart ? parseInt(data.windowStart, 10) : now;
    const isNewWindow = !data?.windowStart || now - windowStart > config.windowSizeMs;

    if (isNewWindow) {
      // Start new window
      await this.redis.hmset(key, {
        windowStart: now.toString(),
        attempts: '1',
      });
    } else {
      // Increment attempts in current window
      await this.redis.hincrby(key, 'attempts', 1);
    }

    // Set expiry on the key
    const ttl = Math.ceil(config.windowSizeMs / 1000);
    await this.redis.expire(key, ttl);
  }

  /**
   * Generate rate limit key
   */
  private getKey(action: string, identifier: string): string {
    return `${this.prefix}:${action}:${identifier}`;
  }

  /**
   * Generate block key
   */
  private getBlockKey(action: string, identifier: string): string {
    return `${this.prefix}:block:${action}:${identifier}`;
  }
}

/**
 * In-memory rate limiter for fallback when Redis is unavailable
 */
export class InMemoryRateLimiterService {
  private storage: Map<string, { attempts: number; windowStart: number }> = new Map();
  private blocks: Map<string, number> = new Map();
  private configs: Map<string, RateLimitConfig> = new Map();

  constructor() {
    // Set default configurations
    Object.entries(DEFAULT_RATE_LIMITS).forEach(([key, config]) => {
      this.configs.set(key, config);
    });

    // Cleanup old entries periodically
    setInterval(() => this.cleanup(), 60000);
  }

  setConfig(action: string, config: RateLimitConfig): void {
    this.configs.set(action, config);
  }

  async checkAndRecord(action: string, identifier: string): Promise<RateLimitResult> {
    const config = this.configs.get(action);
    if (!config) {
      return { allowed: true, remaining: Infinity, resetAt: Date.now(), isBlocked: false };
    }

    const key = `${action}:${identifier}`;
    const blockKey = `block:${key}`;
    const now = Date.now();

    // Check if blocked
    const blockExpiry = this.blocks.get(blockKey);
    if (blockExpiry && blockExpiry > now) {
      return {
        allowed: false,
        remaining: 0,
        resetAt: blockExpiry,
        isBlocked: true,
        blockExpiresAt: blockExpiry,
      };
    }

    // Get or create entry
    let entry = this.storage.get(key);
    if (!entry || now - entry.windowStart > config.windowSizeMs) {
      entry = { attempts: 0, windowStart: now };
    }

    if (entry.attempts >= config.maxAttempts) {
      const blockExpiresAt = now + config.blockDurationMs;
      this.blocks.set(blockKey, blockExpiresAt);
      return {
        allowed: false,
        remaining: 0,
        resetAt: blockExpiresAt,
        isBlocked: true,
        blockExpiresAt,
      };
    }

    entry.attempts++;
    this.storage.set(key, entry);

    return {
      allowed: true,
      remaining: config.maxAttempts - entry.attempts,
      resetAt: entry.windowStart + config.windowSizeMs,
      isBlocked: false,
    };
  }

  async check(action: string, identifier: string): Promise<RateLimitResult> {
    const config = this.configs.get(action);
    if (!config) {
      return { allowed: true, remaining: Infinity, resetAt: Date.now(), isBlocked: false };
    }

    const key = `${action}:${identifier}`;
    const blockKey = `block:${key}`;
    const now = Date.now();

    const blockExpiry = this.blocks.get(blockKey);
    if (blockExpiry && blockExpiry > now) {
      return {
        allowed: false,
        remaining: 0,
        resetAt: blockExpiry,
        isBlocked: true,
        blockExpiresAt: blockExpiry,
      };
    }

    const entry = this.storage.get(key);
    if (!entry || now - entry.windowStart > config.windowSizeMs) {
      return { allowed: true, remaining: config.maxAttempts, resetAt: now + config.windowSizeMs, isBlocked: false };
    }

    return {
      allowed: entry.attempts < config.maxAttempts,
      remaining: Math.max(0, config.maxAttempts - entry.attempts),
      resetAt: entry.windowStart + config.windowSizeMs,
      isBlocked: false,
    };
  }

  async reset(action: string, identifier: string): Promise<void> {
    const key = `${action}:${identifier}`;
    this.storage.delete(key);
    this.blocks.delete(`block:${key}`);
  }

  async clearAll(identifier: string): Promise<void> {
    for (const action of this.configs.keys()) {
      await this.reset(action, identifier);
    }
  }

  private cleanup(): void {
    const now = Date.now();
    
    for (const [key, entry] of this.storage.entries()) {
      const action = key.split(':')[0];
      const config = this.configs.get(action);
      if (config && now - entry.windowStart > config.windowSizeMs) {
        this.storage.delete(key);
      }
    }

    for (const [key, expiry] of this.blocks.entries()) {
      if (expiry <= now) {
        this.blocks.delete(key);
      }
    }
  }
}


