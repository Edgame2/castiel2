var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__b89b5a39._.js")
R.c("server/chunks/[root-of-the-server]__c9e0960a._.js")
R.c("server/chunks/9cd88_next_dist_esm_build_templates_app-route_fd8e2745.js")
R.c("server/chunks/services_frontend__next-internal_server_app_favicon_ico_route_actions_dafd4e2a.js")
R.m(87431)
module.exports=R.m(87431).exports
