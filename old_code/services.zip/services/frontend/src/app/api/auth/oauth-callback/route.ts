import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  
  const accessToken = searchParams.get('accessToken');
  const refreshToken = searchParams.get('refreshToken');
  const isNewUser = searchParams.get('isNewUser');
  const error = searchParams.get('error');
  const errorMessage = searchParams.get('message');

  // Handle OAuth errors
  if (error) {
    const errorUrl = new URL('/login', request.url);
    errorUrl.searchParams.set('error', errorMessage || error);
    return NextResponse.redirect(errorUrl);
  }

  // Validate tokens are present
  if (!accessToken || !refreshToken) {
    const errorUrl = new URL('/login', request.url);
    errorUrl.searchParams.set('error', 'OAuth authentication failed. Please try again.');
    return NextResponse.redirect(errorUrl);
  }

  // Set the tokens in cookies
  const cookieStore = await cookies();
  
  // Set access token cookie
  cookieStore.set('access_token', accessToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 60 * 15,
    path: '/',
  });

  // Set refresh token cookie
  cookieStore.set('refresh_token', refreshToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 60 * 60 * 24 * 7,
    path: '/',
  });

  // Determine redirect URL
  const returnUrl = cookieStore.get('oauth_return_url')?.value || '/dashboard';
  
  // Clear the return URL cookie
  cookieStore.delete('oauth_return_url');

  // Build the redirect URL
  const redirectUrl = new URL(returnUrl.startsWith('/') ? returnUrl : '/dashboard', request.url);
  
  // Add a success indicator for new users
  if (isNewUser === 'true') {
    redirectUrl.searchParams.set('welcome', 'true');
  }

  return NextResponse.redirect(redirectUrl);
}


