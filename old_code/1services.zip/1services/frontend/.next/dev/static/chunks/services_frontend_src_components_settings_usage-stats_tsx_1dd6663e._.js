(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_f57bfbde._.js",
  "static/chunks/services_frontend_src_825e45f6._.js"
],
    source: "dynamic"
});
