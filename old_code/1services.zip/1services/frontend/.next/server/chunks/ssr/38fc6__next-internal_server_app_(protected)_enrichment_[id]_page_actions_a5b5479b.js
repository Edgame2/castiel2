module.exports=[25896,(a,b,c)=>{}];

//# sourceMappingURL=38fc6__next-internal_server_app_%28protected%29_enrichment_%5Bid%5D_page_actions_a5b5479b.js.map