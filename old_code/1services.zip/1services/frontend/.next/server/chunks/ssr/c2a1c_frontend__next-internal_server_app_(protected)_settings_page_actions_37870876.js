module.exports=[14366,(a,b,c)=>{}];

//# sourceMappingURL=c2a1c_frontend__next-internal_server_app_%28protected%29_settings_page_actions_37870876.js.map