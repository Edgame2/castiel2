(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_268e0fdb._.js",
  "static/chunks/9cd88_next_dist_compiled_react-dom_eb0758de._.js",
  "static/chunks/9cd88_next_dist_compiled_react-server-dom-turbopack_916cedd1._.js",
  "static/chunks/9cd88_next_dist_compiled_next-devtools_index_bbf159be.js",
  "static/chunks/9cd88_next_dist_compiled_2bb5dbe0._.js",
  "static/chunks/9cd88_next_dist_client_c7efba2e._.js",
  "static/chunks/9cd88_next_dist_c6b4bb04._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
