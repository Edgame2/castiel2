module.exports=[17168,(a,b,c)=>{}];

//# sourceMappingURL=c2a1c_frontend__next-internal_server_app_%28public%29_privacy_page_actions_54a25d72.js.map