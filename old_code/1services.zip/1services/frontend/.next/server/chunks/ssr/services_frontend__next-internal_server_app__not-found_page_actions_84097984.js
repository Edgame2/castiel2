module.exports=[83082,(a,b,c)=>{}];

//# sourceMappingURL=services_frontend__next-internal_server_app__not-found_page_actions_84097984.js.map