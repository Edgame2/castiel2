module.exports=[67195,(a,b,c)=>{}];

//# sourceMappingURL=c2a1c_frontend__next-internal_server_app_%28protected%29_search_page_actions_5ab5ddd8.js.map