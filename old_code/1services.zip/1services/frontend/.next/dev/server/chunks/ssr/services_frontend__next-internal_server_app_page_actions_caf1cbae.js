module.exports = [
"[project]/services/frontend/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=services_frontend__next-internal_server_app_page_actions_caf1cbae.js.map