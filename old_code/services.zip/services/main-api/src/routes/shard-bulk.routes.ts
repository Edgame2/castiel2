/**
 * Shard Bulk Operations Routes
 * 
 * Routes for bulk shard operations
 */

import type { FastifyInstance } from 'fastify';
import type { ShardBulkController } from '../controllers/shard-bulk.controller.js';

const bulkCreateSchema = {
  body: {
    type: 'object',
    required: ['shards'],
    properties: {
      shards: {
        type: 'array',
        maxItems: 100,
        items: {
          type: 'object',
          required: ['shardTypeId', 'structuredData'],
          properties: {
            shardTypeId: { type: 'string' },
            structuredData: { type: 'object' },
            unstructuredData: { type: 'object' },
            metadata: { type: 'object' },
            parentShardId: { type: 'string' },
          },
        },
      },
      options: {
        type: 'object',
        properties: {
          skipValidation: { type: 'boolean' },
          skipEnrichment: { type: 'boolean' },
          skipEvents: { type: 'boolean' },
          transactional: { type: 'boolean' },
          onError: { type: 'string', enum: ['continue', 'abort'] },
        },
      },
    },
  },
};

const bulkUpdateSchema = {
  body: {
    type: 'object',
    required: ['updates'],
    properties: {
      updates: {
        type: 'array',
        maxItems: 100,
        items: {
          type: 'object',
          required: ['id'],
          properties: {
            id: { type: 'string' },
            structuredData: { type: 'object' },
            unstructuredData: { type: 'object' },
            metadata: { type: 'object' },
            status: { type: 'string', enum: ['active', 'archived', 'draft'] },
          },
        },
      },
      options: {
        type: 'object',
        properties: {
          skipValidation: { type: 'boolean' },
          createRevision: { type: 'boolean' },
          skipEvents: { type: 'boolean' },
          onError: { type: 'string', enum: ['continue', 'abort'] },
        },
      },
    },
  },
};

const bulkDeleteSchema = {
  body: {
    type: 'object',
    required: ['shardIds'],
    properties: {
      shardIds: {
        type: 'array',
        maxItems: 100,
        items: { type: 'string' },
      },
      options: {
        type: 'object',
        properties: {
          hardDelete: { type: 'boolean' },
          skipEvents: { type: 'boolean' },
          onError: { type: 'string', enum: ['continue', 'abort'] },
        },
      },
    },
  },
};

const bulkRestoreSchema = {
  body: {
    type: 'object',
    required: ['shardIds'],
    properties: {
      shardIds: {
        type: 'array',
        maxItems: 100,
        items: { type: 'string' },
      },
      options: {
        type: 'object',
        properties: {
          skipEvents: { type: 'boolean' },
        },
      },
    },
  },
};

const restoreShardSchema = {
  params: {
    type: 'object',
    required: ['id'],
    properties: {
      id: { type: 'string' },
    },
  },
};

export function registerShardBulkRoutes(
  server: FastifyInstance,
  bulkController: ShardBulkController
) {
  // Bulk create
  server.post(
    '/api/v1/shards/bulk',
    { schema: bulkCreateSchema },
    bulkController.bulkCreate
  );

  // Bulk update
  server.patch(
    '/api/v1/shards/bulk',
    { schema: bulkUpdateSchema },
    bulkController.bulkUpdate
  );

  // Bulk delete
  server.delete(
    '/api/v1/shards/bulk',
    { schema: bulkDeleteSchema },
    bulkController.bulkDelete
  );

  // Bulk restore
  server.post(
    '/api/v1/shards/bulk/restore',
    { schema: bulkRestoreSchema },
    bulkController.bulkRestore
  );

  // Single shard restore
  server.post(
    '/api/v1/shards/:id/restore',
    { schema: restoreShardSchema },
    bulkController.restoreShard
  );
}


