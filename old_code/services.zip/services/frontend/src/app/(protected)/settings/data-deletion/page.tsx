"use client"

import Link from "next/link"
import { useTranslation } from "react-i18next"
import { DataDeletion } from "@/components/settings/data-deletion"

export default function DataDeletionPage() {
  const { t } = useTranslation('settings')
  
  return (
    <div className="space-y-6">
      <div>
        <div className="mb-2">
          <Link
            href="/settings"
            className="text-sm text-muted-foreground hover:text-foreground"
          >
            {t('backToSettings')}
          </Link>
        </div>
        <h1 className="text-3xl font-bold tracking-tight">{t('dataDeletion.title')}</h1>
        <p className="text-muted-foreground">
          {t('dataDeletion.subtitle')}
        </p>
      </div>

      <DataDeletion />
    </div>
  )
}
