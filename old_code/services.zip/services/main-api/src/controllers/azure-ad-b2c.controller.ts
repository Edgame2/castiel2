/**
 * Azure AD B2C Controller
 * 
 * HTTP handlers for Azure AD B2C authentication flows
 */

import type { FastifyRequest, FastifyReply } from 'fastify';
import type { AzureADB2CService } from '../services/auth/azure-ad-b2c.service.js';
import type { UserService } from '../services/auth/user.service.js';
import type { CacheManager } from '../cache/manager.js';
import ms from 'ms';

interface AzureADB2CInitiateParams {
  tenantId?: string;
}

interface AzureADB2CInitiateQuery {
  returnUrl?: string;
}

interface AzureADB2CCallbackBody {
  code?: string;
  id_token?: string;
  state?: string;
  error?: string;
  error_description?: string;
}

/**
 * Azure AD B2C Controller
 */
export class AzureADB2CController {
  constructor(
    private readonly azureService: AzureADB2CService,
    private readonly userService: UserService,
    private readonly cacheManager: CacheManager,
    private readonly accessTokenExpiry: string,
    private readonly frontendUrl: string
  ) {}

  /**
   * GET /auth/azure-b2c/:tenantId?/login
   * Initiate Azure AD B2C login
   */
  async initiateLogin(request: FastifyRequest, reply: FastifyReply) {
    try {
      if (!this.azureService.isConfigured()) {
        return reply.code(503).send({
          error: 'ServiceUnavailable',
          message: 'Azure AD B2C is not configured',
        });
      }

      const { tenantId = 'default' } = request.params as AzureADB2CInitiateParams;
      const { returnUrl } = request.query as AzureADB2CInitiateQuery;

      const { authUrl } = await this.azureService.createAuthState(tenantId, returnUrl);

      return reply.redirect(authUrl);
    } catch (error: any) {
      request.log.error({ error }, 'Failed to initiate Azure AD B2C login');
      return reply.redirect(`${this.frontendUrl}/login?error=azure_init_failed`);
    }
  }

  /**
   * POST /auth/azure-b2c/callback
   * Handle Azure AD B2C callback (form_post response mode)
   */
  async handleCallback(request: FastifyRequest, reply: FastifyReply) {
    try {
      const body = request.body as AzureADB2CCallbackBody;

      // Check for errors
      if (body.error) {
        request.log.warn({ error: body.error, description: body.error_description }, 'Azure AD B2C auth error');
        return reply.redirect(`${this.frontendUrl}/login?error=${body.error}`);
      }

      const { state, id_token, code } = body;

      if (!state) {
        return reply.redirect(`${this.frontendUrl}/login?error=missing_state`);
      }

      // Validate state
      const stateData = await this.azureService.validateState(state);
      if (!stateData) {
        return reply.redirect(`${this.frontendUrl}/login?error=invalid_state`);
      }

      let userInfo;

      // If we have an ID token, validate and extract user info directly
      if (id_token) {
        try {
          const claims = await this.azureService.validateIdToken(id_token, stateData.nonce);
          userInfo = this.azureService.extractUserInfo(claims);
        } catch (error: any) {
          request.log.error({ error }, 'Failed to validate ID token');
          return reply.redirect(`${this.frontendUrl}/login?error=invalid_token`);
        }
      } else if (code) {
        // Exchange code for tokens
        try {
          const tokens = await this.azureService.exchangeCode(code);
          const claims = await this.azureService.validateIdToken(tokens.id_token, stateData.nonce);
          userInfo = this.azureService.extractUserInfo(claims);
        } catch (error: any) {
          request.log.error({ error }, 'Failed to exchange code');
          return reply.redirect(`${this.frontendUrl}/login?error=token_exchange_failed`);
        }
      } else {
        return reply.redirect(`${this.frontendUrl}/login?error=no_credentials`);
      }

      // Find or create user
      let user = await this.userService.findByEmail(userInfo.email);

      if (!user) {
        // Auto-provision user (JIT provisioning)
        user = await this.userService.create({
          email: userInfo.email,
          firstName: userInfo.firstName,
          lastName: userInfo.lastName,
          displayName: userInfo.displayName,
          tenantId: stateData.tenantId,
          status: 'active',
          emailVerified: true, // Azure AD B2C handles email verification
          ssoProvider: 'azure_ad_b2c',
          ssoSubject: userInfo.id,
        });

        request.log.info({ userId: user.id, email: user.email }, 'User provisioned via Azure AD B2C');
      } else {
        // Update SSO info if needed
        if (!user.ssoProvider) {
          await this.userService.update(user.id, {
            ssoProvider: 'azure_ad_b2c',
            ssoSubject: userInfo.id,
          });
        }
      }

      // Check if user is allowed to sign in
      if (user.status === 'suspended') {
        return reply.redirect(`${this.frontendUrl}/login?error=account_suspended`);
      }

      // Generate tokens
      const accessTokenExpiryMs = typeof this.accessTokenExpiry === 'string' 
        ? ms(this.accessTokenExpiry) 
        : this.accessTokenExpiry;
      const accessTokenExpirySeconds = Math.floor(accessTokenExpiryMs / 1000);

      const accessToken = await (reply as any).jwtSign(
        {
          sub: user.id,
          email: user.email,
          tenantId: user.tenantId,
          roles: user.roles || [],
        },
        { expiresIn: this.accessTokenExpiry }
      );

      // Generate and store refresh token
      const refreshToken = await this.cacheManager.refreshTokens.createRefreshToken(
        user.id,
        user.tenantId
      );

      // Create session
      await this.cacheManager.sessions.createSession(user.id, {
        tenantId: user.tenantId,
        email: user.email,
        roles: user.roles || [],
        loginMethod: 'azure_ad_b2c',
        deviceInfo: request.headers['user-agent'],
        ipAddress: request.ip,
      });

      // Update last login
      await this.userService.update(user.id, {
        lastLogin: new Date().toISOString(),
      });

      // Determine redirect URL
      const redirectUrl = stateData.returnUrl || `${this.frontendUrl}/dashboard`;

      // Redirect with tokens (using fragment for security)
      const tokenParams = new URLSearchParams({
        access_token: accessToken,
        refresh_token: refreshToken,
        token_type: 'Bearer',
        expires_in: accessTokenExpirySeconds.toString(),
      });

      return reply.redirect(`${this.frontendUrl}/auth/callback#${tokenParams.toString()}`);
    } catch (error: any) {
      request.log.error({ error }, 'Azure AD B2C callback failed');
      return reply.redirect(`${this.frontendUrl}/login?error=callback_failed`);
    }
  }

  /**
   * GET /auth/azure-b2c/logout
   * Initiate logout from Azure AD B2C
   */
  async logout(request: FastifyRequest, reply: FastifyReply) {
    try {
      const postLogoutRedirectUri = `${this.frontendUrl}/login?logout=success`;
      const logoutUrl = this.azureService.getLogoutUrl(postLogoutRedirectUri);
      return reply.redirect(logoutUrl);
    } catch (error: any) {
      request.log.error({ error }, 'Failed to initiate Azure AD B2C logout');
      return reply.redirect(`${this.frontendUrl}/login`);
    }
  }
}


