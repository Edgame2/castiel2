module.exports=[75442,(a,b,c)=>{}];

//# sourceMappingURL=c2a1c_frontend__next-internal_server_app_%28public%29_cookies_page_actions_a07ab979.js.map