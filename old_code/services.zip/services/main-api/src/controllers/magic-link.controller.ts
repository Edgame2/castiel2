/**
 * Magic Link Controller
 * 
 * HTTP handlers for passwordless authentication via magic links
 */

import type { FastifyRequest, FastifyReply } from 'fastify';
import type { MagicLinkService } from '../services/auth/magic-link.service.js';
import type { CacheManager } from '../cache/manager.js';
import { SessionManagementService } from '../services/auth/session-management.service.js';

/**
 * Request magic link request body
 */
interface RequestMagicLinkBody {
  email: string;
  tenantId?: string;
  returnUrl?: string;
}

/**
 * Verify magic link request params
 */
interface VerifyMagicLinkParams {
  token: string;
}

/**
 * Magic Link Controller
 */
export class MagicLinkController {
  constructor(
    private readonly magicLinkService: MagicLinkService,
    private readonly cacheManager: CacheManager,
    private readonly accessTokenExpiry: string = '9h'
  ) {}

  /**
   * POST /auth/magic-link/request
   * Request a magic link for passwordless login
   */
  async requestMagicLink(request: FastifyRequest, reply: FastifyReply) {
    try {
      const { email, tenantId, returnUrl } = request.body as RequestMagicLinkBody;

      if (!email) {
        return reply.code(400).send({
          error: 'BadRequest',
          message: 'Email is required',
        });
      }

      // Default tenant if not specified
      const resolvedTenantId = tenantId || 'default';

      const result = await this.magicLinkService.requestMagicLink(
        email.toLowerCase(),
        resolvedTenantId,
        returnUrl
      );

      request.log.info({ email: email.toLowerCase() }, 'Magic link requested');

      return reply.code(200).send(result);
    } catch (error: any) {
      request.log.error({ error }, 'Failed to request magic link');
      return reply.code(500).send({
        error: 'InternalError',
        message: 'Failed to process magic link request',
      });
    }
  }

  /**
   * GET /auth/magic-link/verify/:token
   * Verify magic link and complete login
   */
  async verifyMagicLink(request: FastifyRequest, reply: FastifyReply) {
    try {
      const { token } = request.params as VerifyMagicLinkParams;

      if (!token) {
        return reply.code(400).send({
          error: 'BadRequest',
          message: 'Token is required',
        });
      }

      // Verify the magic link
      const verifyResult = await this.magicLinkService.verifyMagicLink(token);

      if (!verifyResult.valid) {
        return reply.code(401).send({
          error: 'InvalidToken',
          message: 'Invalid or expired magic link',
        });
      }

      // Get the user
      const user = await this.magicLinkService.getUserById(
        verifyResult.userId!,
        verifyResult.tenantId!
      );

      if (!user) {
        return reply.code(401).send({
          error: 'UserNotFound',
          message: 'User not found',
        });
      }

      // Check if user is active
      if (user.status !== 'active' && user.status !== 'pending_verification') {
        return reply.code(403).send({
          error: 'AccountInactive',
          message: 'Account is not active',
        });
      }

      // If user was pending verification, mark as verified
      // (Magic link serves as email verification)
      if (user.status === 'pending_verification' || !user.emailVerified) {
        user.emailVerified = true;
        user.status = 'active';
        // The user service should handle the update
      }

      // Generate access token
      const accessToken = (request.server as any).jwt.sign(
        {
          sub: user.id,
          email: user.email,
          tenantId: user.tenantId,
          isDefaultTenant: user.isDefaultTenant ?? false,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.roles?.[0] || 'user',
          roles: user.roles || [],
          organizationId: user.organizationId,
          status: user.status,
          type: 'access',
          loginMethod: 'magic_link',
        },
        {
          expiresIn: this.accessTokenExpiry,
        }
      );

      // Create refresh token
      const refreshTokenResult = await this.cacheManager.tokens.createRefreshToken(
        user.id,
        user.tenantId
      );

      // Extract device and location metadata
      const metadata = SessionManagementService.extractSessionMetadata(request);

      // Create session
      await this.cacheManager.sessions.createSession(user.id, user.tenantId, {
        email: user.email,
        name: `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.email,
        provider: 'magic_link',
        deviceInfo: metadata.deviceInfo,
        locationInfo: metadata.locationInfo,
      });

      request.log.info({ userId: user.id, email: user.email }, 'Magic link login successful');

      return reply.code(200).send({
        accessToken,
        refreshToken: refreshTokenResult.token,
        expiresIn: this.accessTokenExpiry,
        returnUrl: verifyResult.returnUrl,
        user: {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          tenantId: user.tenantId,
          isDefaultTenant: user.isDefaultTenant ?? false,
        },
      });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to verify magic link');
      return reply.code(500).send({
        error: 'InternalError',
        message: 'Failed to verify magic link',
      });
    }
  }
}


