(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__1dbd64a0._.css",
  "static/chunks/services_frontend_src_baa7d22f._.js",
  "static/chunks/29fc1_@microsoft_applicationinsights-common_dist-es5_4793ed7a._.js",
  "static/chunks/5dbdb_@microsoft_applicationinsights-core-js_dist-es5_20e5c818._.js",
  "static/chunks/1ef0a_@microsoft_applicationinsights-analytics-js_dist-es5_461db7d5._.js",
  "static/chunks/6a607_@microsoft_applicationinsights-channel-js_dist-es5_f3f6480a._.js",
  "static/chunks/def69_@microsoft_applicationinsights-dependencies-js_dist-es5_1bee37f4._.js",
  "static/chunks/f6fcc_@microsoft_applicationinsights-properties-js_dist-es5_91cb4896._.js",
  "static/chunks/51e7d_react-i18next_dist_es_f77b2ecd._.js",
  "static/chunks/a94f9_tailwind-merge_dist_bundle-mjs_mjs_f110c13e._.js",
  "static/chunks/node_modules__pnpm_e9d9cfa2._.js"
],
    source: "dynamic"
});
