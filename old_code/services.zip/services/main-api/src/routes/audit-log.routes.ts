/**
 * Audit Log Routes
 * API routes for audit log operations
 */

import type { FastifyInstance } from 'fastify';
import { AuditLogController } from '../controllers/audit-log.controller.js';
import { AuditLogService } from '../services/audit/audit-log.service.js';
import { requireAuth } from '../middleware/auth.middleware.js';
import { requireRole } from '../middleware/authorization.js';
import {
  listAuditLogsSchema,
  getAuditLogSchema,
  getAuditStatsSchema,
  exportAuditLogsSchema,
  getFilterOptionsSchema,
} from '../schemas/audit-log.schemas.js';

export async function auditLogRoutes(fastify: FastifyInstance): Promise<void> {
  const database = fastify.cosmos;
  const container = database.container('AuditLogs');
  
  const auditLogService = new AuditLogService(container, {
    environment: process.env.NODE_ENV,
    serviceName: 'main-api',
  });
  
  const controller = new AuditLogController(auditLogService);

  // Auth guard for all routes
  const authGuard = { preHandler: [requireAuth(fastify)] };
  
  // Admin guard - only admins and super-admins can view audit logs
  const adminGuard = {
    preHandler: [
      requireAuth(fastify),
      requireRole('admin', 'super-admin', 'global_admin'),
    ],
  };

  // GET /audit-logs - List audit logs
  fastify.get(
    '/audit-logs',
    {
      ...adminGuard,
      schema: listAuditLogsSchema,
    },
    controller.listLogs.bind(controller)
  );

  // GET /audit-logs/stats - Get audit statistics
  fastify.get(
    '/audit-logs/stats',
    {
      ...adminGuard,
      schema: getAuditStatsSchema,
    },
    controller.getStats.bind(controller)
  );

  // GET /audit-logs/export - Export audit logs
  fastify.get(
    '/audit-logs/export',
    {
      ...adminGuard,
      schema: exportAuditLogsSchema,
    },
    controller.exportLogs.bind(controller)
  );

  // GET /audit-logs/filters - Get filter options
  fastify.get(
    '/audit-logs/filters',
    {
      ...adminGuard,
      schema: getFilterOptionsSchema,
    },
    controller.getFilterOptions.bind(controller)
  );

  // GET /audit-logs/:id - Get single audit log
  fastify.get(
    '/audit-logs/:id',
    {
      ...adminGuard,
      schema: getAuditLogSchema,
    },
    controller.getLog.bind(controller)
  );
}


