(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-dependencies-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-dependencies-js/dist-es5/InternalConstants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Dependencies Plugin, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ // ###################################################################################################################################################
// Note: DON'T Export these const from the package as we are still targeting IE/ES5 this will export a mutable variables that someone could change ###
// ###################################################################################################################################################
// Generally you should only put values that are used more than 2 times and then only if not already exposed as a constant (such as SdkCoreNames)
// as when using "short" named values from here they will be will be minified smaller than the SdkCoreNames[eSdkCoreNames.xxxx] value.
__turbopack_context__.s([
    "STR_DURATION",
    ()=>STR_DURATION,
    "STR_PROPERTIES",
    ()=>STR_PROPERTIES
]);
var STR_DURATION = "duration";
var STR_PROPERTIES = "properties"; //# sourceMappingURL=InternalConstants.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-dependencies-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-dependencies-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Dependencies Plugin, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ // @skip-file-minify
// ##############################################################
// AUTO GENERATED FILE: This file is Auto Generated during build.
// ##############################################################
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// Note: DON'T Export these const from the package as we are still targeting ES5 which can result in a mutable variables that someone could change!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
__turbopack_context__.s([
    "_DYN_ABORTED",
    ()=>_DYN_ABORTED,
    "_DYN_AJAX_DIAGNOSTICS_MES14",
    ()=>_DYN_AJAX_DIAGNOSTICS_MES14,
    "_DYN_AJAX_PERF_LOOKUP_DEL8",
    ()=>_DYN_AJAX_PERF_LOOKUP_DEL8,
    "_DYN_AJAX_TOTAL_DURATION",
    ()=>_DYN_AJAX_TOTAL_DURATION,
    "_DYN_CONTEXT",
    ()=>_DYN_CONTEXT,
    "_DYN_CORE",
    ()=>_DYN_CORE,
    "_DYN_CORRELATION_CONTEXT",
    ()=>_DYN_CORRELATION_CONTEXT,
    "_DYN_DISABLE_AJAX_TRACKIN7",
    ()=>_DYN_DISABLE_AJAX_TRACKIN7,
    "_DYN_DISABLE_FETCH_TRACKI9",
    ()=>_DYN_DISABLE_FETCH_TRACKI9,
    "_DYN_ENABLE_AJAX_ERROR_ST3",
    ()=>_DYN_ENABLE_AJAX_ERROR_ST3,
    "_DYN_ENABLE_AJAX_PERF_TRA4",
    ()=>_DYN_ENABLE_AJAX_PERF_TRA4,
    "_DYN_ENABLE_REQUEST_HEADE2",
    ()=>_DYN_ENABLE_REQUEST_HEADE2,
    "_DYN_ENABLE_RESPONSE_HEAD10",
    ()=>_DYN_ENABLE_RESPONSE_HEAD10,
    "_DYN_ERROR_STATUS_TEXT",
    ()=>_DYN_ERROR_STATUS_TEXT,
    "_DYN_EVENT_TRACE_CTX",
    ()=>_DYN_EVENT_TRACE_CTX,
    "_DYN_EXCLUDE_REQUEST_FROM6",
    ()=>_DYN_EXCLUDE_REQUEST_FROM6,
    "_DYN_GET_ABSOLUTE_URL",
    ()=>_DYN_GET_ABSOLUTE_URL,
    "_DYN_GET_ALL_RESPONSE_HEA13",
    ()=>_DYN_GET_ALL_RESPONSE_HEA13,
    "_DYN_GET_PART_APROPS",
    ()=>_DYN_GET_PART_APROPS,
    "_DYN_GET_TRACE_FLAGS",
    ()=>_DYN_GET_TRACE_FLAGS,
    "_DYN_GET_TRACE_ID",
    ()=>_DYN_GET_TRACE_ID,
    "_DYN_HEADERS",
    ()=>_DYN_HEADERS,
    "_DYN_HEADER_MAP",
    ()=>_DYN_HEADER_MAP,
    "_DYN_INCLUDE_CORRELATION_0",
    ()=>_DYN_INCLUDE_CORRELATION_0,
    "_DYN_LENGTH",
    ()=>_DYN_LENGTH,
    "_DYN_MAX_AJAX_CALLS_PER_V5",
    ()=>_DYN_MAX_AJAX_CALLS_PER_V5,
    "_DYN_METHOD",
    ()=>_DYN_METHOD,
    "_DYN_PERF_MARK",
    ()=>_DYN_PERF_MARK,
    "_DYN_PERF_TIMING",
    ()=>_DYN_PERF_TIMING,
    "_DYN_REQUEST_HEADERS",
    ()=>_DYN_REQUEST_HEADERS,
    "_DYN_REQUEST_SENT_TIME",
    ()=>_DYN_REQUEST_SENT_TIME,
    "_DYN_REQUEST_URL",
    ()=>_DYN_REQUEST_URL,
    "_DYN_RESPONSE_FINISHED_TI12",
    ()=>_DYN_RESPONSE_FINISHED_TI12,
    "_DYN_RESPONSE_TEXT",
    ()=>_DYN_RESPONSE_TEXT,
    "_DYN_SET_REQUEST_HEADER",
    ()=>_DYN_SET_REQUEST_HEADER,
    "_DYN_SPAN_ID",
    ()=>_DYN_SPAN_ID,
    "_DYN_START_TIME",
    ()=>_DYN_START_TIME,
    "_DYN_STATE_CHANGE_ATTACHE11",
    ()=>_DYN_STATE_CHANGE_ATTACHE11,
    "_DYN_STATUS",
    ()=>_DYN_STATUS,
    "_DYN_STATUS_TEXT",
    ()=>_DYN_STATUS_TEXT,
    "_DYN_TO_LOWER_CASE",
    ()=>_DYN_TO_LOWER_CASE,
    "_DYN_TRACE_FLAGS",
    ()=>_DYN_TRACE_FLAGS,
    "_DYN_TRACE_ID",
    ()=>_DYN_TRACE_ID,
    "_DYN_TRACK_DEPENDENCY_DAT1",
    ()=>_DYN_TRACK_DEPENDENCY_DAT1,
    "_DYN__ADD_HOOK",
    ()=>_DYN__ADD_HOOK,
    "_DYN__CREATE_TRACK_ITEM",
    ()=>_DYN__CREATE_TRACK_ITEM
]);
var _DYN_REQUEST_URL = "requestUrl"; // Count: 11
var _DYN_LENGTH = "length"; // Count: 8
var _DYN_TRACE_ID = "traceID"; // Count: 8
var _DYN_SPAN_ID = "spanID"; // Count: 8
var _DYN_TRACE_FLAGS = "traceFlags"; // Count: 11
var _DYN_CONTEXT = "context"; // Count: 5
var _DYN_ABORTED = "aborted"; // Count: 6
var _DYN__ADD_HOOK = "_addHook"; // Count: 4
var _DYN_CORE = "core"; // Count: 8
var _DYN_INCLUDE_CORRELATION_0 = "includeCorrelationHeaders"; // Count: 4
var _DYN_GET_ABSOLUTE_URL = "getAbsoluteUrl"; // Count: 3
var _DYN_HEADERS = "headers"; // Count: 7
var _DYN_REQUEST_HEADERS = "requestHeaders"; // Count: 13
var _DYN_SET_REQUEST_HEADER = "setRequestHeader"; // Count: 3
var _DYN_TRACK_DEPENDENCY_DAT1 = "trackDependencyDataInternal"; // Count: 2
var _DYN_START_TIME = "startTime"; // Count: 5
var _DYN_TO_LOWER_CASE = "toLowerCase"; // Count: 6
var _DYN_ENABLE_REQUEST_HEADE2 = "enableRequestHeaderTracking"; // Count: 3
var _DYN_ENABLE_AJAX_ERROR_ST3 = "enableAjaxErrorStatusText"; // Count: 2
var _DYN_ENABLE_AJAX_PERF_TRA4 = "enableAjaxPerfTracking"; // Count: 2
var _DYN_MAX_AJAX_CALLS_PER_V5 = "maxAjaxCallsPerView"; // Count: 2
var _DYN_EXCLUDE_REQUEST_FROM6 = "excludeRequestFromAutoTrackingPatterns"; // Count: 2
var _DYN_DISABLE_AJAX_TRACKIN7 = "disableAjaxTracking"; // Count: 3
var _DYN_AJAX_PERF_LOOKUP_DEL8 = "ajaxPerfLookupDelay"; // Count: 2
var _DYN_DISABLE_FETCH_TRACKI9 = "disableFetchTracking"; // Count: 2
var _DYN_ENABLE_RESPONSE_HEAD10 = "enableResponseHeaderTracking"; // Count: 2
var _DYN_STATUS = "status"; // Count: 11
var _DYN_STATUS_TEXT = "statusText"; // Count: 7
var _DYN_HEADER_MAP = "headerMap"; // Count: 5
var _DYN_REQUEST_SENT_TIME = "requestSentTime"; // Count: 9
var _DYN_GET_TRACE_ID = "getTraceId"; // Count: 3
var _DYN_GET_TRACE_FLAGS = "getTraceFlags"; // Count: 3
var _DYN_METHOD = "method"; // Count: 8
var _DYN_ERROR_STATUS_TEXT = "errorStatusText"; // Count: 3
var _DYN_STATE_CHANGE_ATTACHE11 = "stateChangeAttached"; // Count: 2
var _DYN_RESPONSE_TEXT = "responseText"; // Count: 6
var _DYN_RESPONSE_FINISHED_TI12 = "responseFinishedTime"; // Count: 7
var _DYN__CREATE_TRACK_ITEM = "CreateTrackItem"; // Count: 3
var _DYN_GET_ALL_RESPONSE_HEA13 = "getAllResponseHeaders"; // Count: 2
var _DYN_GET_PART_APROPS = "getPartAProps"; // Count: 3
var _DYN_PERF_MARK = "perfMark"; // Count: 4
var _DYN_PERF_TIMING = "perfTiming"; // Count: 3
var _DYN_AJAX_DIAGNOSTICS_MES14 = "ajaxDiagnosticsMessage"; // Count: 3
var _DYN_CORRELATION_CONTEXT = "correlationContext"; // Count: 3
var _DYN_AJAX_TOTAL_DURATION = "ajaxTotalDuration"; // Count: 3
var _DYN_EVENT_TRACE_CTX = "eventTraceCtx"; // Count: 3
 //# sourceMappingURL=__DynamicConstants.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-dependencies-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-dependencies-js/dist-es5/ajaxRecord.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Dependencies Plugin, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "XHRMonitoringState",
    ()=>XHRMonitoringState,
    "ajaxRecord",
    ()=>ajaxRecord
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Interfaces/PartAExtensions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$DataSanitizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Common/DataSanitizer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$UrlHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/UrlHelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-dependencies-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-dependencies-js/dist-es5/InternalConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-dependencies-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-dependencies-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
;
;
;
;
;
/** @ignore */ function _calcPerfDuration(resourceEntry, start, end) {
    var result = 0;
    var from = resourceEntry[start];
    var to = resourceEntry[end];
    if (from && to) {
        result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsDuration"])(from, to);
    }
    return result;
}
/** @ignore */ function _setPerfDuration(props, name, resourceEntry, start, end) {
    var result = 0;
    var value = _calcPerfDuration(resourceEntry, start, end);
    if (value) {
        result = _setPerfValue(props, name, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["msToTimeSpan"])(value));
    }
    return result;
}
/** @ignore */ function _setPerfValue(props, name, value) {
    var strPerf = "ajaxPerf";
    var result = 0;
    if (props && name && value) {
        var perfData = props[strPerf] = props[strPerf] || {};
        perfData[name] = value;
        result = 1;
    }
    return result;
}
/** @ignore */ function _populatePerfData(ajaxData, dependency) {
    /*
    * https://developer.mozilla.org/en-US/docs/Web/API/Resource_Timing_API/Using_the_Resource_Timing_API
    *  | -startTime
    *  | -redirectStart
    *  |            | -redirectEnd
    *  |            | | -fetchStart
    *  |            | |   | -domainLookupStart
    *  |            | |   |                |- domainLookupEnd
    *  |            | |   |                | | -connectStart
    *  |            | |   |                | |  | -secureConnectionStart
    *  |            | |   |                | |  |        | -connectEnd
    *  |            | |   |                | |  |        | | -requestStart
    *  |            | |   |                | |  |        | |           | | -responseStart
    *  |            | |   |                | |  |        | |           | |            | | -responseEnd
    *  +------------+-+---+----------------+-+--+--------+-+-----------+-+------------+-+
    *  |--redirect--| |---|--domainLookup--| |--connect--| |--request--| |--response--| |
    *  |-------------------networkConnect----------------|
    *  |                                                   |---------sentRequest--------|
    *  |------------------------------------perfTotal-----------------------------------|
    */ var resourceEntry = ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PERF_TIMING"] /* @min:%2eperfTiming */ ];
    var props = dependency[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PROPERTIES"] /* @min:%2eproperties */ ] || {};
    var propsSet = 0;
    var strName = "name";
    var strStart = "Start";
    var strEnd = "End";
    var strDomainLookup = "domainLookup";
    var strConnect = "connect";
    var strRedirect = "redirect";
    var strRequest = "request";
    var strResponse = "response";
    var strStartTime = "startTime";
    var strDomainLookupStart = strDomainLookup + strStart;
    var strDomainLookupEnd = strDomainLookup + strEnd;
    var strConnectStart = strConnect + strStart;
    var strConnectEnd = strConnect + strEnd;
    var strRequestStart = strRequest + strStart;
    var strRequestEnd = strRequest + strEnd;
    var strResponseStart = strResponse + strStart;
    var strResponseEnd = strResponse + strEnd;
    var strRedirectStart = strRedirect + strStart;
    var strRedirectEnd = strRedirect = strEnd;
    var strTransferSize = "transferSize";
    var strEncodedBodySize = "encodedBodySize";
    var strDecodedBodySize = "decodedBodySize";
    var strServerTiming = "serverTiming";
    if (resourceEntry) {
        // redirect
        propsSet |= _setPerfDuration(props, strRedirect, resourceEntry, strRedirectStart, strRedirectEnd);
        // domainLookup
        propsSet |= _setPerfDuration(props, strDomainLookup, resourceEntry, strDomainLookupStart, strDomainLookupEnd);
        // connect
        propsSet |= _setPerfDuration(props, strConnect, resourceEntry, strConnectStart, strConnectEnd);
        // request
        propsSet |= _setPerfDuration(props, strRequest, resourceEntry, strRequestStart, strRequestEnd);
        // response
        propsSet |= _setPerfDuration(props, strResponse, resourceEntry, strResponseStart, strResponseEnd);
        // Network connection time
        propsSet |= _setPerfDuration(props, "networkConnect", resourceEntry, strStartTime, strConnectEnd);
        // Sent Request
        propsSet |= _setPerfDuration(props, "sentRequest", resourceEntry, strRequestStart, strResponseEnd);
        // PerfTotal / Duration
        var duration = resourceEntry[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_DURATION"] /* @min:%2eduration */ ];
        if (!duration) {
            duration = _calcPerfDuration(resourceEntry, strStartTime, strResponseEnd) || 0;
        }
        propsSet |= _setPerfValue(props, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_DURATION"], duration);
        propsSet |= _setPerfValue(props, "perfTotal", duration);
        var serverTiming = resourceEntry[strServerTiming];
        if (serverTiming) {
            var server_1 = {};
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(serverTiming, function(value, idx) {
                var name = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeJsName"])(value[strName] || "" + idx);
                var newValue = server_1[name] || {};
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(value, function(key, val) {
                    if (key !== strName && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(val) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNumber"])(val)) {
                        if (newValue[key]) {
                            val = newValue[key] + ";" + val;
                        }
                        if (val || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(val)) {
                            // Only set the value if it has a value and it's not an empty string
                            newValue[key] = val;
                        }
                    }
                });
                server_1[name] = newValue;
            });
            propsSet |= _setPerfValue(props, strServerTiming, server_1);
        }
        propsSet |= _setPerfValue(props, strTransferSize, resourceEntry[strTransferSize]);
        propsSet |= _setPerfValue(props, strEncodedBodySize, resourceEntry[strEncodedBodySize]);
        propsSet |= _setPerfValue(props, strDecodedBodySize, resourceEntry[strDecodedBodySize]);
    } else {
        if (ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PERF_MARK"] /* @min:%2eperfMark */ ]) {
            propsSet |= _setPerfValue(props, "missing", ajaxData.perfAttempts);
        }
    }
    if (propsSet) {
        dependency[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PROPERTIES"] /* @min:%2eproperties */ ] = props;
    }
}
var XHRMonitoringState = function() {
    function XHRMonitoringState() {
        var self = this;
        self.openDone = false;
        self.setRequestHeaderDone = false;
        self.sendDone = false;
        self.abortDone = false;
        // <summary>True, if onreadyStateChangeCallback function attached to xhr, otherwise false</summary>
        self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATE_CHANGE_ATTACHE11"] /* @min:%2estateChangeAttached */ ] = false;
    }
    return XHRMonitoringState;
}();
;
var ajaxRecord = function() {
    function ajaxRecord(traceId, spanId, logger, traceCtx) {
        var self = this;
        var _logger = logger;
        var strResponseText = "responseText";
        // Assigning the initial/default values within the constructor to avoid typescript from creating a bunch of
        // this.XXXX = null
        self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PERF_MARK"] /* @min:%2eperfMark */ ] = null;
        self.completed = false;
        self.requestHeadersSize = null;
        self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_HEADERS"] /* @min:%2erequestHeaders */ ] = null;
        self.responseReceivingDuration = null;
        self.callbackDuration = null;
        self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AJAX_TOTAL_DURATION"] /* @min:%2eajaxTotalDuration */ ] = null;
        self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ABORTED"] /* @min:%2eaborted */ ] = 0;
        self.pageUrl = null;
        self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_URL"] /* @min:%2erequestUrl */ ] = null;
        self.requestSize = 0;
        self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_METHOD"] /* @min:%2emethod */ ] = null;
        self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ] = null;
        self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_SENT_TIME"] /* @min:%2erequestSentTime */ ] = null;
        self.responseStartedTime = null;
        self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RESPONSE_FINISHED_TI12"] /* @min:%2eresponseFinishedTime */ ] = null;
        self.callbackFinishedTime = null;
        self.endTime = null;
        self.xhrMonitoringState = new XHRMonitoringState();
        self.clientFailure = 0;
        self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_ID"] /* @min:%2etraceID */ ] = traceId;
        self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPAN_ID"] /* @min:%2espanID */ ] = spanId;
        self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_FLAGS"] /* @min:%2etraceFlags */ ] = traceCtx === null || traceCtx === void 0 ? void 0 : traceCtx.getTraceFlags();
        if (traceCtx) {
            self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_EVENT_TRACE_CTX"] /* @min:%2eeventTraceCtx */ ] = {
                traceId: traceCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_TRACE_ID"] /* @min:%2egetTraceId */ ](),
                spanId: traceCtx.getSpanId(),
                traceFlags: traceCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_TRACE_FLAGS"] /* @min:%2egetTraceFlags */ ]()
            };
        } else {
            self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_EVENT_TRACE_CTX"] /* @min:%2eeventTraceCtx */ ] = null;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ajaxRecord, self, function(self) {
            self.getAbsoluteUrl = function() {
                return self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_URL"] /* @min:%2erequestUrl */ ] ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$UrlHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["urlGetAbsoluteUrl"])(self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_URL"] /* @min:%2erequestUrl */ ]) : null;
            };
            self.getPathName = function() {
                return self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_URL"] /* @min:%2erequestUrl */ ] ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$DataSanitizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dataSanitizeUrl"])(_logger, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$UrlHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["urlGetCompleteUrl"])(self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_METHOD"] /* @min:%2emethod */ ], self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_URL"] /* @min:%2erequestUrl */ ])) : null;
            };
            self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__CREATE_TRACK_ITEM"] /* @min:%2eCreateTrackItem */ ] = function(ajaxType, enableRequestHeaderTracking, getResponse) {
                var _a;
                // round to 3 decimal points
                self.ajaxTotalDuration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mathRound"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsDuration"])(self.requestSentTime, self.responseFinishedTime) * 1000) / 1000;
                if (self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AJAX_TOTAL_DURATION"] /* @min:%2eajaxTotalDuration */ ] < 0) {
                    return null;
                }
                var dependency = (_a = {
                    id: "|" + self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_ID"] /* @min:%2etraceID */ ] + "." + self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPAN_ID"] /* @min:%2espanID */ ],
                    target: self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_ABSOLUTE_URL"] /* @min:%2egetAbsoluteUrl */ ](),
                    name: self.getPathName(),
                    type: ajaxType,
                    startTime: null,
                    duration: self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AJAX_TOTAL_DURATION"] /* @min:%2eajaxTotalDuration */ ],
                    success: +self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ] >= 200 && +self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ] < 400,
                    responseCode: +self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ]
                }, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PROPERTIES"]] = {
                    HttpMethod: self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_METHOD"] /* @min:%2emethod */ ]
                }, _a);
                var props = dependency[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PROPERTIES"]];
                if (self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ABORTED"] /* @min:%2eaborted */ ]) {
                    props[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ABORTED"] /* @min:%2eaborted */ ] = true;
                }
                if (self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_SENT_TIME"] /* @min:%2erequestSentTime */ ]) {
                    // Set the correct dependency start time
                    dependency[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_START_TIME"] /* @min:%2estartTime */ ] = new Date();
                    dependency[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_START_TIME"] /* @min:%2estartTime */ ].setTime(self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_SENT_TIME"] /* @min:%2erequestSentTime */ ]);
                }
                // Add Ajax perf details if available
                _populatePerfData(self, dependency);
                if (enableRequestHeaderTracking) {
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objKeys"])(self.requestHeaders)[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                        props[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_HEADERS"] /* @min:%2erequestHeaders */ ] = self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_HEADERS"] /* @min:%2erequestHeaders */ ];
                    }
                }
                if (getResponse) {
                    var response = getResponse();
                    if (response) {
                        // enrich dependency target with correlation context from the server
                        var correlationContext = response[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORRELATION_CONTEXT"] /* @min:%2ecorrelationContext */ ];
                        if (correlationContext) {
                            dependency.correlationContext = /* dependency.target + " | " + */ correlationContext;
                        }
                        if (response[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HEADER_MAP"] /* @min:%2eheaderMap */ ]) {
                            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objKeys"])(response.headerMap)[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                                props.responseHeaders = response[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HEADER_MAP"] /* @min:%2eheaderMap */ ];
                            }
                        }
                        if (self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ERROR_STATUS_TEXT"] /* @min:%2eerrorStatusText */ ]) {
                            if (self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ] >= 400) {
                                var responseType = response.type;
                                if (responseType === "" || responseType === "text") {
                                    props.responseText = response.responseText ? response[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS_TEXT"] /* @min:%2estatusText */ ] + " - " + response[strResponseText] : response[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS_TEXT"] /* @min:%2estatusText */ ];
                                }
                                if (responseType === "json") {
                                    props.responseText = response.response ? response[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS_TEXT"] /* @min:%2estatusText */ ] + " - " + JSON.stringify(response.response) : response[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS_TEXT"] /* @min:%2estatusText */ ];
                                }
                            } else if (self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ] === 0) {
                                props.responseText = response[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS_TEXT"] /* @min:%2estatusText */ ] || "";
                            }
                        }
                    }
                }
                return dependency;
            };
            self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_PART_APROPS"] /* @min:%2egetPartAProps */ ] = function() {
                var partA = null;
                var traceCtx = self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_EVENT_TRACE_CTX"] /* @min:%2eeventTraceCtx */ ];
                if (traceCtx && (traceCtx.traceId || traceCtx.spanId)) {
                    partA = {};
                    var traceExt = partA[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Interfaces$2f$PartAExtensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Extensions"].TraceExt] = {
                        traceID: traceCtx.traceId,
                        parentID: traceCtx.spanId
                    };
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(traceCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_FLAGS"] /* @min:%2etraceFlags */ ])) {
                        traceExt[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_FLAGS"] /* @min:%2etraceFlags */ ] = traceCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_FLAGS"] /* @min:%2etraceFlags */ ];
                    }
                }
                return partA;
            };
        });
    }
    // Removed Stub for ajaxRecord.prototype.getAbsoluteUrl.
    // Removed Stub for ajaxRecord.prototype.getPathName.
    // Removed Stub for ajaxRecord.prototype.CreateTrackItem.
    // Removed Stub for ajaxRecord.prototype.getPartAProps.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    ajaxRecord.__ieDyn = 1;
    return ajaxRecord;
}();
;
 //# sourceMappingURL=ajaxRecord.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-dependencies-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-dependencies-js/dist-es5/ajax.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Dependencies Plugin, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "AjaxMonitor",
    ()=>AjaxMonitor,
    "DfltAjaxCorrelationHeaderExDomains",
    ()=>DfltAjaxCorrelationHeaderExDomains
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-shims@3.0.1/node_modules/@microsoft/applicationinsights-shims/dist-es5/TsLibShims.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$applicationinsights$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/applicationinsights-common.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$RemoteDependencyData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/RemoteDependencyData.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/RequestResponseHeaders.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$TelemetryItemCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/TelemetryItemCreator.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$W3cTraceParent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/W3cTraceParent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$BaseTelemetryPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/BaseTelemetryPlugin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InstrumentHooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InstrumentHooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/ProcessTelemetryContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DataCacheHelper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EventHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EventHelpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EnvUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CoreUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/CoreUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicConfig.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__strShimPrototype__as__strPrototype$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-shims@3.0.1/node_modules/@microsoft/applicationinsights-shims/dist-es5/Constants.js [app-client] (ecmascript) <export strShimPrototype as strPrototype>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-dependencies-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-dependencies-js/dist-es5/InternalConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-dependencies-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-dependencies-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$ajaxRecord$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-dependencies-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-dependencies-js/dist-es5/ajaxRecord.js [app-client] (ecmascript)");
var _a;
;
;
;
;
;
;
;
;
// const AJAX_MONITOR_PREFIX = "ai.ajxmn.";
var strDiagLog = "diagLog";
var AJAX_DATA_CONTAINER = "_ajaxData";
var STR_FETCH = "fetch";
var ERROR_HEADER = "Failed to monitor XMLHttpRequest";
var ERROR_PREFIX = ", monitoring data for this ajax call ";
var ERROR_POSTFIX = ERROR_PREFIX + "may be incorrect.";
var ERROR_NOT_SENT = ERROR_PREFIX + "won't be sent.";
var CORRELATION_HEADER_ERROR = "Failed to get Request-Context correlation header as it may be not included in the response or not accessible.";
var CUSTOM_REQUEST_CONTEXT_ERROR = "Failed to add custom defined request context as configured call back may missing a null check.";
var FAILED_TO_CALCULATE_DURATION_ERROR = "Failed to calculate the duration of the ";
// Using a global value so that to handle same iKey with multiple app insights instances (mostly for testing)
var _markCount = 0;
/** @Ignore */ function _supportsFetch() {
    var _global = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobal"])();
    if (!_global || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(_global.Request) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(_global.Request[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__strShimPrototype__as__strPrototype$3e$__["strPrototype"]]) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(_global[STR_FETCH])) {
        return null;
    }
    return _global[STR_FETCH];
}
/**
 * Determines whether ajax monitoring can be enabled on this document
 * @returns True if Ajax monitoring is supported on this page, otherwise false
 * @ignore
 */ function _supportsAjaxMonitoring(ajaxMonitorInstance, ajaxDataId) {
    var _a;
    var result = false;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isXhrSupported"])()) {
        var proto = XMLHttpRequest[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__strShimPrototype__as__strPrototype$3e$__["strPrototype"]];
        result = !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(proto) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(proto.open) && // eslint-disable-line security/detect-non-literal-fs-filename -- false positive
        !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(proto.send) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(proto.abort);
    }
    var ieVer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIEVersion"])();
    if (ieVer && ieVer < 9) {
        result = false;
    }
    if (result) {
        // Disable if the XmlHttpRequest can't be extended or hooked
        try {
            var xhr = new XMLHttpRequest();
            var xhrData = {
                xh: [],
                i: (_a = {}, _a[ajaxDataId] = {}, _a)
            };
            xhr[AJAX_DATA_CONTAINER] = xhrData;
            // Check that we can update the prototype
            var theOpen = XMLHttpRequest[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__strShimPrototype__as__strPrototype$3e$__["strPrototype"]].open;
            XMLHttpRequest[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__strShimPrototype__as__strPrototype$3e$__["strPrototype"]].open = theOpen;
        } catch (e) {
            // We can't decorate the xhr object so disable monitoring
            result = false;
            _throwInternalCritical(ajaxMonitorInstance, 15 /* _eInternalMessageId.FailedMonitorAjaxOpen */ , "Failed to enable XMLHttpRequest monitoring, extension is not supported", {
                exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
            });
        }
    }
    return result;
}
/**
 * Internal helper to fetch the SDK instance tracking data for this XHR request
 * @param xhr
 * @param ajaxDataId
 * @returns
 */ var _getAjaxData = function(xhr, ajaxDataId) {
    if (xhr && ajaxDataId && xhr[AJAX_DATA_CONTAINER]) {
        return (xhr[AJAX_DATA_CONTAINER].i || {})[ajaxDataId];
    }
    return null;
};
/**
 * @ignore
 * Internal helper to track the singleton shared tracking headers, so we can attempt to not create headers
 * that might cause an issue if multiple values are populated.
 * @param xhr - The instrumented XHR instance
 */ var _addSharedXhrHeaders = function(xhr, name, value) {
    if (xhr) {
        var headers = (xhr[AJAX_DATA_CONTAINER] || {}).xh;
        if (headers) {
            headers.push({
                n: name,
                v: value
            });
        }
    }
};
var _isHeaderSet = function(xhr, name) {
    var isPresent = false;
    if (xhr) {
        var headers = (xhr[AJAX_DATA_CONTAINER] || {}).xh;
        if (headers) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(headers, function(header) {
                if (header.n === name) {
                    isPresent = true;
                    return -1;
                }
            });
        }
    }
    return isPresent;
};
/** @Ignore */ function _getFailedAjaxDiagnosticsMessage(xhr, ajaxDataId) {
    var result = "";
    try {
        var ajaxData = _getAjaxData(xhr, ajaxDataId);
        if (ajaxData && ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_URL"] /* @min:%2erequestUrl */ ]) {
            result += "(url: '" + ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_URL"] /* @min:%2erequestUrl */ ] + "')";
        }
    } catch (e) {
    // eslint-disable-next-line no-empty
    }
    return result;
}
/** @ignore */ function _throwInternalCritical(ajaxMonitorInstance, msgId, message, properties, isUserAct) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(ajaxMonitorInstance[strDiagLog](), 1 /* eLoggingSeverity.CRITICAL */ , msgId, message, properties, isUserAct);
}
/** @ignore */ function _throwInternalWarning(ajaxMonitorInstance, msgId, message, properties, isUserAct) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(ajaxMonitorInstance[strDiagLog](), 2 /* eLoggingSeverity.WARNING */ , msgId, message, properties, isUserAct);
}
/** @Ignore */ function _createErrorCallbackFunc(ajaxMonitorInstance, internalMessage, message) {
    // tslint:disable-next-line
    return function(callDetails) {
        var _a;
        _throwInternalCritical(ajaxMonitorInstance, internalMessage, message, (_a = {}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AJAX_DIAGNOSTICS_MES14"] /* @min:ajaxDiagnosticsMessage */ ] = _getFailedAjaxDiagnosticsMessage(callDetails.inst, ajaxMonitorInstance._ajaxDataId), _a.exception = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(callDetails.err), _a));
    };
}
function _indexOf(value, match) {
    if (value && match) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strIndexOf"])(value, match);
    }
    return -1;
}
function _addHandler(container, id, theFunc) {
    var theHandler = {
        id: id,
        fn: theFunc
    };
    container.push(theHandler);
    return {
        remove: function() {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(container, function(initializer, idx) {
                if (initializer.id === theHandler.id) {
                    container.splice(idx, 1);
                    return -1;
                }
            });
        }
    };
}
function _processDependencyContainer(core, container, details, message) {
    var result = true;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(container, function(theFunc, idx) {
        try {
            if (theFunc.fn.call(null, details) === false) {
                result = false;
            }
        } catch (e) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(core && core.logger, 1 /* eLoggingSeverity.CRITICAL */ , 64 /* _eInternalMessageId.TelemetryInitializerFailed */ , "Dependency " + message + " [#" + idx + "] failed: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
            }, true);
        }
    });
    return result;
}
function _processDependencyListeners(listeners, core, ajaxData, xhr, input, init) {
    var initializersCount = listeners[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
    var result = true;
    if (initializersCount > 0) {
        var details = {
            core: core,
            xhr: xhr,
            input: input,
            init: init,
            traceId: ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_ID"] /* @min:%2etraceID */ ],
            spanId: ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPAN_ID"] /* @min:%2espanID */ ],
            traceFlags: ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_FLAGS"] /* @min:%2etraceFlags */ ],
            context: ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONTEXT"] /* @min:%2econtext */ ] || {},
            aborted: !!ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ABORTED"] /* @min:%2eaborted */ ]
        };
        result = _processDependencyContainer(core, listeners, details, "listener");
        ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_ID"] /* @min:%2etraceID */ ] = details.traceId;
        ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPAN_ID"] /* @min:%2espanID */ ] = details.spanId;
        ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_FLAGS"] /* @min:%2etraceFlags */ ] = details[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_FLAGS"] /* @min:%2etraceFlags */ ];
        ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONTEXT"] /* @min:%2econtext */ ] = details[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONTEXT"] /* @min:%2econtext */ ];
    }
    return result;
}
var BLOB_CORE = "*.blob.core.";
var DfltAjaxCorrelationHeaderExDomains = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objFreeze"])([
    BLOB_CORE + "windows.net",
    BLOB_CORE + "chinacloudapi.cn",
    BLOB_CORE + "cloudapi.de",
    BLOB_CORE + "usgovcloudapi.net"
]);
var _internalExcludeEndpoints = [
    /https:\/\/[^\/]*(\.pipe\.aria|aria\.pipe|events\.data|collector\.azure)\.[^\/]+\/(OneCollector\/1|Collector\/3)\.0/i
];
var _defaultConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objFreeze"])((_a = {}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MAX_AJAX_CALLS_PER_V5"] /* @min:maxAjaxCallsPerView */ ] = 500, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DISABLE_AJAX_TRACKIN7"] /* @min:disableAjaxTracking */ ] = false, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DISABLE_FETCH_TRACKI9"] /* @min:disableFetchTracking */ ] = false, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_EXCLUDE_REQUEST_FROM6"] /* @min:excludeRequestFromAutoTrackingPatterns */ ] = undefined, _a.disableCorrelationHeaders = false, _a.distributedTracingMode = 1 /* eDistributedTracingModes.AI_AND_W3C */ , _a.correlationHeaderExcludedDomains = DfltAjaxCorrelationHeaderExDomains, _a.correlationHeaderDomains = undefined, _a.correlationHeaderExcludePatterns = undefined, _a.appId = undefined, _a.enableCorsCorrelation = false, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLE_REQUEST_HEADE2"] /* @min:enableRequestHeaderTracking */ ] = false, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLE_RESPONSE_HEAD10"] /* @min:enableResponseHeaderTracking */ ] = false, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLE_AJAX_ERROR_ST3"] /* @min:enableAjaxErrorStatusText */ ] = false, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLE_AJAX_PERF_TRA4"] /* @min:enableAjaxPerfTracking */ ] = false, _a.maxAjaxPerfLookupAttempts = 3, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AJAX_PERF_LOOKUP_DEL8"] /* @min:ajaxPerfLookupDelay */ ] = 25, _a.ignoreHeaders = [
    "Authorization",
    "X-API-Key",
    "WWW-Authenticate"
], _a.addRequestContext = undefined, _a.addIntEndpoints = true, _a));
var AjaxMonitor = function(_super) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__extendsFn"])(AjaxMonitor, _super);
    function AjaxMonitor() {
        var _this = _super.call(this) || this;
        _this.identifier = AjaxMonitor.identifier;
        _this.priority = 120;
        var _fetchInitialized; // fetch monitoring initialized
        var _xhrInitialized; // XHR monitoring initialized
        var _currentWindowHost;
        var _extensionConfig;
        var _enableRequestHeaderTracking;
        var _enableAjaxErrorStatusText;
        var _trackAjaxAttempts;
        var _context;
        var _isUsingW3CHeaders;
        var _isUsingAIHeaders;
        var _markPrefix;
        var _enableAjaxPerfTracking;
        var _maxAjaxCallsPerView;
        var _enableResponseHeaderTracking;
        var _disabledUrls;
        var _disableAjaxTracking;
        var _disableFetchTracking;
        var _excludeRequestFromAutoTrackingPatterns;
        var _addRequestContext;
        var _evtNamespace;
        var _ajaxDataId;
        var _dependencyHandlerId;
        var _dependencyListeners;
        var _dependencyInitializers;
        var _ignoreHeaders;
        var _maxAjaxPerfLookupAttempts;
        var _ajaxPerfLookupDelay;
        var _distributedTracingMode;
        var _appId;
        var _polyfillInitialized;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(AjaxMonitor, _this, function(_self, _base) {
            var _addHook = _base[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ADD_HOOK"] /* @min:%2e_addHook */ ];
            _initDefaults();
            _self.initialize = function(config, core, extensions, pluginChain) {
                if (!_self.isInitialized()) {
                    _base.initialize(config, core, extensions, pluginChain);
                    _evtNamespace = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EventHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeEvtNamespace"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUniqueNamespace"])("ajax"), core && core.evtNamespace && core.evtNamespace());
                    _populateDefaults(config);
                    _instrumentXhr();
                    _instrumentFetch();
                    _populateContext();
                }
            };
            _self._doTeardown = function() {
                _initDefaults();
            };
            _self.trackDependencyData = function(dependency, properties) {
                _reportDependencyInternal(_dependencyInitializers, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ], null, dependency, properties);
            };
            _self.resetAjaxAttempts = function() {
                _trackAjaxAttempts = 0;
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INCLUDE_CORRELATION_0"] /* @min:%2eincludeCorrelationHeaders */ ] = function(ajaxData, input, init, xhr) {
                // Test Hook to allow the overriding of the location host
                var currentWindowHost = _self["_currentWindowHost"] || _currentWindowHost;
                if (_processDependencyListeners(_dependencyListeners, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ], ajaxData, xhr, input, init)) {
                    if (input || input === "") {
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["correlationIdCanIncludeCorrelationHeader"])(_extensionConfig, ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_ABSOLUTE_URL"] /* @min:%2egetAbsoluteUrl */ ](), currentWindowHost)) {
                            if (!init) {
                                init = {};
                            }
                            // init headers override original request headers
                            // so, if they exist use only them, otherwise use request's because they should have been applied in the first place
                            // not using original request headers will result in them being lost
                            var headers = new Headers(init[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HEADERS"] /* @min:%2eheaders */ ] || (input instanceof Request ? input[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HEADERS"] /* @min:%2eheaders */ ] || {} : {}));
                            if (_isUsingAIHeaders) {
                                var id = "|" + ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_ID"] /* @min:%2etraceID */ ] + "." + ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPAN_ID"] /* @min:%2espanID */ ];
                                headers.set(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][3 /* eRequestHeaders.requestIdHeader */ ], id);
                                if (_enableRequestHeaderTracking) {
                                    ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_HEADERS"] /* @min:%2erequestHeaders */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][3 /* eRequestHeaders.requestIdHeader */ ]] = id;
                                }
                            }
                            var appId = _appId || _context && _context.appId();
                            if (appId) {
                                headers.set(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][0 /* eRequestHeaders.requestContextHeader */ ], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][2 /* eRequestHeaders.requestContextAppIdFormat */ ] + appId);
                                if (_enableRequestHeaderTracking) {
                                    ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_HEADERS"] /* @min:%2erequestHeaders */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][0 /* eRequestHeaders.requestContextHeader */ ]] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][2 /* eRequestHeaders.requestContextAppIdFormat */ ] + appId;
                                }
                            }
                            if (_isUsingW3CHeaders) {
                                var traceFlags = ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_FLAGS"] /* @min:%2etraceFlags */ ];
                                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(traceFlags)) {
                                    traceFlags = 0x01;
                                }
                                var traceParent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$W3cTraceParent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatTraceParent"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$W3cTraceParent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTraceParent"])(ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_ID"] /* @min:%2etraceID */ ], ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPAN_ID"] /* @min:%2espanID */ ], traceFlags));
                                headers.set(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][4 /* eRequestHeaders.traceParentHeader */ ], traceParent);
                                if (_enableRequestHeaderTracking) {
                                    ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_HEADERS"] /* @min:%2erequestHeaders */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][4 /* eRequestHeaders.traceParentHeader */ ]] = traceParent;
                                }
                            }
                            init[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HEADERS"] /* @min:%2eheaders */ ] = headers;
                        }
                    } else if (xhr) {
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["correlationIdCanIncludeCorrelationHeader"])(_extensionConfig, ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_ABSOLUTE_URL"] /* @min:%2egetAbsoluteUrl */ ](), currentWindowHost)) {
                            if (_isUsingAIHeaders) {
                                if (!_isHeaderSet(xhr, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][3 /* eRequestHeaders.requestIdHeader */ ])) {
                                    var id = "|" + ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_ID"] /* @min:%2etraceID */ ] + "." + ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPAN_ID"] /* @min:%2espanID */ ];
                                    xhr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_REQUEST_HEADER"] /* @min:%2esetRequestHeader */ ](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][3 /* eRequestHeaders.requestIdHeader */ ], id);
                                    if (_enableRequestHeaderTracking) {
                                        ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_HEADERS"] /* @min:%2erequestHeaders */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][3 /* eRequestHeaders.requestIdHeader */ ]] = id;
                                    }
                                } else {
                                    _throwInternalWarning(_self, 71 /* _eInternalMessageId.FailedMonitorAjaxSetRequestHeader */ , "Unable to set [" + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][3 /* eRequestHeaders.requestIdHeader */ ] + "] as it has already been set by another instance");
                                }
                            }
                            var appId = _appId || _context && _context.appId();
                            if (appId) {
                                if (!_isHeaderSet(xhr, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][0 /* eRequestHeaders.requestContextHeader */ ])) {
                                    xhr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_REQUEST_HEADER"] /* @min:%2esetRequestHeader */ ](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][0 /* eRequestHeaders.requestContextHeader */ ], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][2 /* eRequestHeaders.requestContextAppIdFormat */ ] + appId);
                                    if (_enableRequestHeaderTracking) {
                                        ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_HEADERS"] /* @min:%2erequestHeaders */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][0 /* eRequestHeaders.requestContextHeader */ ]] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][2 /* eRequestHeaders.requestContextAppIdFormat */ ] + appId;
                                    }
                                } else {
                                    _throwInternalWarning(_self, 71 /* _eInternalMessageId.FailedMonitorAjaxSetRequestHeader */ , "Unable to set [" + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][0 /* eRequestHeaders.requestContextHeader */ ] + "] as it has already been set by another instance");
                                }
                            }
                            if (_isUsingW3CHeaders) {
                                var traceFlags = ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_FLAGS"] /* @min:%2etraceFlags */ ];
                                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(traceFlags)) {
                                    traceFlags = 0x01;
                                }
                                if (!_isHeaderSet(xhr, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][4 /* eRequestHeaders.traceParentHeader */ ])) {
                                    var traceParent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$W3cTraceParent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatTraceParent"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$W3cTraceParent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTraceParent"])(ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_ID"] /* @min:%2etraceID */ ], ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPAN_ID"] /* @min:%2espanID */ ], traceFlags));
                                    xhr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_REQUEST_HEADER"] /* @min:%2esetRequestHeader */ ](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][4 /* eRequestHeaders.traceParentHeader */ ], traceParent);
                                    if (_enableRequestHeaderTracking) {
                                        ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_HEADERS"] /* @min:%2erequestHeaders */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][4 /* eRequestHeaders.traceParentHeader */ ]] = traceParent;
                                    }
                                } else {
                                    _throwInternalWarning(_self, 71 /* _eInternalMessageId.FailedMonitorAjaxSetRequestHeader */ , "Unable to set [" + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][4 /* eRequestHeaders.traceParentHeader */ ] + "] as it has already been set by another instance");
                                }
                            }
                        }
                    }
                }
                return xhr || init;
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACK_DEPENDENCY_DAT1"] /* @min:%2etrackDependencyDataInternal */ ] = function(dependency, properties, systemProperties) {
                if (_maxAjaxCallsPerView === -1 || _trackAjaxAttempts < _maxAjaxCallsPerView) {
                    // Hack since expected format in w3c mode is |abc.def.
                    // Non-w3c format is |abc.def
                    // @todo Remove if better solution is available, e.g. handle in portal
                    if ((_distributedTracingMode === 2 /* eDistributedTracingModes.W3C */  || _distributedTracingMode === 1 /* eDistributedTracingModes.AI_AND_W3C */ ) && typeof dependency.id === "string" && dependency.id[dependency.id[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] - 1] !== ".") {
                        dependency.id += ".";
                    }
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(dependency[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_START_TIME"] /* @min:%2estartTime */ ])) {
                        dependency[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_START_TIME"] /* @min:%2estartTime */ ] = new Date();
                    }
                    var item = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$TelemetryItemCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTelemetryItem"])(dependency, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$RemoteDependencyData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RemoteDependencyData"].dataType, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$RemoteDependencyData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RemoteDependencyData"].envelopeType, _self[strDiagLog](), properties, systemProperties);
                    _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ].track(item);
                } else if (_trackAjaxAttempts === _maxAjaxCallsPerView) {
                    _throwInternalCritical(_self, 55 /* _eInternalMessageId.MaxAjaxPerPVExceeded */ , "Maximum ajax per page view limit reached, ajax monitoring is paused until the next trackPageView(). In order to increase the limit set the maxAjaxCallsPerView configuration parameter.", true);
                }
                ++_trackAjaxAttempts;
            };
            _self.addDependencyListener = function(dependencyListener) {
                return _addHandler(_dependencyListeners, _dependencyHandlerId++, dependencyListener);
            };
            _self.addDependencyInitializer = function(dependencyInitializer) {
                return _addHandler(_dependencyInitializers, _dependencyHandlerId++, dependencyInitializer);
            };
            function _initDefaults() {
                var location = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLocation"])();
                _fetchInitialized = false; // fetch monitoring initialized
                _xhrInitialized = false; // XHR monitoring initialized
                _polyfillInitialized = false; // polyfill monitoring initialized
                _currentWindowHost = location && location.host && location.host[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ]();
                _extensionConfig = null;
                _enableRequestHeaderTracking = false;
                _enableAjaxErrorStatusText = false;
                _trackAjaxAttempts = 0;
                _context = null;
                _isUsingW3CHeaders = false;
                _isUsingAIHeaders = false;
                _markPrefix = null;
                _enableAjaxPerfTracking = false;
                _maxAjaxCallsPerView = 0;
                _enableResponseHeaderTracking = false;
                _disabledUrls = {};
                _disableAjaxTracking = false;
                _disableFetchTracking = false;
                _excludeRequestFromAutoTrackingPatterns = null;
                _addRequestContext = null;
                _evtNamespace = null;
                _dependencyHandlerId = 0;
                _dependencyListeners = [];
                _dependencyInitializers = [];
                _ajaxDataId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUniqueNamespace"])("ajaxData");
                _self._ajaxDataId = _ajaxDataId;
                _ignoreHeaders = null;
                _maxAjaxPerfLookupAttempts = 1;
                _ajaxPerfLookupDelay = 1;
                _distributedTracingMode = 1 /* eDistributedTracingModes.AI_AND_W3C */ ;
                _appId = null;
            }
            function _populateDefaults(config) {
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ADD_HOOK"] /* @min:%2e_addHook */ ]((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onConfigChange"])(config, function(details) {
                    var config = details.cfg;
                    var ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProcessTelemetryContext"])(null, config, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ]);
                    _extensionConfig = ctx.getExtCfg(AjaxMonitor.identifier, _defaultConfig);
                    _distributedTracingMode = _extensionConfig.distributedTracingMode;
                    _enableRequestHeaderTracking = _extensionConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLE_REQUEST_HEADE2"] /* @min:%2eenableRequestHeaderTracking */ ];
                    _enableAjaxErrorStatusText = _extensionConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLE_AJAX_ERROR_ST3"] /* @min:%2eenableAjaxErrorStatusText */ ];
                    _enableAjaxPerfTracking = _extensionConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLE_AJAX_PERF_TRA4"] /* @min:%2eenableAjaxPerfTracking */ ];
                    _maxAjaxCallsPerView = _extensionConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MAX_AJAX_CALLS_PER_V5"] /* @min:%2emaxAjaxCallsPerView */ ];
                    _excludeRequestFromAutoTrackingPatterns = [].concat(_extensionConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_EXCLUDE_REQUEST_FROM6"] /* @min:%2eexcludeRequestFromAutoTrackingPatterns */ ] || [], _extensionConfig.addIntEndpoints !== false ? _internalExcludeEndpoints : []);
                    _addRequestContext = _extensionConfig.addRequestContext;
                    _isUsingAIHeaders = _distributedTracingMode === 0 /* eDistributedTracingModes.AI */  || _distributedTracingMode === 1 /* eDistributedTracingModes.AI_AND_W3C */ ;
                    _isUsingW3CHeaders = _distributedTracingMode === 1 /* eDistributedTracingModes.AI_AND_W3C */  || _distributedTracingMode === 2 /* eDistributedTracingModes.W3C */ ;
                    if (_enableAjaxPerfTracking) {
                        _markPrefix = _ajaxDataId;
                    }
                    _disableAjaxTracking = !!_extensionConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DISABLE_AJAX_TRACKIN7"] /* @min:%2edisableAjaxTracking */ ];
                    _maxAjaxPerfLookupAttempts = _extensionConfig.maxAjaxPerfLookupAttempts;
                    _ajaxPerfLookupDelay = _extensionConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AJAX_PERF_LOOKUP_DEL8"] /* @min:%2eajaxPerfLookupDelay */ ];
                    _ignoreHeaders = _extensionConfig.ignoreHeaders;
                    _appId = _extensionConfig.appId;
                }));
            }
            function _populateContext() {
                var propExt = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ].getPlugin(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$applicationinsights$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PropertiesPluginIdentifier"]);
                if (propExt) {
                    _context = propExt.plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONTEXT"] /* @min:%2econtext */ ]; // we could move IPropertiesPlugin to common as well
                }
            }
            // discard the header if it's defined as ignoreHeaders in ICorrelationConfig
            function _canIncludeHeaders(header) {
                var rlt = true;
                if (header || _ignoreHeaders) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(_ignoreHeaders, function(key) {
                        if (key[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ]() === header[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ]()) {
                            rlt = false;
                            return -1;
                        }
                    });
                }
                return rlt;
            }
            // Fetch Stuff
            function _instrumentFetch() {
                var fetch = _supportsFetch();
                if (!fetch) {
                    return;
                }
                var global = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobal"])();
                var isPolyfill = fetch.polyfill;
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ADD_HOOK"] /* @min:%2e_addHook */ ]((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onConfigChange"])(_extensionConfig, function() {
                    _disableFetchTracking = !!_extensionConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DISABLE_FETCH_TRACKI9"] /* @min:%2edisableFetchTracking */ ];
                    _enableResponseHeaderTracking = _extensionConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLE_RESPONSE_HEAD10"] /* @min:%2eenableResponseHeaderTracking */ ];
                    if (!_disableFetchTracking && !_fetchInitialized) {
                        _addHook((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InstrumentHooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstrumentFunc"])(global, STR_FETCH, {
                            ns: _evtNamespace,
                            // Add request hook
                            req: function(callDetails, input, init) {
                                var fetchData;
                                if (!_disableFetchTracking && _fetchInitialized && !_isDisabledRequest(null, input, init) && // If we have a polyfil and XHR instrumented then let XHR report otherwise we get duplicates
                                !(isPolyfill && _xhrInitialized)) {
                                    var ctx = callDetails.ctx();
                                    fetchData = _createFetchRecord(input, init);
                                    var newInit = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INCLUDE_CORRELATION_0"] /* @min:%2eincludeCorrelationHeaders */ ](fetchData, input, init);
                                    if (newInit !== init) {
                                        callDetails.set(1, newInit);
                                    }
                                    ctx.data = fetchData;
                                }
                            },
                            rsp: function(callDetails, input) {
                                if (!_disableFetchTracking) {
                                    var fetchData_1 = callDetails.ctx().data;
                                    if (fetchData_1) {
                                        // Replace the result with the new promise from this code
                                        callDetails.rslt = callDetails.rslt.then(function(response) {
                                            _reportFetchMetrics(callDetails, (response || {})[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ], input, response, fetchData_1, function() {
                                                var _a;
                                                var ajaxResponse = (_a = {
                                                    statusText: (response || {})[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS_TEXT"] /* @min:%2estatusText */ ],
                                                    headerMap: null
                                                }, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORRELATION_CONTEXT"] /* @min:correlationContext */ ] = _getFetchCorrelationContext(response), _a);
                                                if (_enableResponseHeaderTracking && response) {
                                                    var responseHeaderMap_1 = {};
                                                    response.headers.forEach(function(value, name) {
                                                        if (_canIncludeHeaders(name)) {
                                                            responseHeaderMap_1[name] = value;
                                                        }
                                                    });
                                                    ajaxResponse[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HEADER_MAP"] /* @min:%2eheaderMap */ ] = responseHeaderMap_1;
                                                }
                                                return ajaxResponse;
                                            });
                                            return response;
                                        }).catch(function(reason) {
                                            _reportFetchMetrics(callDetails, 0, input, null, fetchData_1, null, {
                                                error: reason.message || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(reason)
                                            });
                                            throw reason;
                                        });
                                    }
                                }
                            },
                            // Create an error callback to report any hook errors
                            hkErr: _createErrorCallbackFunc(_self, 15 /* _eInternalMessageId.FailedMonitorAjaxOpen */ , "Failed to monitor Window.fetch" + ERROR_POSTFIX)
                        }, true, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWebWorker"])()));
                        _fetchInitialized = true;
                    } else if (isPolyfill && !_polyfillInitialized) {
                        // If fetch is a polyfill we need to capture the request to ensure that we correctly track
                        // disabled request URLS (i.e. internal urls) to ensure we don't end up in a constant loop
                        // of reporting ourselves, for example React Native uses a polyfill for fetch
                        // Note: Polyfill implementations that don't support the "polyfill" tag are not supported
                        // the workaround is to add a polyfill property to your fetch implementation before initializing
                        // App Insights
                        _addHook((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InstrumentHooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstrumentFunc"])(global, STR_FETCH, {
                            ns: _evtNamespace,
                            req: function(callDetails, input, init) {
                                // Just call so that we record any disabled URL
                                _isDisabledRequest(null, input, init);
                            }
                        }));
                        _polyfillInitialized = true;
                    }
                }));
                if (isPolyfill) {
                    // retag the instrumented fetch with the same polyfill settings this is mostly for testing
                    // But also supports multiple App Insights usages
                    global[STR_FETCH].polyfill = isPolyfill;
                }
            }
            function _hookProto(target, funcName, callbacks) {
                _addHook((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InstrumentHooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstrumentProto"])(target, funcName, callbacks));
            }
            function _instrumentXhr() {
                if (!_supportsAjaxMonitoring(_self, _ajaxDataId)) {
                    return;
                }
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ADD_HOOK"] /* @min:%2e_addHook */ ]((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onConfigChange"])(_extensionConfig, function() {
                    _disableAjaxTracking = !!_extensionConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DISABLE_AJAX_TRACKIN7"] /* @min:%2edisableAjaxTracking */ ];
                    _enableRequestHeaderTracking = _extensionConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLE_REQUEST_HEADE2"] /* @min:%2eenableRequestHeaderTracking */ ];
                    if (!_disableAjaxTracking && !_xhrInitialized) {
                        // Instrument open
                        _hookProto(XMLHttpRequest, "open", {
                            ns: _evtNamespace,
                            req: function(callDetails, method, url, async) {
                                if (!_disableAjaxTracking) {
                                    var xhr = callDetails.inst;
                                    var ajaxData = _getAjaxData(xhr, _ajaxDataId);
                                    if (!_isDisabledRequest(xhr, url) && _isMonitoredXhrInstance(xhr, ajaxData, true)) {
                                        if (!ajaxData || !ajaxData.xhrMonitoringState.openDone) {
                                            // Only create a single ajaxData (even when multiple AI instances are running)
                                            ajaxData = _openHandler(xhr, method, url, async);
                                        }
                                        // always attach to the on ready state change (required for handling multiple instances)
                                        _attachToOnReadyStateChange(xhr, ajaxData);
                                    }
                                }
                            },
                            hkErr: _createErrorCallbackFunc(_self, 15 /* _eInternalMessageId.FailedMonitorAjaxOpen */ , ERROR_HEADER + ".open" + ERROR_POSTFIX)
                        });
                        // Instrument send
                        _hookProto(XMLHttpRequest, "send", {
                            ns: _evtNamespace,
                            req: function(callDetails, context) {
                                if (!_disableAjaxTracking) {
                                    var xhr = callDetails.inst;
                                    var ajaxData = _getAjaxData(xhr, _ajaxDataId);
                                    if (_isMonitoredXhrInstance(xhr, ajaxData) && !ajaxData.xhrMonitoringState.sendDone) {
                                        _createMarkId("xhr", ajaxData);
                                        ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_SENT_TIME"] /* @min:%2erequestSentTime */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsNow"])();
                                        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INCLUDE_CORRELATION_0"] /* @min:%2eincludeCorrelationHeaders */ ](ajaxData, undefined, undefined, xhr);
                                        ajaxData.xhrMonitoringState.sendDone = true;
                                    }
                                }
                            },
                            hkErr: _createErrorCallbackFunc(_self, 17 /* _eInternalMessageId.FailedMonitorAjaxSend */ , ERROR_HEADER + ERROR_POSTFIX)
                        });
                        // Instrument abort
                        _hookProto(XMLHttpRequest, "abort", {
                            ns: _evtNamespace,
                            req: function(callDetails) {
                                if (!_disableAjaxTracking) {
                                    var xhr = callDetails.inst;
                                    var ajaxData = _getAjaxData(xhr, _ajaxDataId);
                                    if (_isMonitoredXhrInstance(xhr, ajaxData) && !ajaxData.xhrMonitoringState.abortDone) {
                                        ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ABORTED"] /* @min:%2eaborted */ ] = 1;
                                        ajaxData.xhrMonitoringState.abortDone = true;
                                    }
                                }
                            },
                            hkErr: _createErrorCallbackFunc(_self, 13 /* _eInternalMessageId.FailedMonitorAjaxAbort */ , ERROR_HEADER + ".abort" + ERROR_POSTFIX)
                        });
                        // Instrument setRequestHeader
                        _hookProto(XMLHttpRequest, "setRequestHeader", {
                            ns: _evtNamespace,
                            req: function(callDetails, header, value) {
                                if (!_disableAjaxTracking) {
                                    var xhr = callDetails.inst;
                                    var ajaxData = _getAjaxData(xhr, _ajaxDataId);
                                    if (ajaxData && _isMonitoredXhrInstance(xhr, ajaxData)) {
                                        _addSharedXhrHeaders(xhr, header, value);
                                        if (_enableRequestHeaderTracking && _canIncludeHeaders(header)) {
                                            ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_HEADERS"] /* @min:%2erequestHeaders */ ][header] = value;
                                        }
                                    }
                                }
                            },
                            hkErr: _createErrorCallbackFunc(_self, 71 /* _eInternalMessageId.FailedMonitorAjaxSetRequestHeader */ , ERROR_HEADER + ".setRequestHeader" + ERROR_POSTFIX)
                        });
                        _xhrInitialized = true;
                    }
                }));
            }
            function _isDisabledRequest(xhr, request, init) {
                var isDisabled = false;
                var theUrl = ((!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(request) ? (request || {}).url || "" : request) || "")[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ]();
                // check excludeRequestFromAutoTrackingPatterns before stripping off any query string
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(_excludeRequestFromAutoTrackingPatterns, function(regex) {
                    var theRegex = regex;
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(regex)) {
                        theRegex = new RegExp(regex);
                    }
                    if (!isDisabled) {
                        isDisabled = theRegex.test(theUrl);
                    }
                });
                // if request url matches with exclude regex pattern, return true and no need to check for headers
                if (isDisabled) {
                    return isDisabled;
                }
                var idx = _indexOf(theUrl, "?");
                var idx2 = _indexOf(theUrl, "#");
                if (idx === -1 || idx2 !== -1 && idx2 < idx) {
                    idx = idx2;
                }
                if (idx !== -1) {
                    // Strip off any Query string
                    theUrl = theUrl.substring(0, idx);
                }
                // check that this instance is not not used by ajax call performed inside client side monitoring to send data to collector
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(xhr)) {
                    // Look on the XMLHttpRequest of the URL string value
                    isDisabled = xhr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DisabledPropertyName"]] === true || theUrl[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DisabledPropertyName"]] === true;
                } else if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(request)) {
                    // Look for DisabledPropertyName in either Request or RequestInit
                    isDisabled = (typeof request === "object" ? request[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DisabledPropertyName"]] === true : false) || (init ? init[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DisabledPropertyName"]] === true : false);
                }
                // Also add extra check just in case the XHR or fetch objects where not decorated with the DisableProperty due to sealing or freezing
                if (!isDisabled && theUrl && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInternalApplicationInsightsEndpoint"])(theUrl)) {
                    isDisabled = true;
                }
                if (isDisabled) {
                    // Add the disabled url if not present
                    if (!_disabledUrls[theUrl]) {
                        _disabledUrls[theUrl] = 1;
                    }
                } else {
                    // Check to see if the url is listed as disabled
                    if (_disabledUrls[theUrl]) {
                        isDisabled = true;
                    }
                }
                return isDisabled;
            }
            /// <summary>Verifies that particular instance of XMLHttpRequest needs to be monitored</summary>
            /// <param name="excludeAjaxDataValidation">Optional parameter. True if ajaxData must be excluded from verification</param>
            /// <returns type="bool">True if instance needs to be monitored, otherwise false</returns>
            function _isMonitoredXhrInstance(xhr, ajaxData, excludeAjaxDataValidation) {
                var ajaxValidation = true;
                var initialized = _xhrInitialized;
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(xhr)) {
                    ajaxValidation = excludeAjaxDataValidation === true || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(ajaxData);
                }
                // checking to see that all interested functions on xhr were instrumented
                return initialized && ajaxValidation;
            }
            function _getDistributedTraceCtx() {
                var distributedTraceCtx = null;
                if (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ] && _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ].getTraceCtx) {
                    distributedTraceCtx = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ].getTraceCtx(false);
                }
                // Fall back
                if (!distributedTraceCtx && _context && _context.telemetryTrace) {
                    distributedTraceCtx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDistributedTraceContextFromTrace"])(_context.telemetryTrace);
                }
                return distributedTraceCtx;
            }
            function _openHandler(xhr, method, url, async) {
                var _a;
                var distributedTraceCtx = _getDistributedTraceCtx();
                var traceID = distributedTraceCtx && distributedTraceCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_TRACE_ID"] /* @min:%2egetTraceId */ ]() || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CoreUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateW3CId"])();
                var spanID = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstr"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CoreUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateW3CId"])(), 0, 16);
                var xhrRequestData = xhr[AJAX_DATA_CONTAINER] = xhr[AJAX_DATA_CONTAINER] || {
                    xh: [],
                    i: {}
                };
                var ajaxDataCntr = xhrRequestData.i = xhrRequestData.i || {};
                var ajaxData = ajaxDataCntr[_ajaxDataId] = ajaxDataCntr[_ajaxDataId] || new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$ajaxRecord$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ajaxRecord"](traceID, spanID, _self[strDiagLog](), (_a = _self.core) === null || _a === void 0 ? void 0 : _a.getTraceCtx());
                ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_FLAGS"] /* @min:%2etraceFlags */ ] = distributedTraceCtx && distributedTraceCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_TRACE_FLAGS"] /* @min:%2egetTraceFlags */ ]();
                ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_METHOD"] /* @min:%2emethod */ ] = method;
                ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_URL"] /* @min:%2erequestUrl */ ] = url;
                ajaxData.xhrMonitoringState.openDone = true;
                ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_HEADERS"] /* @min:%2erequestHeaders */ ] = {};
                ajaxData.async = async;
                ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ERROR_STATUS_TEXT"] /* @min:%2eerrorStatusText */ ] = _enableAjaxErrorStatusText;
                return ajaxData;
            }
            function _attachToOnReadyStateChange(xhr, ajaxData) {
                ajaxData.xhrMonitoringState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATE_CHANGE_ATTACHE11"] /* @min:%2estateChangeAttached */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EventHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventOn"])(xhr, "readystatechange", function() {
                    var _a;
                    try {
                        if (xhr && xhr.readyState === 4 && _isMonitoredXhrInstance(xhr, ajaxData)) {
                            _onAjaxComplete(xhr);
                        }
                    } catch (e) {
                        var exceptionText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e);
                        // ignore messages with c00c023f, as this a known IE9 XHR abort issue
                        if (!exceptionText || _indexOf(exceptionText[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ](), "c00c023f") === -1) {
                            _throwInternalCritical(_self, 16 /* _eInternalMessageId.FailedMonitorAjaxRSC */ , ERROR_HEADER + " 'readystatechange' event handler" + ERROR_POSTFIX, (_a = {}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AJAX_DIAGNOSTICS_MES14"] /* @min:ajaxDiagnosticsMessage */ ] = _getFailedAjaxDiagnosticsMessage(xhr, _ajaxDataId), _a.exception = exceptionText, _a));
                        }
                    }
                }, _evtNamespace);
            }
            function _getResponseText(xhr) {
                try {
                    var responseType = xhr.responseType;
                    if (responseType === "" || responseType === "text") {
                        // As per the specification responseText is only valid if the type is an empty string or "text"
                        return xhr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RESPONSE_TEXT"] /* @min:%2eresponseText */ ];
                    }
                } catch (e) {
                // This shouldn't happen because of the above check -- but just in case, so just ignore
                }
                return null;
            }
            function _onAjaxComplete(xhr) {
                var ajaxData = _getAjaxData(xhr, _ajaxDataId);
                ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RESPONSE_FINISHED_TI12"] /* @min:%2eresponseFinishedTime */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsNow"])();
                ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ] = xhr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ];
                function _reportXhrError(e, failedProps) {
                    var errorProps = failedProps || {};
                    errorProps["ajaxDiagnosticsMessage"] = _getFailedAjaxDiagnosticsMessage(xhr, _ajaxDataId);
                    if (e) {
                        errorProps["exception"] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e);
                    }
                    _throwInternalWarning(_self, 14 /* _eInternalMessageId.FailedMonitorAjaxDur */ , FAILED_TO_CALCULATE_DURATION_ERROR + "ajax call" + ERROR_NOT_SENT, errorProps);
                }
                _findPerfResourceEntry("xmlhttprequest", ajaxData, function() {
                    try {
                        var dependency = ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__CREATE_TRACK_ITEM"] /* @min:%2eCreateTrackItem */ ]("Ajax", _enableRequestHeaderTracking, function() {
                            var _a;
                            var ajaxResponse = (_a = {
                                statusText: xhr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS_TEXT"] /* @min:%2estatusText */ ],
                                headerMap: null
                            }, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORRELATION_CONTEXT"] /* @min:correlationContext */ ] = _getAjaxCorrelationContext(xhr), _a.type = xhr.responseType, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RESPONSE_TEXT"] /* @min:responseText */ ] = _getResponseText(xhr), _a.response = xhr.response, _a);
                            if (_enableResponseHeaderTracking) {
                                var headers = xhr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_ALL_RESPONSE_HEA13"] /* @min:%2egetAllResponseHeaders */ ]();
                                if (headers) {
                                    // xhr.getAllResponseHeaders() method returns all the response headers, separated by CRLF, as a string or null
                                    // the regex converts the header string into an array of individual headers
                                    var arr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strTrim"])(headers).split(/[\r\n]+/);
                                    var responseHeaderMap_2 = {};
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(arr, function(line) {
                                        var parts = line.split(": ");
                                        var header = parts.shift();
                                        var value = parts.join(": ");
                                        if (_canIncludeHeaders(header)) {
                                            responseHeaderMap_2[header] = value;
                                        }
                                    });
                                    ajaxResponse[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HEADER_MAP"] /* @min:%2eheaderMap */ ] = responseHeaderMap_2;
                                }
                            }
                            return ajaxResponse;
                        });
                        var properties = void 0;
                        try {
                            if (!!_addRequestContext) {
                                properties = _addRequestContext({
                                    status: xhr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ],
                                    xhr: xhr
                                });
                            }
                        } catch (e) {
                            _throwInternalWarning(_self, 104 /* _eInternalMessageId.FailedAddingCustomDefinedRequestContext */ , CUSTOM_REQUEST_CONTEXT_ERROR);
                        }
                        if (dependency) {
                            if (properties !== undefined) {
                                dependency[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PROPERTIES"] /* @min:%2eproperties */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assignFn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assignFn"])({}, dependency.properties), properties);
                            }
                            var sysProperties = ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_PART_APROPS"] /* @min:%2egetPartAProps */ ]();
                            _reportDependencyInternal(_dependencyInitializers, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ], ajaxData, dependency, null, sysProperties);
                        } else {
                            _reportXhrError(null, {
                                requestSentTime: ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_SENT_TIME"] /* @min:%2erequestSentTime */ ],
                                responseFinishedTime: ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RESPONSE_FINISHED_TI12"] /* @min:%2eresponseFinishedTime */ ]
                            });
                        }
                    } finally{
                        // cleanup telemetry data
                        try {
                            var xhrRequestData = xhr[AJAX_DATA_CONTAINER] || {
                                i: {}
                            };
                            var ajaxDataCntr = xhrRequestData.i || {};
                            if (ajaxDataCntr[_ajaxDataId]) {
                                ajaxDataCntr[_ajaxDataId] = null;
                            }
                        } catch (e) {
                        // May throw in environments that prevent extension or freeze xhr
                        }
                    }
                }, function(e) {
                    _reportXhrError(e, null);
                });
            }
            function _getAjaxCorrelationContext(xhr) {
                var _a;
                try {
                    var responseHeadersString = xhr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_ALL_RESPONSE_HEA13"] /* @min:%2egetAllResponseHeaders */ ]();
                    if (responseHeadersString !== null) {
                        var index = _indexOf(responseHeadersString[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ](), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][8 /* eRequestHeaders.requestContextHeaderLowerCase */ ]);
                        if (index !== -1) {
                            var responseHeader = xhr.getResponseHeader(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][0 /* eRequestHeaders.requestContextHeader */ ]);
                            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["correlationIdGetCorrelationContext"])(responseHeader);
                        }
                    }
                } catch (e) {
                    _throwInternalWarning(_self, 18 /* _eInternalMessageId.FailedMonitorAjaxGetCorrelationHeader */ , CORRELATION_HEADER_ERROR, (_a = {}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AJAX_DIAGNOSTICS_MES14"] /* @min:ajaxDiagnosticsMessage */ ] = _getFailedAjaxDiagnosticsMessage(xhr, _ajaxDataId), _a.exception = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e), _a));
                }
            }
            function _createMarkId(type, ajaxData) {
                if (ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_URL"] /* @min:%2erequestUrl */ ] && _markPrefix && _enableAjaxPerfTracking) {
                    var performance_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPerformance"])();
                    if (performance_1 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(performance_1.mark)) {
                        _markCount++;
                        var markId = _markPrefix + type + "#" + _markCount;
                        performance_1.mark(markId);
                        var entries = performance_1.getEntriesByName(markId);
                        if (entries && entries[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] === 1) {
                            ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PERF_MARK"] /* @min:%2eperfMark */ ] = entries[0];
                        }
                    }
                }
            }
            function _findPerfResourceEntry(initiatorType, ajaxData, trackCallback, reportError) {
                var perfMark = ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PERF_MARK"] /* @min:%2eperfMark */ ];
                var performance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPerformance"])();
                var maxAttempts = _maxAjaxPerfLookupAttempts;
                var retryDelay = _ajaxPerfLookupDelay;
                var requestUrl = ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_URL"] /* @min:%2erequestUrl */ ];
                var attempt = 0;
                (function locateResourceTiming() {
                    try {
                        if (performance && perfMark) {
                            attempt++;
                            var perfTiming = null;
                            var entries = performance.getEntries();
                            for(var lp = entries[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] - 1; lp >= 0; lp--){
                                var entry = entries[lp];
                                if (entry) {
                                    if (entry.entryType === "resource") {
                                        if (entry.initiatorType === initiatorType && (_indexOf(entry.name, requestUrl) !== -1 || _indexOf(requestUrl, entry.name) !== -1)) {
                                            perfTiming = entry;
                                        }
                                    } else if (entry.entryType === "mark" && entry.name === perfMark.name) {
                                        // We hit the start event
                                        ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PERF_TIMING"] /* @min:%2eperfTiming */ ] = perfTiming;
                                        break;
                                    }
                                    if (entry[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_START_TIME"] /* @min:%2estartTime */ ] < perfMark[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_START_TIME"] /* @min:%2estartTime */ ] - 1000) {
                                        break;
                                    }
                                }
                            }
                        }
                        if (!perfMark || // - we don't have a perfMark or
                        ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PERF_TIMING"] /* @min:%2eperfTiming */ ] || // - we have not found the perf entry or
                        attempt >= maxAttempts || // - we have tried too many attempts or
                        ajaxData.async === false) {
                            if (perfMark && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(performance.clearMarks)) {
                                // Remove the mark so we don't fill up the performance resources too much
                                performance.clearMarks(perfMark.name);
                            }
                            ajaxData.perfAttempts = attempt;
                            // just continue and report the track event
                            trackCallback();
                        } else {
                            // We need to wait for the browser to populate the window.performance entry
                            // This needs to be at least 1ms as waiting <= 1 (on firefox) is not enough time for fetch or xhr,
                            // this is a scheduling issue for the browser implementation
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["scheduleTimeout"])(locateResourceTiming, retryDelay);
                        }
                    } catch (e) {
                        reportError(e);
                    }
                })();
            }
            function _createFetchRecord(input, init) {
                var _a;
                var distributedTraceCtx = _getDistributedTraceCtx();
                var traceID = distributedTraceCtx && distributedTraceCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_TRACE_ID"] /* @min:%2egetTraceId */ ]() || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CoreUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateW3CId"])();
                var spanID = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstr"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CoreUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateW3CId"])(), 0, 16);
                var ajaxData = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$ajaxRecord$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ajaxRecord"](traceID, spanID, _self[strDiagLog](), (_a = _self.core) === null || _a === void 0 ? void 0 : _a.getTraceCtx());
                ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_FLAGS"] /* @min:%2etraceFlags */ ] = distributedTraceCtx && distributedTraceCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_TRACE_FLAGS"] /* @min:%2egetTraceFlags */ ]();
                ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_SENT_TIME"] /* @min:%2erequestSentTime */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsNow"])();
                ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ERROR_STATUS_TEXT"] /* @min:%2eerrorStatusText */ ] = _enableAjaxErrorStatusText;
                var requestUrl;
                if (input instanceof Request) {
                    requestUrl = (input || {}).url || "";
                } else {
                    requestUrl = input;
                }
                if (requestUrl === "") {
                    var location_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLocation"])();
                    if (location_1 && location_1.href) {
                        requestUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSplit"])(location_1.href, "#")[0];
                    }
                }
                if (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ] && _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ].config) {
                    requestUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fieldRedaction"])(requestUrl, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ].config);
                }
                ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_URL"] /* @min:%2erequestUrl */ ] = requestUrl;
                var method = "GET";
                if (init && init[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_METHOD"] /* @min:%2emethod */ ]) {
                    method = init[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_METHOD"] /* @min:%2emethod */ ];
                } else if (input && input instanceof Request) {
                    method = input[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_METHOD"] /* @min:%2emethod */ ];
                }
                ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_METHOD"] /* @min:%2emethod */ ] = method;
                var requestHeaders = {};
                if (_enableRequestHeaderTracking) {
                    var headers = new Headers((init ? init[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HEADERS"] /* @min:%2eheaders */ ] : 0) || (input instanceof Request ? input[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HEADERS"] /* @min:%2eheaders */ ] || {} : {}));
                    headers.forEach(function(value, key) {
                        if (_canIncludeHeaders(key)) {
                            requestHeaders[key] = value;
                        }
                    });
                }
                ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_HEADERS"] /* @min:%2erequestHeaders */ ] = requestHeaders;
                _createMarkId(STR_FETCH, ajaxData);
                return ajaxData;
            }
            function _getFailedFetchDiagnosticsMessage(input) {
                var result = "";
                try {
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(input)) {
                        if (typeof input === "string") {
                            result += "(url: '".concat(input, "')");
                        } else {
                            result += "(url: '".concat(input.url, "')");
                        }
                    }
                } catch (e) {
                    _throwInternalCritical(_self, 15 /* _eInternalMessageId.FailedMonitorAjaxOpen */ , "Failed to grab failed fetch diagnostics message", {
                        exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                    });
                }
                return result;
            }
            function _reportFetchMetrics(callDetails, status, input, response, ajaxData, getResponse, properties) {
                if (!ajaxData) {
                    return;
                }
                function _reportFetchError(msgId, e, failedProps) {
                    var errorProps = failedProps || {};
                    errorProps["fetchDiagnosticsMessage"] = _getFailedFetchDiagnosticsMessage(input);
                    if (e) {
                        errorProps["exception"] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e);
                    }
                    _throwInternalWarning(_self, msgId, FAILED_TO_CALCULATE_DURATION_ERROR + "fetch call" + ERROR_NOT_SENT, errorProps);
                }
                ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RESPONSE_FINISHED_TI12"] /* @min:%2eresponseFinishedTime */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsNow"])();
                ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ] = status;
                _findPerfResourceEntry(STR_FETCH, ajaxData, function() {
                    var dependency = ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__CREATE_TRACK_ITEM"] /* @min:%2eCreateTrackItem */ ]("Fetch", _enableRequestHeaderTracking, getResponse);
                    var properties;
                    try {
                        if (!!_addRequestContext) {
                            properties = _addRequestContext({
                                status: status,
                                request: input,
                                response: response
                            });
                        }
                    } catch (e) {
                        _throwInternalWarning(_self, 104 /* _eInternalMessageId.FailedAddingCustomDefinedRequestContext */ , CUSTOM_REQUEST_CONTEXT_ERROR);
                    }
                    if (dependency) {
                        if (properties !== undefined) {
                            dependency[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PROPERTIES"] /* @min:%2eproperties */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assignFn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assignFn"])({}, dependency.properties), properties);
                        }
                        var sysProperties = ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_PART_APROPS"] /* @min:%2egetPartAProps */ ]();
                        _reportDependencyInternal(_dependencyInitializers, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ], ajaxData, dependency, null, sysProperties);
                    } else {
                        _reportFetchError(14 /* _eInternalMessageId.FailedMonitorAjaxDur */ , null, {
                            requestSentTime: ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_SENT_TIME"] /* @min:%2erequestSentTime */ ],
                            responseFinishedTime: ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RESPONSE_FINISHED_TI12"] /* @min:%2eresponseFinishedTime */ ]
                        });
                    }
                }, function(e) {
                    _reportFetchError(18 /* _eInternalMessageId.FailedMonitorAjaxGetCorrelationHeader */ , e, null);
                });
            }
            function _getFetchCorrelationContext(response) {
                if (response && response[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HEADERS"] /* @min:%2eheaders */ ]) {
                    try {
                        var responseHeader = response[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HEADERS"] /* @min:%2eheaders */ ].get(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$RequestResponseHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestHeaders"][0 /* eRequestHeaders.requestContextHeader */ ]);
                        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["correlationIdGetCorrelationContext"])(responseHeader);
                    } catch (e) {
                        _throwInternalWarning(_self, 18 /* _eInternalMessageId.FailedMonitorAjaxGetCorrelationHeader */ , CORRELATION_HEADER_ERROR, {
                            fetchDiagnosticsMessage: _getFailedFetchDiagnosticsMessage(response),
                            exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                        });
                    }
                }
            }
            function _reportDependencyInternal(initializers, core, ajaxData, dependency, properties, systemProperties) {
                var result = true;
                var initializersCount = initializers[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
                if (initializersCount > 0) {
                    var details = {
                        item: dependency,
                        properties: properties,
                        sysProperties: systemProperties,
                        context: ajaxData ? ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONTEXT"] /* @min:%2econtext */ ] : null,
                        aborted: ajaxData ? !!ajaxData[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ABORTED"] /* @min:%2eaborted */ ] : false
                    };
                    result = _processDependencyContainer(core, initializers, details, "initializer");
                }
                if (result) {
                    _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACK_DEPENDENCY_DAT1"] /* @min:%2etrackDependencyDataInternal */ ](dependency, properties, systemProperties);
                }
            }
        });
        return _this;
    }
    // Removed Stub for AjaxMonitor.prototype.initialize.
    AjaxMonitor.prototype.processTelemetry = function(item, itemCtx) {
        this.processNext(item, itemCtx);
    };
    // Removed Stub for AjaxMonitor.prototype.trackDependencyData.
    // Removed Stub for AjaxMonitor.prototype.resetAjaxAttempts.
    // Removed Stub for AjaxMonitor.prototype.includeCorrelationHeaders.
    // Removed Stub for AjaxMonitor.prototype.addDependencyListener.
    /**
     * Add an dependency telemetry initializer callback function to allow populating additional properties or drop the request.
     * It is called after the dependency call has completed and any available performance details are available. A dependency
     * initializer is similar to the TelemetryInitializer function but it allows you to block the reporting of the dependency
     * request so that it doesn't count against the `maxAjaxCallsPerView`.
     * @param dependencyInitializer - The Dependency Telemetry Initializer function
     * @returns - A IDependencyInitializerHandler to enable the initializer to be removed
     */ AjaxMonitor.prototype.addDependencyInitializer = function(dependencyInitializer) {
        return null;
    };
    // Removed Stub for AjaxMonitor.prototype.trackDependencyDataInternal.
    AjaxMonitor.identifier = "AjaxDependencyPlugin";
    return AjaxMonitor;
}(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$BaseTelemetryPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseTelemetryPlugin"]);
;
 //# sourceMappingURL=ajax.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-dependencies-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-dependencies-js/dist-es5/ajax.js [app-client] (ecmascript) <export AjaxMonitor as AjaxPlugin>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AjaxPlugin",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$ajax$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AjaxMonitor"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$dependencies$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$dependencies$2d$js$2f$dist$2d$es5$2f$ajax$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-dependencies-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-dependencies-js/dist-es5/ajax.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=def69_%40microsoft_applicationinsights-dependencies-js_dist-es5_1bee37f4._.js.map