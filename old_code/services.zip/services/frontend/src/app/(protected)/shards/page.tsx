"use client"

import { ColumnDef } from "@tanstack/react-table"
import { useRouter } from "next/navigation"
import { formatDistanceToNow } from "date-fns"
import { MoreHorizontal, Plus } from "lucide-react"
import { useTranslation } from "react-i18next"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { DataTable } from "@/components/data-table/data-table"
import { DataTableColumnHeader } from "@/components/data-table/data-table-column-header"
import { useShards, useDeleteShard } from "@/hooks/use-shards"
import { Shard } from "@/types/api"
import { toast } from "sonner"

export default function ShardsPage() {
  const router = useRouter()
  const { t } = useTranslation(['shards', 'common'])
  const { data, isLoading } = useShards({ page: 1, limit: 50 })
  const deleteShard = useDeleteShard()

  const handleDelete = (id: string, name: string) => {
    if (confirm(t('shards:deleteConfirm.message', { name }))) {
      deleteShard.mutate(id, {
        onSuccess: () => {
          toast.success(t('common:success'))
        },
        onError: () => {
          toast.error(t('common:error'))
        },
      })
    }
  }

  const columns: ColumnDef<Shard>[] = [
    {
      accessorKey: "name",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title={t('shards:table.name')} />
      ),
      cell: ({ row }) => {
        return (
          <div className="flex flex-col">
            <span className="font-medium">{row.getValue("name")}</span>
            {row.original.description && (
              <span className="text-xs text-muted-foreground">
                {row.original.description}
              </span>
            )}
          </div>
        )
      },
    },
    {
      accessorKey: "shardTypeName",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title={t('shards:table.type')} />
      ),
      cell: ({ row }) => {
        return (
          <Badge variant="outline">
            {row.getValue("shardTypeName")}
          </Badge>
        )
      },
    },
    {
      accessorKey: "isPublic",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title={t('shards:table.visibility')} />
      ),
      cell: ({ row }) => {
        const isPublic = row.getValue("isPublic")
        return (
          <Badge variant={isPublic ? "default" : "secondary"}>
            {isPublic ? t('shards:visibility.public') : t('shards:visibility.private')}
          </Badge>
        )
      },
    },
    {
      accessorKey: "tags",
      header: t('shards:table.tags'),
      cell: ({ row }) => {
        const tags = row.original.tags || []
        if (tags.length === 0) return <span className="text-xs text-muted-foreground">{t('common:noData')}</span>
        return (
          <div className="flex gap-1 flex-wrap max-w-[200px]">
            {tags.slice(0, 2).map((tag) => (
              <Badge key={tag} variant="secondary" className="text-xs">
                {tag}
              </Badge>
            ))}
            {tags.length > 2 && (
              <Badge variant="secondary" className="text-xs">
                +{tags.length - 2}
              </Badge>
            )}
          </div>
        )
      },
    },
    {
      accessorKey: "recordCount",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title={t('common:results')} />
      ),
      cell: ({ row }) => {
        return (
          <div className="text-right font-medium">
            {row.getValue("recordCount")}
          </div>
        )
      },
    },
    {
      accessorKey: "createdAt",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title={t('common:createdAt')} />
      ),
      cell: ({ row }) => {
        return (
          <div className="text-sm text-muted-foreground">
            {formatDistanceToNow(new Date(row.getValue("createdAt")), {
              addSuffix: true,
            })}
          </div>
        )
      },
    },
    {
      id: "actions",
      cell: ({ row }) => {
        const shard = row.original

        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">{t('common:actions')}</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>{t('common:actions')}</DropdownMenuLabel>
              <DropdownMenuItem
                onClick={() => navigator.clipboard.writeText(shard.id)}
              >
                {t('common:copyToClipboard')}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => router.push(`/shards/${shard.id}`)}
              >
                {t('common:viewDetails')}
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => router.push(`/shards/${shard.id}/edit`)}
              >
                {t('common:edit')}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => handleDelete(shard.id, shard.name)}
                className="text-destructive"
              >
                {t('common:delete')}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )
      },
    },
  ]

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t('shards:title')}</h1>
          <p className="text-muted-foreground">
            {t('shards:subtitle')}
          </p>
        </div>
        <Button onClick={() => router.push("/shards/new")}>
          <Plus className="h-4 w-4 mr-2" />
          {t('shards:create')}
        </Button>
      </div>

      <DataTable
        columns={columns}
        data={data?.items ?? []}
        searchKey="name"
        searchPlaceholder={t('shards:searchPlaceholder')}
        onRowClick={(shard) => router.push(`/shards/${shard.id}`)}
        isLoading={isLoading}
      />
    </div>
  )
}
