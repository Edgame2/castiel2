(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/services_frontend_src_ab6aed56._.js",
  "static/chunks/3ad0e_@radix-ui_react-select_dist_index_mjs_fabcf722._.js",
  "static/chunks/16716_@dnd-kit_core_dist_core_esm_cc9a58d0.js",
  "static/chunks/77b74_axios_lib_3ffa8d91._.js",
  "static/chunks/7d783_react-hook-form_dist_index_esm_mjs_d31afe53._.js",
  "static/chunks/37e87_zod_v4_9728400a._.js",
  "static/chunks/node_modules__pnpm_c4a625da._.js"
],
    source: "dynamic"
});
