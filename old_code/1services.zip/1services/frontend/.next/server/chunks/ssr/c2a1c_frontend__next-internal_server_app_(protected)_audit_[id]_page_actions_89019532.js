module.exports=[30573,(a,b,c)=>{}];

//# sourceMappingURL=c2a1c_frontend__next-internal_server_app_%28protected%29_audit_%5Bid%5D_page_actions_89019532.js.map