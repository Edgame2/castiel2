module.exports=[60754,(a,b,c)=>{}];

//# sourceMappingURL=c2a1c_frontend__next-internal_server_app_%28protected%29_users_%5Bid%5D_page_actions_3c393178.js.map