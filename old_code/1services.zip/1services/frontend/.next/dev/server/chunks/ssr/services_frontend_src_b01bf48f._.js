module.exports = [
"[project]/services/frontend/src/lib/auth/oauth.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// OAuth 2.0 configuration and utilities
__turbopack_context__.s([
    "buildAuthorizationUrl",
    ()=>buildAuthorizationUrl,
    "exchangeCodeForTokens",
    ()=>exchangeCodeForTokens,
    "getUserInfo",
    ()=>getUserInfo,
    "oAuthConfig",
    ()=>oAuthConfig,
    "refreshAccessToken",
    ()=>refreshAccessToken
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$env$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/frontend/src/lib/env.ts [app-ssr] (ecmascript)");
;
const normalizeBaseUrl = (value)=>{
    if (!value) return null;
    return value.endsWith('/') ? value.slice(0, -1) : value;
};
const resolvedBaseUrl = normalizeBaseUrl(__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$env$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["env"].NEXT_PUBLIC_API_BASE_URL);
if (!resolvedBaseUrl) {
    throw new Error('Missing NEXT_PUBLIC_API_BASE_URL for OAuth');
}
const oAuthConfig = {
    baseUrl: resolvedBaseUrl,
    authorizationEndpoint: `${resolvedBaseUrl}/oauth2/authorize`,
    tokenEndpoint: `${resolvedBaseUrl}/oauth2/token`,
    revokeEndpoint: `${resolvedBaseUrl}/oauth2/revoke`,
    userInfoEndpoint: `${resolvedBaseUrl}/oauth2/userinfo`,
    clientId: __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$env$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["env"].NEXT_PUBLIC_OAUTH_CLIENT_ID || '',
    redirectUri: __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$env$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["env"].NEXT_PUBLIC_OAUTH_REDIRECT_URI || '',
    scope: __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$env$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["env"].NEXT_PUBLIC_OAUTH_SCOPE || 'openid profile email'
};
function buildAuthorizationUrl(options) {
    const params = new URLSearchParams({
        response_type: 'code',
        client_id: oAuthConfig.clientId,
        redirect_uri: oAuthConfig.redirectUri,
        scope: options.scopeOverride ?? oAuthConfig.scope,
        state: options.state
    });
    if (options.codeChallenge) {
        params.set('code_challenge', options.codeChallenge);
        params.set('code_challenge_method', options.codeChallengeMethod ?? 'S256');
    }
    return `${oAuthConfig.authorizationEndpoint}?${params.toString()}`;
}
async function exchangeCodeForTokens(code, codeVerifier) {
    const payload = {
        grant_type: 'authorization_code',
        code,
        client_id: oAuthConfig.clientId,
        redirect_uri: oAuthConfig.redirectUri
    };
    if (codeVerifier) {
        payload.code_verifier = codeVerifier;
    }
    const response = await fetch(oAuthConfig.tokenEndpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        cache: 'no-store',
        body: JSON.stringify(payload)
    });
    if (!response.ok) {
        throw new Error(`Token exchange failed: ${response.statusText}`);
    }
    return response.json();
}
async function refreshAccessToken(refreshToken) {
    const response = await fetch(oAuthConfig.tokenEndpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        cache: 'no-store',
        body: JSON.stringify({
            grant_type: 'refresh_token',
            refresh_token: refreshToken,
            client_id: oAuthConfig.clientId
        })
    });
    if (!response.ok) {
        throw new Error(`Token refresh failed: ${response.statusText}`);
    }
    return response.json();
}
async function getUserInfo(accessToken) {
    const response = await fetch(oAuthConfig.userInfoEndpoint, {
        cache: 'no-store',
        headers: {
            Authorization: `Bearer ${accessToken}`
        }
    });
    if (!response.ok) {
        throw new Error(`Failed to fetch user info: ${response.statusText}`);
    }
    return response.json();
}
}),
"[project]/services/frontend/src/app/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$d_b7fcb0b13d52771d3a90da208c7b0dec$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.3_@babel+core@7.28.5_@opentelemetry+api@1.9.0_@playwright+test@1.56.1_react-d_b7fcb0b13d52771d3a90da208c7b0dec/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$d_b7fcb0b13d52771d3a90da208c7b0dec$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.3_@babel+core@7.28.5_@opentelemetry+api@1.9.0_@playwright+test@1.56.1_react-d_b7fcb0b13d52771d3a90da208c7b0dec/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$d_b7fcb0b13d52771d3a90da208c7b0dec$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.3_@babel+core@7.28.5_@opentelemetry+api@1.9.0_@playwright+test@1.56.1_react-d_b7fcb0b13d52771d3a90da208c7b0dec/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$contexts$2f$auth$2d$context$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/frontend/src/contexts/auth-context.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$auth$2f$oauth$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/frontend/src/lib/auth/oauth.ts [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
function Home() {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$d_b7fcb0b13d52771d3a90da208c7b0dec$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const { isAuthenticated, isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$contexts$2f$auth$2d$context$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useAuth"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$d_b7fcb0b13d52771d3a90da208c7b0dec$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log('Home: useEffect called - isLoading:', isLoading, 'isAuthenticated:', isAuthenticated);
        if (!isLoading) {
            console.log('Home: isAuthenticated =', isAuthenticated);
            if (isAuthenticated) {
                console.log('Home: Redirecting to /dashboard');
                router.push('/dashboard');
            } else {
                console.log('Home: Redirecting to login');
                // Build OAuth URL manually to ensure it works client-side
                const params = new URLSearchParams({
                    response_type: 'code',
                    client_id: __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$auth$2f$oauth$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["oAuthConfig"].clientId,
                    redirect_uri: __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$auth$2f$oauth$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["oAuthConfig"].redirectUri,
                    scope: __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$auth$2f$oauth$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["oAuthConfig"].scope,
                    state: encodeURIComponent('/dashboard')
                });
                const authUrl = `${__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$auth$2f$oauth$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["oAuthConfig"].authorizationEndpoint}?${params.toString()}`;
                console.log('Home: Auth URL =', authUrl);
                window.location.href = authUrl;
            }
        }
    }, [
        isAuthenticated,
        isLoading,
        router
    ]);
    // Show loading while checking auth
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$d_b7fcb0b13d52771d3a90da208c7b0dec$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex h-screen items-center justify-center",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$d_b7fcb0b13d52771d3a90da208c7b0dec$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$d_b7fcb0b13d52771d3a90da208c7b0dec$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-4 h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto"
                }, void 0, false, {
                    fileName: "[project]/services/frontend/src/app/page.tsx",
                    lineNumber: 41,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$d_b7fcb0b13d52771d3a90da208c7b0dec$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-muted-foreground",
                    children: "Loading..."
                }, void 0, false, {
                    fileName: "[project]/services/frontend/src/app/page.tsx",
                    lineNumber: 42,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/services/frontend/src/app/page.tsx",
            lineNumber: 40,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/services/frontend/src/app/page.tsx",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=services_frontend_src_b01bf48f._.js.map