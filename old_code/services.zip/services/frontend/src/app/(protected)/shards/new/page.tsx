"use client"

import { useRouter } from "next/navigation"
import { useTranslation } from "react-i18next"
import { ArrowLeft } from "lucide-react"
import { toast } from "sonner"

import { Button } from "@/components/ui/button"
import { ShardForm } from "@/components/forms/shard-form"
import { useCreateShard } from "@/hooks/use-shards"
import { CreateShardFormData } from "@/lib/validations/shard"
import { useActiveShardTypes } from "@/hooks/use-shard-types"

export default function NewShardPage() {
  const { t } = useTranslation('shards')
  const router = useRouter()
  const createShard = useCreateShard()

  // Fetch active shard types for the select dropdown
  const { data: shardTypesData, isLoading: isLoadingTypes } = useActiveShardTypes()
  const shardTypes = shardTypesData?.items ?? []

  const handleSubmit = async (data: CreateShardFormData & { files?: File[] }) => {
    try {
      const { files, ...shardData } = data

      if (files && files.length > 0) {
        // Create shard with files using FormData
        const formData = new FormData()
        formData.append('data', JSON.stringify(shardData))
        files.forEach((file) => {
          formData.append('files', file)
        })

        await createShard.mutateAsync(formData as any)
      } else {
        // Create shard without files
        await createShard.mutateAsync(shardData)
      }

      toast.success(t('messages.createSuccess'))
      router.push("/shards")
    } catch (error) {
      // Error handling is done in the mutation
      console.error("Failed to create shard:", error)
    }
  }

  const handleCancel = () => {
    router.back()
  }

  if (isLoadingTypes) {
    return (
      <div className="flex flex-col gap-6 p-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{t('createNew')}</h1>
            <p className="text-muted-foreground">{t('common:loading')}</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t('createNew')}</h1>
          <p className="text-muted-foreground">
            {t('createSubtitle')}
          </p>
        </div>
      </div>

      <div className="max-w-2xl">
        <ShardForm
          shardTypes={shardTypes.map((type) => ({
            id: type.id,
            name: type.displayName || type.name,
          }))}
          onSubmit={handleSubmit}
          onCancel={handleCancel}
          isLoading={createShard.isPending}
        />
      </div>
    </div>
  )
}
