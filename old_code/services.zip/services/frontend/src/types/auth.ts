// Authentication types
export interface User {
  id: string
  email: string
  name?: string
  firstName?: string
  lastName?: string
  displayName?: string
  avatarUrl?: string
  tenantId: string
  isDefaultTenant?: boolean
  role?: UserRole
  roles?: string[] // Array of role strings from API
  status: UserStatus
  emailVerified?: boolean
  lastLogin?: string
  createdAt?: string
  updatedAt?: string
}

export type UserRole = 'super-admin' | 'super_admin' | 'admin' | 'owner' | 'tenant_admin' | 'user' | 'read_only'
export type UserStatus = 'active' | 'inactive' | 'pending'

export interface AuthTokens {
  access_token: string
  refresh_token: string
  expires_in: number
  token_type: string
}

export interface OAuthConfig {
  authorizationEndpoint: string
  tokenEndpoint: string
  clientId: string
  redirectUri: string
  scope: string
}
