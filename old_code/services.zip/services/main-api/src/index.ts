import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import mercurius from 'mercurius';
import fastifyJwt from '@fastify/jwt';
import { MonitoringService } from '@castiel/monitoring';
import { config } from './config/env.js';
import { RedisConnectionManager } from './cache/redis.js';
import { CacheManager } from './cache/manager.js';
import { TokenValidationCacheService } from './services/token-validation-cache.service.js';
import { CacheService } from './services/cache.service.js';
import { CacheSubscriberService } from './services/cache-subscriber.service.js';
import { errorHandler, notFoundHandler } from './middleware/error-handler.js';
import { requestLogger } from './middleware/logger.js';
import { authenticate, optionalAuthenticate } from './middleware/authenticate.js';
import { registerRoutes } from './routes/index.js';
import { schema } from './graphql/schema.js';
import { resolvers } from './graphql/resolvers.js';
import { registerSwagger } from './plugins/swagger.js';
import {
  UserService,
  UserCacheService,
  CosmosDbClient,
  OAuthService,
  OAuth2ClientService,
  OAuth2AuthService,
} from './services/auth/index.js';
import { UnifiedEmailService } from './services/email/index.js';
import { UserManagementService } from './services/auth/user-management.service.js';
import { RoleManagementService } from './services/auth/role-management.service.js';
import { TenantService } from './services/auth/tenant.service.js';
import { MFAService } from './services/auth/mfa.service.js';
import { MagicLinkService } from './services/auth/magic-link.service.js';
import { SAMLService } from './services/auth/saml.service.js';
import { SSOConfigService } from './services/auth/sso-config.service.js';
import { SessionManagementService } from './services/auth/session-management.service.js';
import { AuthController } from './controllers/auth.controller.js';
import { MFAController } from './controllers/mfa.controller.js';
import { MagicLinkController } from './controllers/magic-link.controller.js';
import { SSOController } from './controllers/sso.controller.js';
import { SSOConfigController } from './controllers/sso-config.controller.js';
import { AzureADB2CController } from './controllers/azure-ad-b2c.controller.js';
import { AzureADB2CService } from './services/auth/azure-ad-b2c.service.js';
import { OAuthController } from './controllers/oauth.controller.js';
import { UserSecurityController } from './controllers/user-security.controller.js';
import { DeviceSecurityService } from './services/security/device-security.service.js';
import { OAuth2Controller } from './controllers/oauth2.controller.js';
import { UserManagementController } from './controllers/user-management.controller.js';
import { RoleManagementController } from './controllers/role-management.controller.js';
import { SessionManagementController } from './controllers/session-management.controller.js';
import { TenantController } from './controllers/tenant.controller.js';
import { TenantMembershipController } from './controllers/tenant-membership.controller.js';
import { TenantJoinRequestService } from './services/auth/tenant-join-request.service.js';
import { TenantInvitationService } from './services/auth/tenant-invitation.service.js';
import { TenantInvitationLifecycleScheduler } from './services/auth/tenant-invitation-lifecycle.scheduler.js';
import { AuditLogService, setAuditLogService } from './services/audit/audit-log.service.js';
import { RateLimiterService, InMemoryRateLimiterService } from './services/security/rate-limiter.service.js';

// Initialize monitoring
const monitoring = MonitoringService.initialize({
  enabled: config.monitoring.enabled,
  provider: config.monitoring.provider,
  instrumentationKey: config.monitoring.instrumentationKey,
  samplingRate: config.monitoring.samplingRate,
});

// Create Fastify server
const server = Fastify({
  logger: {
    level: config.logLevel,
  },
});

// Global references for graceful shutdown
let cacheSubscriberInstance: CacheSubscriberService | null = null;
let cacheManagerInstance: CacheManager | null = null;
let invitationLifecycleScheduler: TenantInvitationLifecycleScheduler | null = null;

/**
 * Start the server
 */
const start = async () => {
  try {
    // Initialize email service with flexible provider support
    const emailService = new UnifiedEmailService({
      provider: config.email.provider,
      fromEmail: config.email.fromEmail,
      fromName: config.email.fromName,
      resend: config.email.resend,
      azureAcs: config.email.azureAcs,
    });
    server.log.info(`✅ Email service initialized (provider: ${emailService.getProviderName()})`);

    let cosmosClient: CosmosDbClient | null = null;
    let userCacheService: UserCacheService | null = null;
    let userService: UserService | null = null;
    let cacheManager: CacheManager | null = null;
  let mfaController: MFAController | null = null;
  let magicLinkController: MagicLinkController | null = null;
  let ssoController: SSOController | null = null;
  let userManagementController: UserManagementController | null = null;
  let roleManagementController: RoleManagementController | null = null;
  let sessionManagementController: SessionManagementController | null = null;
  let tenantController: TenantController | null = null;
  let tenantMembershipController: TenantMembershipController | null = null;
  let tenantServiceInstance: TenantService | null = null;
  let tenantJoinRequestService: TenantJoinRequestService | null = null;
  let tenantInvitationService: TenantInvitationService | null = null;

    // Initialize Redis connection
    let redisClient = null;
    let tokenValidationCache = null;
    let cacheService = null;
    let cacheSubscriber = null;

    try {
      const redisManager = new RedisConnectionManager(config.redis);
      redisClient = await redisManager.getClient();
      server.log.info('✅ Redis connected successfully');

      // Initialize cache service
      cacheService = new CacheService(redisClient, monitoring);
      server.log.info('✅ Cache service initialized');

      // Initialize auth cache manager
      cacheManager = new CacheManager(redisClient, {
        sessionTTL: 9 * 60 * 60,
        refreshTokenTTL: 7 * 24 * 60 * 60,
        jwtCacheTTL: 5 * 60,
        cleanupInterval: 60 * 60 * 1000,
      });
      cacheManagerInstance = cacheManager;
      server.decorate('cacheManager', cacheManager);
      server.log.info('✅ Auth cache manager initialized');

      // Initialize user cache service
      userCacheService = new UserCacheService(redisClient);
      server.log.info('✅ User cache service initialized');

      // Initialize rate limiter
      const rateLimiter = new RateLimiterService(redisClient, 'castiel_rate_limit');
      server.decorate('rateLimiter', rateLimiter);
      server.log.info('✅ Rate limiter service initialized');

      // Initialize cache subscriber for cross-instance invalidation
      cacheSubscriber = new CacheSubscriberService(redisClient, cacheService, monitoring);
      await cacheSubscriber.initialize();
      server.log.info('✅ Cache subscriber initialized');

      // Store for graceful shutdown
      cacheSubscriberInstance = cacheSubscriber;

      // Initialize token validation cache if enabled
      if (config.jwt.validationCacheEnabled) {
        tokenValidationCache = new TokenValidationCacheService(redisClient);
        server.log.info('✅ Token validation cache enabled');
      }
    } catch (err) {
      server.log.warn({ err }, 'Redis connection failed - running without cache');
      
      // Use in-memory rate limiter as fallback
      const inMemoryRateLimiter = new InMemoryRateLimiterService();
      server.decorate('rateLimiter', inMemoryRateLimiter);
      server.log.info('✅ In-memory rate limiter initialized (fallback)');
    }

    // Initialize Cosmos DB client for auth data
    try {
      cosmosClient = new CosmosDbClient({
        endpoint: config.cosmosDb.endpoint,
        key: config.cosmosDb.key,
        database: config.cosmosDb.databaseId,
        rolesContainer: config.cosmosDb.containers.roles,
        usersContainer: config.cosmosDb.containers.users,
        tenantsContainer: config.cosmosDb.containers.tenants,
        ssoConfigsContainer: config.cosmosDb.containers.ssoConfigs,
          oauth2ClientsContainer: config.cosmosDb.containers.oauth2Clients,
          joinRequestsContainer: config.cosmosDb.containers.joinRequests,
          tenantInvitationsContainer: config.cosmosDb.containers.tenantInvitations,
      });

      const cosmosHealthy = await cosmosClient.healthCheck();
      if (cosmosHealthy) {
        server.log.info('✅ Cosmos DB connection established for auth services');
      } else {
        server.log.warn('⚠️ Cosmos DB health check failed for auth services');
      }
    } catch (err) {
      server.log.error({ err }, 'Failed to initialize Cosmos DB client for auth features');
    }

    // Initialize core auth domain services
    if (cosmosClient) {
      try {
        userService = new UserService(
          cosmosClient.getUsersContainer(),
          userCacheService || undefined
        );
        server.log.info('✅ User service initialized');
      } catch (err) {
        server.log.error({ err }, 'Failed to initialize user service');
      }
    } else {
      server.log.warn('⚠️ User service not initialized - Cosmos DB unavailable');
    }

    if (redisClient && cosmosClient) {
      try {
        const mfaService = new MFAService(
          server,
          redisClient,
          cosmosClient.getUsersContainer(),
          cosmosClient.getTenantsContainer(),
          emailService
        );
        mfaController = new MFAController(mfaService, {
          userService: userService || undefined,
          cacheManager: cacheManager || undefined,
          accessTokenExpiry: process.env.JWT_ACCESS_TOKEN_EXPIRY || '9h',
        });
        server.decorate('mfaController', mfaController);
        server.log.info('✅ MFA controller initialized');
      } catch (err) {
        server.log.warn({ err }, '⚠️ MFA service not initialized');
      }
    } else {
      server.log.warn('⚠️ MFA service not initialized - Redis or Cosmos DB unavailable');
    }

    // Initialize Magic Link controller
    if (redisClient && userService && cacheManager) {
      try {
        const magicLinkService = new MagicLinkService(
          server,
          redisClient,
          userService,
          emailService,
          process.env.FRONTEND_URL || 'http://localhost:3000'
        );
        magicLinkController = new MagicLinkController(
          magicLinkService,
          cacheManager,
          process.env.JWT_ACCESS_TOKEN_EXPIRY || '9h'
        );
        server.decorate('magicLinkController', magicLinkController);
        server.log.info('✅ Magic link controller initialized');
      } catch (err) {
        server.log.warn({ err }, '⚠️ Magic link service not initialized');
      }
    } else {
      server.log.warn('⚠️ Magic link service not initialized - missing dependencies');
    }

    // Initialize SSO/SAML controller
    let ssoConfigService: SSOConfigService | null = null;
    if (redisClient && cosmosClient && userService && cacheManager) {
      try {
        const samlService = new SAMLService(redisClient);
        const ssoConfigsContainer = cosmosClient.getSSOConfigsContainer();
        ssoConfigService = new SSOConfigService(ssoConfigsContainer, redisClient);
        
        ssoController = new SSOController(
          samlService,
          ssoConfigService,
          userService,
          cacheManager,
          process.env.JWT_ACCESS_TOKEN_EXPIRY || '9h',
          process.env.FRONTEND_URL || 'http://localhost:3000'
        );
        server.decorate('ssoController', ssoController);
        server.log.info('✅ SSO controller initialized');

        // Initialize SSO config controller for admin management
        const ssoConfigController = new SSOConfigController(ssoConfigService);
        server.decorate('ssoConfigController', ssoConfigController);
        server.log.info('✅ SSO config controller initialized');
      } catch (err) {
        server.log.warn({ err }, '⚠️ SSO controller not initialized');
      }
    } else {
      server.log.warn('⚠️ SSO controller not initialized - missing dependencies');
    }

    // Initialize Azure AD B2C controller
    if (redisClient && userService && cacheManager) {
      try {
        // Only initialize if Azure AD B2C is configured
        const azureB2CConfig = {
          tenantName: process.env.AZURE_B2C_TENANT_NAME || '',
          tenantId: process.env.AZURE_B2C_TENANT_ID || '',
          clientId: process.env.AZURE_B2C_CLIENT_ID || '',
          clientSecret: process.env.AZURE_B2C_CLIENT_SECRET || '',
          policyName: process.env.AZURE_B2C_POLICY_NAME || 'B2C_1_signupsignin',
          redirectUri: process.env.AZURE_B2C_REDIRECT_URI || `${process.env.API_BASE_URL || 'http://localhost:3001'}/auth/azure-b2c/callback`,
          scopes: ['openid', 'profile', 'email', 'offline_access'],
        };

        if (azureB2CConfig.tenantName && azureB2CConfig.clientId) {
          const azureB2CService = new AzureADB2CService(redisClient, azureB2CConfig);
          const azureB2CController = new AzureADB2CController(
            azureB2CService,
            userService,
            cacheManager,
            process.env.JWT_ACCESS_TOKEN_EXPIRY || '9h',
            process.env.FRONTEND_URL || 'http://localhost:3000'
          );
          server.decorate('azureADB2CController', azureB2CController);
          server.log.info('✅ Azure AD B2C controller initialized');
        } else {
          server.log.info('ℹ️ Azure AD B2C not configured - skipping initialization');
        }
      } catch (err) {
        server.log.warn({ err }, '⚠️ Azure AD B2C controller not initialized');
      }
    }

    if (cosmosClient && cacheManager) {
      const userManagementService = new UserManagementService(
        cosmosClient.getUsersContainer(),
        userCacheService || undefined,
        emailService
      );
      userManagementController = new UserManagementController(
        userManagementService,
        cacheManager
      );
      server.decorate('userManagementController', userManagementController);
      server.log.info('✅ User management controller initialized');
    } else {
      server.log.warn('⚠️ User management controller not initialized - missing dependencies');
    }

    // Initialize user security controller
    if (userService && mfaController && cacheManager) {
      try {
        const mfaService = new MFAService(
          server,
          redisClient!,
          cosmosClient!.getUsersContainer(),
          cosmosClient!.getTenantsContainer(),
          emailService
        );
        const userSecurityController = new UserSecurityController(
          userService,
          mfaService,
          cacheManager,
          emailService,
          process.env.FRONTEND_URL || 'http://localhost:3000'
        );
        server.decorate('userSecurityController', userSecurityController);
        server.log.info('✅ User security controller initialized');
      } catch (err) {
        server.log.warn({ err }, '⚠️ User security controller not initialized');
      }
    } else {
      server.log.warn('⚠️ User security controller not initialized - missing dependencies');
    }

    if (cosmosClient) {
      try {
        const roleService = new RoleManagementService(
          cosmosClient.getDatabase(),
          cosmosClient.getRolesContainer(),
          cosmosClient.getUsersContainer()
        );
        roleManagementController = new RoleManagementController(roleService);
        server.decorate('roleManagementController', roleManagementController);
        server.log.info('✅ Role management controller initialized');
      } catch (err) {
        server.log.warn({ err }, '⚠️ Role management controller not initialized');
      }
    } else {
      server.log.warn('⚠️ Role management controller not initialized - Cosmos DB unavailable');
    }

    if (cosmosClient) {
      try {
        tenantServiceInstance = new TenantService(cosmosClient.getTenantsContainer());
        tenantController = new TenantController(tenantServiceInstance);
        server.decorate('tenantController', tenantController);
        server.log.info('✅ Tenant controller initialized');
      } catch (err) {
        server.log.warn({ err }, '⚠️ Tenant controller not initialized');
      }
    } else {
      server.log.warn('⚠️ Tenant controller not initialized - Cosmos DB unavailable');
    }

    if (cosmosClient) {
      try {
        tenantJoinRequestService = new TenantJoinRequestService(
          cosmosClient.getTenantJoinRequestsContainer()
        );
        server.log.info('✅ Tenant join request service initialized');
      } catch (err) {
        server.log.warn({ err }, '⚠️ Tenant join request service not initialized');
      }

      try {
        tenantInvitationService = new TenantInvitationService(
          cosmosClient.getTenantInvitationsContainer(),
          config.membership.invitations,
          redisClient
        );
        server.log.info('✅ Tenant invitation service initialized');
      } catch (err) {
        server.log.warn({ err }, '⚠️ Tenant invitation service not initialized');
      }
    }

    if (
      tenantServiceInstance &&
      tenantJoinRequestService &&
      tenantInvitationService &&
      userService
    ) {
      tenantMembershipController = new TenantMembershipController(
        tenantJoinRequestService,
        tenantInvitationService,
        tenantServiceInstance,
        userService,
        emailService,
        config.frontend.baseUrl,
        config.membership.invitations
      );
      server.decorate('tenantMembershipController', tenantMembershipController);
      server.log.info('✅ Tenant membership controller initialized');
    } else {
      server.log.warn('⚠️ Tenant membership controller not initialized - missing dependencies');
    }

    if (
      tenantInvitationService &&
      tenantServiceInstance &&
      userService &&
      !invitationLifecycleScheduler
    ) {
      invitationLifecycleScheduler = new TenantInvitationLifecycleScheduler(
        tenantInvitationService,
        tenantServiceInstance,
        userService,
        emailService,
        config.frontend.baseUrl,
        config.membership.invitations,
        server.log
      );
      invitationLifecycleScheduler.start();
    }

    // Initialize Audit Log Service
    let auditLogService: AuditLogService | undefined;
    if (cosmosClient) {
      try {
        const auditLogsContainer = cosmosClient.database.container('AuditLogs');
        auditLogService = new AuditLogService(auditLogsContainer, {
          environment: config.nodeEnv,
          serviceName: 'main-api',
        });
        setAuditLogService(auditLogService);
        server.log.info('✅ Audit log service initialized');
      } catch (err) {
        server.log.warn({ err }, '⚠️ Audit log service not initialized');
      }
    }

    // Initialize device security service for new device detection
    let deviceSecurityService: DeviceSecurityService | undefined;
    if (emailService) {
      deviceSecurityService = new DeviceSecurityService(
        redisClient,
        emailService,
        config.api.publicUrl
      );
      server.log.info('✅ Device security service initialized');
    }

    if (cacheManager && userService && tenantServiceInstance && tenantJoinRequestService) {
      const authController = new AuthController(
        userService,
        emailService,
        cacheManager,
        config.api.publicUrl,
        config.jwt.accessTokenExpiry,
        tenantServiceInstance,
        tenantJoinRequestService,
        mfaController ?? undefined,
        auditLogService,
        deviceSecurityService
      );
      server.decorate('authController', authController);
      server.log.info('✅ Auth controller initialized');
    } else {
      server.log.warn('⚠️ Auth controller not initialized - missing dependencies');
    }

    if (cacheManager) {
      try {
        const sessionManagementService = new SessionManagementService(cacheManager.sessions);
        sessionManagementController = new SessionManagementController(sessionManagementService);
        server.decorate('sessionManagementController', sessionManagementController);
        server.log.info('✅ Session management controller initialized');
      } catch (err) {
        server.log.warn({ err }, '⚠️ Session management controller not initialized');
      }
    } else {
      server.log.warn('⚠️ Session management controller not initialized - cache manager unavailable');
    }

    if (redisClient && cacheManager && userService) {
      try {
        const oauthService = new OAuthService(
          redisClient,
          {
            clientId: config.oauth.google.clientId,
            clientSecret: config.oauth.google.clientSecret,
            redirectUri: config.oauth.google.redirectUri,
            authorizationUrl: config.oauth.google.authorizationUrl,
            tokenUrl: config.oauth.google.tokenUrl,
            userInfoUrl: config.oauth.google.userInfoUrl,
            scope: config.oauth.google.scope,
          },
          {
            clientId: config.oauth.github.clientId,
            clientSecret: config.oauth.github.clientSecret,
            redirectUri: config.oauth.github.redirectUri,
            authorizationUrl: config.oauth.github.authorizationUrl,
            tokenUrl: config.oauth.github.tokenUrl,
            userInfoUrl: config.oauth.github.userInfoUrl,
            scope: config.oauth.github.scope,
          },
          // Microsoft OAuth config (optional)
          config.oauth.microsoft.clientId ? {
            clientId: config.oauth.microsoft.clientId,
            clientSecret: config.oauth.microsoft.clientSecret,
            redirectUri: config.oauth.microsoft.redirectUri,
            authorizationUrl: config.oauth.microsoft.authorizationUrl,
            tokenUrl: config.oauth.microsoft.tokenUrl,
            userInfoUrl: config.oauth.microsoft.userInfoUrl,
            scope: config.oauth.microsoft.scope,
          } : undefined
        );

        const oauthControllerInstance = new OAuthController(
          oauthService,
          userService,
          cacheManager,
          config.jwt.accessTokenExpiry
        );
        server.decorate('oauthController', oauthControllerInstance);
        server.log.info('✅ OAuth controller initialized');
      } catch (err) {
        server.log.warn({ err }, '⚠️ OAuth controller not initialized');
      }
    } else {
      server.log.warn('⚠️ OAuth controller not initialized - missing dependencies');
    }

    if (redisClient && cosmosClient) {
      try {
        const oauth2ClientService = new OAuth2ClientService(
          cosmosClient.getOAuth2ClientsContainer()
        );
        const oauth2AuthService = new OAuth2AuthService(redisClient);
        const oauth2Controller = new OAuth2Controller(
          oauth2ClientService,
          oauth2AuthService
        );
        server.decorate('oauth2Controller', oauth2Controller);
        server.log.info('✅ OAuth2 controller initialized');
      } catch (err) {
        server.log.warn({ err }, '⚠️ OAuth2 controller not initialized');
      }
    } else {
      server.log.warn('⚠️ OAuth2 controller not initialized - Redis or Cosmos DB unavailable');
    }
    // Register security plugins
    await server.register(helmet, {
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
          imgSrc: ["'self'", 'data:', 'https:'],
        },
      },
    });

    // Register CORS
    await server.register(cors, {
      origin: config.cors.origin,
      credentials: config.cors.credentials,
    });

    // Register Swagger/OpenAPI documentation
    await registerSwagger(server);

    // Register JWT plugin for first-party auth tokens
    const jwtSignOptions: any = {
      issuer: config.jwt.issuer,
      expiresIn: config.jwt.accessTokenExpiry,
    };
    const jwtVerifyOptions: any = {
      issuer: config.jwt.issuer,
    };

    if (config.jwt.audience) {
      jwtSignOptions.audience = config.jwt.audience;
      jwtVerifyOptions.audience = config.jwt.audience;
    }

    await server.register(fastifyJwt, {
      secret: config.jwt.accessTokenSecret,
      sign: jwtSignOptions,
      verify: jwtVerifyOptions,
    });

    // Register GraphQL
    if (config.graphql.enabled) {
      await server.register(mercurius, {
        schema,
        resolvers,
        graphiql: config.graphql.playground,
        path: config.graphql.path,
      });
      server.log.info(`GraphQL endpoint: ${config.graphql.path}`);
      if (config.graphql.playground) {
        server.log.info(`GraphQL playground: ${config.graphql.path}`);
      }
    }

    // Register request logger middleware
    server.addHook('onRequest', requestLogger(monitoring));

    // Decorate server with cache services (for route access)
    if (cacheService) {
      server.decorate('cache', cacheService);
      server.decorate('cacheSubscriber', cacheSubscriber);
    }

    // Decorate server with auth services (for route access)
    server.decorate('tokenValidationCache', tokenValidationCache);
    server.decorate('authenticate', authenticate(tokenValidationCache));
    server.decorate('optionalAuthenticate', optionalAuthenticate(tokenValidationCache));

    // Register routes
    await registerRoutes(server, redisClient);

    // Register error handlers
    server.setErrorHandler(errorHandler(monitoring));
    server.setNotFoundHandler(notFoundHandler);

    // Start listening
    await server.listen({ port: config.port, host: config.host });

    monitoring.trackEvent('service.started', {
      service: 'main-api',
      port: config.port,
      environment: config.nodeEnv,
    });

    server.log.info(`🚀 Main API service running on http://${config.host}:${config.port}`);
    server.log.info(`📊 Environment: ${config.nodeEnv}`);
    server.log.info(`🔍 Log level: ${config.logLevel}`);

  } catch (err) {
    server.log.error(err);
    monitoring.trackException(err as Error, {
      phase: 'startup',
      service: 'main-api',
    });
    process.exit(1);
  }
};

// Graceful shutdown
const gracefulShutdown = async (
  signal: string,
  cacheSubscriberInstance: CacheSubscriberService | null,
  lifecycleScheduler: TenantInvitationLifecycleScheduler | null
) => {
  server.log.info(`${signal} received, shutting down gracefully...`);

  try {
    // Disconnect cache subscriber first
    if (cacheSubscriberInstance) {
      await cacheSubscriberInstance.disconnect();
      server.log.info('Cache subscriber disconnected');
    }

    if (cacheManagerInstance) {
      cacheManagerInstance.stopCleanup();
      server.log.info('Cache manager cleanup stopped');
    }

    if (lifecycleScheduler) {
      lifecycleScheduler.stop();
    }

    await server.close();
    server.log.info('Server closed');
    process.exit(0);
  } catch (err) {
    server.log.error({ err }, 'Error during shutdown');
    process.exit(1);
  }
};

process.on('SIGINT', () => gracefulShutdown('SIGINT', cacheSubscriberInstance, invitationLifecycleScheduler));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM', cacheSubscriberInstance, invitationLifecycleScheduler));

// Start the server
start();

