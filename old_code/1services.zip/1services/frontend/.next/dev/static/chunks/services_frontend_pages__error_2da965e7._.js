(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/9cd88_next_dist_compiled_d335a598._.js",
  "static/chunks/9cd88_next_dist_shared_lib_6a6799c6._.js",
  "static/chunks/9cd88_next_dist_client_977b685f._.js",
  "static/chunks/9cd88_next_dist_a14c9776._.js",
  "static/chunks/9cd88_next_error_2d37f224.js",
  "static/chunks/[next]_entry_page-loader_ts_1a9b7212._.js",
  "static/chunks/76102_react-dom_44795136._.js",
  "static/chunks/node_modules__pnpm_7136f466._.js",
  "static/chunks/[root-of-the-server]__f76ab578._.js"
],
    source: "entry"
});
