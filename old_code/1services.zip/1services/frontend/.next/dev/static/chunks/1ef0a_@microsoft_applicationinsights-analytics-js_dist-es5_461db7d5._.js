(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-analytics-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-analytics-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Web Analytics, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ // @skip-file-minify
// ##############################################################
// AUTO GENERATED FILE: This file is Auto Generated during build.
// ##############################################################
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// Note: DON'T Export these const from the package as we are still targeting ES5 which can result in a mutable variables that someone could change!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
__turbopack_context__.s([
    "_DYN_ADD_TELEMETRY_INITIA7",
    ()=>_DYN_ADD_TELEMETRY_INITIA7,
    "_DYN_AUTO_EXCEPTION_INSTR9",
    ()=>_DYN_AUTO_EXCEPTION_INSTR9,
    "_DYN_AUTO_TRACK_PAGE_VISI10",
    ()=>_DYN_AUTO_TRACK_PAGE_VISI10,
    "_DYN_AUTO_UNHANDLED_PROMI14",
    ()=>_DYN_AUTO_UNHANDLED_PROMI14,
    "_DYN_COLUMN_NUMBER",
    ()=>_DYN_COLUMN_NUMBER,
    "_DYN_CONFIG",
    ()=>_DYN_CONFIG,
    "_DYN_CONNECT_END",
    ()=>_DYN_CONNECT_END,
    "_DYN_CORE",
    ()=>_DYN_CORE,
    "_DYN_DATA_TYPE",
    ()=>_DYN_DATA_TYPE,
    "_DYN_DIAG_LOG",
    ()=>_DYN_DIAG_LOG,
    "_DYN_DURATION",
    ()=>_DYN_DURATION,
    "_DYN_ENABLE_AUTO_ROUTE_TR12",
    ()=>_DYN_ENABLE_AUTO_ROUTE_TR12,
    "_DYN_ENABLE_UNHANDLED_PRO13",
    ()=>_DYN_ENABLE_UNHANDLED_PRO13,
    "_DYN_ENVELOPE_TYPE",
    ()=>_DYN_ENVELOPE_TYPE,
    "_DYN_ERROR",
    ()=>_DYN_ERROR,
    "_DYN_GET_ENTRIES_BY_TYPE",
    ()=>_DYN_GET_ENTRIES_BY_TYPE,
    "_DYN_GET_PERFORMANCE_TIMI16",
    ()=>_DYN_GET_PERFORMANCE_TIMI16,
    "_DYN_HREF",
    ()=>_DYN_HREF,
    "_DYN_IS_BROWSER_LINK_TRAC11",
    ()=>_DYN_IS_BROWSER_LINK_TRAC11,
    "_DYN_IS_PERFORMANCE_TIMIN15",
    ()=>_DYN_IS_PERFORMANCE_TIMIN15,
    "_DYN_IS_PERFORMANCE_TIMIN18",
    ()=>_DYN_IS_PERFORMANCE_TIMIN18,
    "_DYN_IS_STORAGE_USE_DISAB0",
    ()=>_DYN_IS_STORAGE_USE_DISAB0,
    "_DYN_LENGTH",
    ()=>_DYN_LENGTH,
    "_DYN_LINE_NUMBER",
    ()=>_DYN_LINE_NUMBER,
    "_DYN_LOAD_EVENT_END",
    ()=>_DYN_LOAD_EVENT_END,
    "_DYN_NAVIGATION_START",
    ()=>_DYN_NAVIGATION_START,
    "_DYN_OVERRIDE_PAGE_VIEW_D8",
    ()=>_DYN_OVERRIDE_PAGE_VIEW_D8,
    "_DYN_POPULATE_PAGE_VIEW_P4",
    ()=>_DYN_POPULATE_PAGE_VIEW_P4,
    "_DYN_PROPERTIES",
    ()=>_DYN_PROPERTIES,
    "_DYN_REF_URI",
    ()=>_DYN_REF_URI,
    "_DYN_REQUEST_START",
    ()=>_DYN_REQUEST_START,
    "_DYN_RESPONSE_END",
    ()=>_DYN_RESPONSE_END,
    "_DYN_RESPONSE_START",
    ()=>_DYN_RESPONSE_START,
    "_DYN_SEND_EXCEPTION_INTER5",
    ()=>_DYN_SEND_EXCEPTION_INTER5,
    "_DYN_SEND_PAGE_VIEW_INTER2",
    ()=>_DYN_SEND_PAGE_VIEW_INTER2,
    "_DYN_SEND_PAGE_VIEW_PERFO3",
    ()=>_DYN_SEND_PAGE_VIEW_PERFO3,
    "_DYN_SHOULD_COLLECT_DURAT17",
    ()=>_DYN_SHOULD_COLLECT_DURAT17,
    "_DYN_START_TIME",
    ()=>_DYN_START_TIME,
    "_DYN_TO_STRING",
    ()=>_DYN_TO_STRING,
    "_DYN_TRACK",
    ()=>_DYN_TRACK,
    "_DYN_TRACK_PAGE_VIEW",
    ()=>_DYN_TRACK_PAGE_VIEW,
    "_DYN_TRACK_PREVIOUS_PAGE_1",
    ()=>_DYN_TRACK_PREVIOUS_PAGE_1,
    "_DYN__ADD_HOOK",
    ()=>_DYN__ADD_HOOK,
    "_DYN__CREATE_AUTO_EXCEPTI6",
    ()=>_DYN__CREATE_AUTO_EXCEPTI6
]);
var _DYN_TO_STRING = "toString"; // Count: 4
var _DYN_IS_STORAGE_USE_DISAB0 = "isStorageUseDisabled"; // Count: 3
var _DYN__ADD_HOOK = "_addHook"; // Count: 6
var _DYN_CORE = "core"; // Count: 14
var _DYN_DATA_TYPE = "dataType"; // Count: 8
var _DYN_ENVELOPE_TYPE = "envelopeType"; // Count: 7
var _DYN_DIAG_LOG = "diagLog"; // Count: 13
var _DYN_TRACK = "track"; // Count: 7
var _DYN_TRACK_PAGE_VIEW = "trackPageView"; // Count: 4
var _DYN_CONFIG = "config"; // Count: 12
var _DYN_TRACK_PREVIOUS_PAGE_1 = "trackPreviousPageVisit"; // Count: 3
var _DYN_SEND_PAGE_VIEW_INTER2 = "sendPageViewInternal"; // Count: 7
var _DYN_REF_URI = "refUri"; // Count: 5
var _DYN_START_TIME = "startTime"; // Count: 6
var _DYN_PROPERTIES = "properties"; // Count: 5
var _DYN_DURATION = "duration"; // Count: 12
var _DYN_SEND_PAGE_VIEW_PERFO3 = "sendPageViewPerformanceInternal"; // Count: 3
var _DYN_POPULATE_PAGE_VIEW_P4 = "populatePageViewPerformanceEvent"; // Count: 3
var _DYN_HREF = "href"; // Count: 6
var _DYN_SEND_EXCEPTION_INTER5 = "sendExceptionInternal"; // Count: 2
var _DYN_ERROR = "error"; // Count: 5
var _DYN_LINE_NUMBER = "lineNumber"; // Count: 4
var _DYN_COLUMN_NUMBER = "columnNumber"; // Count: 5
var _DYN__CREATE_AUTO_EXCEPTI6 = "CreateAutoException"; // Count: 3
var _DYN_ADD_TELEMETRY_INITIA7 = "addTelemetryInitializer"; // Count: 4
var _DYN_OVERRIDE_PAGE_VIEW_D8 = "overridePageViewDuration"; // Count: 2
var _DYN_AUTO_EXCEPTION_INSTR9 = "autoExceptionInstrumented"; // Count: 3
var _DYN_AUTO_TRACK_PAGE_VISI10 = "autoTrackPageVisitTime"; // Count: 2
var _DYN_IS_BROWSER_LINK_TRAC11 = "isBrowserLinkTrackingEnabled"; // Count: 2
var _DYN_LENGTH = "length"; // Count: 5
var _DYN_ENABLE_AUTO_ROUTE_TR12 = "enableAutoRouteTracking"; // Count: 2
var _DYN_ENABLE_UNHANDLED_PRO13 = "enableUnhandledPromiseRejectionTracking"; // Count: 2
var _DYN_AUTO_UNHANDLED_PROMI14 = "autoUnhandledPromiseInstrumented"; // Count: 3
var _DYN_GET_ENTRIES_BY_TYPE = "getEntriesByType"; // Count: 5
var _DYN_IS_PERFORMANCE_TIMIN15 = "isPerformanceTimingSupported"; // Count: 2
var _DYN_GET_PERFORMANCE_TIMI16 = "getPerformanceTiming"; // Count: 2
var _DYN_NAVIGATION_START = "navigationStart"; // Count: 4
var _DYN_SHOULD_COLLECT_DURAT17 = "shouldCollectDuration"; // Count: 3
var _DYN_IS_PERFORMANCE_TIMIN18 = "isPerformanceTimingDataReady"; // Count: 2
var _DYN_RESPONSE_START = "responseStart"; // Count: 5
var _DYN_REQUEST_START = "requestStart"; // Count: 3
var _DYN_LOAD_EVENT_END = "loadEventEnd"; // Count: 4
var _DYN_RESPONSE_END = "responseEnd"; // Count: 5
var _DYN_CONNECT_END = "connectEnd"; // Count: 4
 //# sourceMappingURL=__DynamicConstants.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-analytics-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-analytics-js/dist-es5/JavaScriptSDK/Telemetry/PageViewManager.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Web Analytics, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "PageViewManager",
    ()=>PageViewManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EnvUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-analytics-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-analytics-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
;
;
;
;
/**
 * Class encapsulates sending page views and page view performance telemetry.
 */ var PageViewManager = function() {
    function PageViewManager(appInsights, overridePageViewDuration, core, pageViewPerformanceManager) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(PageViewManager, this, function(_self) {
            var queueTimer = null;
            var itemQueue = [];
            var pageViewPerformanceSent = false;
            var firstPageViewSent = false;
            var _logger;
            if (core) {
                _logger = core.logger;
            }
            function _flushChannels(isAsync) {
                if (core) {
                    core.flush(isAsync, function() {
                    // Event flushed, callback added to prevent promise creation
                    });
                }
            }
            function _startTimer() {
                if (!queueTimer) {
                    queueTimer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["scheduleTimeout"])(function() {
                        queueTimer = null;
                        var allItems = itemQueue.slice(0);
                        var doFlush = false;
                        itemQueue = [];
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(allItems, function(item) {
                            if (!item()) {
                                // Not processed so rescheduled
                                itemQueue.push(item);
                            } else {
                                doFlush = true;
                            }
                        });
                        if (itemQueue[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                            _startTimer();
                        }
                        if (doFlush) {
                            // We process at least one item so flush the queue
                            _flushChannels(true);
                        }
                    }, 100);
                }
            }
            function _addQueue(cb) {
                itemQueue.push(cb);
                _startTimer();
            }
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACK_PAGE_VIEW"] /* @min:%2etrackPageView */ ] = function(pageView, customProperties) {
                var name = pageView.name;
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(name) || typeof name !== "string") {
                    var doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])();
                    name = pageView.name = doc && doc.title || "";
                }
                var uri = pageView.uri;
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(uri) || typeof uri !== "string") {
                    var location_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLocation"])();
                    uri = pageView.uri = location_1 && location_1[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HREF"] /* @min:%2ehref */ ] || "";
                }
                if (core && core[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONFIG"] /* @min:%2econfig */ ]) {
                    uri = pageView.uri = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fieldRedaction"])(pageView.uri, core[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONFIG"] /* @min:%2econfig */ ]);
                }
                if (!firstPageViewSent) {
                    var perf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPerformance"])();
                    // Access the performance timing object
                    var navigationEntries = perf && perf[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_ENTRIES_BY_TYPE"] /* @min:%2egetEntriesByType */ ] && perf[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_ENTRIES_BY_TYPE"] /* @min:%2egetEntriesByType */ ]("navigation");
                    // Edge Case the navigation Entries may return an empty array and the timeOrigin is not supported on IE
                    if (navigationEntries && navigationEntries[0] && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"])(perf.timeOrigin)) {
                        // Get the value of loadEventStart
                        var loadEventStart = navigationEntries[0].loadEventStart;
                        pageView[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_START_TIME"] /* @min:%2estartTime */ ] = new Date(perf.timeOrigin + loadEventStart);
                    } else {
                        // calculate the start time manually
                        var duration_1 = (customProperties || pageView[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROPERTIES"] /* @min:%2eproperties */ ] || {})[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DURATION"] /* @min:%2eduration */ ] || 0;
                        pageView[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_START_TIME"] /* @min:%2estartTime */ ] = new Date(new Date().getTime() - duration_1);
                    }
                    firstPageViewSent = true;
                }
                // case 1a. if performance timing is not supported by the browser, send the page view telemetry with the duration provided by the user. If the user
                // do not provide the duration, set duration to undefined
                // Also this is case 4
                if (!pageViewPerformanceManager[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_PERFORMANCE_TIMIN15"] /* @min:%2eisPerformanceTimingSupported */ ]()) {
                    appInsights[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SEND_PAGE_VIEW_INTER2"] /* @min:%2esendPageViewInternal */ ](pageView, customProperties);
                    _flushChannels(true);
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWebWorker"])()) {
                        // no navigation timing (IE 8, iOS Safari 8.4, Opera Mini 8 - see http://caniuse.com/#feat=nav-timing)
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_logger, 2 /* eLoggingSeverity.WARNING */ , 25 /* _eInternalMessageId.NavigationTimingNotSupported */ , "trackPageView: navigation timing API used for calculation of page duration is not supported in this browser. This page view will be collected without duration and timing info.");
                    }
                    return;
                }
                var pageViewSent = false;
                var customDuration;
                // if the performance timing is supported by the browser, calculate the custom duration
                var start = pageViewPerformanceManager[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_PERFORMANCE_TIMI16"] /* @min:%2egetPerformanceTiming */ ]()[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAVIGATION_START"] /* @min:%2enavigationStart */ ];
                if (start > 0) {
                    customDuration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsDuration"])(start, +new Date);
                    if (!pageViewPerformanceManager[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SHOULD_COLLECT_DURAT17"] /* @min:%2eshouldCollectDuration */ ](customDuration)) {
                        customDuration = undefined;
                    }
                }
                // if the user has provided duration, send a page view telemetry with the provided duration. Otherwise, if
                // overridePageViewDuration is set to true, send a page view telemetry with the custom duration calculated earlier
                var duration;
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(customProperties) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(customProperties[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DURATION"] /* @min:%2eduration */ ])) {
                    duration = customProperties[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DURATION"] /* @min:%2eduration */ ];
                }
                if (overridePageViewDuration || !isNaN(duration)) {
                    if (isNaN(duration)) {
                        // case 3
                        if (!customProperties) {
                            customProperties = {};
                        }
                        customProperties[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DURATION"] /* @min:%2eduration */ ] = customDuration;
                    }
                    // case 2
                    appInsights[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SEND_PAGE_VIEW_INTER2"] /* @min:%2esendPageViewInternal */ ](pageView, customProperties);
                    _flushChannels(true);
                    pageViewSent = true;
                }
                // now try to send the page view performance telemetry
                var maxDurationLimit = 60000;
                if (!customProperties) {
                    customProperties = {};
                }
                // Queue the event for processing
                _addQueue(function() {
                    var processed = false;
                    try {
                        if (pageViewPerformanceManager[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_PERFORMANCE_TIMIN18"] /* @min:%2eisPerformanceTimingDataReady */ ]()) {
                            processed = true;
                            var pageViewPerformance = {
                                name: name,
                                uri: uri
                            };
                            pageViewPerformanceManager[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_POPULATE_PAGE_VIEW_P4"] /* @min:%2epopulatePageViewPerformanceEvent */ ](pageViewPerformance);
                            if (!pageViewPerformance.isValid && !pageViewSent) {
                                // If navigation timing gives invalid numbers, then go back to "override page view duration" mode.
                                // That's the best value we can get that makes sense.
                                customProperties[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DURATION"] /* @min:%2eduration */ ] = customDuration;
                                appInsights[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SEND_PAGE_VIEW_INTER2"] /* @min:%2esendPageViewInternal */ ](pageView, customProperties);
                            } else {
                                if (!pageViewSent) {
                                    customProperties[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DURATION"] /* @min:%2eduration */ ] = pageViewPerformance.durationMs;
                                    appInsights[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SEND_PAGE_VIEW_INTER2"] /* @min:%2esendPageViewInternal */ ](pageView, customProperties);
                                }
                                if (!pageViewPerformanceSent) {
                                    appInsights[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SEND_PAGE_VIEW_PERFO3"] /* @min:%2esendPageViewPerformanceInternal */ ](pageViewPerformance, customProperties);
                                    pageViewPerformanceSent = true;
                                }
                            }
                        } else if (start > 0 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsDuration"])(start, +new Date) > maxDurationLimit) {
                            // if performance timings are not ready but we exceeded the maximum duration limit, just log a page view telemetry
                            // with the maximum duration limit. Otherwise, keep waiting until performance timings are ready
                            processed = true;
                            if (!pageViewSent) {
                                customProperties[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DURATION"] /* @min:%2eduration */ ] = maxDurationLimit;
                                appInsights[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SEND_PAGE_VIEW_INTER2"] /* @min:%2esendPageViewInternal */ ](pageView, customProperties);
                            }
                        }
                    } catch (e) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_logger, 1 /* eLoggingSeverity.CRITICAL */ , 38 /* _eInternalMessageId.TrackPVFailedCalc */ , "trackPageView failed on page load calculation: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                            exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                        });
                    }
                    return processed;
                });
            };
            _self.teardown = function(unloadCtx, unloadState) {
                if (queueTimer) {
                    queueTimer.cancel();
                    queueTimer = null;
                    var allItems = itemQueue.slice(0);
                    var doFlush_1 = false;
                    itemQueue = [];
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(allItems, function(item) {
                        if (item()) {
                            doFlush_1 = true;
                        }
                    });
                }
            };
        });
    }
    // Removed Stub for PageViewManager.prototype.trackPageView.
    // Removed Stub for PageViewManager.prototype.teardown.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    PageViewManager.__ieDyn = 1;
    return PageViewManager;
}();
;
 //# sourceMappingURL=PageViewManager.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-analytics-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-analytics-js/dist-es5/JavaScriptSDK/Telemetry/PageViewPerformanceManager.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Web Analytics, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "PageViewPerformanceManager",
    ()=>PageViewPerformanceManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-analytics-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-analytics-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
;
;
;
;
var MAX_DURATION_ALLOWED = 3600000; // 1h
var botAgentNames = [
    "googlebot",
    "adsbot-google",
    "apis-google",
    "mediapartners-google"
];
function _isPerformanceTimingSupported() {
    var perf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPerformance"])();
    return perf && !!perf.timing;
}
function _isPerformanceNavigationTimingSupported() {
    var perf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPerformance"])();
    return perf && perf.getEntriesByType && perf.getEntriesByType("navigation")[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0;
}
function _isPerformanceTimingDataReady() {
    var perf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPerformance"])();
    var timing = perf ? perf.timing : 0;
    return timing && timing.domainLookupStart > 0 && timing[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAVIGATION_START"] /* @min:%2enavigationStart */ ] > 0 && timing[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RESPONSE_START"] /* @min:%2eresponseStart */ ] > 0 && timing[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REQUEST_START"] /* @min:%2erequestStart */ ] > 0 && timing[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOAD_EVENT_END"] /* @min:%2eloadEventEnd */ ] > 0 && timing[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RESPONSE_END"] /* @min:%2eresponseEnd */ ] > 0 && timing[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONNECT_END"] /* @min:%2econnectEnd */ ] > 0 && timing.domLoading > 0;
}
function _getPerformanceTiming() {
    if (_isPerformanceTimingSupported()) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPerformance"])().timing;
    }
    return null;
}
function _getPerformanceNavigationTiming() {
    if (_isPerformanceNavigationTimingSupported()) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPerformance"])()[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_ENTRIES_BY_TYPE"] /* @min:%2egetEntriesByType */ ]("navigation")[0];
    }
    return null;
}
/**
* This method tells if given durations should be excluded from collection.
*/ function _shouldCollectDuration() {
    var durations = [];
    for(var _i = 0; _i < arguments.length; _i++){
        durations[_i] = arguments[_i];
    }
    var _navigator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNavigator"])() || {};
    // a full list of Google crawlers user agent strings - https://support.google.com/webmasters/answer/1061943?hl=en
    var userAgent = _navigator.userAgent;
    var isGoogleBot = false;
    if (userAgent) {
        for(var i = 0; i < botAgentNames[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; i++){
            isGoogleBot = isGoogleBot || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strIndexOf"])(userAgent.toLowerCase(), botAgentNames[i]) !== -1;
        }
    }
    if (isGoogleBot) {
        // Don't report durations for GoogleBot, it is returning invalid values in performance.timing API.
        return false;
    } else {
        // for other page views, don't report if it's outside of a reasonable range
        for(var i = 0; i < durations[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; i++){
            if (durations[i] < 0 || durations[i] >= MAX_DURATION_ALLOWED) {
                return false;
            }
        }
    }
    return true;
}
/**
 * Class encapsulates sending page view performance telemetry.
 */ var PageViewPerformanceManager = function() {
    function PageViewPerformanceManager(core) {
        var _logger = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeGetLogger"])(core);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(PageViewPerformanceManager, this, function(_self) {
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_POPULATE_PAGE_VIEW_P4"] /* @min:%2epopulatePageViewPerformanceEvent */ ] = function(pageViewPerformance) {
                pageViewPerformance.isValid = false;
                /*
                 * http://www.w3.org/TR/navigation-timing/#processing-model
                 *  |-navigationStart
                 *  |             |-connectEnd
                 *  |             ||-requestStart
                 *  |             ||             |-responseStart
                 *  |             ||             |              |-responseEnd
                 *  |             ||             |              |
                 *  |             ||             |              |         |-loadEventEnd
                 *  |---network---||---request---|---response---|---dom---|
                 *  |--------------------------total----------------------|
                 *
                 *  total = The difference between the load event of the current document is completed and the first recorded timestamp of the performance entry : https://developer.mozilla.org/en-US/docs/Web/Performance/Navigation_and_resource_timings#duration
                 *  network = Redirect time + App Cache + DNS lookup time + TCP connection time
                 *  request = Request time : https://developer.mozilla.org/en-US/docs/Web/Performance/Navigation_and_resource_timings#request_time
                 *  response = Response time
                 *  dom = Document load time : https://html.spec.whatwg.org/multipage/dom.html#document-load-timing-info
                 *      = Document processing time : https://developers.google.com/web/fundamentals/performance/navigation-and-resource-timing/#document_processing
                 *      + Loading time : https://developers.google.com/web/fundamentals/performance/navigation-and-resource-timing/#loading
                 */ var navigationTiming = _getPerformanceNavigationTiming();
                var timing = _getPerformanceTiming();
                var total = 0;
                var network = 0;
                var request = 0;
                var response = 0;
                var dom = 0;
                if (navigationTiming || timing) {
                    if (navigationTiming) {
                        total = navigationTiming[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DURATION"] /* @min:%2eduration */ ];
                        /**
                         * support both cases:
                         * - startTime is always zero: https://developer.mozilla.org/en-US/docs/Web/API/PerformanceNavigationTiming
                         * - for older browsers where the startTime is not zero
                         */ network = navigationTiming[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_START_TIME"] /* @min:%2estartTime */ ] === 0 ? navigationTiming[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONNECT_END"] /* @min:%2econnectEnd */ ] : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsDuration"])(navigationTiming[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_START_TIME"] /* @min:%2estartTime */ ], navigationTiming[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONNECT_END"] /* @min:%2econnectEnd */ ]);
                        request = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsDuration"])(navigationTiming.requestStart, navigationTiming[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RESPONSE_START"] /* @min:%2eresponseStart */ ]);
                        response = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsDuration"])(navigationTiming[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RESPONSE_START"] /* @min:%2eresponseStart */ ], navigationTiming[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RESPONSE_END"] /* @min:%2eresponseEnd */ ]);
                        dom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsDuration"])(navigationTiming.responseEnd, navigationTiming[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOAD_EVENT_END"] /* @min:%2eloadEventEnd */ ]);
                    } else {
                        total = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsDuration"])(timing[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAVIGATION_START"] /* @min:%2enavigationStart */ ], timing[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOAD_EVENT_END"] /* @min:%2eloadEventEnd */ ]);
                        network = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsDuration"])(timing[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAVIGATION_START"] /* @min:%2enavigationStart */ ], timing[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONNECT_END"] /* @min:%2econnectEnd */ ]);
                        request = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsDuration"])(timing.requestStart, timing[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RESPONSE_START"] /* @min:%2eresponseStart */ ]);
                        response = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsDuration"])(timing[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RESPONSE_START"] /* @min:%2eresponseStart */ ], timing[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_RESPONSE_END"] /* @min:%2eresponseEnd */ ]);
                        dom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsDuration"])(timing.responseEnd, timing[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOAD_EVENT_END"] /* @min:%2eloadEventEnd */ ]);
                    }
                    if (total === 0) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_logger, 2 /* eLoggingSeverity.WARNING */ , 10 /* _eInternalMessageId.ErrorPVCalc */ , "error calculating page view performance.", {
                            total: total,
                            network: network,
                            request: request,
                            response: response,
                            dom: dom
                        });
                    } else if (!_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SHOULD_COLLECT_DURAT17"] /* @min:%2eshouldCollectDuration */ ](total, network, request, response, dom)) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_logger, 2 /* eLoggingSeverity.WARNING */ , 45 /* _eInternalMessageId.InvalidDurationValue */ , "Invalid page load duration value. Browser perf data won't be sent.", {
                            total: total,
                            network: network,
                            request: request,
                            response: response,
                            dom: dom
                        });
                    } else if (total < (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mathFloor"])(network) + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mathFloor"])(request) + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mathFloor"])(response) + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mathFloor"])(dom)) {
                        // some browsers may report individual components incorrectly so that the sum of the parts will be bigger than total PLT
                        // in this case, don't report client performance from this page
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_logger, 2 /* eLoggingSeverity.WARNING */ , 8 /* _eInternalMessageId.ClientPerformanceMathError */ , "client performance math error.", {
                            total: total,
                            network: network,
                            request: request,
                            response: response,
                            dom: dom
                        });
                    } else {
                        pageViewPerformance.durationMs = total;
                        // // convert to timespans
                        pageViewPerformance.perfTotal = pageViewPerformance[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DURATION"] /* @min:%2eduration */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["msToTimeSpan"])(total);
                        pageViewPerformance.networkConnect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["msToTimeSpan"])(network);
                        pageViewPerformance.sentRequest = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["msToTimeSpan"])(request);
                        pageViewPerformance.receivedResponse = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["msToTimeSpan"])(response);
                        pageViewPerformance.domProcessing = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["msToTimeSpan"])(dom);
                        pageViewPerformance.isValid = true;
                    }
                }
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_PERFORMANCE_TIMI16"] /* @min:%2egetPerformanceTiming */ ] = _getPerformanceTiming;
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_PERFORMANCE_TIMIN15"] /* @min:%2eisPerformanceTimingSupported */ ] = _isPerformanceTimingSupported;
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_PERFORMANCE_TIMIN18"] /* @min:%2eisPerformanceTimingDataReady */ ] = _isPerformanceTimingDataReady;
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SHOULD_COLLECT_DURAT17"] /* @min:%2eshouldCollectDuration */ ] = _shouldCollectDuration;
        });
    }
    // Removed Stub for PageViewPerformanceManager.prototype.populatePageViewPerformanceEvent.
    // Removed Stub for PageViewPerformanceManager.prototype.getPerformanceTiming.
    // Removed Stub for PageViewPerformanceManager.prototype.isPerformanceTimingSupported.
    // Removed Stub for PageViewPerformanceManager.prototype.isPerformanceTimingDataReady.
    // Removed Stub for PageViewPerformanceManager.prototype.shouldCollectDuration.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    PageViewPerformanceManager.__ieDyn = 1;
    return PageViewPerformanceManager;
}();
;
 //# sourceMappingURL=PageViewPerformanceManager.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-analytics-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-analytics-js/dist-es5/JavaScriptSDK/Telemetry/PageVisitTimeManager.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Web Analytics, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "PageVisitData",
    ()=>PageVisitData,
    "PageVisitTimeManager",
    ()=>PageVisitTimeManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/StorageHelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__utcNow__as__dateNow$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript) <export utcNow as dateNow>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EnvUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-analytics-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-analytics-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
;
;
;
;
/**
 * Used to track page visit durations
 */ var PageVisitTimeManager = function() {
    /**
     * Creates a new instance of PageVisitTimeManager
     * @param pageVisitTimeTrackingHandler - Delegate that will be called to send telemetry data to AI (when trackPreviousPageVisit is called)
     * @returns {}
     */ function PageVisitTimeManager(logger, pageVisitTimeTrackingHandler) {
        var prevPageVisitDataKeyName = "prevPageVisitData";
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(PageVisitTimeManager, this, function(_self) {
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACK_PREVIOUS_PAGE_1"] /* @min:%2etrackPreviousPageVisit */ ] = function(currentPageName, currentPageUrl) {
                try {
                    // Restart timer for new page view
                    var prevPageVisitTimeData = restartPageVisitTimer(currentPageName, currentPageUrl);
                    // If there was a page already being timed, track the visit time for it now.
                    if (prevPageVisitTimeData) {
                        pageVisitTimeTrackingHandler(prevPageVisitTimeData.pageName, prevPageVisitTimeData.pageUrl, prevPageVisitTimeData.pageVisitTime);
                    }
                } catch (e) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_warnToConsole"])(logger, "Auto track page visit time failed, metric will not be collected: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e));
                }
            };
            /**
             * Stops timing of current page (if exists) and starts timing for duration of visit to pageName
             * @param pageName - Name of page to begin timing visit duration
             * @returns {PageVisitData} Page visit data (including duration) of pageName from last call to start or restart, if exists. Null if not.
             */ function restartPageVisitTimer(pageName, pageUrl) {
                var prevPageVisitData = null;
                try {
                    prevPageVisitData = stopPageVisitTimer();
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlCanUseSessionStorage"])()) {
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlGetSessionStorage"])(logger, prevPageVisitDataKeyName) != null) {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throwError"])("Cannot call startPageVisit consecutively without first calling stopPageVisit");
                        }
                        var currPageVisitDataStr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getJSON"])().stringify(new PageVisitData(pageName, pageUrl));
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlSetSessionStorage"])(logger, prevPageVisitDataKeyName, currPageVisitDataStr);
                    }
                } catch (e) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_warnToConsole"])(logger, "Call to restart failed: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e));
                    prevPageVisitData = null;
                }
                return prevPageVisitData;
            }
            /**
             * Stops timing of current page, if exists.
             * @returns {PageVisitData} Page visit data (including duration) of pageName from call to start, if exists. Null if not.
             */ function stopPageVisitTimer() {
                var prevPageVisitData = null;
                try {
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlCanUseSessionStorage"])()) {
                        // Define end time of page's visit
                        var pageVisitEndTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__utcNow__as__dateNow$3e$__["dateNow"])();
                        // Try to retrieve  page name and start time from session storage
                        var pageVisitDataJsonStr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlGetSessionStorage"])(logger, prevPageVisitDataKeyName);
                        if (pageVisitDataJsonStr && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasJSON"])()) {
                            // if previous page data exists, set end time of visit
                            prevPageVisitData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getJSON"])().parse(pageVisitDataJsonStr);
                            prevPageVisitData.pageVisitTime = pageVisitEndTime - prevPageVisitData.pageVisitStartTime;
                            // Remove data from storage since we already used it
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlRemoveSessionStorage"])(logger, prevPageVisitDataKeyName);
                        }
                    }
                } catch (e) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_warnToConsole"])(logger, "Stop page visit timer failed: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e));
                    prevPageVisitData = null;
                }
                return prevPageVisitData;
            }
            // For backward compatibility
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "_logger", {
                g: function() {
                    return logger;
                }
            });
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "pageVisitTimeTrackingHandler", {
                g: function() {
                    return pageVisitTimeTrackingHandler;
                }
            });
        });
    }
    // Removed Stub for PageVisitTimeManager.prototype.trackPreviousPageVisit.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    PageVisitTimeManager.__ieDyn = 1;
    return PageVisitTimeManager;
}();
;
var PageVisitData = function() {
    function PageVisitData(pageName, pageUrl) {
        this.pageVisitStartTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__utcNow__as__dateNow$3e$__["dateNow"])();
        this.pageName = pageName;
        this.pageUrl = pageUrl;
    }
    return PageVisitData;
}();
;
 //# sourceMappingURL=PageVisitTimeManager.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-analytics-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-analytics-js/dist-es5/JavaScriptSDK/Timing.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Web Analytics, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "Timing",
    ()=>Timing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
;
;
/**
 * Used to record timed events and page views.
 */ var Timing = function() {
    function Timing(logger, name) {
        var _self = this;
        var _events = {};
        _self.start = function(name) {
            if (typeof _events[name] !== "undefined") {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 2 /* eLoggingSeverity.WARNING */ , 62 /* _eInternalMessageId.StartCalledMoreThanOnce */ , "start was called more than once for this event without calling stop.", {
                    name: name,
                    key: name
                }, true);
            }
            _events[name] = +new Date;
        };
        _self.stop = function(name, url, properties, measurements) {
            var start = _events[name];
            if (isNaN(start)) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 2 /* eLoggingSeverity.WARNING */ , 63 /* _eInternalMessageId.StopCalledWithoutStart */ , "stop was called without a corresponding start.", {
                    name: name,
                    key: name
                }, true);
            } else {
                var end = +new Date;
                var duration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dateTimeUtilsDuration"])(start, end);
                _self.action(name, url, duration, properties, measurements);
            }
            delete _events[name];
            _events[name] = undefined;
        };
    }
    return Timing;
}();
;
 //# sourceMappingURL=Timing.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-analytics-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-analytics-js/dist-es5/JavaScriptSDK/AnalyticsPlugin.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Web Analytics, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ /**
* ApplicationInsights.ts
* @copyright Microsoft 2018
*/ __turbopack_context__.s([
    "AnalyticsPlugin",
    ()=>AnalyticsPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-shims@3.0.1/node_modules/@microsoft/applicationinsights-shims/dist-es5/TsLibShims.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$applicationinsights$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/applicationinsights-common.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Event.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Exception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Exception.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Metric$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Metric.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/PageView.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageViewPerformance$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/PageViewPerformance.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$RemoteDependencyData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/RemoteDependencyData.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Trace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Trace.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$DomHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/DomHelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$TelemetryItemCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/TelemetryItemCreator.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$DataSanitizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Telemetry/Common/DataSanitizer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/Constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-common@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-common/dist-es5/StorageHelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$BaseTelemetryPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/BaseTelemetryPlugin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InstrumentHooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InstrumentHooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/ConfigDefaultHelpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/ProcessTelemetryContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DataCacheHelper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EventHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EventHelpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EnvUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$W3cTraceParent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/W3cTraceParent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CoreUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/CoreUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicConfig.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CookieMgr$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/CookieMgr.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__strShimUndefined__as__strUndefined$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-shims@3.0.1/node_modules/@microsoft/applicationinsights-shims/dist-es5/Constants.js [app-client] (ecmascript) <export strShimUndefined as strUndefined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-analytics-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-analytics-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$Telemetry$2f$PageViewManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-analytics-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-analytics-js/dist-es5/JavaScriptSDK/Telemetry/PageViewManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$Telemetry$2f$PageViewPerformanceManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-analytics-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-analytics-js/dist-es5/JavaScriptSDK/Telemetry/PageViewPerformanceManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$Telemetry$2f$PageVisitTimeManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-analytics-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-analytics-js/dist-es5/JavaScriptSDK/Telemetry/PageVisitTimeManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$Timing$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-analytics-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-analytics-js/dist-es5/JavaScriptSDK/Timing.js [app-client] (ecmascript)");
var _a;
;
;
;
;
;
;
;
;
;
;
var strEvent = "event";
function _dispatchEvent(target, evnt) {
    if (target && target.dispatchEvent && evnt) {
        target.dispatchEvent(evnt);
    }
}
function _getReason(error) {
    if (error && error.reason) {
        var reason = error.reason;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(reason) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(reason[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_STRING"] /* @min:%2etoString */ ])) {
            return reason[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_STRING"] /* @min:%2etoString */ ]();
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(reason);
    }
    // Pass the original object down which will eventually get evaluated for any message or description
    return error || "";
}
var MinMilliSeconds = 60000;
var defaultValues = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDeepFreeze"])((_a = {
    sessionRenewalMs: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfSet"])(_chkConfigMilliseconds, 30 * 60 * 1000),
    sessionExpirationMs: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfSet"])(_chkConfigMilliseconds, 24 * 60 * 60 * 1000),
    disableExceptionTracking: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])()
}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTO_TRACK_PAGE_VISI10"] /* @min:autoTrackPageVisitTime */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_OVERRIDE_PAGE_VIEW_D8"] /* @min:overridePageViewDuration */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLE_UNHANDLED_PRO13"] /* @min:enableUnhandledPromiseRejectionTracking */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTO_UNHANDLED_PROMI14"] /* @min:autoUnhandledPromiseInstrumented */ ] = false, _a.samplingPercentage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfValidate"])(_chkSampling, 100), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_STORAGE_USE_DISAB0"] /* @min:isStorageUseDisabled */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_BROWSER_LINK_TRAC11"] /* @min:isBrowserLinkTrackingEnabled */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLE_AUTO_ROUTE_TR12"] /* @min:enableAutoRouteTracking */ ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(), _a.namePrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfString"])(), _a.enableDebug = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(), _a.disableFlushOnBeforeUnload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(), _a.disableFlushOnUnload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfBoolean"])(false, "disableFlushOnBeforeUnload"), _a.expCfg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfMerge"])({
    inclScripts: false,
    expLog: undefined,
    maxLogs: 50
}), _a));
function _chkConfigMilliseconds(value, defValue) {
    value = value || defValue;
    if (value < MinMilliSeconds) {
        value = MinMilliSeconds;
    }
    return +value;
}
function _chkSampling(value) {
    return !isNaN(value) && value > 0 && value <= 100;
}
function _updateStorageUsage(extConfig) {
    // Not resetting the storage usage as someone may have manually called utlDisableStorage, so this will only
    // reset based if the configuration option is provided
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"])(extConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_STORAGE_USE_DISAB0"] /* @min:%2eisStorageUseDisabled */ ])) {
        if (extConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_STORAGE_USE_DISAB0"] /* @min:%2eisStorageUseDisabled */ ]) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlDisableStorage"])();
        } else {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlEnableStorage"])();
        }
    }
}
var AnalyticsPlugin = function(_super) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__extendsFn"])(AnalyticsPlugin, _super);
    function AnalyticsPlugin() {
        var _this = _super.call(this) || this;
        _this.identifier = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$applicationinsights$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AnalyticsPluginIdentifier"]; // do not change name or priority
        _this.priority = 180; // take from reserved priority range 100- 200
        _this.autoRoutePVDelay = 500; // ms; Time to wait after a route change before triggering a pageview to allow DOM changes to take place
        var _eventTracking;
        var _pageTracking;
        var _pageViewManager;
        var _pageViewPerformanceManager;
        var _pageVisitTimeManager;
        var _preInitTelemetryInitializers;
        var _isBrowserLinkTrackingEnabled;
        var _browserLinkInitializerAdded;
        var _enableAutoRouteTracking;
        var _historyListenerAdded;
        var _disableExceptionTracking;
        var _autoExceptionInstrumented;
        var _enableUnhandledPromiseRejectionTracking;
        var _autoUnhandledPromiseInstrumented;
        var _extConfig;
        var _autoTrackPageVisitTime;
        var _expCfg;
        // array with max length of 2 that store current url and previous url for SPA page route change trackPageview use.
        var _prevUri; // Assigned in the constructor
        var _currUri;
        var _evtNamespace;
        // For testing error hooks only
        var _errorHookCnt;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(AnalyticsPlugin, _this, function(_self, _base) {
            var _addHook = _base[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ADD_HOOK"] /* @min:%2e_addHook */ ];
            _initDefaults();
            _self.getCookieMgr = function() {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CookieMgr$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeGetCookieMgr"])(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ]);
            };
            _self.processTelemetry = function(env, itemCtx) {
                _self.processNext(env, itemCtx);
            };
            _self.trackEvent = function(event, customProperties) {
                try {
                    var telemetryItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$TelemetryItemCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTelemetryItem"])(event, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Event"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Event"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENVELOPE_TYPE"] /* @min:%2eenvelopeType */ ], _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), customProperties);
                    _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACK"] /* @min:%2etrack */ ](telemetryItem);
                } catch (e) {
                    _throwInternal(2 /* eLoggingSeverity.WARNING */ , 39 /* _eInternalMessageId.TrackTraceFailed */ , "trackTrace failed, trace will not be collected: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                        exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                    });
                }
            };
            /**
             * Start timing an extended event. Call `stopTrackEvent` to log the event when it ends.
             * @param name - A string that identifies this event uniquely within the document.
             */ _self.startTrackEvent = function(name) {
                try {
                    _eventTracking.start(name);
                } catch (e) {
                    _throwInternal(1 /* eLoggingSeverity.CRITICAL */ , 29 /* _eInternalMessageId.StartTrackEventFailed */ , "startTrackEvent failed, event will not be collected: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                        exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                    });
                }
            };
            /**
             * Log an extended event that you started timing with `startTrackEvent`.
             * @param name - The string you used to identify this event in `startTrackEvent`.
             * @param properties - map[string, string] - additional data used to filter events and metrics in the portal. Defaults to empty.
             * @param measurements - map[string, number] - metrics associated with this event, displayed in Metrics Explorer on the portal. Defaults to empty.
             */ _self.stopTrackEvent = function(name, properties, measurements) {
                try {
                    _eventTracking.stop(name, undefined, properties, measurements);
                } catch (e) {
                    _throwInternal(1 /* eLoggingSeverity.CRITICAL */ , 30 /* _eInternalMessageId.StopTrackEventFailed */ , "stopTrackEvent failed, event will not be collected: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                        exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                    });
                }
            };
            /**
             * @description Log a diagnostic message
             * @param trace - the trace message
             * @param customProperties - Additional custom properties to include in the event
             */ _self.trackTrace = function(trace, customProperties) {
                try {
                    var telemetryItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$TelemetryItemCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTelemetryItem"])(trace, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Trace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trace"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Trace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trace"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENVELOPE_TYPE"] /* @min:%2eenvelopeType */ ], _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), customProperties);
                    _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACK"] /* @min:%2etrack */ ](telemetryItem);
                } catch (e) {
                    _throwInternal(2 /* eLoggingSeverity.WARNING */ , 39 /* _eInternalMessageId.TrackTraceFailed */ , "trackTrace failed, trace will not be collected: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                        exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                    });
                }
            };
            /**
             * @description Log a numeric value that is not associated with a specific event. Typically
             * used to send regular reports of performance indicators. To send single measurement, just
             * use the name and average fields of {@link IMetricTelemetry}. If you take measurements
             * frequently, you can reduce the telemetry bandwidth by aggregating multiple measurements
             * and sending the resulting average at intervals
             * @param metric - input object argument. Only name and average are mandatory.
             * @param } customProperties additional data used to filter metrics in the
             * portal. Defaults to empty.
             */ _self.trackMetric = function(metric, customProperties) {
                try {
                    var telemetryItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$TelemetryItemCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTelemetryItem"])(metric, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Metric$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metric"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Metric$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metric"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENVELOPE_TYPE"] /* @min:%2eenvelopeType */ ], _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), customProperties);
                    _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACK"] /* @min:%2etrack */ ](telemetryItem);
                } catch (e) {
                    _throwInternal(1 /* eLoggingSeverity.CRITICAL */ , 36 /* _eInternalMessageId.TrackMetricFailed */ , "trackMetric failed, metric will not be collected: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                        exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                    });
                }
            };
            /**
             * Logs that a page or other item was viewed.
             * @param IPageViewTelemetry - The string you used as the name in startTrackPage. Defaults to the document title.
             * @param customProperties - Additional data used to filter events and metrics. Defaults to empty.
             * If a user wants to provide duration for pageLoad, it'll have to be in pageView.properties.duration
             */ _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACK_PAGE_VIEW"] /* @min:%2etrackPageView */ ] = function(pageView, customProperties) {
                try {
                    var inPv = pageView || {};
                    if (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ] && _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONFIG"] /* @min:%2econfig */ ]) {
                        inPv.uri = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fieldRedaction"])(inPv.uri, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONFIG"] /* @min:%2econfig */ ]);
                    }
                    _pageViewManager[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACK_PAGE_VIEW"] /* @min:%2etrackPageView */ ](inPv, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assignFn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assignFn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assignFn"])({}, inPv.properties), inPv.measurements), customProperties));
                    if (_autoTrackPageVisitTime) {
                        _pageVisitTimeManager[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACK_PREVIOUS_PAGE_1"] /* @min:%2etrackPreviousPageVisit */ ](inPv.name, inPv.uri);
                    }
                } catch (e) {
                    _throwInternal(1 /* eLoggingSeverity.CRITICAL */ , 37 /* _eInternalMessageId.TrackPVFailed */ , "trackPageView failed, page view will not be collected: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                        exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                    });
                }
            };
            /**
             * Create a page view telemetry item and send it to the SDK pipeline through the core.track API
             * @param pageView - Page view item to be sent
             * @param properties - Custom properties (Part C) that a user can add to the telemetry item
             * @param systemProperties - System level properties (Part A) that a user can add to the telemetry item
             */ _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SEND_PAGE_VIEW_INTER2"] /* @min:%2esendPageViewInternal */ ] = function(pageView, properties, systemProperties) {
                var doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])();
                if (doc) {
                    pageView[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REF_URI"] /* @min:%2erefUri */ ] = pageView[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REF_URI"] /* @min:%2erefUri */ ] === undefined ? doc.referrer : pageView[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REF_URI"] /* @min:%2erefUri */ ];
                }
                if (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ] && _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONFIG"] /* @min:%2econfig */ ]) {
                    pageView.refUri = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fieldRedaction"])(pageView.refUri, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONFIG"] /* @min:%2econfig */ ]);
                }
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(pageView[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_START_TIME"] /* @min:%2estartTime */ ])) {
                    // calculate the start time manually
                    var duration = (properties || pageView[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROPERTIES"] /* @min:%2eproperties */ ] || {})[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DURATION"] /* @min:%2eduration */ ] || 0;
                    pageView[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_START_TIME"] /* @min:%2estartTime */ ] = new Date(new Date().getTime() - duration);
                }
                var telemetryItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$TelemetryItemCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTelemetryItem"])(pageView, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageView"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageView"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENVELOPE_TYPE"] /* @min:%2eenvelopeType */ ], _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), properties, systemProperties);
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACK"] /* @min:%2etrack */ ](telemetryItem);
                // reset ajaxes counter
                _resetAjaxAttempts();
            };
            /**
             * @ignore INTERNAL ONLY
             * @param pageViewPerformance
             * @param properties
             */ _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SEND_PAGE_VIEW_PERFO3"] /* @min:%2esendPageViewPerformanceInternal */ ] = function(pageViewPerformance, properties, systemProperties) {
                var telemetryItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$TelemetryItemCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTelemetryItem"])(pageViewPerformance, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageViewPerformance$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageViewPerformance"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$PageViewPerformance$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageViewPerformance"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENVELOPE_TYPE"] /* @min:%2eenvelopeType */ ], _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), properties, systemProperties);
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACK"] /* @min:%2etrack */ ](telemetryItem);
            };
            /**
             * Send browser performance metrics.
             * @param pageViewPerformance
             * @param customProperties
             */ _self.trackPageViewPerformance = function(pageViewPerformance, customProperties) {
                var inPvp = pageViewPerformance || {};
                try {
                    _pageViewPerformanceManager[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_POPULATE_PAGE_VIEW_P4"] /* @min:%2epopulatePageViewPerformanceEvent */ ](inPvp);
                    _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SEND_PAGE_VIEW_PERFO3"] /* @min:%2esendPageViewPerformanceInternal */ ](inPvp, customProperties);
                } catch (e) {
                    _throwInternal(1 /* eLoggingSeverity.CRITICAL */ , 37 /* _eInternalMessageId.TrackPVFailed */ , "trackPageViewPerformance failed, page view will not be collected: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                        exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                    });
                }
            };
            /**
             * Starts the timer for tracking a page load time. Use this instead of `trackPageView` if you want to control when the page view timer starts and stops,
             * but don't want to calculate the duration yourself. This method doesn't send any telemetry. Call `stopTrackPage` to log the end of the page view
             * and send the event.
             * @param name - A string that idenfities this item, unique within this HTML document. Defaults to the document title.
             */ _self.startTrackPage = function(name) {
                try {
                    if (typeof name !== "string") {
                        var doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])();
                        name = doc && doc.title || "";
                    }
                    _pageTracking.start(name);
                } catch (e) {
                    _throwInternal(1 /* eLoggingSeverity.CRITICAL */ , 31 /* _eInternalMessageId.StartTrackFailed */ , "startTrackPage failed, page view may not be collected: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                        exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                    });
                }
            };
            /**
             * Stops the timer that was started by calling `startTrackPage` and sends the pageview load time telemetry with the specified properties and measurements.
             * The duration of the page view will be the time between calling `startTrackPage` and `stopTrackPage`.
             * @param name - The string you used as the name in startTrackPage. Defaults to the document title.
             * @param url - String - a relative or absolute URL that identifies the page or other item. Defaults to the window location.
             * @param properties - map[string, string] - additional data used to filter pages and metrics in the portal. Defaults to empty.
             * @param measurements - map[string, number] - metrics associated with this page, displayed in Metrics Explorer on the portal. Defaults to empty.
             */ _self.stopTrackPage = function(name, url, properties, measurement) {
                try {
                    if (typeof name !== "string") {
                        var doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])();
                        name = doc && doc.title || "";
                    }
                    if (typeof url !== "string") {
                        var loc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLocation"])();
                        url = loc && loc[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HREF"] /* @min:%2ehref */ ] || "";
                    }
                    if (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ] && _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONFIG"] /* @min:%2econfig */ ]) {
                        url = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fieldRedaction"])(url, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONFIG"] /* @min:%2econfig */ ]);
                    }
                    _pageTracking.stop(name, url, properties, measurement);
                    if (_autoTrackPageVisitTime) {
                        _pageVisitTimeManager[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACK_PREVIOUS_PAGE_1"] /* @min:%2etrackPreviousPageVisit */ ](name, url);
                    }
                } catch (e) {
                    _throwInternal(1 /* eLoggingSeverity.CRITICAL */ , 32 /* _eInternalMessageId.StopTrackFailed */ , "stopTrackPage failed, page view will not be collected: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                        exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                    });
                }
            };
            /**
            * @ignore INTERNAL ONLY
            * @param exception
            * @param properties
            * @param systemProperties
            */ _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SEND_EXCEPTION_INTER5"] /* @min:%2esendExceptionInternal */ ] = function(exception, customProperties, systemProperties) {
                // Adding additional edge cases to handle
                // - Not passing anything (null / undefined)
                var theError = exception && (exception.exception || exception[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ERROR"] /* @min:%2eerror */ ]) || // - Handle someone calling trackException based of v1 API where the exception was the Error
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isError"])(exception) && exception || // - Handles no error being defined and instead of creating a new Error() instance attempt to map so any stacktrace
                //   is preserved and does not list ApplicationInsights code as the source
                {
                    name: exception && typeof exception,
                    message: exception || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strNotSpecified"]
                };
                // If no exception object was passed assign to an empty object to avoid internal exceptions
                exception = exception || {};
                var exceptionPartB = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Exception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Exception"](_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), theError, exception[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROPERTIES"] /* @min:%2eproperties */ ] || customProperties, exception.measurements, exception.severityLevel, exception.id).toInterface();
                var doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])();
                if (doc && (_expCfg === null || _expCfg === void 0 ? void 0 : _expCfg.inclScripts)) {
                    var scriptsInfo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$W3cTraceParent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findAllScripts"])(doc);
                    exceptionPartB[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROPERTIES"] /* @min:%2eproperties */ ]["exceptionScripts"] = JSON.stringify(scriptsInfo);
                }
                if (_expCfg === null || _expCfg === void 0 ? void 0 : _expCfg.expLog) {
                    var logs = _expCfg.expLog();
                    if (logs && logs.logs && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(logs.logs)) {
                        exceptionPartB[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROPERTIES"] /* @min:%2eproperties */ ]["exceptionLog"] = logs.logs.slice(0, _expCfg.maxLogs).join("\n");
                    }
                }
                var telemetryItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$TelemetryItemCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTelemetryItem"])(exceptionPartB, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Exception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Exception"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Exception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Exception"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENVELOPE_TYPE"] /* @min:%2eenvelopeType */ ], _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), customProperties, systemProperties);
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACK"] /* @min:%2etrack */ ](telemetryItem);
            };
            /**
             * Log an exception you have caught.
             *
             * @param exception -   Object which contains exception to be sent
             * @param } customProperties   Additional data used to filter pages and metrics in the portal. Defaults to empty.
             *
             * Any property of type double will be considered a measurement, and will be treated by Application Insights as a metric.
             */ _self.trackException = function(exception, customProperties) {
                if (exception && !exception.exception && exception[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ERROR"] /* @min:%2eerror */ ]) {
                    exception.exception = exception[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ERROR"] /* @min:%2eerror */ ];
                }
                try {
                    _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SEND_EXCEPTION_INTER5"] /* @min:%2esendExceptionInternal */ ](exception, customProperties);
                } catch (e) {
                    _throwInternal(1 /* eLoggingSeverity.CRITICAL */ , 35 /* _eInternalMessageId.TrackExceptionFailed */ , "trackException failed, exception will not be collected: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                        exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                    });
                }
            };
            /**
             * @description Custom error handler for Application Insights Analytics
             * @param exception
             */ _self._onerror = function(exception) {
                var error = exception && exception[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ERROR"] /* @min:%2eerror */ ];
                var evt = exception && exception.evt;
                try {
                    if (!evt) {
                        var _window = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWindow"])();
                        if (_window) {
                            evt = _window[strEvent];
                        }
                    }
                    var url = exception && exception.url || ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])() || {}).URL;
                    // If no error source is provided assume the default window.onerror handler
                    var errorSrc = exception.errorSrc || "window.onerror@" + url + ":" + (exception[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LINE_NUMBER"] /* @min:%2elineNumber */ ] || 0) + ":" + (exception[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_COLUMN_NUMBER"] /* @min:%2ecolumnNumber */ ] || 0);
                    var properties = {
                        errorSrc: errorSrc,
                        url: url,
                        lineNumber: exception[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LINE_NUMBER"] /* @min:%2elineNumber */ ] || 0,
                        columnNumber: exception[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_COLUMN_NUMBER"] /* @min:%2ecolumnNumber */ ] || 0,
                        message: exception.message
                    };
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCrossOriginError"])(exception.message, exception.url, exception.lineNumber, exception.columnNumber, exception[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ERROR"] /* @min:%2eerror */ ])) {
                        _sendCORSException(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Exception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Exception"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__CREATE_AUTO_EXCEPTI6"] /* @min:%2eCreateAutoException */ ]("Script error: The browser's same-origin policy prevents us from getting the details of this exception. Consider using the 'crossorigin' attribute.", url, exception[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LINE_NUMBER"] /* @min:%2elineNumber */ ] || 0, exception[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_COLUMN_NUMBER"] /* @min:%2ecolumnNumber */ ] || 0, error, evt, null, errorSrc), properties);
                    } else {
                        if (!exception.errorSrc) {
                            exception.errorSrc = errorSrc;
                        }
                        _self.trackException({
                            exception: exception,
                            severityLevel: 3 /* eSeverityLevel.Error */ 
                        }, properties);
                    }
                } catch (e) {
                    var errorString = error ? error.name + ", " + error.message : "null";
                    _throwInternal(1 /* eLoggingSeverity.CRITICAL */ , 11 /* _eInternalMessageId.ExceptionWhileLoggingError */ , "_onError threw exception while logging error, error will not be collected: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                        exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e),
                        errorString: errorString
                    });
                }
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ADD_TELEMETRY_INITIA7"] /* @min:%2eaddTelemetryInitializer */ ] = function(telemetryInitializer) {
                if (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ]) {
                    // Just add to the core
                    return _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ADD_TELEMETRY_INITIA7"] /* @min:%2eaddTelemetryInitializer */ ](telemetryInitializer);
                }
                // Handle "pre-initialization" telemetry initializers (for backward compatibility)
                if (!_preInitTelemetryInitializers) {
                    _preInitTelemetryInitializers = [];
                }
                _preInitTelemetryInitializers.push(telemetryInitializer);
            };
            _self.initialize = function(config, core, extensions, pluginChain) {
                if (_self.isInitialized()) {
                    return;
                }
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(core)) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throwError"])("Error initializing");
                }
                _base.initialize(config, core, extensions, pluginChain);
                try {
                    _evtNamespace = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EventHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeEvtNamespace"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUniqueNamespace"])(_self.identifier), core.evtNamespace && core.evtNamespace());
                    if (_preInitTelemetryInitializers) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(_preInitTelemetryInitializers, function(initializer) {
                            core[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ADD_TELEMETRY_INITIA7"] /* @min:%2eaddTelemetryInitializer */ ](initializer);
                        });
                        _preInitTelemetryInitializers = null;
                    }
                    _populateDefaults(config);
                    _pageViewPerformanceManager = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$Telemetry$2f$PageViewPerformanceManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageViewPerformanceManager"](_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ]);
                    _pageViewManager = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$Telemetry$2f$PageViewManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageViewManager"](_self, _extConfig.overridePageViewDuration, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ], _pageViewPerformanceManager);
                    _pageVisitTimeManager = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$Telemetry$2f$PageVisitTimeManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageVisitTimeManager"](_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), function(pageName, pageUrl, pageVisitTime) {
                        return trackPageVisitTime(pageName, pageUrl, pageVisitTime);
                    });
                    _eventTracking = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$Timing$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timing"](_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), "trackEvent");
                    _eventTracking.action = function(name, url, duration, properties, measurements) {
                        if (!properties) {
                            properties = {};
                        }
                        if (!measurements) {
                            measurements = {};
                        }
                        properties.duration = duration[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_STRING"] /* @min:%2etoString */ ]();
                        _self.trackEvent({
                            name: name,
                            properties: properties,
                            measurements: measurements
                        });
                    };
                    // initialize page view timing
                    _pageTracking = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$Timing$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timing"](_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), "trackPageView");
                    _pageTracking.action = function(name, url, duration, properties, measurements) {
                        // duration must be a custom property in order for the collector to extract it
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(properties)) {
                            properties = {};
                        }
                        properties.duration = duration[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_STRING"] /* @min:%2etoString */ ]();
                        var pageViewItem = {
                            name: name,
                            uri: url,
                            properties: properties,
                            measurements: measurements
                        };
                        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SEND_PAGE_VIEW_INTER2"] /* @min:%2esendPageViewInternal */ ](pageViewItem, properties);
                    };
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasWindow"])()) {
                        _updateExceptionTracking();
                        _updateLocationChange();
                    }
                } catch (e) {
                    // resetting the initialized state because of failure
                    _self.setInitialized(false);
                    throw e;
                }
            };
            _self._doTeardown = function(unloadCtx, unloadState) {
                _pageViewManager && _pageViewManager.teardown(unloadCtx, unloadState);
                // Just register to remove all events associated with this namespace
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EventHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventOff"])(window, null, null, _evtNamespace);
                _initDefaults();
            };
            _self["_getDbgPlgTargets"] = function() {
                return [
                    _errorHookCnt,
                    _autoExceptionInstrumented
                ];
            };
            function _resetAjaxAttempts() {
                // Reset ajax attempts counter for the new page view
                if (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ]) {
                    var ajaxPlugin = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ].getPlugin("AjaxDependencyPlugin");
                    if (ajaxPlugin && ajaxPlugin.plugin && ajaxPlugin.plugin.resetAjaxAttempts) {
                        ajaxPlugin.plugin.resetAjaxAttempts();
                    }
                }
            }
            function _populateDefaults(config) {
                // it is used for 1DS as well, so config type should be IConfiguration only
                var identifier = _self.identifier;
                var core = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ];
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ADD_HOOK"] /* @min:%2e_addHook */ ]((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onConfigChange"])(config, function() {
                    var ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProcessTelemetryContext"])(null, config, core);
                    _extConfig = ctx.getExtCfg(identifier, defaultValues);
                    // make sure auto exception is instrumented only once and it won't be overriden by the following config changes
                    _autoExceptionInstrumented = _autoExceptionInstrumented || config[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTO_EXCEPTION_INSTR9"] /* @min:%2eautoExceptionInstrumented */ ] || _extConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTO_EXCEPTION_INSTR9"] /* @min:%2eautoExceptionInstrumented */ ];
                    _expCfg = _extConfig.expCfg;
                    _autoTrackPageVisitTime = _extConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTO_TRACK_PAGE_VISI10"] /* @min:%2eautoTrackPageVisitTime */ ];
                    if (config.storagePrefix) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$StorageHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utlSetStoragePrefix"])(config.storagePrefix);
                    }
                    _updateStorageUsage(_extConfig);
                    // _updateBrowserLinkTracking
                    _isBrowserLinkTrackingEnabled = _extConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_BROWSER_LINK_TRAC11"] /* @min:%2eisBrowserLinkTrackingEnabled */ ];
                    _addDefaultTelemetryInitializers();
                }));
            }
            /**
             * Log a page visit time
             * @param pageName - Name of page
             * @param pageVisitDuration - Duration of visit to the page in milliseconds
             */ function trackPageVisitTime(pageName, pageUrl, pageVisitTime) {
                var properties = {
                    PageName: pageName,
                    PageUrl: pageUrl
                };
                _self.trackMetric({
                    name: "PageVisitTime",
                    average: pageVisitTime,
                    max: pageVisitTime,
                    min: pageVisitTime,
                    sampleCount: 1
                }, properties);
            }
            function _addDefaultTelemetryInitializers() {
                if (!_browserLinkInitializerAdded && _isBrowserLinkTrackingEnabled) {
                    var browserLinkPaths_1 = [
                        "/browserLinkSignalR/",
                        "/__browserLink/"
                    ];
                    var dropBrowserLinkRequests = function(envelope) {
                        if (_isBrowserLinkTrackingEnabled && envelope.baseType === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$RemoteDependencyData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RemoteDependencyData"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ]) {
                            var remoteData = envelope.baseData;
                            if (remoteData) {
                                for(var i = 0; i < browserLinkPaths_1[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; i++){
                                    if (remoteData.target && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strIndexOf"])(remoteData.target, browserLinkPaths_1[i]) >= 0) {
                                        return false;
                                    }
                                }
                            }
                        }
                        return true;
                    };
                    _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ADD_HOOK"] /* @min:%2e_addHook */ ](_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ADD_TELEMETRY_INITIA7"] /* @min:%2eaddTelemetryInitializer */ ](dropBrowserLinkRequests));
                    _browserLinkInitializerAdded = true;
                }
            }
            function _sendCORSException(exception, properties) {
                var telemetryItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$TelemetryItemCreator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTelemetryItem"])(exception, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Exception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Exception"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA_TYPE"] /* @min:%2edataType */ ], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Exception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Exception"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENVELOPE_TYPE"] /* @min:%2eenvelopeType */ ], _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), properties);
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACK"] /* @min:%2etrack */ ](telemetryItem);
            }
            function _updateExceptionTracking() {
                var _window = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWindow"])();
                var locn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLocation"])(true);
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ADD_HOOK"] /* @min:%2e_addHook */ ]((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onConfigChange"])(_extConfig, function() {
                    _disableExceptionTracking = _extConfig.disableExceptionTracking;
                    if (!_disableExceptionTracking && !_autoExceptionInstrumented && !_extConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTO_EXCEPTION_INSTR9"] /* @min:%2eautoExceptionInstrumented */ ]) {
                        // We want to enable exception auto collection and it has not been done so yet
                        _addHook((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InstrumentHooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstrumentEvent"])(_window, "onerror", {
                            ns: _evtNamespace,
                            rsp: function(callDetails, message, url, lineNumber, columnNumber, error) {
                                if (!_disableExceptionTracking && callDetails.rslt !== true) {
                                    _self._onerror(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Exception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Exception"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__CREATE_AUTO_EXCEPTI6"] /* @min:%2eCreateAutoException */ ](message, url, lineNumber, columnNumber, error, callDetails.evt));
                                }
                            }
                        }, false));
                        _errorHookCnt++;
                        _autoExceptionInstrumented = true;
                    }
                }));
                _addUnhandledPromiseRejectionTracking(_window, locn);
            }
            function _updateLocationChange() {
                var win = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWindow"])();
                var locn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLocation"])(true);
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ADD_HOOK"] /* @min:%2e_addHook */ ]((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onConfigChange"])(_extConfig, function() {
                    _enableAutoRouteTracking = _extConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLE_AUTO_ROUTE_TR12"] /* @min:%2eenableAutoRouteTracking */ ] === true;
                    /**
                     * Create a custom "locationchange" event which is triggered each time the history object is changed
                     */ if (win && _enableAutoRouteTracking && !_historyListenerAdded && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasHistory"])()) {
                        var _history = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHistory"])();
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(_history.pushState) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(_history.replaceState) && typeof Event !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__strShimUndefined__as__strUndefined$3e$__["strUndefined"]) {
                            _addHistoryListener(win, _history, locn);
                        }
                    }
                }));
            }
            function _getDistributedTraceCtx() {
                var distributedTraceCtx = null;
                if (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ] && _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ].getTraceCtx) {
                    distributedTraceCtx = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ].getTraceCtx(false);
                }
                if (!distributedTraceCtx) {
                    // Fallback when using an older Core and PropertiesPlugin
                    var properties = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ].getPlugin(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$applicationinsights$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PropertiesPluginIdentifier"]);
                    if (properties) {
                        var context = properties.plugin.context;
                        if (context) {
                            distributedTraceCtx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDistributedTraceContextFromTrace"])(context.telemetryTrace);
                        }
                    }
                }
                return distributedTraceCtx;
            }
            /**
             * Create a custom "locationchange" event which is triggered each time the history object is changed
             */ function _addHistoryListener(win, history, locn) {
                if (_historyListenerAdded) {
                    return;
                }
                // Name Prefix is only referenced during the initial initialization and cannot be changed afterwards
                var namePrefix = _extConfig.namePrefix || "";
                function _popstateHandler() {
                    if (_enableAutoRouteTracking) {
                        _dispatchEvent(win, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$DomHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDomEvent"])(namePrefix + "locationchange"));
                    }
                }
                function _locationChangeHandler() {
                    // We always track the changes (if the handler is installed) to handle the feature being disabled between location changes
                    if (_currUri) {
                        _prevUri = _currUri;
                        _currUri = locn && locn[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HREF"] /* @min:%2ehref */ ] || "";
                    } else {
                        _currUri = locn && locn[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HREF"] /* @min:%2ehref */ ] || "";
                    }
                    if (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ] && _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONFIG"] /* @min:%2econfig */ ]) {
                        _currUri = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fieldRedaction"])(_currUri, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONFIG"] /* @min:%2econfig */ ]);
                    }
                    if (_enableAutoRouteTracking) {
                        var distributedTraceCtx = _getDistributedTraceCtx();
                        if (distributedTraceCtx) {
                            distributedTraceCtx.setTraceId((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CoreUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateW3CId"])());
                            var traceLocationName = "_unknown_";
                            if (locn && locn.pathname) {
                                traceLocationName = locn.pathname + (locn.hash || "");
                            }
                            // This populates the ai.operation.name which has a maximum size of 1024 so we need to sanitize it
                            distributedTraceCtx.setName((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Common$2f$DataSanitizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dataSanitizeString"])(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), traceLocationName));
                        }
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["scheduleTimeout"])((function(uri) {
                            // todo: override start time so that it is not affected by autoRoutePVDelay
                            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACK_PAGE_VIEW"] /* @min:%2etrackPageView */ ]({
                                refUri: uri,
                                properties: {
                                    duration: 0
                                }
                            }); // SPA route change loading durations are undefined, so send 0
                        }).bind(_self, _prevUri), _self.autoRoutePVDelay);
                    }
                }
                _addHook((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InstrumentHooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstrumentEvent"])(history, "pushState", {
                    ns: _evtNamespace,
                    rsp: function() {
                        if (_enableAutoRouteTracking) {
                            _dispatchEvent(win, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$DomHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDomEvent"])(namePrefix + "pushState"));
                            _dispatchEvent(win, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$DomHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDomEvent"])(namePrefix + "locationchange"));
                        }
                    }
                }, true));
                _addHook((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InstrumentHooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstrumentEvent"])(history, "replaceState", {
                    ns: _evtNamespace,
                    rsp: function() {
                        if (_enableAutoRouteTracking) {
                            _dispatchEvent(win, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$DomHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDomEvent"])(namePrefix + "replaceState"));
                            _dispatchEvent(win, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$DomHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDomEvent"])(namePrefix + "locationchange"));
                        }
                    }
                }, true));
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EventHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventOn"])(win, namePrefix + "popstate", _popstateHandler, _evtNamespace);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EventHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventOn"])(win, namePrefix + "locationchange", _locationChangeHandler, _evtNamespace);
                _historyListenerAdded = true;
            }
            function _addUnhandledPromiseRejectionTracking(_window, _location) {
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__ADD_HOOK"] /* @min:%2e_addHook */ ]((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onConfigChange"])(_extConfig, function() {
                    _enableUnhandledPromiseRejectionTracking = _extConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLE_UNHANDLED_PRO13"] /* @min:%2eenableUnhandledPromiseRejectionTracking */ ] === true;
                    _autoExceptionInstrumented = _autoExceptionInstrumented || _extConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTO_UNHANDLED_PROMI14"] /* @min:%2eautoUnhandledPromiseInstrumented */ ];
                    if (_enableUnhandledPromiseRejectionTracking && !_autoUnhandledPromiseInstrumented) {
                        // We want to enable exception auto collection and it has not been done so yet
                        _addHook((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InstrumentHooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstrumentEvent"])(_window, "onunhandledrejection", {
                            ns: _evtNamespace,
                            rsp: function(callDetails, error) {
                                if (_enableUnhandledPromiseRejectionTracking && callDetails.rslt !== true) {
                                    _self._onerror(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$common$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$common$2f$dist$2d$es5$2f$Telemetry$2f$Exception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Exception"][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__CREATE_AUTO_EXCEPTI6"] /* @min:%2eCreateAutoException */ ](_getReason(error), _location ? _location[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HREF"] /* @min:%2ehref */ ] : "", 0, 0, error, callDetails.evt));
                                }
                            }
                        }, false));
                        _errorHookCnt++;
                        _extConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_AUTO_UNHANDLED_PROMI14"] /* @min:%2eautoUnhandledPromiseInstrumented */ ] = _autoUnhandledPromiseInstrumented = true;
                    }
                }));
            }
            /**
             * This method will throw exceptions in debug mode or attempt to log the error as a console warning.
             * @param severity - The severity of the log message
             * @param msgId - The log message.
             */ function _throwInternal(severity, msgId, msg, properties, isUserAct) {
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ]().throwInternal(severity, msgId, msg, properties, isUserAct);
            }
            function _initDefaults() {
                _eventTracking = null;
                _pageTracking = null;
                _pageViewManager = null;
                _pageViewPerformanceManager = null;
                _pageVisitTimeManager = null;
                _preInitTelemetryInitializers = null;
                _isBrowserLinkTrackingEnabled = false;
                _browserLinkInitializerAdded = false;
                _enableAutoRouteTracking = false;
                _historyListenerAdded = false;
                _disableExceptionTracking = false;
                _autoExceptionInstrumented = false;
                _enableUnhandledPromiseRejectionTracking = false;
                _autoUnhandledPromiseInstrumented = false;
                _autoTrackPageVisitTime = false;
                // Reset ajax attempts counter
                _resetAjaxAttempts();
                // array with max length of 2 that store current url and previous url for SPA page route change trackPageview use.
                var location = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLocation"])(true);
                _prevUri = location && location[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HREF"] /* @min:%2ehref */ ] || "";
                if (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ] && _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONFIG"] /* @min:%2econfig */ ]) {
                    _prevUri = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fieldRedaction"])(_prevUri, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CORE"] /* @min:%2ecore */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$analytics$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$analytics$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CONFIG"] /* @min:%2econfig */ ]);
                }
                _currUri = null;
                _evtNamespace = null;
                _extConfig = null;
                _errorHookCnt = 0;
                // Define _self.config
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "config", {
                    g: function() {
                        return _extConfig;
                    }
                });
            }
            // For backward compatibility
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "_pageViewManager", {
                g: function() {
                    return _pageViewManager;
                }
            });
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "_pageViewPerformanceManager", {
                g: function() {
                    return _pageViewPerformanceManager;
                }
            });
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "_pageVisitTimeManager", {
                g: function() {
                    return _pageVisitTimeManager;
                }
            });
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "_evtNamespace", {
                g: function() {
                    return "." + _evtNamespace;
                }
            });
        });
        return _this;
    }
    // Removed Stub for AnalyticsPlugin.prototype.getCookieMgr.
    // Removed Stub for AnalyticsPlugin.prototype.processTelemetry.
    // Removed Stub for AnalyticsPlugin.prototype.trackEvent.
    // Removed Stub for AnalyticsPlugin.prototype.startTrackEvent.
    // Removed Stub for AnalyticsPlugin.prototype.stopTrackEvent.
    // Removed Stub for AnalyticsPlugin.prototype.trackTrace.
    // Removed Stub for AnalyticsPlugin.prototype.trackMetric.
    // Removed Stub for AnalyticsPlugin.prototype.trackPageView.
    // Removed Stub for AnalyticsPlugin.prototype.sendPageViewInternal.
    // Removed Stub for AnalyticsPlugin.prototype.sendPageViewPerformanceInternal.
    // Removed Stub for AnalyticsPlugin.prototype.trackPageViewPerformance.
    // Removed Stub for AnalyticsPlugin.prototype.startTrackPage.
    // Removed Stub for AnalyticsPlugin.prototype.stopTrackPage.
    // Removed Stub for AnalyticsPlugin.prototype.sendExceptionInternal.
    // Removed Stub for AnalyticsPlugin.prototype.trackException.
    // Removed Stub for AnalyticsPlugin.prototype._onerror.
    // Removed Stub for AnalyticsPlugin.prototype.addTelemetryInitializer.
    // Removed Stub for AnalyticsPlugin.prototype.initialize.
    AnalyticsPlugin.Version = '3.3.10'; // Not currently used anywhere
    return AnalyticsPlugin;
}(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$BaseTelemetryPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseTelemetryPlugin"]);
;
 //# sourceMappingURL=AnalyticsPlugin.js.map
}),
]);

//# sourceMappingURL=1ef0a_%40microsoft_applicationinsights-analytics-js_dist-es5_461db7d5._.js.map