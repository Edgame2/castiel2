module.exports=[88920,(a,b,c)=>{}];

//# sourceMappingURL=c2a1c_frontend__next-internal_server_app_%28protected%29_users_page_actions_92f03d4b.js.map