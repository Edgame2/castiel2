'use client'

import { createContext, useContext, useEffect, useState } from 'react'
import { User } from '@/types/auth'

interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  logout: () => Promise<void>
  refreshUser: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    let mounted = true

    async function fetchUser() {
      console.log('AuthContext: Fetching user from /api/auth/me')
      try {
        const response = await fetch('/api/auth/me')
        console.log('AuthContext: Response status:', response.status)
        if (response.ok && mounted) {
          const userData = await response.json()
          console.log('AuthContext: User authenticated:', userData.email)
          // Normalize user data - ensure name is set
          const normalizedUser = {
            ...userData,
            name: userData.name || userData.displayName || `${userData.firstName || ''} ${userData.lastName || ''}`.trim() || userData.email,
            role: userData.role || userData.roles?.[0] || 'user',
          }
          setUser(normalizedUser)
        } else if (mounted) {
          console.log('AuthContext: User not authenticated')
          setUser(null)
        }
      } catch (error) {
        console.error('AuthContext: Failed to fetch user:', error)
        if (mounted) {
          setUser(null)
        }
      } finally {
        if (mounted) {
          console.log('AuthContext: Setting isLoading to false')
          setIsLoading(false)
        }
      }
    }

    fetchUser()

    return () => {
      mounted = false
    }
  }, [])

  const refreshUser = async () => {
    try {
      const response = await fetch('/api/auth/me')
      if (response.ok) {
        const userData = await response.json()
        // Normalize user data - ensure name is set
        const normalizedUser = {
          ...userData,
          name: userData.name || userData.displayName || `${userData.firstName || ''} ${userData.lastName || ''}`.trim() || userData.email,
          role: userData.role || userData.roles?.[0] || 'user',
        }
        setUser(normalizedUser)
      } else {
        setUser(null)
      }
    } catch (error) {
      console.error('Failed to fetch user:', error)
      setUser(null)
    }
  }

  const logout = async () => {
    try {
      console.log('Logout: Starting logout process...')
      const response = await fetch('/api/auth/logout', { 
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
      })
      
      if (!response.ok) {
        console.error('Logout: API returned error:', response.status, response.statusText)
      } else {
        console.log('Logout: API call successful')
      }
      
      setUser(null)
      
      // Clear localStorage tokens (legacy support)
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
      
      console.log('Logout: User state cleared, redirecting...')
      
      // Force a hard redirect to login page
      window.location.href = '/login'
    } catch (error) {
      console.error('Logout: Exception occurred:', error)
      // On error, still try to clear and redirect
      setUser(null)
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
      window.location.href = '/login'
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        logout,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider')
  }
  return context
}
