globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/7689b1910546a430.js",
    "static/chunks/597c9d2d3ce1232c.js",
    "static/chunks/e1ccea7070249266.js",
    "static/chunks/ceb8d3dbfbb004cc.js",
    "static/chunks/874680ff50bdea73.js",
    "static/chunks/turbopack-7c623f208ab8488b.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];