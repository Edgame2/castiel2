/**
 * Azure Service Bus Service
 *
 * Handles messaging to Azure Service Bus for distributed processing
 * Used for embedding jobs, webhooks, and other asynchronous tasks
 */

import { ServiceBusClient } from '@azure/service-bus';
import type { ServiceBusSender } from '@azure/service-bus';
import { IMonitoringProvider } from '@castiel/monitoring';
import { config } from '../config/env.js';
import type { EmbeddingJobMessage } from '../types/embedding-job.types.js';
import { shouldIgnoreShardType } from '../types/embedding-job.types.js';

export class AzureServiceBusService {
  private client: ServiceBusClient;
  private senders: Map<string, ServiceBusSender> = new Map();
  private monitoring: IMonitoringProvider;

  constructor(monitoring: IMonitoringProvider) {
    this.monitoring = monitoring;

    // Initialize Service Bus client
    const connectionString = config.serviceBus?.connectionString;
    if (!connectionString) {
      throw new Error('AZURE_SERVICE_BUS_CONNECTION_STRING is required');
    }

    this.client = new ServiceBusClient(connectionString);
  }

  /**
   * Get or create a sender for a queue
   */
  private getSender(queueName: string): ServiceBusSender {
    if (!this.senders.has(queueName)) {
      const sender = this.client.createSender(queueName);
      this.senders.set(queueName, sender);
    }
    return this.senders.get(queueName)!;
  }

  /**
   * Check if a shard type should be ignored from embedding
   */
  isShardTypeIgnored(shardTypeId: string): boolean {
    return shouldIgnoreShardType(shardTypeId, config.embeddingJob.ignoredShardTypes);
  }

  /**
   * Send an embedding job message to Service Bus
   * Returns false if the shard type is ignored
   */
  async sendEmbeddingJob(
    jobMessage: EmbeddingJobMessage,
    options?: { delayInSeconds?: number }
  ): Promise<boolean> {
    const startTime = Date.now();
    const queueName = config.serviceBus?.embeddingQueueName || 'embedding-jobs';

    // Check if this shard type should be ignored
    if (this.isShardTypeIgnored(jobMessage.shardTypeId)) {
      this.monitoring.trackEvent('embedding_job.ignored', {
        shardId: jobMessage.shardId,
        tenantId: jobMessage.tenantId,
        shardTypeId: jobMessage.shardTypeId,
        reason: 'shard_type_in_ignore_list',
      });
      return false;
    }

    try {
      const sender = this.getSender(queueName);

      const sbMessage: any = {
        body: jobMessage,
        contentType: 'application/json',
        // Use dedupeKey as message ID for deduplication
        messageId: jobMessage.dedupeKey,
        // Session ID for ordered processing per tenant
        sessionId: jobMessage.tenantId,
        // Custom properties for filtering
        userProperties: {
          shardId: jobMessage.shardId,
          tenantId: jobMessage.tenantId,
          shardTypeId: jobMessage.shardTypeId,
          revisionNumber: jobMessage.revisionNumber.toString(),
        },
      };

      // Set scheduled enqueue time if delay is specified
      if (options?.delayInSeconds && options.delayInSeconds > 0) {
        const scheduledTime = new Date(Date.now() + options.delayInSeconds * 1000);
        sbMessage.scheduledEnqueueTimeUtc = scheduledTime;
      }

      await sender.sendMessages(sbMessage);

      const duration = Date.now() - startTime;
      this.monitoring.trackDependency(
        'azure-service-bus.send',
        'ServiceBus',
        queueName,
        duration,
        true
      );

      this.monitoring.trackEvent('embedding_job.enqueued', {
        shardId: jobMessage.shardId,
        tenantId: jobMessage.tenantId,
        shardTypeId: jobMessage.shardTypeId,
        dedupeKey: jobMessage.dedupeKey,
      });

      return true;
    } catch (error) {
      const duration = Date.now() - startTime;
      this.monitoring.trackDependency(
        'azure-service-bus.send',
        'ServiceBus',
        queueName,
        duration,
        false,
        error instanceof Error ? error.message : 'Unknown error'
      );

      this.monitoring.trackException(error as Error, {
        context: 'AzureServiceBusService.sendEmbeddingJob',
        shardId: jobMessage.shardId,
      });

      throw error;
    }
  }

  /**
   * Send multiple embedding job messages in batch
   * Returns count of messages actually sent (excluding ignored types)
   */
  async sendEmbeddingJobBatch(
    jobMessages: EmbeddingJobMessage[],
    options?: { delayInSeconds?: number }
  ): Promise<number> {
    const queueName = config.serviceBus?.embeddingQueueName || 'embedding-jobs';

    try {
      const sender = this.getSender(queueName);
      const startTime = Date.now();

      // Filter out ignored shard types
      const messagesToSend = jobMessages.filter(job => {
        const isIgnored = this.isShardTypeIgnored(job.shardTypeId);
        if (isIgnored) {
          this.monitoring.trackEvent('embedding_job.ignored', {
            shardId: job.shardId,
            tenantId: job.tenantId,
            shardTypeId: job.shardTypeId,
            reason: 'shard_type_in_ignore_list',
          });
        }
        return !isIgnored;
      });

      // If all messages were filtered out, return early
      if (messagesToSend.length === 0) {
        this.monitoring.trackEvent('embedding_jobs.batch_all_ignored', {
          totalCount: jobMessages.length,
          ignoredCount: jobMessages.length,
        });
        return 0;
      }

      const sbMessages = messagesToSend.map((job) => ({
        body: job,
        contentType: 'application/json',
        messageId: job.dedupeKey,
        sessionId: job.tenantId,
        userProperties: {
          shardId: job.shardId,
          tenantId: job.tenantId,
          shardTypeId: job.shardTypeId,
          revisionNumber: job.revisionNumber.toString(),
        },
        scheduledEnqueueTimeUtc: options?.delayInSeconds
          ? new Date(Date.now() + options.delayInSeconds * 1000)
          : undefined,
      }));

      await sender.sendMessages(sbMessages);

      const duration = Date.now() - startTime;
      this.monitoring.trackDependency(
        'azure-service-bus.send-batch',
        'ServiceBus',
        queueName,
        duration,
        true
      );

      this.monitoring.trackEvent('embedding_jobs.enqueued_batch', {
        sentCount: messagesToSend.length,
        totalCount: jobMessages.length,
        ignoredCount: jobMessages.length - messagesToSend.length,
      });

      return messagesToSend.length;
    } catch (error) {
      this.monitoring.trackException(error as Error, {
        context: 'AzureServiceBusService.sendEmbeddingJobBatch',
        count: jobMessages.length,
      });

      throw error;
    }
  }

  /**
   * Get the list of ignored shard types
   */
  getIgnoredShardTypes(): string[] {
    return [...config.embeddingJob.ignoredShardTypes];
  }

  /**
   * Close all senders and the client
   */
  async close(): Promise<void> {
    try {
      // Close all senders
      for (const sender of this.senders.values()) {
        await sender.close();
      }
      this.senders.clear();

      // Close client
      await this.client.close();
    } catch (error) {
      this.monitoring.trackException(error as Error, {
        context: 'AzureServiceBusService.close',
      });
    }
  }
}
