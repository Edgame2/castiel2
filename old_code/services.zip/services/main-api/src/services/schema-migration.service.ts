/**
 * Schema Migration Service
 * 
 * Handles schema evolution and migration of shards
 */

import type { Redis } from 'ioredis';
import type { FastifyInstance } from 'fastify';
import crypto from 'crypto';
import {
  SchemaMigration,
  MigrationStrategy,
  MigrationStatus,
  MigrationResult,
  SchemaVersionInfo,
  CreateMigrationInput,
  MigrationExecutionOptions,
  FieldTransformation,
  TransformationType,
  ShardMigrationState,
} from '../types/schema-migration.types.js';
import type { Shard, UpdateShardInput } from '../types/shard.types.js';
import type { ShardRepository } from '../repositories/shard.repository.js';

// Redis keys
const MIGRATION_KEY_PREFIX = 'schema_migrations:';
const VERSION_KEY_PREFIX = 'schema_versions:';
const MIGRATION_STATE_KEY = 'shard_migration_state:';

/**
 * Built-in transformers for common operations
 */
const BUILT_IN_TRANSFORMERS: Record<string, (value: any, config?: any) => any> = {
  toString: (value) => String(value),
  toNumber: (value) => Number(value) || 0,
  toBoolean: (value) => Boolean(value),
  toArray: (value) => Array.isArray(value) ? value : [value],
  toLowerCase: (value) => String(value).toLowerCase(),
  toUpperCase: (value) => String(value).toUpperCase(),
  trim: (value) => String(value).trim(),
  parseJSON: (value) => {
    try {
      return JSON.parse(value);
    } catch {
      return value;
    }
  },
  stringifyJSON: (value) => JSON.stringify(value),
  extractDate: (value) => new Date(value).toISOString().split('T')[0],
  splitComma: (value) => String(value).split(',').map((s) => s.trim()),
  joinComma: (value) => Array.isArray(value) ? value.join(', ') : value,
  defaultIfNull: (value, config) => value ?? config?.default,
  concatenate: (value, config) => {
    const parts = config?.fields?.map((f: string) => value?.[f] || '') || [];
    return parts.join(config?.separator || ' ');
  },
};

/**
 * Schema Migration Service
 */
export class SchemaMigrationService {
  private customTransformers: Map<string, (value: any, config?: any) => any> = new Map();

  constructor(
    private readonly redis: Redis,
    private readonly shardRepository: ShardRepository,
    private readonly server?: FastifyInstance
  ) {}

  // =====================================
  // MIGRATION MANAGEMENT
  // =====================================

  /**
   * Create a new migration
   */
  async createMigration(
    tenantId: string,
    userId: string,
    input: CreateMigrationInput
  ): Promise<SchemaMigration> {
    const id = crypto.randomUUID();

    const migration: SchemaMigration = {
      id,
      shardTypeId: input.shardTypeId,
      fromVersion: input.fromVersion,
      toVersion: input.toVersion,
      description: input.description,
      transformations: input.transformations,
      strategy: input.strategy || MigrationStrategy.LAZY,
      batchSize: input.batchSize || 100,
      reversible: input.reversible ?? true,
      rollbackTransformations: input.rollbackTransformations,
      createdAt: new Date(),
      createdBy: userId,
      status: MigrationStatus.PENDING,
    };

    // Store migration
    const key = `${MIGRATION_KEY_PREFIX}${tenantId}:${input.shardTypeId}:${id}`;
    await this.redis.set(key, JSON.stringify(migration));

    // Add to migration list
    await this.redis.sadd(
      `${MIGRATION_KEY_PREFIX}${tenantId}:${input.shardTypeId}:list`,
      id
    );

    this.server?.log.info({ migrationId: id, shardTypeId: input.shardTypeId }, 'Migration created');

    return migration;
  }

  /**
   * Get a migration by ID
   */
  async getMigration(tenantId: string, shardTypeId: string, migrationId: string): Promise<SchemaMigration | null> {
    const key = `${MIGRATION_KEY_PREFIX}${tenantId}:${shardTypeId}:${migrationId}`;
    const data = await this.redis.get(key);
    return data ? JSON.parse(data) : null;
  }

  /**
   * List migrations for a shard type
   */
  async listMigrations(tenantId: string, shardTypeId: string): Promise<SchemaMigration[]> {
    const ids = await this.redis.smembers(`${MIGRATION_KEY_PREFIX}${tenantId}:${shardTypeId}:list`);
    const migrations: SchemaMigration[] = [];

    for (const id of ids) {
      const migration = await this.getMigration(tenantId, shardTypeId, id);
      if (migration) {
        migrations.push(migration);
      }
    }

    // Sort by version
    return migrations.sort((a, b) => a.fromVersion - b.fromVersion);
  }

  /**
   * Get migration path from one version to another
   */
  async getMigrationPath(
    tenantId: string,
    shardTypeId: string,
    fromVersion: number,
    toVersion: number
  ): Promise<SchemaMigration[]> {
    const allMigrations = await this.listMigrations(tenantId, shardTypeId);
    const path: SchemaMigration[] = [];

    let currentVersion = fromVersion;
    while (currentVersion < toVersion) {
      const nextMigration = allMigrations.find(
        (m) => m.fromVersion === currentVersion && m.toVersion > currentVersion
      );

      if (!nextMigration) {
        throw new Error(`No migration path from version ${currentVersion} to ${toVersion}`);
      }

      path.push(nextMigration);
      currentVersion = nextMigration.toVersion;
    }

    return path;
  }

  // =====================================
  // MIGRATION EXECUTION
  // =====================================

  /**
   * Execute a migration (eager strategy)
   */
  async executeMigration(
    tenantId: string,
    migrationId: string,
    shardTypeId: string,
    options: MigrationExecutionOptions = {}
  ): Promise<MigrationResult> {
    const migration = await this.getMigration(tenantId, shardTypeId, migrationId);
    if (!migration) {
      throw new Error('Migration not found');
    }

    const result: MigrationResult = {
      migrationId,
      success: true,
      shardsProcessed: 0,
      shardsSucceeded: 0,
      shardsFailed: 0,
      errors: [],
      startedAt: new Date(),
    };

    // Update status
    migration.status = MigrationStatus.IN_PROGRESS;
    await this.updateMigration(tenantId, shardTypeId, migration);

    try {
      const batchSize = options.batchSize || migration.batchSize || 100;
      let continuationToken: string | undefined;

      do {
        // Fetch shards at the source version
        const { shards, continuationToken: nextToken } = await this.shardRepository.list({
          filter: {
            tenantId,
            shardTypeId,
          },
          limit: batchSize,
          continuationToken,
        });

        // Filter by version
        const shardsToMigrate = shards.filter(
          (s) => (s.schemaVersion || 1) === migration.fromVersion
        );

        for (const shard of shardsToMigrate) {
          result.shardsProcessed++;

          try {
            if (!options.dryRun) {
              await this.migrateShard(shard, migration);
            }
            result.shardsSucceeded++;
          } catch (error: any) {
            result.shardsFailed++;
            result.errors.push({
              shardId: shard.id,
              error: error.message,
            });

            if (!options.continueOnError) {
              throw error;
            }
          }
        }

        continuationToken = nextToken;
      } while (continuationToken);

      // Update migration status
      migration.status = MigrationStatus.COMPLETED;
      migration.executedAt = new Date();
      await this.updateMigration(tenantId, shardTypeId, migration);

      result.success = result.shardsFailed === 0;
      result.completedAt = new Date();
      result.duration = result.completedAt.getTime() - result.startedAt.getTime();

      this.server?.log.info({ result }, 'Migration completed');

    } catch (error: any) {
      migration.status = MigrationStatus.FAILED;
      await this.updateMigration(tenantId, shardTypeId, migration);

      result.success = false;
      result.completedAt = new Date();
      result.duration = result.completedAt.getTime() - result.startedAt.getTime();

      this.server?.log.error({ error, result }, 'Migration failed');
    }

    return result;
  }

  /**
   * Migrate a single shard (lazy strategy)
   */
  async migrateShard(shard: Shard, migration: SchemaMigration): Promise<Shard> {
    // Apply transformations
    const migratedData = this.applyTransformations(
      shard.structuredData,
      migration.transformations
    );

    // Update shard
    const updateInput: UpdateShardInput = {
      structuredData: migratedData,
    };

    const updated = await this.shardRepository.update(shard.id, shard.tenantId, updateInput);
    if (!updated) {
      throw new Error('Failed to update shard');
    }

    // Update schema version
    const versionedShard = {
      ...updated,
      schemaVersion: migration.toVersion,
    };

    await this.shardRepository.update(shard.id, shard.tenantId, {
      structuredData: versionedShard.structuredData,
    });

    // Track migration state
    await this.updateShardMigrationState(shard, migration);

    return versionedShard;
  }

  /**
   * Migrate shard on read (lazy migration)
   */
  async migrateOnRead(shard: Shard, targetVersion: number): Promise<Shard> {
    const currentVersion = shard.schemaVersion || 1;
    
    if (currentVersion >= targetVersion) {
      return shard;
    }

    try {
      const migrationPath = await this.getMigrationPath(
        shard.tenantId,
        shard.shardTypeId,
        currentVersion,
        targetVersion
      );

      let migratedShard = shard;
      for (const migration of migrationPath) {
        if (migration.strategy === MigrationStrategy.MANUAL) {
          // Don't auto-migrate manual migrations
          break;
        }
        migratedShard = await this.migrateShard(migratedShard, migration);
      }

      return migratedShard;
    } catch (error) {
      this.server?.log.warn({ shardId: shard.id, error }, 'Failed to auto-migrate shard');
      return shard; // Return original on failure
    }
  }

  // =====================================
  // TRANSFORMATION LOGIC
  // =====================================

  /**
   * Apply transformations to structured data
   */
  applyTransformations(
    data: Record<string, any>,
    transformations: FieldTransformation[]
  ): Record<string, any> {
    let result = { ...data };

    for (const transform of transformations) {
      result = this.applyTransformation(result, transform);
    }

    return result;
  }

  /**
   * Apply a single transformation
   */
  private applyTransformation(
    data: Record<string, any>,
    transform: FieldTransformation
  ): Record<string, any> {
    const result = { ...data };

    switch (transform.type) {
      case TransformationType.RENAME: {
        if (transform.sourcePath && transform.targetPath) {
          const value = this.getValueByPath(result, transform.sourcePath);
          this.setValueByPath(result, transform.targetPath, value);
          this.deleteValueByPath(result, transform.sourcePath);
        }
        break;
      }

      case TransformationType.DELETE: {
        if (transform.sourcePath) {
          this.deleteValueByPath(result, transform.sourcePath);
        }
        break;
      }

      case TransformationType.ADD: {
        if (transform.targetPath) {
          const value = transform.defaultValue;
          this.setValueByPath(result, transform.targetPath, value);
        }
        break;
      }

      case TransformationType.CHANGE_TYPE: {
        if (transform.sourcePath && transform.transformer) {
          const value = this.getValueByPath(result, transform.sourcePath);
          const transformer = this.getTransformer(transform.transformer);
          const transformedValue = transformer(value, transform.config);
          this.setValueByPath(result, transform.sourcePath, transformedValue);
        }
        break;
      }

      case TransformationType.MOVE: {
        if (transform.sourcePath && transform.targetPath) {
          const value = this.getValueByPath(result, transform.sourcePath);
          this.setValueByPath(result, transform.targetPath, value);
          this.deleteValueByPath(result, transform.sourcePath);
        }
        break;
      }

      case TransformationType.MERGE: {
        if (transform.targetPath && transform.config?.fields) {
          const values = transform.config.fields.map((f: string) => 
            this.getValueByPath(result, f)
          );
          const separator = transform.config.separator || ' ';
          this.setValueByPath(result, transform.targetPath, values.join(separator));
          
          // Optionally delete source fields
          if (transform.config.deleteSource) {
            for (const field of transform.config.fields) {
              this.deleteValueByPath(result, field);
            }
          }
        }
        break;
      }

      case TransformationType.SPLIT: {
        if (transform.sourcePath && transform.config?.targets) {
          const value = this.getValueByPath(result, transform.sourcePath);
          const separator = transform.config.separator || ' ';
          const parts = String(value).split(separator);
          
          for (let i = 0; i < transform.config.targets.length; i++) {
            this.setValueByPath(result, transform.config.targets[i], parts[i] || '');
          }
          
          if (transform.config.deleteSource) {
            this.deleteValueByPath(result, transform.sourcePath);
          }
        }
        break;
      }

      case TransformationType.COMPUTE: {
        if (transform.targetPath && transform.transformer) {
          const transformer = this.getTransformer(transform.transformer);
          const value = transformer(result, transform.config);
          this.setValueByPath(result, transform.targetPath, value);
        }
        break;
      }
    }

    return result;
  }

  /**
   * Get transformer function
   */
  private getTransformer(name: string): (value: any, config?: any) => any {
    // Check custom transformers first
    const custom = this.customTransformers.get(name);
    if (custom) return custom;

    // Check built-in transformers
    const builtin = BUILT_IN_TRANSFORMERS[name];
    if (builtin) return builtin;

    throw new Error(`Unknown transformer: ${name}`);
  }

  /**
   * Register a custom transformer
   */
  registerTransformer(name: string, fn: (value: any, config?: any) => any): void {
    this.customTransformers.set(name, fn);
  }

  // =====================================
  // PATH UTILITIES
  // =====================================

  private getValueByPath(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => current?.[key], obj);
  }

  private setValueByPath(obj: any, path: string, value: any): void {
    const keys = path.split('.');
    const lastKey = keys.pop()!;
    const target = keys.reduce((current, key) => {
      if (current[key] === undefined) {
        current[key] = {};
      }
      return current[key];
    }, obj);
    target[lastKey] = value;
  }

  private deleteValueByPath(obj: any, path: string): void {
    const keys = path.split('.');
    const lastKey = keys.pop()!;
    const target = keys.reduce((current, key) => current?.[key], obj);
    if (target) {
      delete target[lastKey];
    }
  }

  // =====================================
  // VERSION TRACKING
  // =====================================

  /**
   * Get schema version info for a shard type
   */
  async getVersionInfo(tenantId: string, shardTypeId: string): Promise<SchemaVersionInfo> {
    const migrations = await this.listMigrations(tenantId, shardTypeId);
    
    // Get version distribution
    const shardsPerVersion: Record<number, number> = {};
    let continuationToken: string | undefined;

    do {
      const { shards, continuationToken: nextToken } = await this.shardRepository.list({
        filter: { tenantId, shardTypeId },
        limit: 100,
        continuationToken,
      });

      for (const shard of shards) {
        const version = shard.schemaVersion || 1;
        shardsPerVersion[version] = (shardsPerVersion[version] || 0) + 1;
      }

      continuationToken = nextToken;
    } while (continuationToken);

    // Calculate versions
    const versions = Object.keys(shardsPerVersion).map(Number);
    const currentVersion = versions.length > 0 ? Math.min(...versions) : 1;
    const latestVersion = migrations.length > 0 
      ? Math.max(...migrations.map((m) => m.toVersion))
      : currentVersion;

    return {
      shardTypeId,
      currentVersion,
      latestVersion,
      migrations: migrations.map((m) => ({
        fromVersion: m.fromVersion,
        toVersion: m.toVersion,
        status: m.status,
        description: m.description,
      })),
      shardsPerVersion,
    };
  }

  // =====================================
  // HELPER METHODS
  // =====================================

  private async updateMigration(
    tenantId: string,
    shardTypeId: string,
    migration: SchemaMigration
  ): Promise<void> {
    const key = `${MIGRATION_KEY_PREFIX}${tenantId}:${shardTypeId}:${migration.id}`;
    await this.redis.set(key, JSON.stringify(migration));
  }

  private async updateShardMigrationState(
    shard: Shard,
    migration: SchemaMigration
  ): Promise<void> {
    const key = `${MIGRATION_STATE_KEY}${shard.tenantId}:${shard.id}`;
    const existingData = await this.redis.get(key);
    
    const state: ShardMigrationState = existingData 
      ? JSON.parse(existingData)
      : {
          shardId: shard.id,
          tenantId: shard.tenantId,
          shardTypeId: shard.shardTypeId,
          originalVersion: shard.schemaVersion || 1,
          currentVersion: migration.toVersion,
          migrationsApplied: [],
        };

    state.currentVersion = migration.toVersion;
    state.migrationsApplied.push(migration.id);
    state.lastMigratedAt = new Date();

    await this.redis.set(key, JSON.stringify(state));
  }
}


