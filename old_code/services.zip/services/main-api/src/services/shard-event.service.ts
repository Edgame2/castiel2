/**
 * Shard Event Service
 * 
 * Handles shard event emission, webhook delivery, and SSE broadcasting
 */

import type { Redis } from 'ioredis';
import type { FastifyInstance } from 'fastify';
import crypto from 'crypto';
import axios from 'axios';
import {
  ShardEventType,
  ShardEventPayload,
  WebhookConfig,
  WebhookDelivery,
  EventSubscription,
  FieldChange,
  EventTriggerSource,
  CreateWebhookInput,
  UpdateWebhookInput,
} from '../types/shard-event.types.js';
import type { Shard } from '../types/shard.types.js';

// Redis keys
const WEBHOOK_KEY_PREFIX = 'webhooks:';
const DELIVERY_KEY_PREFIX = 'webhook_delivery:';
const SUBSCRIPTION_KEY_PREFIX = 'event_subscriptions:';
const EVENT_CHANNEL = 'shard_events';

/**
 * Shard Event Service
 */
export class ShardEventService {
  private readonly webhookTTL = 30 * 24 * 60 * 60; // 30 days for delivery records

  constructor(
    private readonly redis: Redis,
    private readonly server?: FastifyInstance
  ) {}

  // =====================================
  // EVENT EMISSION
  // =====================================

  /**
   * Emit a shard event
   */
  async emit(
    eventType: ShardEventType,
    shard: Shard,
    options: {
      triggeredBy: string;
      triggerSource: EventTriggerSource;
      changes?: FieldChange[];
      previousState?: Record<string, any>;
      shardTypeName?: string;
    }
  ): Promise<string> {
    const eventId = crypto.randomUUID();

    const payload: ShardEventPayload = {
      eventId,
      eventType,
      timestamp: new Date(),
      tenantId: shard.tenantId,
      shardId: shard.id,
      shardTypeId: shard.shardTypeId,
      shardTypeName: options.shardTypeName,
      changes: options.changes,
      triggeredBy: options.triggeredBy,
      triggerSource: options.triggerSource,
      shardSnapshot: {
        id: shard.id,
        structuredData: shard.structuredData,
        metadata: shard.metadata,
        status: shard.status,
      },
      previousState: options.previousState,
    };

    // Publish to Redis for real-time subscriptions
    await this.publishToRedis(payload);

    // Queue webhook deliveries
    await this.queueWebhookDeliveries(payload);

    // Log the event
    this.server?.log.info({ eventId, eventType, shardId: shard.id }, 'Shard event emitted');

    return eventId;
  }

  /**
   * Publish event to Redis pub/sub
   */
  private async publishToRedis(payload: ShardEventPayload): Promise<void> {
    try {
      await this.redis.publish(EVENT_CHANNEL, JSON.stringify(payload));
    } catch (error) {
      this.server?.log.error({ error }, 'Failed to publish event to Redis');
    }
  }

  /**
   * Subscribe to shard events (for SSE/WebSocket connections)
   */
  async subscribe(
    subscription: Omit<EventSubscription, 'id' | 'connectedAt' | 'lastHeartbeat'>
  ): Promise<string> {
    const id = crypto.randomUUID();
    const sub: EventSubscription = {
      ...subscription,
      id,
      connectedAt: new Date(),
      lastHeartbeat: new Date(),
    };

    const key = `${SUBSCRIPTION_KEY_PREFIX}${subscription.tenantId}:${id}`;
    await this.redis.setex(key, 3600, JSON.stringify(sub)); // 1 hour TTL

    return id;
  }

  /**
   * Unsubscribe from events
   */
  async unsubscribe(tenantId: string, subscriptionId: string): Promise<void> {
    const key = `${SUBSCRIPTION_KEY_PREFIX}${tenantId}:${subscriptionId}`;
    await this.redis.del(key);
  }

  /**
   * Update subscription heartbeat
   */
  async heartbeat(tenantId: string, subscriptionId: string): Promise<void> {
    const key = `${SUBSCRIPTION_KEY_PREFIX}${tenantId}:${subscriptionId}`;
    const data = await this.redis.get(key);
    if (data) {
      const sub = JSON.parse(data) as EventSubscription;
      sub.lastHeartbeat = new Date();
      await this.redis.setex(key, 3600, JSON.stringify(sub));
    }
  }

  // =====================================
  // WEBHOOK MANAGEMENT
  // =====================================

  /**
   * Create a new webhook
   */
  async createWebhook(tenantId: string, userId: string, input: CreateWebhookInput): Promise<WebhookConfig> {
    const id = crypto.randomUUID();
    const secret = crypto.randomBytes(32).toString('hex');

    const webhook: WebhookConfig = {
      id,
      tenantId,
      name: input.name,
      description: input.description,
      url: input.url,
      method: input.method || 'POST',
      headers: input.headers,
      events: input.events,
      filters: input.filters,
      retryCount: input.retryCount ?? 3,
      retryDelayMs: input.retryDelayMs ?? 5000,
      timeoutMs: input.timeoutMs ?? 30000,
      secret,
      isActive: true,
      failureCount: 0,
      createdAt: new Date(),
      createdBy: userId,
    };

    const key = `${WEBHOOK_KEY_PREFIX}${tenantId}:${id}`;
    await this.redis.set(key, JSON.stringify(webhook));

    // Add to tenant's webhook list
    await this.redis.sadd(`${WEBHOOK_KEY_PREFIX}${tenantId}:list`, id);

    return webhook;
  }

  /**
   * Get a webhook by ID
   */
  async getWebhook(tenantId: string, webhookId: string): Promise<WebhookConfig | null> {
    const key = `${WEBHOOK_KEY_PREFIX}${tenantId}:${webhookId}`;
    const data = await this.redis.get(key);
    return data ? JSON.parse(data) : null;
  }

  /**
   * List webhooks for a tenant
   */
  async listWebhooks(tenantId: string): Promise<WebhookConfig[]> {
    const ids = await this.redis.smembers(`${WEBHOOK_KEY_PREFIX}${tenantId}:list`);
    const webhooks: WebhookConfig[] = [];

    for (const id of ids) {
      const webhook = await this.getWebhook(tenantId, id);
      if (webhook) {
        webhooks.push(webhook);
      }
    }

    return webhooks;
  }

  /**
   * Update a webhook
   */
  async updateWebhook(
    tenantId: string,
    webhookId: string,
    input: UpdateWebhookInput
  ): Promise<WebhookConfig | null> {
    const webhook = await this.getWebhook(tenantId, webhookId);
    if (!webhook) return null;

    const updated: WebhookConfig = {
      ...webhook,
      ...input,
      updatedAt: new Date(),
    };

    const key = `${WEBHOOK_KEY_PREFIX}${tenantId}:${webhookId}`;
    await this.redis.set(key, JSON.stringify(updated));

    return updated;
  }

  /**
   * Delete a webhook
   */
  async deleteWebhook(tenantId: string, webhookId: string): Promise<boolean> {
    const key = `${WEBHOOK_KEY_PREFIX}${tenantId}:${webhookId}`;
    const deleted = await this.redis.del(key);
    await this.redis.srem(`${WEBHOOK_KEY_PREFIX}${tenantId}:list`, webhookId);
    return deleted > 0;
  }

  /**
   * Regenerate webhook secret
   */
  async regenerateSecret(tenantId: string, webhookId: string): Promise<string | null> {
    const webhook = await this.getWebhook(tenantId, webhookId);
    if (!webhook) return null;

    const newSecret = crypto.randomBytes(32).toString('hex');
    webhook.secret = newSecret;
    webhook.updatedAt = new Date();

    const key = `${WEBHOOK_KEY_PREFIX}${tenantId}:${webhookId}`;
    await this.redis.set(key, JSON.stringify(webhook));

    return newSecret;
  }

  // =====================================
  // WEBHOOK DELIVERY
  // =====================================

  /**
   * Queue webhook deliveries for an event
   */
  private async queueWebhookDeliveries(payload: ShardEventPayload): Promise<void> {
    const webhooks = await this.listWebhooks(payload.tenantId);

    for (const webhook of webhooks) {
      if (!webhook.isActive) continue;
      if (!webhook.events.includes(payload.eventType)) continue;

      // Check filters
      if (webhook.filters?.shardTypeIds?.length) {
        if (!webhook.filters.shardTypeIds.includes(payload.shardTypeId)) continue;
      }

      // Create delivery record
      const delivery: WebhookDelivery = {
        id: crypto.randomUUID(),
        webhookId: webhook.id,
        tenantId: payload.tenantId,
        eventId: payload.eventId,
        eventType: payload.eventType,
        payload,
        status: 'pending',
        attempts: 0,
        maxAttempts: webhook.retryCount + 1,
        createdAt: new Date(),
      };

      // Store delivery record
      const key = `${DELIVERY_KEY_PREFIX}${payload.tenantId}:${delivery.id}`;
      await this.redis.setex(key, this.webhookTTL, JSON.stringify(delivery));

      // Queue for immediate delivery
      await this.deliverWebhook(webhook, delivery);
    }
  }

  /**
   * Deliver a webhook
   */
  private async deliverWebhook(webhook: WebhookConfig, delivery: WebhookDelivery): Promise<void> {
    delivery.attempts++;

    try {
      const signature = this.generateSignature(delivery.payload, webhook.secret);

      const startTime = Date.now();
      const response = await axios({
        method: webhook.method,
        url: webhook.url,
        headers: {
          'Content-Type': 'application/json',
          'X-Webhook-Id': webhook.id,
          'X-Event-Id': delivery.eventId,
          'X-Event-Type': delivery.eventType,
          'X-Signature': signature,
          'X-Timestamp': new Date().toISOString(),
          ...webhook.headers,
        },
        data: delivery.payload,
        timeout: webhook.timeoutMs,
        validateStatus: () => true, // Don't throw on non-2xx
      });

      delivery.responseTime = Date.now() - startTime;
      delivery.responseStatus = response.status;
      delivery.responseBody = typeof response.data === 'string' 
        ? response.data.substring(0, 1000) 
        : JSON.stringify(response.data).substring(0, 1000);

      if (response.status >= 200 && response.status < 300) {
        delivery.status = 'success';
        delivery.completedAt = new Date();

        // Reset failure count on success
        webhook.failureCount = 0;
        webhook.lastTriggeredAt = new Date();
        await this.updateWebhookStatus(webhook);
      } else {
        throw new Error(`HTTP ${response.status}: ${delivery.responseBody}`);
      }
    } catch (error: any) {
      delivery.error = error.message || 'Unknown error';
      delivery.status = delivery.attempts >= delivery.maxAttempts ? 'failed' : 'retrying';

      if (delivery.status === 'retrying') {
        // Schedule retry
        delivery.nextRetryAt = new Date(Date.now() + webhook.retryDelayMs * delivery.attempts);
        setTimeout(() => this.deliverWebhook(webhook, delivery), webhook.retryDelayMs * delivery.attempts);
      } else {
        // Update webhook failure count
        webhook.failureCount++;
        webhook.lastError = error.message;
        
        // Disable webhook after 10 consecutive failures
        if (webhook.failureCount >= 10) {
          webhook.isActive = false;
          this.server?.log.warn({ webhookId: webhook.id }, 'Webhook disabled due to repeated failures');
        }
        
        await this.updateWebhookStatus(webhook);
      }
    }

    // Update delivery record
    const key = `${DELIVERY_KEY_PREFIX}${delivery.tenantId}:${delivery.id}`;
    await this.redis.setex(key, this.webhookTTL, JSON.stringify(delivery));
  }

  /**
   * Update webhook status in Redis
   */
  private async updateWebhookStatus(webhook: WebhookConfig): Promise<void> {
    const key = `${WEBHOOK_KEY_PREFIX}${webhook.tenantId}:${webhook.id}`;
    await this.redis.set(key, JSON.stringify(webhook));
  }

  /**
   * Generate HMAC signature for webhook payload
   */
  private generateSignature(payload: ShardEventPayload, secret: string): string {
    const hmac = crypto.createHmac('sha256', secret);
    hmac.update(JSON.stringify(payload));
    return `sha256=${hmac.digest('hex')}`;
  }

  /**
   * Get delivery history for a webhook
   */
  async getDeliveryHistory(tenantId: string, webhookId: string, limit: number = 50): Promise<WebhookDelivery[]> {
    const pattern = `${DELIVERY_KEY_PREFIX}${tenantId}:*`;
    const keys = await this.redis.keys(pattern);
    const deliveries: WebhookDelivery[] = [];

    for (const key of keys) {
      const data = await this.redis.get(key);
      if (data) {
        const delivery = JSON.parse(data) as WebhookDelivery;
        if (delivery.webhookId === webhookId) {
          deliveries.push(delivery);
        }
      }
    }

    // Sort by createdAt descending
    deliveries.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return deliveries.slice(0, limit);
  }

  /**
   * Test a webhook with a sample event
   */
  async testWebhook(tenantId: string, webhookId: string, userId: string): Promise<WebhookDelivery> {
    const webhook = await this.getWebhook(tenantId, webhookId);
    if (!webhook) {
      throw new Error('Webhook not found');
    }

    const testPayload: ShardEventPayload = {
      eventId: crypto.randomUUID(),
      eventType: ShardEventType.CREATED,
      timestamp: new Date(),
      tenantId,
      shardId: 'test-shard-id',
      shardTypeId: 'test-shard-type-id',
      shardTypeName: 'Test Shard Type',
      triggeredBy: userId,
      triggerSource: 'api',
      shardSnapshot: {
        id: 'test-shard-id',
        structuredData: { name: 'Test Shard', description: 'This is a test webhook delivery' },
        status: 'active',
      },
    };

    const delivery: WebhookDelivery = {
      id: crypto.randomUUID(),
      webhookId: webhook.id,
      tenantId,
      eventId: testPayload.eventId,
      eventType: testPayload.eventType,
      payload: testPayload,
      status: 'pending',
      attempts: 0,
      maxAttempts: 1, // No retries for test
      createdAt: new Date(),
    };

    await this.deliverWebhook(webhook, delivery);

    return delivery;
  }

  // =====================================
  // UTILITY METHODS
  // =====================================

  /**
   * Calculate field changes between two shard states
   */
  static calculateChanges(oldShard: Partial<Shard>, newShard: Partial<Shard>): FieldChange[] {
    const changes: FieldChange[] = [];

    // Compare structured data
    if (oldShard.structuredData && newShard.structuredData) {
      const allKeys = new Set([
        ...Object.keys(oldShard.structuredData),
        ...Object.keys(newShard.structuredData),
      ]);

      for (const key of allKeys) {
        const oldValue = oldShard.structuredData[key];
        const newValue = newShard.structuredData[key];

        if (JSON.stringify(oldValue) !== JSON.stringify(newValue)) {
          changes.push({ field: `structuredData.${key}`, oldValue, newValue });
        }
      }
    }

    // Compare status
    if (oldShard.status !== newShard.status) {
      changes.push({ field: 'status', oldValue: oldShard.status, newValue: newShard.status });
    }

    // Compare metadata
    if (JSON.stringify(oldShard.metadata) !== JSON.stringify(newShard.metadata)) {
      changes.push({ field: 'metadata', oldValue: oldShard.metadata, newValue: newShard.metadata });
    }

    return changes;
  }
}


