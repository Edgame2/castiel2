/**
 * Standardized error codes for Shard operations
 */

/**
 * Shard-specific error codes
 */
export enum ShardErrorCode {
  // Validation errors
  SHARD_VALIDATION_FAILED = 'SHARD_VALIDATION_FAILED',
  SHARD_TYPE_NOT_FOUND = 'SHARD_TYPE_NOT_FOUND',
  SHARD_TYPE_INACTIVE = 'SHARD_TYPE_INACTIVE',
  REQUIRED_FIELD_MISSING = 'REQUIRED_FIELD_MISSING',
  INVALID_FIELD_VALUE = 'INVALID_FIELD_VALUE',
  SCHEMA_VALIDATION_FAILED = 'SCHEMA_VALIDATION_FAILED',

  // Access errors
  SHARD_NOT_FOUND = 'SHARD_NOT_FOUND',
  SHARD_ACCESS_DENIED = 'SHARD_ACCESS_DENIED',
  CROSS_TENANT_ACCESS = 'CROSS_TENANT_ACCESS',
  INSUFFICIENT_PERMISSIONS = 'INSUFFICIENT_PERMISSIONS',

  // Relationship errors
  RELATIONSHIP_TARGET_NOT_FOUND = 'RELATIONSHIP_TARGET_NOT_FOUND',
  RELATIONSHIP_CYCLE_DETECTED = 'RELATIONSHIP_CYCLE_DETECTED',
  INVALID_RELATIONSHIP_TYPE = 'INVALID_RELATIONSHIP_TYPE',
  RELATIONSHIP_ALREADY_EXISTS = 'RELATIONSHIP_ALREADY_EXISTS',
  SELF_RELATIONSHIP_NOT_ALLOWED = 'SELF_RELATIONSHIP_NOT_ALLOWED',

  // Operation errors
  SHARD_ALREADY_DELETED = 'SHARD_ALREADY_DELETED',
  SHARD_RESTORE_FAILED = 'SHARD_RESTORE_FAILED',
  SHARD_ALREADY_ARCHIVED = 'SHARD_ALREADY_ARCHIVED',
  SHARD_NOT_ARCHIVED = 'SHARD_NOT_ARCHIVED',
  SHARD_NOT_DELETED = 'SHARD_NOT_DELETED',

  // Bulk operation errors
  BULK_OPERATION_PARTIAL_FAILURE = 'BULK_OPERATION_PARTIAL_FAILURE',
  BULK_OPERATION_LIMIT_EXCEEDED = 'BULK_OPERATION_LIMIT_EXCEEDED',
  BULK_OPERATION_ABORTED = 'BULK_OPERATION_ABORTED',

  // Schema migration errors
  SCHEMA_MIGRATION_FAILED = 'SCHEMA_MIGRATION_FAILED',
  SCHEMA_VERSION_MISMATCH = 'SCHEMA_VERSION_MISMATCH',
  MIGRATION_NOT_SUPPORTED = 'MIGRATION_NOT_SUPPORTED',

  // Import/Export errors
  IMPORT_FAILED = 'IMPORT_FAILED',
  IMPORT_VALIDATION_FAILED = 'IMPORT_VALIDATION_FAILED',
  EXPORT_FAILED = 'EXPORT_FAILED',
  UNSUPPORTED_FILE_FORMAT = 'UNSUPPORTED_FILE_FORMAT',

  // Enrichment errors
  ENRICHMENT_FAILED = 'ENRICHMENT_FAILED',
  EMBEDDING_GENERATION_FAILED = 'EMBEDDING_GENERATION_FAILED',

  // Rate limiting
  RATE_LIMIT_EXCEEDED = 'RATE_LIMIT_EXCEEDED',
}

/**
 * Structured error response for Shard API
 */
export interface ShardError {
  code: ShardErrorCode;
  message: string;
  details?: Record<string, any>;
  field?: string; // For validation errors
  shardId?: string;
  timestamp: string;
}

/**
 * Bulk operation error detail
 */
export interface BulkOperationError {
  index: number;
  code: ShardErrorCode;
  message: string;
  shardId?: string;
  field?: string;
}

/**
 * Bulk operation result
 */
export interface BulkOperationResult<T = any> {
  success: boolean;
  summary: {
    total: number;
    succeeded: number;
    failed: number;
  };
  results: Array<{
    index: number;
    status: 'created' | 'updated' | 'deleted' | 'failed';
    shardId?: string;
    data?: T;
    error?: BulkOperationError;
  }>;
}

/**
 * Create a standardized shard error
 */
export function createShardError(
  code: ShardErrorCode,
  message: string,
  details?: Record<string, any>
): ShardError {
  return {
    code,
    message,
    details,
    timestamp: new Date().toISOString(),
  };
}

/**
 * HTTP status code mapping for shard errors
 */
export const ShardErrorHttpStatus: Record<ShardErrorCode, number> = {
  // 400 Bad Request
  [ShardErrorCode.SHARD_VALIDATION_FAILED]: 400,
  [ShardErrorCode.REQUIRED_FIELD_MISSING]: 400,
  [ShardErrorCode.INVALID_FIELD_VALUE]: 400,
  [ShardErrorCode.SCHEMA_VALIDATION_FAILED]: 400,
  [ShardErrorCode.INVALID_RELATIONSHIP_TYPE]: 400,
  [ShardErrorCode.SELF_RELATIONSHIP_NOT_ALLOWED]: 400,
  [ShardErrorCode.SCHEMA_VERSION_MISMATCH]: 400,
  [ShardErrorCode.IMPORT_VALIDATION_FAILED]: 400,
  [ShardErrorCode.UNSUPPORTED_FILE_FORMAT]: 400,

  // 403 Forbidden
  [ShardErrorCode.SHARD_ACCESS_DENIED]: 403,
  [ShardErrorCode.CROSS_TENANT_ACCESS]: 403,
  [ShardErrorCode.INSUFFICIENT_PERMISSIONS]: 403,

  // 404 Not Found
  [ShardErrorCode.SHARD_NOT_FOUND]: 404,
  [ShardErrorCode.SHARD_TYPE_NOT_FOUND]: 404,
  [ShardErrorCode.RELATIONSHIP_TARGET_NOT_FOUND]: 404,

  // 409 Conflict
  [ShardErrorCode.SHARD_ALREADY_DELETED]: 409,
  [ShardErrorCode.SHARD_ALREADY_ARCHIVED]: 409,
  [ShardErrorCode.SHARD_NOT_ARCHIVED]: 409,
  [ShardErrorCode.SHARD_NOT_DELETED]: 409,
  [ShardErrorCode.RELATIONSHIP_ALREADY_EXISTS]: 409,
  [ShardErrorCode.RELATIONSHIP_CYCLE_DETECTED]: 409,

  // 410 Gone
  [ShardErrorCode.SHARD_TYPE_INACTIVE]: 410,

  // 422 Unprocessable Entity
  [ShardErrorCode.SHARD_RESTORE_FAILED]: 422,
  [ShardErrorCode.SCHEMA_MIGRATION_FAILED]: 422,
  [ShardErrorCode.MIGRATION_NOT_SUPPORTED]: 422,
  [ShardErrorCode.IMPORT_FAILED]: 422,
  [ShardErrorCode.EXPORT_FAILED]: 422,
  [ShardErrorCode.ENRICHMENT_FAILED]: 422,
  [ShardErrorCode.EMBEDDING_GENERATION_FAILED]: 422,

  // 429 Too Many Requests
  [ShardErrorCode.RATE_LIMIT_EXCEEDED]: 429,
  [ShardErrorCode.BULK_OPERATION_LIMIT_EXCEEDED]: 429,

  // 500 Internal Server Error (partial failures)
  [ShardErrorCode.BULK_OPERATION_PARTIAL_FAILURE]: 207, // Multi-Status
  [ShardErrorCode.BULK_OPERATION_ABORTED]: 500,
};


