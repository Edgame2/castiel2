(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["chunks/[root-of-the-server]__734dcc39._.js",
"[externals]/node:buffer [external] (node:buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:buffer", () => require("node:buffer"));

module.exports = mod;
}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}),
"[project]/services/frontend/src/lib/env.ts [middleware-edge] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Environment configuration with validation
__turbopack_context__.s([
    "env",
    ()=>env
]);
const requiredEnvVars = {
    NEXT_PUBLIC_API_BASE_URL: ("TURBOPACK compile-time value", "http://localhost:3001"),
    NEXT_PUBLIC_OAUTH_CLIENT_ID: ("TURBOPACK compile-time value", "your-client-id"),
    NEXT_PUBLIC_OAUTH_REDIRECT_URI: ("TURBOPACK compile-time value", "http://localhost:3000/auth/callback"),
    NEXT_PUBLIC_OAUTH_SCOPE: ("TURBOPACK compile-time value", "openid profile email")
};
const optionalEnvVars = {
    NEXT_PUBLIC_APP_INSIGHTS_CONNECTION_STRING: ("TURBOPACK compile-time value", ""),
    NEXT_PUBLIC_APP_INSIGHTS_INSTRUMENTATION_KEY: ("TURBOPACK compile-time value", ""),
    NEXT_PUBLIC_ENABLE_ANALYTICS: ("TURBOPACK compile-time value", "false") === 'true'
};
// Validate required environment variables
if ("TURBOPACK compile-time truthy", 1) {
    const missingVars = Object.entries(requiredEnvVars).filter(([, value])=>!value).map(([key])=>key);
    if (missingVars.length > 0) {
        throw new Error(`Missing required environment variables:\n${missingVars.map((v)=>`- ${v}`).join('\n')}`);
    }
}
const env = {
    ...requiredEnvVars,
    ...optionalEnvVars,
    isDevelopment: ("TURBOPACK compile-time value", "development") === 'development',
    isProduction: ("TURBOPACK compile-time value", "development") === 'production',
    isTest: ("TURBOPACK compile-time value", "development") === 'test'
};
}),
"[project]/services/frontend/src/lib/auth/oauth.ts [middleware-edge] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// OAuth 2.0 configuration and utilities
__turbopack_context__.s([
    "buildAuthorizationUrl",
    ()=>buildAuthorizationUrl,
    "exchangeCodeForTokens",
    ()=>exchangeCodeForTokens,
    "getUserInfo",
    ()=>getUserInfo,
    "oAuthConfig",
    ()=>oAuthConfig,
    "refreshAccessToken",
    ()=>refreshAccessToken
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$env$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/frontend/src/lib/env.ts [middleware-edge] (ecmascript)");
;
const normalizeBaseUrl = (value)=>{
    if (!value) return null;
    return value.endsWith('/') ? value.slice(0, -1) : value;
};
const resolvedBaseUrl = normalizeBaseUrl(__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$env$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["env"].NEXT_PUBLIC_API_BASE_URL);
if (!resolvedBaseUrl) {
    throw new Error('Missing NEXT_PUBLIC_API_BASE_URL for OAuth');
}
const oAuthConfig = {
    baseUrl: resolvedBaseUrl,
    authorizationEndpoint: `${resolvedBaseUrl}/oauth2/authorize`,
    tokenEndpoint: `${resolvedBaseUrl}/oauth2/token`,
    revokeEndpoint: `${resolvedBaseUrl}/oauth2/revoke`,
    userInfoEndpoint: `${resolvedBaseUrl}/oauth2/userinfo`,
    clientId: __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$env$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["env"].NEXT_PUBLIC_OAUTH_CLIENT_ID || '',
    redirectUri: __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$env$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["env"].NEXT_PUBLIC_OAUTH_REDIRECT_URI || '',
    scope: __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$env$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["env"].NEXT_PUBLIC_OAUTH_SCOPE || 'openid profile email'
};
function buildAuthorizationUrl(options) {
    const params = new URLSearchParams({
        response_type: 'code',
        client_id: oAuthConfig.clientId,
        redirect_uri: oAuthConfig.redirectUri,
        scope: options.scopeOverride ?? oAuthConfig.scope,
        state: options.state
    });
    if (options.codeChallenge) {
        params.set('code_challenge', options.codeChallenge);
        params.set('code_challenge_method', options.codeChallengeMethod ?? 'S256');
    }
    return `${oAuthConfig.authorizationEndpoint}?${params.toString()}`;
}
async function exchangeCodeForTokens(code, codeVerifier) {
    const payload = {
        grant_type: 'authorization_code',
        code,
        client_id: oAuthConfig.clientId,
        redirect_uri: oAuthConfig.redirectUri
    };
    if (codeVerifier) {
        payload.code_verifier = codeVerifier;
    }
    const response = await fetch(oAuthConfig.tokenEndpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        cache: 'no-store',
        body: JSON.stringify(payload)
    });
    if (!response.ok) {
        throw new Error(`Token exchange failed: ${response.statusText}`);
    }
    return response.json();
}
async function refreshAccessToken(refreshToken) {
    const response = await fetch(oAuthConfig.tokenEndpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        cache: 'no-store',
        body: JSON.stringify({
            grant_type: 'refresh_token',
            refresh_token: refreshToken,
            client_id: oAuthConfig.clientId
        })
    });
    if (!response.ok) {
        throw new Error(`Token refresh failed: ${response.statusText}`);
    }
    return response.json();
}
async function getUserInfo(accessToken) {
    const response = await fetch(oAuthConfig.userInfoEndpoint, {
        cache: 'no-store',
        headers: {
            Authorization: `Bearer ${accessToken}`
        }
    });
    if (!response.ok) {
        throw new Error(`Failed to fetch user info: ${response.statusText}`);
    }
    return response.json();
}
}),
"[project]/services/frontend/middleware.ts [middleware-edge] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "config",
    ()=>config,
    "middleware",
    ()=>middleware
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$d_b7fcb0b13d52771d3a90da208c7b0dec$2f$node_modules$2f$next$2f$dist$2f$esm$2f$api$2f$server$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.3_@babel+core@7.28.5_@opentelemetry+api@1.9.0_@playwright+test@1.56.1_react-d_b7fcb0b13d52771d3a90da208c7b0dec/node_modules/next/dist/esm/api/server.js [middleware-edge] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$d_b7fcb0b13d52771d3a90da208c7b0dec$2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.3_@babel+core@7.28.5_@opentelemetry+api@1.9.0_@playwright+test@1.56.1_react-d_b7fcb0b13d52771d3a90da208c7b0dec/node_modules/next/dist/esm/server/web/exports/index.js [middleware-edge] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$auth$2f$oauth$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/frontend/src/lib/auth/oauth.ts [middleware-edge] (ecmascript)");
;
;
const isProduction = ("TURBOPACK compile-time value", "development") === 'production';
async function middleware(request) {
    const accessToken = request.cookies.get('access_token');
    const { pathname } = request.nextUrl;
    // Public routes that don't require authentication
    const publicRoutes = [
        '/accessibility',
        '/cookies',
        '/privacy',
        '/terms',
        '/auth/callback'
    ];
    // Check if current path is public
    const isPublicRoute = publicRoutes.some((route)=>pathname === route || pathname.startsWith(`${route}/`));
    // Check if it's an API route or static file
    const isApiOrStatic = pathname.startsWith('/api') || pathname.startsWith('/_next') || pathname.includes('.');
    // Skip middleware for API routes and static files
    if (isApiOrStatic) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$d_b7fcb0b13d52771d3a90da208c7b0dec$2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
    }
    // Root path - redirect based on auth status
    if (pathname === '/') {
        if (accessToken) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$d_b7fcb0b13d52771d3a90da208c7b0dec$2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].redirect(new URL('/dashboard', request.url));
        }
        return redirectToOAuth(request, '/dashboard');
    }
    // Public routes - allow access
    if (isPublicRoute) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$d_b7fcb0b13d52771d3a90da208c7b0dec$2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
    }
    // Protected routes - require authentication
    if (!accessToken) {
        console.log(`[Middleware] Unauthenticated access to ${pathname}, redirecting to login`);
        return redirectToOAuth(request, pathname);
    }
    // Authenticated - allow access
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$d_b7fcb0b13d52771d3a90da208c7b0dec$2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
}
async function redirectToOAuth(request, returnPath) {
    const safePath = returnPath.startsWith('/') ? returnPath : '/dashboard';
    const state = createStateToken(safePath);
    const pkce = await generatePkcePair();
    const authorizationUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$frontend$2f$src$2f$lib$2f$auth$2f$oauth$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["buildAuthorizationUrl"])({
        state,
        codeChallenge: pkce.challenge,
        codeChallengeMethod: 'S256'
    });
    const response = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$d_b7fcb0b13d52771d3a90da208c7b0dec$2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].redirect(authorizationUrl);
    response.cookies.set('pkce_verifier', pkce.verifier, {
        httpOnly: true,
        secure: isProduction,
        sameSite: 'lax',
        maxAge: 5 * 60,
        path: '/'
    });
    response.cookies.set('oauth_state', state, {
        httpOnly: true,
        secure: isProduction,
        sameSite: 'lax',
        maxAge: 5 * 60,
        path: '/'
    });
    return response;
}
function createStateToken(returnPath) {
    const nonce = generateRandomString(32);
    const encodedPath = encodeURIComponent(returnPath);
    return `${nonce}:${encodedPath}`;
}
function generateRandomString(length) {
    const charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~';
    const randomValues = new Uint8Array(length);
    crypto.getRandomValues(randomValues);
    let result = '';
    randomValues.forEach((value)=>{
        result += charset[value % charset.length];
    });
    return result;
}
async function generatePkcePair() {
    const verifier = generateRandomString(64);
    const encoder = new TextEncoder();
    const data = encoder.encode(verifier);
    const digest = await crypto.subtle.digest('SHA-256', data);
    const challenge = bufferToBase64Url(new Uint8Array(digest));
    return {
        verifier,
        challenge
    };
}
function bufferToBase64Url(buffer) {
    let binary = '';
    buffer.forEach((byte)=>{
        binary += String.fromCharCode(byte);
    });
    return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
const config = {
    matcher: [
        /*
     * Match all request paths except:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public files (public folder)
     */ '/((?!api|_next/static|_next/image|favicon.ico|.*\\..*).*)'
    ]
};
}),
]);

//# sourceMappingURL=%5Broot-of-the-server%5D__734dcc39._.js.map