module.exports = [
"[project]/services/frontend/.next-internal/server/app/api/auth/token/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=c2a1c_frontend__next-internal_server_app_api_auth_token_route_actions_f01e31fd.js.map