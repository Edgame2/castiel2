(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/services_frontend_src_components_admin_42a8bcd8._.js",
  "static/chunks/_0d1fa0b2._.js"
],
    source: "dynamic"
});
