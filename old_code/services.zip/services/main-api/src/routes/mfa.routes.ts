/**
 * MFA Routes
 */

import type { FastifyInstance } from 'fastify';
import { MFAController } from '../controllers/mfa.controller.js';
import {
  enrollTOTPSchema,
  verifyTOTPSchema,
  enrollSMSSchema,
  verifySMSSchema,
  enrollEmailSchema,
  verifyEmailSchema,
  mfaChallengeSchema,
  sendMFACodeSchema,
  disableMFAMethodSchema,
  listMFAMethodsSchema,
  generateRecoveryCodesSchema,
  getMFAPolicySchema,
  updateMFAPolicySchema,
} from '../schemas/mfa.schemas.js';

export async function registerMFARoutes(server: FastifyInstance): Promise<void> {
  const mfaController = (server as FastifyInstance & { mfaController?: MFAController })
    .mfaController;

  if (!mfaController) {
    throw new Error('MFAController not found on server instance');
  }

  server.post('/api/auth/mfa/enroll/totp', { schema: enrollTOTPSchema }, (request, reply) =>
    mfaController.enrollTOTP(request, reply)
  );

  server.post('/api/auth/mfa/verify/totp', { schema: verifyTOTPSchema }, (request, reply) =>
    mfaController.verifyTOTP(request, reply)
  );

  server.post('/api/auth/mfa/enroll/sms', { schema: enrollSMSSchema }, (request, reply) =>
    mfaController.enrollSMS(request, reply)
  );

  server.post('/api/auth/mfa/verify/sms', { schema: verifySMSSchema }, (request, reply) =>
    mfaController.verifySMS(request, reply)
  );

  server.post('/api/auth/mfa/enroll/email', { schema: enrollEmailSchema }, (request, reply) =>
    mfaController.enrollEmail(request, reply)
  );

  server.post('/api/auth/mfa/verify/email', { schema: verifyEmailSchema }, (request, reply) =>
    mfaController.verifyEmail(request, reply)
  );

  server.post('/api/auth/mfa/challenge', { schema: mfaChallengeSchema }, (request, reply) =>
    mfaController.mfaChallenge(request, reply)
  );

  // Send OTP code for SMS or Email during MFA challenge (no auth required - uses challenge token)
  server.post('/api/auth/mfa/send-code', { schema: sendMFACodeSchema }, (request, reply) =>
    mfaController.sendMFACode(request, reply)
  );

  server.get('/api/auth/mfa/methods', { schema: listMFAMethodsSchema }, (request, reply) =>
    mfaController.listMFAMethods(request, reply)
  );

  server.post('/api/auth/mfa/disable/:method', { schema: disableMFAMethodSchema }, (request, reply) =>
    mfaController.disableMFAMethod(request, reply)
  );

  server.post(
    '/api/auth/mfa/recovery-codes/generate',
    { schema: generateRecoveryCodesSchema },
    (request, reply) => mfaController.generateRecoveryCodes(request, reply)
  );

  server.get(
    '/api/tenants/:tenantId/mfa/policy',
    { schema: getMFAPolicySchema },
    (request, reply) => mfaController.getMFAPolicy(request, reply)
  );

  server.post(
    '/api/tenants/:tenantId/mfa/policy',
    { schema: updateMFAPolicySchema },
    (request, reply) => mfaController.updateMFAPolicy(request, reply)
  );

  server.log.info('MFA routes registered');
}
