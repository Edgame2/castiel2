/**
 * SSO Controller
 * 
 * HTTP handlers for Single Sign-On (SAML) authentication
 */

import crypto from 'crypto';
import type { FastifyRequest, FastifyReply } from 'fastify';
import type { SAMLService } from '../services/auth/saml.service.js';
import type { SSOConfigService } from '../services/auth/sso-config.service.js';
import type { UserService } from '../services/auth/user.service.js';
import type { CacheManager } from '../cache/manager.js';
import type { SSOConfiguration, SAMLProfile, SAMLConfig } from '../types/sso.types.js';
import type { AuthUser } from '../types/auth.types.js';
import { SessionManagementService } from '../services/auth/session-management.service.js';
import { SSOConfigStatus } from '../types/sso.types.js';

/**
 * SSO Controller for handling SAML authentication
 */
export class SSOController {
  constructor(
    private readonly samlService: SAMLService,
    private readonly ssoConfigService: SSOConfigService,
    private readonly userService: UserService,
    private readonly cacheManager: CacheManager,
    private readonly accessTokenExpiry: string = '9h',
    private readonly frontendUrl: string = 'http://localhost:3000'
  ) {}

  /**
   * GET /auth/sso/:tenantId/login
   * Initiate SAML login for an organization
   */
  async initiateLogin(request: FastifyRequest, reply: FastifyReply) {
    try {
      const { tenantId } = request.params as { tenantId: string };
      const { returnUrl } = request.query as { returnUrl?: string };

      // Get SSO configuration for the tenant
      const config = await this.ssoConfigService.getConfigByOrgId(tenantId);

      if (!config) {
        return reply.code(404).send({
          error: 'NotConfigured',
          message: 'SSO is not configured for this organization',
        });
      }

      if (config.status !== SSOConfigStatus.ACTIVE) {
        return reply.code(403).send({
          error: 'Inactive',
          message: 'SSO is not active for this organization',
        });
      }

      // Validate configuration
      const validation = this.ssoConfigService.validateConfig(config);
      if (!validation.valid) {
        request.log.error({ tenantId, errors: validation.errors }, 'Invalid SSO configuration');
        return reply.code(500).send({
          error: 'ConfigurationError',
          message: 'SSO configuration is invalid',
        });
      }

      // Create SAML instance
      const saml = this.samlService.createSAMLInstance(config.samlConfig as SAMLConfig);

      // Generate auth request
      const { url, requestId } = await this.samlService.generateAuthRequest(
        saml,
        tenantId,
        returnUrl
      );

      request.log.info({ tenantId, requestId }, 'SSO login initiated');

      // Redirect to IdP
      return reply.redirect(url);
    } catch (error: any) {
      request.log.error({ error }, 'Failed to initiate SSO login');
      return reply.code(500).send({
        error: 'SSOError',
        message: 'Failed to initiate SSO login',
      });
    }
  }

  /**
   * POST /auth/sso/:tenantId/callback
   * Handle SAML assertion callback from IdP
   */
  async handleCallback(request: FastifyRequest, reply: FastifyReply) {
    try {
      const { tenantId } = request.params as { tenantId: string };
      const body = request.body as any;

      request.log.info({ tenantId }, 'SSO callback received');

      // Get SSO configuration
      const config = await this.ssoConfigService.getConfigByOrgId(tenantId);

      if (!config || config.status !== SSOConfigStatus.ACTIVE) {
        return reply.code(403).send({
          error: 'Inactive',
          message: 'SSO is not active for this organization',
        });
      }

      // Create SAML instance
      const saml = this.samlService.createSAMLInstance(config.samlConfig as SAMLConfig);

      // Validate SAML response
      let profile: SAMLProfile;
      try {
        profile = await this.samlService.validateResponse(saml, body, config.samlConfig as SAMLConfig);
      } catch (error: any) {
        request.log.error({ error }, 'SAML validation failed');
        return this.redirectWithError(reply, 'saml_validation_failed');
      }

      if (!profile.email) {
        request.log.error({ profile }, 'SAML profile missing email');
        return this.redirectWithError(reply, 'missing_email');
      }

      // Validate session (if relay state contains request ID)
      const relayState = body.RelayState;

      // Find or create user
      let user = await this.userService.findByEmail(profile.email.toLowerCase(), tenantId);

      if (!user) {
        // JIT provisioning
        if (!config.jitProvisioning?.enabled) {
          request.log.warn({ email: profile.email, tenantId }, 'JIT provisioning disabled, user not found');
          return this.redirectWithError(reply, 'user_not_found');
        }

        // Check allowed domains if configured
        if (config.jitProvisioning.allowedDomains?.length) {
          const emailDomain = profile.email.split('@')[1]?.toLowerCase();
          if (!config.jitProvisioning.allowedDomains.includes(emailDomain)) {
            request.log.warn({ email: profile.email, domain: emailDomain }, 'Email domain not allowed');
            return this.redirectWithError(reply, 'domain_not_allowed');
          }
        }

        // Generate random password for SSO user (they won't use it)
        const randomPassword = crypto.randomBytes(32).toString('hex');

        // Create user with JIT provisioning
        user = await this.userService.createUser({
          email: profile.email.toLowerCase(),
          password: randomPassword,
          firstName: profile.firstName,
          lastName: profile.lastName,
          tenantId,
          status: config.jitProvisioning.autoActivate ? 'active' : 'pending',
          emailVerified: true, // SSO users are considered verified
          roles: config.jitProvisioning.defaultRole ? [config.jitProvisioning.defaultRole] : ['user'],
        });

        // Update user with SSO info
        await this.userService.updateUser(user.id, tenantId, {
          ssoProvider: 'saml',
          ssoSubject: profile.nameID,
        });

        request.log.info({ userId: user.id, email: profile.email }, 'User created via JIT provisioning');
      } else {
        // Update user with SSO info if not already set
        if (!user.ssoProvider || !user.ssoSubject) {
          await this.userService.updateUser(user.id, tenantId, {
            ssoProvider: 'saml',
            ssoSubject: profile.nameID,
          });
        }
      }

      // Check if user is active
      if (user.status !== 'active') {
        return this.redirectWithError(reply, 'account_inactive');
      }

      // Generate tokens
      const accessToken = (request.server as any).jwt.sign(
        {
          sub: user.id,
          email: user.email,
          tenantId: user.tenantId,
          isDefaultTenant: user.isDefaultTenant ?? false,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.roles?.[0] || 'user',
          roles: user.roles || [],
          organizationId: user.organizationId,
          status: user.status,
          type: 'access',
          loginMethod: 'sso',
          ssoProvider: 'saml',
        },
        {
          expiresIn: this.accessTokenExpiry,
        }
      );

      // Create refresh token
      const refreshTokenResult = await this.cacheManager.tokens.createRefreshToken(
        user.id,
        user.tenantId
      );

      // Extract device and location metadata
      const metadata = SessionManagementService.extractSessionMetadata(request);

      // Create session
      await this.cacheManager.sessions.createSession(user.id, user.tenantId, {
        email: user.email,
        name: `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.email,
        provider: 'sso_saml',
        deviceInfo: metadata.deviceInfo,
        locationInfo: metadata.locationInfo,
      });

      request.log.info({ userId: user.id, email: user.email }, 'SSO login successful');

      // Redirect to frontend with tokens
      const returnUrl = relayState || '/dashboard';
      const redirectUrl = new URL(`${this.frontendUrl}/api/auth/sso-callback`);
      redirectUrl.searchParams.set('accessToken', accessToken);
      redirectUrl.searchParams.set('refreshToken', refreshTokenResult.token);
      redirectUrl.searchParams.set('returnUrl', returnUrl);

      return reply.redirect(redirectUrl.toString());
    } catch (error: any) {
      request.log.error({ error }, 'SSO callback failed');
      return this.redirectWithError(reply, 'sso_error');
    }
  }

  /**
   * GET /auth/sso/:tenantId/metadata
   * Get SAML service provider metadata
   */
  async getMetadata(request: FastifyRequest, reply: FastifyReply) {
    try {
      const { tenantId } = request.params as { tenantId: string };

      // Get SSO configuration
      const config = await this.ssoConfigService.getConfigByOrgId(tenantId);

      if (!config) {
        return reply.code(404).send({
          error: 'NotConfigured',
          message: 'SSO is not configured for this organization',
        });
      }

      // Create SAML instance
      const saml = this.samlService.createSAMLInstance(config.samlConfig as SAMLConfig);

      // Generate metadata
      const metadata = await this.samlService.generateMetadata(saml);

      return reply.header('Content-Type', 'application/xml').send(metadata);
    } catch (error: any) {
      request.log.error({ error }, 'Failed to generate SSO metadata');
      return reply.code(500).send({
        error: 'MetadataError',
        message: 'Failed to generate SSO metadata',
      });
    }
  }

  /**
   * POST /auth/sso/:tenantId/logout
   * Initiate SAML single logout
   */
  async initiateLogout(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({
          error: 'Unauthorized',
          message: 'Authentication required',
        });
      }

      const { tenantId } = request.params as { tenantId: string };
      const { nameID, sessionIndex } = request.body as { nameID?: string; sessionIndex?: string };

      // Get SSO configuration
      const config = await this.ssoConfigService.getConfigByOrgId(tenantId);

      if (!config || config.status !== SSOConfigStatus.ACTIVE) {
        // No SSO config, just do local logout
        await this.cacheManager.logoutUser(user.tenantId, user.id);
        return reply.code(200).send({ success: true, message: 'Logged out locally' });
      }

      // If we have SAML session info, do federated logout
      if (nameID && sessionIndex) {
        const saml = this.samlService.createSAMLInstance(config.samlConfig as SAMLConfig);
        const logoutUrl = await this.samlService.generateLogoutRequest(saml, nameID, sessionIndex);

        // Clear local session
        await this.cacheManager.logoutUser(user.tenantId, user.id);

        return reply.redirect(logoutUrl);
      }

      // No SAML session info, just do local logout
      await this.cacheManager.logoutUser(user.tenantId, user.id);
      return reply.code(200).send({ success: true, message: 'Logged out' });
    } catch (error: any) {
      request.log.error({ error }, 'SSO logout failed');
      return reply.code(500).send({
        error: 'LogoutError',
        message: 'Failed to logout',
      });
    }
  }

  /**
   * Redirect with error to frontend
   */
  private redirectWithError(reply: FastifyReply, error: string) {
    const errorUrl = new URL(`${this.frontendUrl}/login`);
    errorUrl.searchParams.set('sso_error', error);
    return reply.redirect(errorUrl.toString());
  }
}

