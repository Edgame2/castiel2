module.exports=[30008,(a,b,c)=>{}];

//# sourceMappingURL=services_frontend__next-internal_server_app_error_page_actions_7dc6256a.js.map