/**
 * Shard Bulk Operations Controller
 * 
 * HTTP handlers for bulk shard operations
 */

import type { FastifyRequest, FastifyReply } from 'fastify';
import type { ShardRepository } from '../repositories/shard.repository.js';
import type { ShardEventService } from '../services/shard-event.service.js';
import type {
  CreateShardInput,
  UpdateShardInput,
  Shard,
  ShardStatus,
  ShardSource,
  PermissionLevel,
} from '../types/shard.types.js';
import {
  ShardErrorCode,
  BulkOperationResult,
  BulkOperationError,
} from '../types/shard-errors.types.js';
import { ShardEventType } from '../types/shard-event.types.js';

interface AuthContext {
  tenantId: string;
  userId: string;
  roles?: string[];
}

interface BulkCreateInput {
  shards: Array<{
    shardTypeId: string;
    structuredData: Record<string, any>;
    unstructuredData?: Record<string, any>;
    metadata?: Record<string, any>;
    parentShardId?: string;
  }>;
  options?: {
    skipValidation?: boolean;
    skipEnrichment?: boolean;
    skipEvents?: boolean;
    transactional?: boolean;
    onError?: 'continue' | 'abort';
  };
}

interface BulkUpdateInput {
  updates: Array<{
    id: string;
    structuredData?: Record<string, any>;
    unstructuredData?: Record<string, any>;
    metadata?: Record<string, any>;
    status?: ShardStatus;
  }>;
  options?: {
    skipValidation?: boolean;
    createRevision?: boolean;
    skipEvents?: boolean;
    onError?: 'continue' | 'abort';
  };
}

interface BulkDeleteInput {
  shardIds: string[];
  options?: {
    hardDelete?: boolean;
    skipEvents?: boolean;
    onError?: 'continue' | 'abort';
  };
}

interface BulkRestoreInput {
  shardIds: string[];
  options?: {
    skipEvents?: boolean;
  };
}

const MAX_BULK_SIZE = 100;

/**
 * Shard Bulk Controller
 */
export class ShardBulkController {
  constructor(
    private readonly repository: ShardRepository,
    private readonly eventService?: ShardEventService
  ) {}

  /**
   * POST /api/v1/shards/bulk
   * Bulk create shards
   */
  bulkCreate = async (
    req: FastifyRequest<{ Body: BulkCreateInput }>,
    reply: FastifyReply
  ): Promise<void> => {
    const startTime = Date.now();

    try {
      const { tenantId, userId } = req.auth as AuthContext || {};
      if (!tenantId || !userId) {
        reply.status(401).send({ error: 'Unauthorized' });
        return;
      }

      const { shards, options = {} } = req.body;

      // Validate size
      if (!shards || shards.length === 0) {
        reply.status(400).send({ error: 'No shards provided' });
        return;
      }

      if (shards.length > MAX_BULK_SIZE) {
        reply.status(400).send({
          error: `Maximum ${MAX_BULK_SIZE} shards allowed per request`,
          code: ShardErrorCode.BULK_OPERATION_LIMIT_EXCEEDED,
        });
        return;
      }

      const result: BulkOperationResult<Shard> = {
        success: true,
        summary: { total: shards.length, succeeded: 0, failed: 0 },
        results: [],
      };

      for (let i = 0; i < shards.length; i++) {
        const shardInput = shards[i];

        try {
          const input: CreateShardInput = {
            tenantId,
            createdBy: userId,
            shardTypeId: shardInput.shardTypeId,
            structuredData: shardInput.structuredData || {},
            unstructuredData: shardInput.unstructuredData,
            metadata: shardInput.metadata,
            parentShardId: shardInput.parentShardId,
            source: ShardSource.API,
            sourceDetails: { importJobId: `bulk-${Date.now()}` },
            acl: [
              {
                userId,
                permissions: [
                  PermissionLevel.READ,
                  PermissionLevel.WRITE,
                  PermissionLevel.DELETE,
                  PermissionLevel.ADMIN,
                ],
                grantedBy: userId,
                grantedAt: new Date(),
              },
            ],
          };

          const shard = await this.repository.create(input);

          // Emit event if enabled
          if (!options.skipEvents && this.eventService) {
            await this.eventService.emit(ShardEventType.CREATED, shard, {
              triggeredBy: userId,
              triggerSource: 'api',
            });
          }

          result.results.push({
            index: i,
            status: 'created',
            shardId: shard.id,
            data: shard,
          });
          result.summary.succeeded++;
        } catch (error: any) {
          result.results.push({
            index: i,
            status: 'failed',
            error: {
              index: i,
              code: ShardErrorCode.SHARD_VALIDATION_FAILED,
              message: error.message || 'Failed to create shard',
            },
          });
          result.summary.failed++;

          if (options.onError === 'abort') {
            result.success = false;
            break;
          }
        }
      }

      result.success = result.summary.failed === 0;
      const statusCode = result.success ? 201 : result.summary.succeeded > 0 ? 207 : 400;

      req.log.info({
        operation: 'bulk_create',
        total: result.summary.total,
        succeeded: result.summary.succeeded,
        failed: result.summary.failed,
        duration: Date.now() - startTime,
      });

      reply.status(statusCode).send(result);
    } catch (error: any) {
      req.log.error({ error }, 'Bulk create failed');
      reply.status(500).send({ error: 'Bulk create failed' });
    }
  };

  /**
   * PATCH /api/v1/shards/bulk
   * Bulk update shards
   */
  bulkUpdate = async (
    req: FastifyRequest<{ Body: BulkUpdateInput }>,
    reply: FastifyReply
  ): Promise<void> => {
    const startTime = Date.now();

    try {
      const { tenantId, userId } = req.auth as AuthContext || {};
      if (!tenantId || !userId) {
        reply.status(401).send({ error: 'Unauthorized' });
        return;
      }

      const { updates, options = {} } = req.body;

      if (!updates || updates.length === 0) {
        reply.status(400).send({ error: 'No updates provided' });
        return;
      }

      if (updates.length > MAX_BULK_SIZE) {
        reply.status(400).send({
          error: `Maximum ${MAX_BULK_SIZE} updates allowed per request`,
          code: ShardErrorCode.BULK_OPERATION_LIMIT_EXCEEDED,
        });
        return;
      }

      const result: BulkOperationResult<Shard> = {
        success: true,
        summary: { total: updates.length, succeeded: 0, failed: 0 },
        results: [],
      };

      for (let i = 0; i < updates.length; i++) {
        const update = updates[i];

        try {
          // Check permission
          const hasAccess = await this.repository.checkPermission(
            update.id,
            tenantId,
            userId
          );

          if (!hasAccess.hasAccess || !hasAccess.permissions.includes(PermissionLevel.WRITE)) {
            throw new Error('Insufficient permissions');
          }

          const existing = await this.repository.findById(update.id, tenantId);
          if (!existing) {
            throw new Error('Shard not found');
          }

          const input: UpdateShardInput = {
            structuredData: update.structuredData,
            unstructuredData: update.unstructuredData,
            metadata: update.metadata,
            status: update.status,
          };

          const updated = await this.repository.update(update.id, tenantId, input);

          if (!updated) {
            throw new Error('Update failed');
          }

          // Emit event if enabled
          if (!options.skipEvents && this.eventService) {
            const changes = ShardEventService.calculateChanges(existing, updated);
            await this.eventService.emit(ShardEventType.UPDATED, updated, {
              triggeredBy: userId,
              triggerSource: 'api',
              changes,
              previousState: existing.structuredData,
            });
          }

          result.results.push({
            index: i,
            status: 'updated',
            shardId: update.id,
            data: updated,
          });
          result.summary.succeeded++;
        } catch (error: any) {
          const errorCode = error.message === 'Shard not found'
            ? ShardErrorCode.SHARD_NOT_FOUND
            : error.message === 'Insufficient permissions'
            ? ShardErrorCode.INSUFFICIENT_PERMISSIONS
            : ShardErrorCode.SHARD_VALIDATION_FAILED;

          result.results.push({
            index: i,
            status: 'failed',
            shardId: update.id,
            error: {
              index: i,
              code: errorCode,
              message: error.message,
              shardId: update.id,
            },
          });
          result.summary.failed++;

          if (options.onError === 'abort') {
            result.success = false;
            break;
          }
        }
      }

      result.success = result.summary.failed === 0;
      const statusCode = result.success ? 200 : result.summary.succeeded > 0 ? 207 : 400;

      req.log.info({
        operation: 'bulk_update',
        total: result.summary.total,
        succeeded: result.summary.succeeded,
        failed: result.summary.failed,
        duration: Date.now() - startTime,
      });

      reply.status(statusCode).send(result);
    } catch (error: any) {
      req.log.error({ error }, 'Bulk update failed');
      reply.status(500).send({ error: 'Bulk update failed' });
    }
  };

  /**
   * DELETE /api/v1/shards/bulk
   * Bulk delete shards
   */
  bulkDelete = async (
    req: FastifyRequest<{ Body: BulkDeleteInput }>,
    reply: FastifyReply
  ): Promise<void> => {
    const startTime = Date.now();

    try {
      const { tenantId, userId } = req.auth as AuthContext || {};
      if (!tenantId || !userId) {
        reply.status(401).send({ error: 'Unauthorized' });
        return;
      }

      const { shardIds, options = {} } = req.body;

      if (!shardIds || shardIds.length === 0) {
        reply.status(400).send({ error: 'No shard IDs provided' });
        return;
      }

      if (shardIds.length > MAX_BULK_SIZE) {
        reply.status(400).send({
          error: `Maximum ${MAX_BULK_SIZE} shards allowed per request`,
          code: ShardErrorCode.BULK_OPERATION_LIMIT_EXCEEDED,
        });
        return;
      }

      const result: BulkOperationResult = {
        success: true,
        summary: { total: shardIds.length, succeeded: 0, failed: 0 },
        results: [],
      };

      for (let i = 0; i < shardIds.length; i++) {
        const shardId = shardIds[i];

        try {
          // Check permission
          const hasAccess = await this.repository.checkPermission(shardId, tenantId, userId);

          if (!hasAccess.hasAccess || !hasAccess.permissions.includes(PermissionLevel.DELETE)) {
            throw new Error('Insufficient permissions');
          }

          const existing = await this.repository.findById(shardId, tenantId);
          if (!existing) {
            throw new Error('Shard not found');
          }

          const deleted = await this.repository.delete(shardId, tenantId, options.hardDelete || false);

          if (!deleted) {
            throw new Error('Delete failed');
          }

          // Emit event if enabled
          if (!options.skipEvents && this.eventService) {
            await this.eventService.emit(ShardEventType.DELETED, existing, {
              triggeredBy: userId,
              triggerSource: 'api',
            });
          }

          result.results.push({
            index: i,
            status: 'deleted',
            shardId,
          });
          result.summary.succeeded++;
        } catch (error: any) {
          const errorCode = error.message === 'Shard not found'
            ? ShardErrorCode.SHARD_NOT_FOUND
            : error.message === 'Insufficient permissions'
            ? ShardErrorCode.INSUFFICIENT_PERMISSIONS
            : ShardErrorCode.SHARD_VALIDATION_FAILED;

          result.results.push({
            index: i,
            status: 'failed',
            shardId,
            error: {
              index: i,
              code: errorCode,
              message: error.message,
              shardId,
            },
          });
          result.summary.failed++;

          if (options.onError === 'abort') {
            result.success = false;
            break;
          }
        }
      }

      result.success = result.summary.failed === 0;
      const statusCode = result.success ? 200 : result.summary.succeeded > 0 ? 207 : 400;

      req.log.info({
        operation: 'bulk_delete',
        total: result.summary.total,
        succeeded: result.summary.succeeded,
        failed: result.summary.failed,
        duration: Date.now() - startTime,
      });

      reply.status(statusCode).send(result);
    } catch (error: any) {
      req.log.error({ error }, 'Bulk delete failed');
      reply.status(500).send({ error: 'Bulk delete failed' });
    }
  };

  /**
   * POST /api/v1/shards/bulk/restore
   * Bulk restore soft-deleted shards
   */
  bulkRestore = async (
    req: FastifyRequest<{ Body: BulkRestoreInput }>,
    reply: FastifyReply
  ): Promise<void> => {
    const startTime = Date.now();

    try {
      const { tenantId, userId } = req.auth as AuthContext || {};
      if (!tenantId || !userId) {
        reply.status(401).send({ error: 'Unauthorized' });
        return;
      }

      const { shardIds, options = {} } = req.body;

      if (!shardIds || shardIds.length === 0) {
        reply.status(400).send({ error: 'No shard IDs provided' });
        return;
      }

      if (shardIds.length > MAX_BULK_SIZE) {
        reply.status(400).send({
          error: `Maximum ${MAX_BULK_SIZE} shards allowed per request`,
          code: ShardErrorCode.BULK_OPERATION_LIMIT_EXCEEDED,
        });
        return;
      }

      const result: BulkOperationResult<Shard> = {
        success: true,
        summary: { total: shardIds.length, succeeded: 0, failed: 0 },
        results: [],
      };

      for (let i = 0; i < shardIds.length; i++) {
        const shardId = shardIds[i];

        try {
          // Check permission
          const hasAccess = await this.repository.checkPermission(shardId, tenantId, userId);

          if (!hasAccess.hasAccess || !hasAccess.permissions.includes(PermissionLevel.ADMIN)) {
            throw new Error('Insufficient permissions');
          }

          const restored = await this.repository.restore(shardId, tenantId);

          if (!restored) {
            throw new Error('Restore failed - shard not found or not deleted');
          }

          // Emit event if enabled
          if (!options.skipEvents && this.eventService) {
            await this.eventService.emit(ShardEventType.RESTORED, restored, {
              triggeredBy: userId,
              triggerSource: 'api',
            });
          }

          result.results.push({
            index: i,
            status: 'updated',
            shardId,
            data: restored,
          });
          result.summary.succeeded++;
        } catch (error: any) {
          const errorCode = error.message.includes('not found')
            ? ShardErrorCode.SHARD_NOT_FOUND
            : error.message === 'Insufficient permissions'
            ? ShardErrorCode.INSUFFICIENT_PERMISSIONS
            : ShardErrorCode.SHARD_RESTORE_FAILED;

          result.results.push({
            index: i,
            status: 'failed',
            shardId,
            error: {
              index: i,
              code: errorCode,
              message: error.message,
              shardId,
            },
          });
          result.summary.failed++;
        }
      }

      result.success = result.summary.failed === 0;
      const statusCode = result.success ? 200 : result.summary.succeeded > 0 ? 207 : 400;

      req.log.info({
        operation: 'bulk_restore',
        total: result.summary.total,
        succeeded: result.summary.succeeded,
        failed: result.summary.failed,
        duration: Date.now() - startTime,
      });

      reply.status(statusCode).send(result);
    } catch (error: any) {
      req.log.error({ error }, 'Bulk restore failed');
      reply.status(500).send({ error: 'Bulk restore failed' });
    }
  };

  /**
   * POST /api/v1/shards/:id/restore
   * Restore a single soft-deleted shard
   */
  restoreShard = async (
    req: FastifyRequest<{ Params: { id: string } }>,
    reply: FastifyReply
  ): Promise<void> => {
    try {
      const { tenantId, userId } = req.auth as AuthContext || {};
      if (!tenantId || !userId) {
        reply.status(401).send({ error: 'Unauthorized' });
        return;
      }

      const { id } = req.params;

      // Check permission
      const hasAccess = await this.repository.checkPermission(id, tenantId, userId);

      if (!hasAccess.hasAccess || !hasAccess.permissions.includes(PermissionLevel.ADMIN)) {
        reply.status(403).send({
          error: 'Insufficient permissions',
          code: ShardErrorCode.INSUFFICIENT_PERMISSIONS,
        });
        return;
      }

      const restored = await this.repository.restore(id, tenantId);

      if (!restored) {
        reply.status(404).send({
          error: 'Shard not found or not deleted',
          code: ShardErrorCode.SHARD_NOT_FOUND,
        });
        return;
      }

      // Emit event
      if (this.eventService) {
        await this.eventService.emit(ShardEventType.RESTORED, restored, {
          triggeredBy: userId,
          triggerSource: 'api',
        });
      }

      req.log.info({ shardId: id }, 'Shard restored');

      reply.status(200).send(restored);
    } catch (error: any) {
      req.log.error({ error }, 'Restore failed');
      reply.status(500).send({ error: 'Restore failed' });
    }
  };
}


