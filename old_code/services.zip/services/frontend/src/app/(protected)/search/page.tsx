"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useTranslation } from "react-i18next"
import { Search as SearchIcon, Filter, X, Sparkles, Clock } from "lucide-react"

import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Skeleton } from "@/components/ui/skeleton"
import { useVectorSearchShards } from "@/hooks/use-shards"
import { useActiveShardTypes } from "@/hooks/use-shard-types"
import { format } from "date-fns"

export default function SearchPage() {
  const { t } = useTranslation('common')
  const router = useRouter()
  const [query, setQuery] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const [shardTypeFilter, setShardTypeFilter] = useState<string>("")
  const [minScore, setMinScore] = useState<number>(0)
  const [searchHistory, setSearchHistory] = useState<string[]>([])

  const { data: shardTypesData, isLoading: typesLoading } = useActiveShardTypes()
  const shardTypes = shardTypesData?.items ?? []

  const { data: results, isLoading: searchLoading } = useVectorSearchShards(
    searchQuery,
    {
      limit: 20,
      shardTypeId: shardTypeFilter || undefined,
      minScore: minScore / 100,
      enabled: searchQuery.length > 0,
    }
  )

  const handleSearch = () => {
    if (query.trim()) {
      setSearchQuery(query)
      // Add to search history if not already present
      if (!searchHistory.includes(query)) {
        setSearchHistory([query, ...searchHistory.slice(0, 9)])
      }
    }
  }

  const handleClearFilters = () => {
    setShardTypeFilter("")
    setMinScore(0)
  }

  const handleHistoryClick = (historyQuery: string) => {
    setQuery(historyQuery)
    setSearchQuery(historyQuery)
  }

  const handleResultClick = (shardId: string) => {
    router.push(`/shards/${shardId}`)
  }

  const isFiltering = shardTypeFilter || minScore > 0

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <Sparkles className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold tracking-tight">{t('search.title')}</h1>
        </div>
        <p className="text-muted-foreground mt-1">
          {t('search.subtitle')}
        </p>
      </div>

      {/* Search Input */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={t('search.placeholder')}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                className="pl-10"
              />
            </div>
            <Button onClick={handleSearch} disabled={searchLoading || !query.trim()}>
              {searchLoading ? (
                <>
                  <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent" />
                  {t('search.searching')}
                </>
              ) : (
                <>
                  <SearchIcon className="mr-2 h-4 w-4" />
                  {t('search')}
                </>
              )}
            </Button>
          </div>

          {/* Search History */}
          {searchHistory.length > 0 && !searchQuery && (
            <div className="mt-4">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <p className="text-sm font-medium text-muted-foreground">{t('search.recentSearches')}</p>
              </div>
              <div className="flex flex-wrap gap-2">
                {searchHistory.map((historyItem, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    onClick={() => handleHistoryClick(historyItem)}
                    className="h-7 text-xs"
                  >
                    {historyItem}
                  </Button>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Filters */}
      {searchQuery && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4" />
                <CardTitle className="text-base">{t('search.filters')}</CardTitle>
              </div>
              {isFiltering && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleClearFilters}
                  className="h-7 text-xs"
                >
                  <X className="mr-1 h-3 w-3" />
                  {t('search.clearFilters')}
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Shard Type Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium">{t('search.shardType')}</label>
                <Select value={shardTypeFilter} onValueChange={setShardTypeFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder={t('search.allTypes')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">{t('search.allTypes')}</SelectItem>
                    {!typesLoading &&
                      shardTypes.map((type) => (
                        <SelectItem key={type.id} value={type.id}>
                          {type.displayName || type.name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Minimum Score Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium">
                  {t('search.minRelevance')}: {minScore}%
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="5"
                  value={minScore}
                  onChange={(e) => setMinScore(parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search Results */}
      {searchLoading && (
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i}>
              <CardContent className="pt-6">
                <div className="space-y-3">
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-2/3" />
                  <div className="flex gap-2">
                    <Skeleton className="h-5 w-16" />
                    <Skeleton className="h-5 w-16" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {!searchLoading && results && (
        <div className="space-y-4">
          {/* Results Summary */}
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              {t('search.found')} <span className="font-semibold">{results.total}</span> {t('results')}
              {shardTypeFilter && ` ${t('search.resultsWithFilters')}`}
            </p>
            {results.total > 0 && (
              <p className="text-xs text-muted-foreground">
                {t('search.sortedByRelevance')}
              </p>
            )}
          </div>

          {/* Results List */}
            {results.items.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8">
                  <SearchIcon className="mx-auto h-12 w-12 text-muted-foreground/50" />
                  <h3 className="mt-4 text-lg font-semibold">{t('search.noResults')}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">
                    {t('search.noResultsHint')}
                  </p>
                </div>
              </CardContent>
            </Card>
          ) : (
            results.items.map((result) => (
              <Card
                key={result.id}
                className="cursor-pointer hover:bg-accent/50 transition-colors"
                onClick={() => handleResultClick(result.id)}
              >
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      {/* Title */}
                      <h3 className="font-semibold text-lg mb-2">{result.name}</h3>

                      {/* Content Preview */}
                      <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                        {result.content || result.description || "No content available"}
                      </p>

                      {/* Metadata */}
                      <div className="flex flex-wrap gap-2 items-center">
                        {result.shardType && (
                          <Badge variant="outline">{result.shardType.name}</Badge>
                        )}
                        {result.tags?.slice(0, 3).map((tag) => (
                          <Badge key={tag} variant="secondary">
                            {tag}
                          </Badge>
                        ))}
                        {result.tags && result.tags.length > 3 && (
                          <Badge variant="secondary">
                            {t('search.more', { count: result.tags.length - 3 })}
                          </Badge>
                        )}
                        <Separator orientation="vertical" className="h-4" />
                        <span className="text-xs text-muted-foreground">
                          {format(new Date(result.createdAt), "MMM d, yyyy")}
                        </span>
                      </div>
                    </div>

                    {/* Relevance Score */}
                    <div className="flex-shrink-0">
                      <div className="text-center">
                        <Badge
                          variant="default"
                          className={
                            result.score > 0.8
                              ? "bg-green-500 hover:bg-green-600"
                              : result.score > 0.6
                                ? "bg-blue-500 hover:bg-blue-600"
                                : "bg-yellow-500 hover:bg-yellow-600"
                          }
                        >
                          {(result.score * 100).toFixed(0)}%
                        </Badge>
                        <p className="text-xs text-muted-foreground mt-1">{t('search.match')}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}

      {/* Empty State (no search yet) */}
      {!searchQuery && !searchLoading && (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-12">
              <Sparkles className="mx-auto h-16 w-16 text-muted-foreground/50" />
              <h3 className="mt-4 text-lg font-semibold">{t('search.startSearching')}</h3>
              <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto">
                {t('search.startSearchingHint')}
              </p>
              <div className="mt-6 space-y-2">
                <p className="text-xs text-muted-foreground font-medium">{t('search.exampleSearches')}</p>
                <div className="flex flex-wrap gap-2 justify-center">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setQuery("documents about machine learning")
                      handleSearch()
                    }}
                  >
                    documents about machine learning
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setQuery("customer feedback")
                      handleSearch()
                    }}
                  >
                    customer feedback
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setQuery("technical specifications")
                      handleSearch()
                    }}
                  >
                    technical specifications
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
