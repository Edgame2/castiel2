module.exports=[72284,(a,b,c)=>{}];

//# sourceMappingURL=c2a1c_frontend__next-internal_server_app_%28protected%29_shards_new_page_actions_e2b244cd.js.map