module.exports=[50971,(a,b,c)=>{}];

//# sourceMappingURL=c2a1c_frontend__next-internal_server_app_%28public%29_accessibility_page_actions_302ade74.js.map