module.exports=[71087,(e,o,d)=>{}];

//# sourceMappingURL=services_frontend__next-internal_server_app_favicon_ico_route_actions_dafd4e2a.js.map