/**
 * Schema Migration Types
 * 
 * Types for handling schema evolution and migrations
 */

/**
 * Schema migration strategy
 */
export enum MigrationStrategy {
  LAZY = 'lazy',       // Migrate on read
  EAGER = 'eager',     // Migrate all at once
  MANUAL = 'manual',   // Require explicit migration
  VERSIONED = 'versioned', // Keep multiple versions
}

/**
 * Field transformation types
 */
export enum TransformationType {
  RENAME = 'rename',
  DELETE = 'delete',
  ADD = 'add',
  CHANGE_TYPE = 'change_type',
  MOVE = 'move',
  MERGE = 'merge',
  SPLIT = 'split',
  COMPUTE = 'compute',
}

/**
 * Field transformation definition
 */
export interface FieldTransformation {
  type: TransformationType;
  sourcePath?: string;      // Source field path (e.g., "structuredData.oldField")
  targetPath?: string;      // Target field path
  defaultValue?: any;       // Default value for new fields
  transformer?: string;     // Name of custom transformer function
  config?: Record<string, any>; // Additional configuration
}

/**
 * Schema migration definition
 */
export interface SchemaMigration {
  id: string;
  shardTypeId: string;
  fromVersion: number;
  toVersion: number;
  description: string;
  
  // Transformations
  transformations: FieldTransformation[];
  
  // Validation
  preValidation?: string;   // JSON Schema to validate before migration
  postValidation?: string;  // JSON Schema to validate after migration
  
  // Execution
  strategy: MigrationStrategy;
  batchSize?: number;       // For eager migrations
  
  // Rollback
  reversible: boolean;
  rollbackTransformations?: FieldTransformation[];
  
  // Metadata
  createdAt: Date;
  createdBy: string;
  executedAt?: Date;
  status: MigrationStatus;
}

/**
 * Migration status
 */
export enum MigrationStatus {
  PENDING = 'pending',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
  FAILED = 'failed',
  ROLLED_BACK = 'rolled_back',
}

/**
 * Migration execution result
 */
export interface MigrationResult {
  migrationId: string;
  success: boolean;
  shardsProcessed: number;
  shardsSucceeded: number;
  shardsFailed: number;
  errors: Array<{
    shardId: string;
    error: string;
  }>;
  startedAt: Date;
  completedAt?: Date;
  duration?: number;
}

/**
 * Schema version info
 */
export interface SchemaVersionInfo {
  shardTypeId: string;
  currentVersion: number;
  latestVersion: number;
  migrations: Array<{
    fromVersion: number;
    toVersion: number;
    status: MigrationStatus;
    description: string;
  }>;
  shardsPerVersion: Record<number, number>;
}

/**
 * Create migration input
 */
export interface CreateMigrationInput {
  shardTypeId: string;
  fromVersion: number;
  toVersion: number;
  description: string;
  transformations: FieldTransformation[];
  strategy?: MigrationStrategy;
  batchSize?: number;
  reversible?: boolean;
  rollbackTransformations?: FieldTransformation[];
}

/**
 * Migration execution options
 */
export interface MigrationExecutionOptions {
  dryRun?: boolean;
  batchSize?: number;
  continueOnError?: boolean;
  notifyOnCompletion?: boolean;
}

/**
 * Shard migration state (for tracking lazy migrations)
 */
export interface ShardMigrationState {
  shardId: string;
  tenantId: string;
  shardTypeId: string;
  originalVersion: number;
  currentVersion: number;
  migrationsApplied: string[];
  lastMigratedAt?: Date;
  requiresManualReview?: boolean;
  migrationErrors?: string[];
}


