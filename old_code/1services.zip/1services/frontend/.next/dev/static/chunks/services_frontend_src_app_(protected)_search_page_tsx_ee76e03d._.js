(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/services_frontend_src_66821bbd._.js",
  "static/chunks/node_modules__pnpm_069326d8._.js"
],
    source: "dynamic"
});
