import {
  CosmosClient,
  Container,
  IndexingPolicy,
  ContainerDefinition,
  VectorEmbeddingDataType,
  VectorEmbeddingDistanceFunction
} from '@azure/cosmos';
import { IMonitoringProvider } from '@castiel/monitoring';
import { config } from '../config/env.js';
import {
  Shard,
  CreateShardInput,
  UpdateShardInput,
  ShardListOptions,
  ShardListResult,
  ShardStatus,
  PermissionCheckResult,
  PermissionLevel,
} from '../types/shard.types.js';
import type { ShardCacheService } from '../services/shard-cache.service.js';
import type { AzureServiceBusService } from '../services/azure-service-bus.service.js';
import type { EmbeddingJobMessage } from '../types/embedding-job.types.js';
import { v4 as uuidv4 } from 'uuid';

/**
 * Cosmos DB container configuration for Shards
 * Includes vector indexing policy and query indexes
 */
const SHARD_CONTAINER_CONFIG: ContainerDefinition = {
  id: config.cosmosDb.containers.shards,
  partitionKey: {
    paths: ['/tenantId'],
  },
  indexingPolicy: {
    automatic: true,
    indexingMode: 'consistent',
    includedPaths: [
      {
        path: '/*',
      },
    ],
    excludedPaths: [
      {
        path: '/unstructuredData/*', // Don't index large unstructured data
      },
      {
        path: '/_etag/?', // System property, no need to index
      },
    ],
    compositeIndexes: [
      [
        { path: '/tenantId', order: 'ascending' },
        { path: '/createdAt', order: 'descending' },
      ],
      [
        { path: '/tenantId', order: 'ascending' },
        { path: '/userId', order: 'ascending' },
        { path: '/createdAt', order: 'descending' },
      ],
      [
        { path: '/tenantId', order: 'ascending' },
        { path: '/shardTypeId', order: 'ascending' },
        { path: '/createdAt', order: 'descending' },
      ],
      [
        { path: '/tenantId', order: 'ascending' },
        { path: '/status', order: 'ascending' },
        { path: '/updatedAt', order: 'descending' },
      ],
    ],
  } as IndexingPolicy,
  vectorEmbeddingPolicy: {
    vectorEmbeddings: [
      {
        path: '/vectors/embedding',
        dataType: VectorEmbeddingDataType.Float32,
        dimensions: 1536,
        distanceFunction: VectorEmbeddingDistanceFunction.Cosine,
      },
    ],
  },
  // TTL for soft-deleted shards (90 days)
  defaultTtl: -1, // Disabled by default, will set per document
};

/**
 * Shard Repository
 * Handles all Cosmos DB operations for Shards
 */
export class ShardRepository {
  private client: CosmosClient;
  private container: Container;
  private monitoring: IMonitoringProvider;
  private cacheService?: ShardCacheService;

  constructor(
    monitoring: IMonitoringProvider,
    cacheService?: ShardCacheService,
    private readonly serviceBusService?: AzureServiceBusService
  ) {
    this.monitoring = monitoring;
    this.cacheService = cacheService;
    this.client = new CosmosClient({
      endpoint: config.cosmosDb.endpoint,
      key: config.cosmosDb.key,
    });
    this.container = this.client
      .database(config.cosmosDb.databaseId)
      .container(config.cosmosDb.containers.shards);
  }

  /**
   * Initialize container with proper indexing and vector search
   */
  async ensureContainer(): Promise<void> {
    try {
      const { database } = await this.client.databases.createIfNotExists({
        id: config.cosmosDb.databaseId,
      });

      await database.containers.createIfNotExists(
        SHARD_CONTAINER_CONFIG
      );

      this.monitoring.trackEvent('cosmosdb.container.ensured', {
        container: config.cosmosDb.containers.shards,
      });

      console.log(`[ShardRepository] Container '${config.cosmosDb.containers.shards}' ensured`);
    } catch (error) {
      this.monitoring.trackException(error as Error, {
        operation: 'shard.repository.ensureContainer',
      });
      throw error;
    }
  }

  /**
   * Create a new shard
   */
  async create(input: CreateShardInput): Promise<Shard> {
    const startTime = Date.now();

    try {
      // Use createdBy if provided, otherwise fall back to userId
      const creatorId = input.createdBy || input.userId;
      if (!creatorId) {
        throw new Error('Either createdBy or userId must be provided');
      }

      const shard: Shard = {
        id: uuidv4(),
        tenantId: input.tenantId,
        userId: creatorId,
        shardTypeId: input.shardTypeId,
        structuredData: input.structuredData,
        unstructuredData: input.unstructuredData,
        metadata: input.metadata,
        acl: input.acl || [
          {
            userId: creatorId,
            permissions: [PermissionLevel.READ, PermissionLevel.WRITE, PermissionLevel.DELETE, PermissionLevel.ADMIN],
            grantedBy: creatorId,
            grantedAt: new Date(),
          },
        ],
        enrichment: input.enrichment ? {
          config: input.enrichment,
        } : undefined,
        vectors: [],
        revisionId: uuidv4(),
        revisionNumber: 1,
        status: input.status || ShardStatus.ACTIVE,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const { resource } = await this.container.items.create(shard);

      const duration = Date.now() - startTime;
      this.monitoring.trackDependency(
        'cosmosdb.shard.create',
        'CosmosDB',
        config.cosmosDb.endpoint,
        duration,
        true
      );

      this.monitoring.trackEvent('shard.created', {
        shardId: shard.id,
        tenantId: shard.tenantId,
        shardTypeId: shard.shardTypeId,
      });

      // Cache the structured data
      if (this.cacheService) {
        await this.cacheService.cacheStructuredData(
          shard.tenantId,
          shard.id,
          shard.structuredData
        );
      }

      // Send embedding job to Service Bus if enabled
      if (this.serviceBusService && !input.skipEnqueueing && config.embeddingJob.enabled) {
        try {
          // Check if this shard type should be ignored
          if (!this.serviceBusService.isShardTypeIgnored(shard.shardTypeId)) {
            const dedupeKey = `shard-create-${shard.id}-${shard.revisionNumber}`;
            const embeddingJob: EmbeddingJobMessage = {
              shardId: shard.id,
              tenantId: shard.tenantId,
              shardTypeId: shard.shardTypeId,
              revisionNumber: shard.revisionNumber,
              dedupeKey,
              enqueuedAt: new Date().toISOString(),
            };

            await this.serviceBusService.sendEmbeddingJob(embeddingJob);
          }
        } catch (error) {
          // Log error but don't fail the shard creation
          this.monitoring?.log?.error?.({ error }, 'Failed to enqueue embedding job');
        }
      }

      return resource as Shard;
    } catch (error) {
      const duration = Date.now() - startTime;
      this.monitoring.trackDependency(
        'cosmosdb.shard.create',
        'CosmosDB',
        config.cosmosDb.endpoint,
        duration,
        false
      );

      this.monitoring.trackException(error as Error, {
        operation: 'shard.repository.create',
        tenantId: input.tenantId,
      });

      throw error;
    }
  }

  /**
   * Find shard by ID
   * Uses cache-aside pattern: check cache first, then database
   */
  async findById(id: string, tenantId: string): Promise<Shard | null> {
    const startTime = Date.now();

    try {
      // Try cache first if cache service is available
      if (this.cacheService) {
        const cachedStructuredData = await this.cacheService.getCachedStructuredData(tenantId, id);

        if (cachedStructuredData !== null) {
          // Cache hit - we still need to fetch the full document from DB
          // because cache only stores structuredData
          // But we know the shard exists, so we can proceed with the DB call
          this.monitoring.trackEvent('shard.cache.partialHit', {
            shardId: id,
            tenantId,
          });
        }
      }

      const { resource } = await this.container.item(id, tenantId).read<Shard>();

      const duration = Date.now() - startTime;
      this.monitoring.trackDependency(
        'cosmosdb.shard.findById',
        'CosmosDB',
        config.cosmosDb.endpoint,
        duration,
        true
      );

      if (!resource || resource.status === ShardStatus.DELETED) {
        return null;
      }

      // Cache the structured data for future requests
      if (this.cacheService) {
        await this.cacheService.cacheStructuredData(
          tenantId,
          id,
          resource.structuredData
        );
      }

      return resource;
    } catch (error: any) {
      const duration = Date.now() - startTime;

      if (error.code === 404) {
        this.monitoring.trackDependency(
          'cosmosdb.shard.findById',
          'CosmosDB',
          config.cosmosDb.endpoint,
          duration,
          true
        );
        return null;
      }

      this.monitoring.trackDependency(
        'cosmosdb.shard.findById',
        'CosmosDB',
        config.cosmosDb.endpoint,
        duration,
        false
      );

      this.monitoring.trackException(error as Error, {
        operation: 'shard.repository.findById',
        shardId: id,
        tenantId,
      });

      throw error;
    }
  }

  /**
   * Update shard
   */
  async update(id: string, tenantId: string, input: UpdateShardInput): Promise<Shard | null> {
    const startTime = Date.now();

    try {
      const existing = await this.findById(id, tenantId);
      if (!existing) {
        return null;
      }

      const updated: Shard = {
        ...existing,
        structuredData: input.structuredData ?? existing.structuredData,
        unstructuredData: input.unstructuredData ?? existing.unstructuredData,
        metadata: input.metadata ?? existing.metadata,
        acl: input.acl ?? existing.acl,
        enrichment: input.enrichment ?? existing.enrichment,
        status: input.status ?? existing.status,
        revisionId: uuidv4(),
        revisionNumber: existing.revisionNumber + 1,
        updatedAt: new Date(),
      };

      const { resource } = await this.container.item(id, tenantId).replace(updated);

      const duration = Date.now() - startTime;
      this.monitoring.trackDependency(
        'cosmosdb.shard.update',
        'CosmosDB',
        config.cosmosDb.endpoint,
        duration,
        true
      );

      this.monitoring.trackEvent('shard.updated', {
        shardId: id,
        tenantId,
        revisionNumber: updated.revisionNumber,
      });

      // Invalidate cache and publish event
      if (this.cacheService) {
        await this.cacheService.invalidateShardCache(tenantId, id, true);
      }

      // Send embedding job to Service Bus if enabled
      if (this.serviceBusService && config.embeddingJob.enabled) {
        try {
          // Check if this shard type should be ignored
          if (!this.serviceBusService.isShardTypeIgnored(updated.shardTypeId)) {
            const dedupeKey = `shard-update-${updated.id}-${updated.revisionNumber}`;
            const embeddingJob: EmbeddingJobMessage = {
              shardId: updated.id,
              tenantId: updated.tenantId,
              shardTypeId: updated.shardTypeId,
              revisionNumber: updated.revisionNumber,
              dedupeKey,
              enqueuedAt: new Date().toISOString(),
            };

            await this.serviceBusService.sendEmbeddingJob(embeddingJob);
          }
        } catch (error) {
          // Log error but don't fail the shard update
          this.monitoring?.log?.error?.({ error }, 'Failed to enqueue embedding job');
        }
      }

      return resource as Shard;
    } catch (error) {
      const duration = Date.now() - startTime;
      this.monitoring.trackDependency(
        'cosmosdb.shard.update',
        'CosmosDB',
        config.cosmosDb.endpoint,
        duration,
        false
      );

      this.monitoring.trackException(error as Error, {
        operation: 'shard.repository.update',
        shardId: id,
        tenantId,
      });

      throw error;
    }
  }

  /**
   * Soft delete shard
   * Sets status to DELETED and optionally sets TTL for automatic cleanup
   */
  async delete(id: string, tenantId: string, hardDelete = false): Promise<boolean> {
    const startTime = Date.now();

    try {
      if (hardDelete) {
        await this.container.item(id, tenantId).delete();
      } else {
        const existing = await this.findById(id, tenantId);
        if (!existing) {
          return false;
        }

        const deleted: Shard & { ttl?: number } = {
          ...existing,
          status: ShardStatus.DELETED,
          deletedAt: new Date(),
          updatedAt: new Date(),
          ttl: 7776000, // 90 days in seconds
        };

        await this.container.item(id, tenantId).replace(deleted);
      }

      const duration = Date.now() - startTime;
      this.monitoring.trackDependency(
        'cosmosdb.shard.delete',
        'CosmosDB',
        config.cosmosDb.endpoint,
        duration,
        true
      );

      this.monitoring.trackEvent('shard.deleted', {
        shardId: id,
        tenantId,
        hardDelete,
      });

      // Invalidate cache and publish event
      if (this.cacheService) {
        await this.cacheService.invalidateShardCache(tenantId, id, true);
      }

      return true;
    } catch (error: any) {
      const duration = Date.now() - startTime;

      if (error.code === 404) {
        return false;
      }

      this.monitoring.trackDependency(
        'cosmosdb.shard.delete',
        'CosmosDB',
        config.cosmosDb.endpoint,
        duration,
        false
      );

      this.monitoring.trackException(error as Error, {
        operation: 'shard.repository.delete',
        shardId: id,
        tenantId,
      });

      throw error;
    }
  }

  /**
   * Restore a soft-deleted shard
   */
  async restore(id: string, tenantId: string): Promise<Shard | null> {
    const startTime = Date.now();

    try {
      // Fetch the shard directly (including deleted ones)
      const { resource } = await this.container.item(id, tenantId).read<Shard & { ttl?: number }>();

      if (!resource) {
        return null;
      }

      // Check if actually deleted
      if (resource.status !== ShardStatus.DELETED) {
        return null; // Not deleted, nothing to restore
      }

      const restored: Shard & { ttl?: number } = {
        ...resource,
        status: ShardStatus.ACTIVE,
        deletedAt: undefined,
        updatedAt: new Date(),
        ttl: -1, // Remove TTL
      };

      // Remove TTL property entirely
      delete restored.ttl;

      const { resource: result } = await this.container.item(id, tenantId).replace(restored);

      const duration = Date.now() - startTime;
      this.monitoring.trackDependency(
        'cosmosdb.shard.restore',
        'CosmosDB',
        config.cosmosDb.endpoint,
        duration,
        true
      );

      this.monitoring.trackEvent('shard.restored', {
        shardId: id,
        tenantId,
      });

      // Invalidate cache
      if (this.cacheService) {
        await this.cacheService.invalidateShardCache(tenantId, id, true);
      }

      return result as Shard;
    } catch (error: any) {
      const duration = Date.now() - startTime;

      if (error.code === 404) {
        return null;
      }

      this.monitoring.trackDependency(
        'cosmosdb.shard.restore',
        'CosmosDB',
        config.cosmosDb.endpoint,
        duration,
        false
      );

      this.monitoring.trackException(error as Error, {
        operation: 'shard.repository.restore',
        shardId: id,
        tenantId,
      });

      throw error;
    }
  }

  /**
   * List shards with filtering and pagination
   */
  async list(options: ShardListOptions): Promise<ShardListResult> {
    const startTime = Date.now();

    try {
      const { filter, limit = 50, continuationToken, orderBy = 'createdAt', orderDirection = 'desc' } = options;

      // Build query
      let query = 'SELECT * FROM c WHERE c.tenantId = @tenantId AND c.status != @deletedStatus';
      const parameters: any[] = [
        { name: '@tenantId', value: filter?.tenantId },
        { name: '@deletedStatus', value: ShardStatus.DELETED },
      ];

      if (filter?.userId) {
        query += ' AND c.userId = @userId';
        parameters.push({ name: '@userId', value: filter.userId });
      }

      if (filter?.shardTypeId) {
        query += ' AND c.shardTypeId = @shardTypeId';
        parameters.push({ name: '@shardTypeId', value: filter.shardTypeId });
      }

      if (filter?.status) {
        query += ' AND c.status = @status';
        parameters.push({ name: '@status', value: filter.status });
      }

      if (filter?.createdAfter) {
        query += ' AND c.createdAt >= @createdAfter';
        parameters.push({ name: '@createdAfter', value: filter.createdAfter.toISOString() });
      }

      if (filter?.createdBefore) {
        query += ' AND c.createdAt <= @createdBefore';
        parameters.push({ name: '@createdBefore', value: filter.createdBefore.toISOString() });
      }

      query += ` ORDER BY c.${orderBy} ${orderDirection.toUpperCase()}`;

      const querySpec = {
        query,
        parameters,
      };

      const { resources, continuationToken: newContinuationToken } = await this.container.items
        .query(querySpec, {
          maxItemCount: limit,
          continuationToken,
        })
        .fetchNext();

      const duration = Date.now() - startTime;
      this.monitoring.trackDependency(
        'cosmosdb.shard.list',
        'CosmosDB',
        config.cosmosDb.endpoint,
        duration,
        true
      );

      return {
        shards: resources as Shard[],
        continuationToken: newContinuationToken,
        count: resources.length,
      };
    } catch (error) {
      const duration = Date.now() - startTime;
      this.monitoring.trackDependency(
        'cosmosdb.shard.list',
        'CosmosDB',
        config.cosmosDb.endpoint,
        duration,
        false
      );

      this.monitoring.trackException(error as Error, {
        operation: 'shard.repository.list',
        tenantId: options.filter?.tenantId,
      });

      throw error;
    }
  }

  /**
   * Check user permissions for a shard
   */
  async checkPermission(
    shardId: string,
    tenantId: string,
    userId: string
  ): Promise<PermissionCheckResult> {
    try {
      const shard = await this.findById(shardId, tenantId);
      if (!shard) {
        return { hasAccess: false, permissions: [] };
      }

      const aclEntry = shard.acl.find((entry) => entry.userId === userId);
      if (!aclEntry) {
        return { hasAccess: false, permissions: [] };
      }

      return {
        hasAccess: true,
        permissions: aclEntry.permissions,
      };
    } catch (error) {
      this.monitoring.trackException(error as Error, {
        operation: 'shard.repository.checkPermission',
        shardId,
        tenantId,
        userId,
      });

      return { hasAccess: false, permissions: [] };
    }
  }

  /**
   * Check if container is healthy
   */
  async healthCheck(): Promise<boolean> {
    try {
      await this.container.read();
      return true;
    } catch (error) {
      return false;
    }
  }
}
