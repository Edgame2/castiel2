/**
 * Webhook Routes
 * 
 * Routes for webhook management
 */

import type { FastifyInstance } from 'fastify';
import type { WebhookController } from '../controllers/webhook.controller.js';
import { ShardEventType } from '../types/shard-event.types.js';

const createWebhookSchema = {
  body: {
    type: 'object',
    required: ['name', 'url', 'events'],
    properties: {
      name: { type: 'string', minLength: 1, maxLength: 100 },
      description: { type: 'string', maxLength: 500 },
      url: { type: 'string', format: 'uri' },
      method: { type: 'string', enum: ['POST', 'PUT'] },
      headers: {
        type: 'object',
        additionalProperties: { type: 'string' },
      },
      events: {
        type: 'array',
        items: {
          type: 'string',
          enum: Object.values(ShardEventType),
        },
        minItems: 1,
      },
      filters: {
        type: 'object',
        properties: {
          shardTypeIds: { type: 'array', items: { type: 'string' } },
          status: { type: 'array', items: { type: 'string' } },
        },
      },
      retryCount: { type: 'integer', minimum: 0, maximum: 10 },
      retryDelayMs: { type: 'integer', minimum: 1000, maximum: 300000 },
      timeoutMs: { type: 'integer', minimum: 5000, maximum: 60000 },
    },
  },
};

const updateWebhookSchema = {
  params: {
    type: 'object',
    required: ['id'],
    properties: {
      id: { type: 'string' },
    },
  },
  body: {
    type: 'object',
    properties: {
      name: { type: 'string', minLength: 1, maxLength: 100 },
      description: { type: 'string', maxLength: 500 },
      url: { type: 'string', format: 'uri' },
      method: { type: 'string', enum: ['POST', 'PUT'] },
      headers: {
        type: 'object',
        additionalProperties: { type: 'string' },
      },
      events: {
        type: 'array',
        items: {
          type: 'string',
          enum: Object.values(ShardEventType),
        },
        minItems: 1,
      },
      filters: {
        type: 'object',
        properties: {
          shardTypeIds: { type: 'array', items: { type: 'string' } },
          status: { type: 'array', items: { type: 'string' } },
        },
      },
      retryCount: { type: 'integer', minimum: 0, maximum: 10 },
      retryDelayMs: { type: 'integer', minimum: 1000, maximum: 300000 },
      timeoutMs: { type: 'integer', minimum: 5000, maximum: 60000 },
      isActive: { type: 'boolean' },
    },
  },
};

const webhookIdSchema = {
  params: {
    type: 'object',
    required: ['id'],
    properties: {
      id: { type: 'string' },
    },
  },
};

const deliveriesQuerySchema = {
  params: {
    type: 'object',
    required: ['id'],
    properties: {
      id: { type: 'string' },
    },
  },
  querystring: {
    type: 'object',
    properties: {
      limit: { type: 'string', pattern: '^[0-9]+$' },
    },
  },
};

export function registerWebhookRoutes(
  server: FastifyInstance,
  webhookController: WebhookController
) {
  // List webhooks
  server.get(
    '/api/v1/webhooks',
    (request, reply) => webhookController.listWebhooks(request, reply)
  );

  // Get webhook
  server.get(
    '/api/v1/webhooks/:id',
    { schema: webhookIdSchema },
    (request, reply) => webhookController.getWebhook(request, reply)
  );

  // Create webhook
  server.post(
    '/api/v1/webhooks',
    { schema: createWebhookSchema },
    (request, reply) => webhookController.createWebhook(request, reply)
  );

  // Update webhook
  server.put(
    '/api/v1/webhooks/:id',
    { schema: updateWebhookSchema },
    (request, reply) => webhookController.updateWebhook(request, reply)
  );

  // Delete webhook
  server.delete(
    '/api/v1/webhooks/:id',
    { schema: webhookIdSchema },
    (request, reply) => webhookController.deleteWebhook(request, reply)
  );

  // Regenerate secret
  server.post(
    '/api/v1/webhooks/:id/regenerate-secret',
    { schema: webhookIdSchema },
    (request, reply) => webhookController.regenerateSecret(request, reply)
  );

  // Test webhook
  server.post(
    '/api/v1/webhooks/:id/test',
    { schema: webhookIdSchema },
    (request, reply) => webhookController.testWebhook(request, reply)
  );

  // Get delivery history
  server.get(
    '/api/v1/webhooks/:id/deliveries',
    { schema: deliveriesQuerySchema },
    (request, reply) => webhookController.getDeliveries(request, reply)
  );
}


