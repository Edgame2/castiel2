"use client"

import dynamic from 'next/dynamic'
import { useTranslation } from 'react-i18next'
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Skeleton } from "@/components/ui/skeleton"

// Lazy load admin components (heavy and rarely accessed)
const PlatformStats = dynamic(
  () => import("@/components/admin/platform-stats").then(mod => ({ default: mod.PlatformStats })),
  { loading: () => <Skeleton className="h-64" /> }
)
const TenantsList = dynamic(
  () => import("@/components/admin/tenants-list").then(mod => ({ default: mod.TenantsList })),
  { loading: () => <Skeleton className="h-96" /> }
)
const SystemHealth = dynamic(
  () => import("@/components/admin/system-health").then(mod => ({ default: mod.SystemHealth })),
  { loading: () => <Skeleton className="h-96" /> }
)
const SystemLogs = dynamic(
  () => import("@/components/admin/system-logs").then(mod => ({ default: mod.SystemLogs })),
  { loading: () => <Skeleton className="h-96" /> }
)

export default function AdminDashboard() {
  const { t } = useTranslation('common')
  
  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="space-y-0.5">
        <h2 className="text-3xl font-bold tracking-tight">{t('admin.title', 'Super Admin')}</h2>
        <p className="text-muted-foreground">
          {t('admin.subtitle', 'Platform-wide administration and monitoring')}
        </p>
      </div>

      <PlatformStats />

      <Tabs defaultValue="tenants" className="space-y-4">
        <TabsList>
          <TabsTrigger value="tenants">{t('admin.tabs.tenants', 'Tenants')}</TabsTrigger>
          <TabsTrigger value="health">{t('admin.tabs.health', 'System Health')}</TabsTrigger>
          <TabsTrigger value="logs">{t('admin.tabs.logs', 'System Logs')}</TabsTrigger>
        </TabsList>

        <TabsContent value="tenants" className="space-y-4">
          <TenantsList />
        </TabsContent>

        <TabsContent value="health" className="space-y-4">
          <SystemHealth />
        </TabsContent>

        <TabsContent value="logs" className="space-y-4">
          <SystemLogs />
        </TabsContent>
      </Tabs>
    </div>
  )
}
