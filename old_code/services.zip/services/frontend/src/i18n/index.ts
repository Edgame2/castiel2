export { default as i18n, languages, defaultNS, namespaces } from './config'
export type { LanguageCode } from './config'


