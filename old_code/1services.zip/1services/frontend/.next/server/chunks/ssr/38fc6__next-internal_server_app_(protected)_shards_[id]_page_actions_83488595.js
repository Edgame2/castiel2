module.exports=[85210,(a,b,c)=>{}];

//# sourceMappingURL=38fc6__next-internal_server_app_%28protected%29_shards_%5Bid%5D_page_actions_83488595.js.map