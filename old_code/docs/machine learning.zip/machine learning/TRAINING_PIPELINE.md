# Training Pipeline for Risk Analysis ML

## Overview

The training pipeline orchestrates the end-to-end process of preparing training data, training ML models, fine-tuning LLMs, and evaluating model performance. This document describes the training workflows, data preparation, and job orchestration.

## Training Pipeline Architecture

```mermaid
flowchart TB
    subgraph "Data Preparation"
        DS[Data Source<br/>Risk Snapshots]
        FE[Feature Extraction]
        DP[Data Processing]
        VS[Validation & Splitting]
    end
    
    subgraph "Model Training"
        RS[Risk Scoring Model]
        OP[Outcome Prediction Model]
        MR[Mitigation Recommendation Model]
    end
    
    subgraph "LLM Fine-tuning"
        LLMDP[LLM Data Prep]
        LLMFT[Fine-tuning Job]
        LLMEVAL[LLM Evaluation]
    end
    
    subgraph "Evaluation"
        EVAL[Model Evaluation]
        METRICS[Metrics Calculation]
        COMPARE[Model Comparison]
    end
    
    subgraph "Deployment"
        REG[Model Registry]
        AB[A/B Testing Setup]
        DEPLOY[Deploy to Production]
    end
    
    DS --> FE
    FE --> DP
    DP --> VS
    VS --> RS
    VS --> OP
    VS --> MR
    VS --> LLMDP
    LLMDP --> LLMFT
    LLMFT --> LLMEVAL
    RS --> EVAL
    OP --> EVAL
    MR --> EVAL
    EVAL --> METRICS
    METRICS --> COMPARE
    COMPARE --> REG
    REG --> AB
    AB --> DEPLOY
```

## Training Data Preparation

### Step 1: Data Collection

```typescript
async function collectTrainingData(
  options: TrainingDataOptions
): Promise<RiskSnapshot[]> {
  const {
    tenantId,
    startDate,
    endDate,
    minSnapshots = 1000,
    includeOutcomes = true
  } = options;
  
  // Query risk snapshots
  const snapshots = await shardRepository.query({
    shardTypeId: 'c_risk_snapshot',
    tenantId,
    filters: {
      createdAt: {
        $gte: startDate,
        $lte: endDate
      }
    },
    orderBy: 'createdAt',
    limit: 10000
  });
  
  // Filter for opportunities with outcomes (if required)
  if (includeOutcomes) {
    const withOutcomes = await filterSnapshotsWithOutcomes(snapshots);
    if (withOutcomes.length < minSnapshots) {
      throw new Error(
        `Insufficient training data: ${withOutcomes.length} < ${minSnapshots}`
      );
    }
    return withOutcomes;
  }
  
  return snapshots;
}
```

### Step 2: Feature Extraction

```typescript
async function extractTrainingFeatures(
  snapshots: RiskSnapshot[]
): Promise<TrainingExample[]> {
  const examples: TrainingExample[] = [];
  
  for (const snapshot of snapshots) {
    try {
      // Extract features at snapshot time
      const features = await featureStore.extractFeaturesAtTime(
        snapshot.opportunityId,
        snapshot.tenantId,
        snapshot.snapshotDate
      );
      
      // Get labels from snapshot and outcome
      const outcome = await getOutcome(snapshot.opportunityId);
      const labels = {
        actualRiskScore: snapshot.riskScore,
        actualOutcome: outcome?.result || null,
        actualRevenueAtRisk: snapshot.revenueAtRisk,
        actualMitigationEffectiveness: outcome?.mitigationEffectiveness
      };
      
      examples.push({
        id: snapshot.id,
        opportunityId: snapshot.opportunityId,
        tenantId: snapshot.tenantId,
        snapshotDate: snapshot.snapshotDate,
        features,
        labels,
        createdAt: snapshot.createdAt,
        outcomeDate: outcome?.date
      });
    } catch (error) {
      // Log error but continue processing
      monitoring.trackException(error, {
        operation: 'training.extractFeatures',
        snapshotId: snapshot.id
      });
    }
  }
  
  return examples;
}
```

### Step 3: Data Validation & Cleaning

```typescript
function validateAndCleanData(
  examples: TrainingExample[]
): TrainingExample[] {
  return examples
    .filter(example => {
      // Remove examples with missing critical features
      if (!example.features.dealValue || !example.features.probability) {
        return false;
      }
      
      // Remove examples with invalid values
      if (
        example.features.probability < 0 ||
        example.features.probability > 100
      ) {
        return false;
      }
      
      // Remove examples with NaN or Infinity
      for (const value of Object.values(example.features)) {
        if (typeof value === 'number' && (isNaN(value) || !isFinite(value))) {
          return false;
        }
      }
      
      return true;
    })
    .map(example => {
      // Handle missing values
      return {
        ...example,
        features: handleMissingValues(example.features)
      };
    });
}
```

### Step 4: Data Splitting

```typescript
function splitData(
  examples: TrainingExample[],
  splits: { train: number; validation: number; test: number }
): DataSplits {
  // Shuffle data
  const shuffled = shuffleArray([...examples]);
  
  // Calculate split indices
  const total = shuffled.length;
  const trainEnd = Math.floor(total * splits.train);
  const valEnd = trainEnd + Math.floor(total * splits.validation);
  
  return {
    train: shuffled.slice(0, trainEnd),
    validation: shuffled.slice(trainEnd, valEnd),
    test: shuffled.slice(valEnd)
  };
}
```

### Step 5: Data Balancing

```typescript
function balanceData(
  examples: TrainingExample[],
  strategy: 'undersample' | 'oversample' | 'smote'
): TrainingExample[] {
  // For outcome prediction, balance won/lost classes
  const won = examples.filter(e => e.labels.actualOutcome === 'won');
  const lost = examples.filter(e => e.labels.actualOutcome === 'lost');
  
  if (strategy === 'undersample') {
    // Undersample majority class
    const minCount = Math.min(won.length, lost.length);
    return [
      ...shuffleArray(won).slice(0, minCount),
      ...shuffleArray(lost).slice(0, minCount)
    ];
  } else if (strategy === 'oversample') {
    // Oversample minority class
    const maxCount = Math.max(won.length, lost.length);
    const minority = won.length < lost.length ? won : lost;
    const majority = won.length < lost.length ? lost : won;
    
    const oversampled = [];
    for (let i = 0; i < maxCount; i++) {
      oversampled.push(minority[i % minority.length]);
    }
    
    return [...majority, ...oversampled];
  }
  
  // SMOTE or other advanced techniques
  return examples;
}
```

## Model Training

### Risk Scoring Model

**Type**: Regression  
**Algorithm**: XGBoost or LightGBM  
**Target**: Risk score (0-1)

```typescript
async function trainRiskScoringModel(
  trainingData: DataSplits
): Promise<TrainedModel> {
  const model = new XGBoostRegressor({
    objective: 'reg:squarederror',
    maxDepth: 6,
    learningRate: 0.1,
    nEstimators: 100,
    subsample: 0.8,
    colsampleBytree: 0.8
  });
  
  // Prepare features and labels
  const XTrain = trainingData.train.map(e => e.features);
  const yTrain = trainingData.train.map(e => e.labels.actualRiskScore);
  const XVal = trainingData.validation.map(e => e.features);
  const yVal = trainingData.validation.map(e => e.labels.actualRiskScore);
  
  // Train model
  await model.fit(XTrain, yTrain, {
    evalSet: [[XVal, yVal]],
    earlyStoppingRounds: 10
  });
  
  // Evaluate
  const predictions = await model.predict(XVal);
  const metrics = calculateRegressionMetrics(yVal, predictions);
  
  return {
    model,
    metrics,
    featureImportance: await model.getFeatureImportance()
  };
}
```

### Outcome Prediction Model

**Type**: Binary Classification  
**Algorithm**: XGBoost or Neural Network  
**Target**: Won probability (0-1)

```typescript
async function trainOutcomePredictionModel(
  trainingData: DataSplits
): Promise<TrainedModel> {
  const model = new XGBoostClassifier({
    objective: 'binary:logistic',
    maxDepth: 6,
    learningRate: 0.1,
    nEstimators: 100,
    evalMetric: 'auc'
  });
  
  // Prepare features and labels
  const XTrain = trainingData.train.map(e => e.features);
  const yTrain = trainingData.train.map(
    e => e.labels.actualOutcome === 'won' ? 1 : 0
  );
  const XVal = trainingData.validation.map(e => e.features);
  const yVal = trainingData.validation.map(
    e => e.labels.actualOutcome === 'won' ? 1 : 0
  );
  
  // Train model
  await model.fit(XTrain, yTrain, {
    evalSet: [[XVal, yVal]],
    earlyStoppingRounds: 10
  });
  
  // Evaluate
  const predictions = await model.predict(XVal);
  const metrics = calculateClassificationMetrics(yVal, predictions);
  
  return {
    model,
    metrics,
    featureImportance: await model.getFeatureImportance()
  };
}
```

### Mitigation Recommendation Model

**Type**: Multi-class Classification or Ranking  
**Algorithm**: XGBoost or Transformer-based  
**Target**: Ranked list of mitigation actions

```typescript
async function trainMitigationRecommendationModel(
  trainingData: DataSplits
): Promise<TrainedModel> {
  // Prepare data with mitigation effectiveness
  const trainingExamples = trainingData.train.map(example => {
    const mitigations = example.labels.actualMitigationEffectiveness || {};
    const rankedMitigations = Object.entries(mitigations)
      .sort(([, a], [, b]) => b - a)
      .map(([action]) => action);
    
    return {
      features: example.features,
      detectedRisks: example.features.detectedRisks,
      targetMitigations: rankedMitigations
    };
  });
  
  // Train ranking model
  const model = new XGBoostRanker({
    objective: 'rank:pairwise',
    maxDepth: 6,
    learningRate: 0.1
  });
  
  // Train and evaluate
  // ... training logic
  
  return {
    model,
    metrics,
    featureImportance: await model.getFeatureImportance()
  };
}
```

## LLM Fine-tuning

### Data Preparation for LLM Fine-tuning

```typescript
async function prepareLLMFineTuningData(
  snapshots: RiskSnapshot[]
): Promise<LLMTrainingExample[]> {
  const examples: LLMTrainingExample[] = [];
  
  for (const snapshot of snapshots) {
    const opportunity = await shardRepository.get(
      snapshot.opportunityId,
      snapshot.tenantId
    );
    
    // Format as prompt-completion pair
    const prompt = formatRiskAnalysisPrompt(opportunity, snapshot);
    const completion = formatRiskAnalysisCompletion(snapshot);
    
    examples.push({
      messages: [
        {
          role: 'system',
          content: 'You are a risk analysis expert. Analyze opportunities for potential risks.'
        },
        {
          role: 'user',
          content: prompt
        },
        {
          role: 'assistant',
          content: completion
        }
      ]
    });
  }
  
  return examples;
}

function formatRiskAnalysisPrompt(
  opportunity: Shard,
  snapshot: RiskSnapshot
): string {
  const data = opportunity.structuredData;
  return `Analyze this opportunity for potential risks.

Key data:
- Deal Value: ${data.value} ${data.currency}
- Probability: ${data.probability}%
- Stage: ${data.stage}
- Days to Close: ${calculateDaysToClose(data.closeDate)}
- Days Since Activity: ${calculateDaysSinceActivity(data.lastActivityAt)}

Related entities:
${formatRelatedEntities(opportunity)}

Identify risks and provide:
1. Risk IDs and categories
2. Confidence levels (0-1)
3. Explanations with evidence
4. Recommended mitigation actions`;
}

function formatRiskAnalysisCompletion(
  snapshot: RiskSnapshot
): string {
  const risks = snapshot.risks.map(risk => ({
    riskId: risk.riskId,
    riskName: risk.riskName,
    category: risk.category,
    confidence: risk.confidence,
    explanation: risk.explainability,
    mitigationActions: risk.mitigationActions || []
  }));
  
  return JSON.stringify({
    risks,
    overallRiskScore: snapshot.riskScore,
    categoryScores: snapshot.categoryScores
  }, null, 2);
}
```

### Fine-tuning Job

```typescript
async function startLLMFineTuning(
  trainingData: LLMTrainingExample[],
  options: FineTuningOptions
): Promise<FineTuningJob> {
  // Upload training data to Azure Blob Storage
  const dataPath = await uploadTrainingData(trainingData);
  
  // Create fine-tuning job via Azure OpenAI
  const job = await azureOpenAI.fineTuning.jobs.create({
    model: options.baseModel, // e.g., 'gpt-4', 'gpt-3.5-turbo'
    trainingFile: dataPath,
    hyperparameters: {
      nEpochs: options.epochs || 3,
      batchSize: options.batchSize || 4,
      learningRateMultiplier: options.learningRate || 1.0
    }
  });
  
  // Track job status
  await modelService.trackFineTuningJob({
    jobId: job.id,
    status: 'running',
    startedAt: new Date(),
    trainingDataSize: trainingData.length
  });
  
  return job;
}

async function monitorFineTuningJob(jobId: string): Promise<void> {
  const job = await azureOpenAI.fineTuning.jobs.retrieve(jobId);
  
  if (job.status === 'succeeded') {
    // Deploy fine-tuned model
    await deployFineTunedModel(job.fineTunedModel);
    
    // Update model registry
    await modelService.registerModel({
      modelType: 'llm_fine_tuned',
      version: generateVersion(),
      artifactPath: job.fineTunedModel,
      status: 'active',
      trainingDate: new Date()
    });
  } else if (job.status === 'failed') {
    // Log failure and alert
    monitoring.trackException(
      new Error(`Fine-tuning failed: ${job.error}`),
      { jobId }
    );
  }
}
```

## Hyperparameter Optimization

```typescript
async function optimizeHyperparameters(
  modelType: ModelType,
  trainingData: DataSplits
): Promise<OptimalHyperparameters> {
  const searchSpace = getSearchSpace(modelType);
  
  // Use Optuna or similar for hyperparameter optimization
  const study = optuna.createStudy({
    direction: 'maximize', // Maximize validation score
    studyName: `risk_ml_${modelType}_optimization`
  });
  
  for (let trial = 0; trial < 50; trial++) {
    const params = study.suggestParams(searchSpace);
    const model = await trainModelWithParams(modelType, trainingData, params);
    const score = model.metrics.validationScore;
    study.reportTrial(trial, score, params);
  }
  
  return study.getBestParams();
}

function getSearchSpace(modelType: ModelType): SearchSpace {
  if (modelType === 'risk_scoring') {
    return {
      maxDepth: { type: 'int', low: 3, high: 10 },
      learningRate: { type: 'float', low: 0.01, high: 0.3 },
      nEstimators: { type: 'int', low: 50, high: 200 },
      subsample: { type: 'float', low: 0.6, high: 1.0 }
    };
  }
  // ... other model types
}
```

## Model Evaluation

```typescript
async function evaluateModel(
  model: TrainedModel,
  testData: TrainingExample[]
): Promise<EvaluationResults> {
  const XTest = testData.map(e => e.features);
  const yTest = testData.map(e => e.labels);
  
  // Get predictions
  const predictions = await model.predict(XTest);
  
  // Calculate metrics
  const metrics = calculateMetrics(yTest, predictions, model.type);
  
  // Calculate feature importance
  const featureImportance = await model.getFeatureImportance();
  
  // Analyze errors
  const errorAnalysis = analyzeErrors(yTest, predictions);
  
  return {
    metrics,
    featureImportance,
    errorAnalysis,
    predictions: predictions.map((p, i) => ({
      actual: yTest[i],
      predicted: p,
      error: Math.abs(yTest[i] - p)
    }))
  };
}

function calculateMetrics(
  actual: number[],
  predicted: number[],
  modelType: ModelType
): Metrics {
  if (modelType === 'risk_scoring') {
    // Regression metrics
    return {
      mse: meanSquaredError(actual, predicted),
      mae: meanAbsoluteError(actual, predicted),
      r2Score: r2Score(actual, predicted),
      rmse: Math.sqrt(meanSquaredError(actual, predicted))
    };
  } else if (modelType === 'outcome_prediction') {
    // Classification metrics
    const binaryPredicted = predicted.map(p => p > 0.5 ? 1 : 0);
    return {
      accuracy: accuracy(actual, binaryPredicted),
      precision: precision(actual, binaryPredicted),
      recall: recall(actual, binaryPredicted),
      f1Score: f1Score(actual, binaryPredicted),
      auc: rocAuc(actual, predicted)
    };
  }
}
```

## Training Orchestration

### Training Service

```typescript
class TrainingService {
  async scheduleTraining(
    modelType: ModelType,
    options: TrainingOptions
  ): Promise<TrainingJob> {
    const job: TrainingJob = {
      id: generateId(),
      modelType,
      status: 'pending',
      createdAt: new Date(),
      options
    };
    
    // Store job
    await this.storeJob(job);
    
    // Queue training worker
    await this.queueTrainingWorker(job);
    
    return job;
  }
  
  async executeTraining(jobId: string): Promise<void> {
    const job = await this.getJob(jobId);
    
    try {
      // Update status
      await this.updateJobStatus(jobId, 'running');
      
      // Step 1: Collect training data
      const snapshots = await this.collectTrainingData(job.options);
      
      // Step 2: Extract features
      const examples = await this.extractTrainingFeatures(snapshots);
      
      // Step 3: Validate and clean
      const cleaned = this.validateAndCleanData(examples);
      
      // Step 4: Split data
      const splits = this.splitData(cleaned, {
        train: 0.7,
        validation: 0.15,
        test: 0.15
      });
      
      // Step 5: Train model
      let model: TrainedModel;
      if (job.modelType === 'llm_fine_tuned') {
        model = await this.trainLLM(splits);
      } else {
        model = await this.trainMLModel(job.modelType, splits);
      }
      
      // Step 6: Evaluate
      const evaluation = await this.evaluateModel(model, splits.test);
      
      // Step 7: Check if meets threshold
      if (this.meetsThreshold(evaluation.metrics, job.modelType)) {
        // Step 8: Register model
        await this.modelService.registerModel({
          ...model,
          evaluation
        });
        
        await this.updateJobStatus(jobId, 'completed');
      } else {
        await this.updateJobStatus(jobId, 'failed', {
          reason: 'Metrics below threshold',
          metrics: evaluation.metrics
        });
      }
    } catch (error) {
      await this.updateJobStatus(jobId, 'failed', { error });
      throw error;
    }
  }
}
```

## Scheduled Training

```typescript
// Weekly training schedule
async function scheduleWeeklyTraining(): Promise<void> {
  const lastWeek = new Date();
  lastWeek.setDate(lastWeek.getDate() - 7);
  
  // Schedule training for all model types
  for (const modelType of ['risk_scoring', 'outcome_prediction', 'mitigation_recommendation']) {
    await trainingService.scheduleTraining(modelType, {
      startDate: lastWeek,
      endDate: new Date(),
      minSnapshots: 100
    });
  }
  
  // Schedule LLM fine-tuning monthly
  if (isFirstWeekOfMonth()) {
    await trainingService.scheduleTraining('llm_fine_tuned', {
      startDate: getLastMonth(),
      endDate: new Date(),
      minSnapshots: 500
    });
  }
}
```

## Training Workers

Background workers execute training jobs:

```typescript
// Azure Function or dedicated worker
export async function riskMLTrainingWorker(
  context: ExecutionContext,
  jobMessage: TrainingJobMessage
): Promise<void> {
  const trainingService = new TrainingService(/* dependencies */);
  
  try {
    await trainingService.executeTraining(jobMessage.jobId);
  } catch (error) {
    // Log and retry
    context.log.error('Training failed', error);
    throw error; // Trigger retry
  }
}
```

## Best Practices

1. **Data Quality**: Always validate and clean training data
2. **Reproducibility**: Use fixed random seeds, version control training code
3. **Monitoring**: Track training metrics, data quality, and model performance
4. **Incremental Training**: Use incremental training when possible for efficiency
5. **A/B Testing**: Always A/B test new models before full deployment
6. **Rollback Plan**: Maintain ability to rollback to previous model versions
