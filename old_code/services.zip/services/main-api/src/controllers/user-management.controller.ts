import type { FastifyReply, FastifyRequest } from 'fastify';
import { UserManagementService } from '../services/auth/user-management.service.js';
import { CacheManager } from '../cache/manager.js';
import { SessionManagementService } from '../services/auth/session-management.service.js';
import type {
  ImpersonateUserRequest,
  ImpersonateUserResponse,
  UserResponse,
} from '../types/user-management.types.js';
import type { AuthenticatedRequest, AuthUser } from '../types/auth.types.js';
import { ForbiddenError, UnauthorizedError } from '../middleware/error-handler.js';

interface ImpersonateUserParams {
  tenantId: string;
  userId: string;
}

interface UpdateStatusParams {
  userId: string;
}

interface UpdateStatusBody {
  status: 'active' | 'suspended' | 'pending_verification' | 'pending_approval' | 'deleted';
}

interface BulkOperationBody {
  action: 'activate' | 'deactivate' | 'delete' | 'add-role' | 'remove-role' | 'send-password-reset';
  userIds: string[];
  role?: string;
}

export class UserManagementController {
  constructor(
    private readonly userManagementService: UserManagementService,
    private readonly cacheManager: CacheManager
  ) { }

  /**
   * PATCH /api/users/:userId/status
   * Update user status (active, suspended, etc.)
   */
  async updateUserStatus(
    request: FastifyRequest<{ Params: UpdateStatusParams; Body: UpdateStatusBody }>,
    reply: FastifyReply
  ) {
    try {
      const { userId } = request.params;
      const { status } = request.body;
      const adminUser = (request as AuthenticatedRequest).user as AuthUser | undefined;

      if (!adminUser) {
        throw new UnauthorizedError('Authentication required');
      }

      // Update the user status
      const updatedUser = await this.userManagementService.updateUserStatus(userId, status, adminUser);

      if (!updatedUser) {
        return reply.code(404).send({
          error: 'Not Found',
          message: 'User not found',
        });
      }

      // Log the status change
      (request.server as any).monitoring?.trackEvent?.('user.status.changed', {
        userId,
        newStatus: status,
        changedBy: adminUser.id,
        tenantId: adminUser.tenantId,
      });

      return reply.code(200).send({
        message: `User status updated to ${status}`,
        user: {
          id: updatedUser.id,
          email: updatedUser.email,
          status: updatedUser.status,
        },
      });
    } catch (error) {
      if (error instanceof ForbiddenError || error instanceof UnauthorizedError) {
        throw error;
      }

      request.log.error({ err: error }, 'Failed to update user status');

      return reply.code(500).send({
        error: 'Internal Server Error',
        message: 'Failed to update user status',
      });
    }
  }

  /**
   * POST /api/tenants/:tenantId/users/bulk
   * Perform bulk operations on multiple users
   */
  async bulkOperation(
    request: FastifyRequest<{ Params: { tenantId: string }; Body: BulkOperationBody }>,
    reply: FastifyReply
  ) {
    try {
      const { tenantId } = request.params;
      const { action, userIds, role } = request.body;
      const adminUser = (request as AuthenticatedRequest).user as AuthUser | undefined;

      if (!adminUser) {
        throw new UnauthorizedError('Authentication required');
      }

      const results: { userId: string; success: boolean; error?: string }[] = [];
      let successCount = 0;
      let failureCount = 0;

      for (const userId of userIds) {
        try {
          switch (action) {
            case 'activate':
              await this.userManagementService.updateUserStatus(userId, 'active', adminUser);
              results.push({ userId, success: true });
              successCount++;
              break;

            case 'deactivate':
              await this.userManagementService.updateUserStatus(userId, 'suspended', adminUser);
              results.push({ userId, success: true });
              successCount++;
              break;

            case 'delete':
              await this.userManagementService.updateUserStatus(userId, 'deleted', adminUser);
              results.push({ userId, success: true });
              successCount++;
              break;

            case 'add-role':
              if (!role) {
                results.push({ userId, success: false, error: 'Role not specified' });
                failureCount++;
                break;
              }
              await this.userManagementService.addRoleToUser(userId, tenantId, role);
              results.push({ userId, success: true });
              successCount++;
              break;

            case 'remove-role':
              if (!role) {
                results.push({ userId, success: false, error: 'Role not specified' });
                failureCount++;
                break;
              }
              await this.userManagementService.removeRoleFromUser(userId, tenantId, role);
              results.push({ userId, success: true });
              successCount++;
              break;

            case 'send-password-reset':
              await this.userManagementService.adminPasswordReset(tenantId, userId, true);
              results.push({ userId, success: true });
              successCount++;
              break;

            default:
              results.push({ userId, success: false, error: `Unknown action: ${action}` });
              failureCount++;
          }
        } catch (error: any) {
          results.push({ userId, success: false, error: error.message || 'Operation failed' });
          failureCount++;
        }
      }

      // Log the bulk operation
      (request.server as any).monitoring?.trackEvent?.('user.bulk_operation', {
        tenantId,
        action,
        totalUsers: userIds.length,
        successCount,
        failureCount,
        performedBy: adminUser.id,
      });

      return reply.code(200).send({
        message: `Bulk operation completed: ${successCount} succeeded, ${failureCount} failed`,
        successCount,
        failureCount,
        results,
      });
    } catch (error) {
      if (error instanceof ForbiddenError || error instanceof UnauthorizedError) {
        throw error;
      }

      request.log.error({ err: error }, 'Failed to perform bulk operation');

      return reply.code(500).send({
        error: 'Internal Server Error',
        message: 'Failed to perform bulk operation',
      });
    }
  }

  /**
   * POST /api/tenants/:tenantId/users/:userId/impersonate
   * Issues temporary impersonation tokens for admins
   */
  async impersonateUser(
    request: FastifyRequest<{ Params: ImpersonateUserParams; Body: ImpersonateUserRequest }>,
    reply: FastifyReply
  ) {
    try {
      const { tenantId, userId } = request.params;
      const adminUser = (request as AuthenticatedRequest).user as AuthUser | undefined;

      if (!adminUser) {
        throw new UnauthorizedError('Authentication required');
      }

      this.ensureAdminPrivileges(adminUser, tenantId, userId);
      await this.ensureMFA(request, adminUser);

      const body = request.body || {};
      const metadata = SessionManagementService.extractSessionMetadata(request);
      const impersonation = await this.userManagementService.impersonateUser(tenantId, userId, {
        adminId: adminUser.id,
        adminEmail: adminUser.email,
        reason: body.reason,
        expiryMinutes: body.expiryMinutes,
        metadata: {
          ...metadata,
          requestIp: request.ip,
          userAgent: request.headers['user-agent'],
        },
      });

      const accessToken = (request.server as any).jwt.sign(
        {
          sub: impersonation.user.id,
          email: impersonation.user.email,
          tenantId: impersonation.user.tenantId,
          role: impersonation.user.roles?.[0] || 'user',
          roles: impersonation.user.roles || [],
          organizationId: impersonation.user.organizationId,
          impersonatedBy: adminUser.id,
          impersonationId: impersonation.impersonationId,
          type: 'access',
        },
        {
          expiresIn: `${impersonation.expiresInSeconds}s`,
        }
      );

      const refreshTokenResult = await this.cacheManager.tokens.createRefreshToken(
        impersonation.user.id,
        impersonation.user.tenantId,
        undefined,
        { ttlSeconds: impersonation.expiresInSeconds }
      );

      await this.cacheManager.sessions.createSession(impersonation.user.id, impersonation.user.tenantId, {
        email: impersonation.user.email,
        name: this.getDisplayName(impersonation.user),
        provider: 'impersonation',
        deviceInfo: metadata.deviceInfo,
        locationInfo: metadata.locationInfo,
        metadata: {
          impersonationId: impersonation.impersonationId,
          impersonatedBy: adminUser.id,
          adminEmail: adminUser.email,
          reason: impersonation.reason,
          expiresAt: impersonation.expiresAt,
        },
      });

      (request.server as any).monitoring?.trackEvent?.('user.impersonation.started', {
        tenantId,
        adminId: adminUser.id,
        targetUserId: userId,
        impersonationId: impersonation.impersonationId,
      });

      const response: ImpersonateUserResponse = {
        accessToken,
        refreshToken: refreshTokenResult.token,
        expiresIn: impersonation.expiresInSeconds,
        expiresAt: impersonation.expiresAt,
        impersonationId: impersonation.impersonationId,
        message: 'Impersonation token issued',
        user: impersonation.user,
      };

      return reply.code(200).send(response);
    } catch (error) {
      if (error instanceof ForbiddenError || error instanceof UnauthorizedError) {
        throw error;
      }

      request.log.error({ err: error }, 'Failed to impersonate user');

      if (error instanceof Error) {
        if (error.message === 'User not found') {
          return reply.code(404).send({
            error: 'Not Found',
            message: 'User not found',
          });
        }

        if (error.message === 'User is not active' || error.message === 'Cannot impersonate yourself') {
          return reply.code(400).send({
            error: 'Bad Request',
            message: error.message,
          });
        }
      }

      return reply.code(500).send({
        error: 'Internal Server Error',
        message: 'Failed to impersonate user',
      });
    }
  }

  private ensureAdminPrivileges(user: AuthUser, tenantId: string, targetUserId: string) {
    if (user.tenantId !== tenantId) {
      throw new ForbiddenError('Access denied to this tenant');
    }

    if (user.id === targetUserId) {
      throw new ForbiddenError('Cannot impersonate your own account');
    }

    const roles = user.roles || [];
    const hasAdminRole = roles.includes('admin') || roles.includes('owner') || roles.includes('global_admin');

    if (!hasAdminRole) {
      throw new ForbiddenError('Admin role required for impersonation');
    }
  }

  private async ensureMFA(request: FastifyRequest, user: AuthUser): Promise<void> {
    const headerValue = request.headers['x-mfa-verified'];
    if (typeof headerValue === 'string' && headerValue.toLowerCase() === 'true') {
      return;
    }

    if (user.sessionId) {
      try {
        const session = await this.cacheManager.sessions.getSession(
          user.tenantId,
          user.id,
          user.sessionId
        );

        if (session?.metadata?.mfaVerified || session?.metadata?.mfaCompletedAt) {
          return;
        }
      } catch (error) {
        request.log.warn({ err: error }, 'Unable to verify MFA from session metadata');
      }
    }

    throw new ForbiddenError('MFA verification required for impersonation');
  }

  private getDisplayName(user: UserResponse): string {
    if (user.displayName) {
      return user.displayName;
    }

    const fullName = `${user.firstName || ''} ${user.lastName || ''}`.trim();
    return fullName || user.email;
  }
}
