module.exports=[66784,(a,b,c)=>{}];

//# sourceMappingURL=services_frontend__next-internal_server_app_%28public%29_terms_page_actions_946b25e5.js.map