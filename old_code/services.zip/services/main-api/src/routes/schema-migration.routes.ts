/**
 * Schema Migration Routes
 * 
 * Routes for schema migration management
 */

import type { FastifyInstance } from 'fastify';
import type { SchemaMigrationController } from '../controllers/schema-migration.controller.js';
import { MigrationStrategy, TransformationType } from '../types/schema-migration.types.js';

const createMigrationSchema = {
  body: {
    type: 'object',
    required: ['shardTypeId', 'fromVersion', 'toVersion', 'description', 'transformations'],
    properties: {
      shardTypeId: { type: 'string' },
      fromVersion: { type: 'integer', minimum: 1 },
      toVersion: { type: 'integer', minimum: 1 },
      description: { type: 'string', maxLength: 500 },
      transformations: {
        type: 'array',
        items: {
          type: 'object',
          required: ['type'],
          properties: {
            type: { type: 'string', enum: Object.values(TransformationType) },
            sourcePath: { type: 'string' },
            targetPath: { type: 'string' },
            defaultValue: {},
            transformer: { type: 'string' },
            config: { type: 'object' },
          },
        },
      },
      strategy: { type: 'string', enum: Object.values(MigrationStrategy) },
      batchSize: { type: 'integer', minimum: 1, maximum: 1000 },
      reversible: { type: 'boolean' },
      rollbackTransformations: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            type: { type: 'string' },
            sourcePath: { type: 'string' },
            targetPath: { type: 'string' },
            defaultValue: {},
            transformer: { type: 'string' },
            config: { type: 'object' },
          },
        },
      },
    },
  },
};

const executeMigrationSchema = {
  params: {
    type: 'object',
    required: ['shardTypeId', 'migrationId'],
    properties: {
      shardTypeId: { type: 'string' },
      migrationId: { type: 'string' },
    },
  },
  body: {
    type: 'object',
    properties: {
      dryRun: { type: 'boolean' },
      batchSize: { type: 'integer', minimum: 1, maximum: 1000 },
      continueOnError: { type: 'boolean' },
      notifyOnCompletion: { type: 'boolean' },
    },
  },
};

const shardTypeIdSchema = {
  params: {
    type: 'object',
    required: ['shardTypeId'],
    properties: {
      shardTypeId: { type: 'string' },
    },
  },
};

const migrationIdSchema = {
  params: {
    type: 'object',
    required: ['shardTypeId', 'migrationId'],
    properties: {
      shardTypeId: { type: 'string' },
      migrationId: { type: 'string' },
    },
  },
};

const migrationPathSchema = {
  params: {
    type: 'object',
    required: ['shardTypeId'],
    properties: {
      shardTypeId: { type: 'string' },
    },
  },
  querystring: {
    type: 'object',
    required: ['fromVersion', 'toVersion'],
    properties: {
      fromVersion: { type: 'string', pattern: '^[0-9]+$' },
      toVersion: { type: 'string', pattern: '^[0-9]+$' },
    },
  },
};

export function registerSchemaMigrationRoutes(
  server: FastifyInstance,
  controller: SchemaMigrationController
) {
  // Create migration
  server.post(
    '/api/v1/schema-migrations',
    { schema: createMigrationSchema },
    (request, reply) => controller.createMigration(request, reply)
  );

  // List migrations for shard type
  server.get(
    '/api/v1/schema-migrations/:shardTypeId',
    { schema: shardTypeIdSchema },
    (request, reply) => controller.listMigrations(request, reply)
  );

  // Get version info
  server.get(
    '/api/v1/schema-migrations/:shardTypeId/version-info',
    { schema: shardTypeIdSchema },
    (request, reply) => controller.getVersionInfo(request, reply)
  );

  // Get migration path
  server.get(
    '/api/v1/schema-migrations/:shardTypeId/path',
    { schema: migrationPathSchema },
    (request, reply) => controller.getMigrationPath(request, reply)
  );

  // Get specific migration
  server.get(
    '/api/v1/schema-migrations/:shardTypeId/:migrationId',
    { schema: migrationIdSchema },
    (request, reply) => controller.getMigration(request, reply)
  );

  // Execute migration
  server.post(
    '/api/v1/schema-migrations/:shardTypeId/:migrationId/execute',
    { schema: executeMigrationSchema },
    (request, reply) => controller.executeMigration(request, reply)
  );
}


