/**
 * User Security Controller
 * 
 * Admin endpoints for managing user security settings
 */

import type { FastifyRequest, FastifyReply } from 'fastify';
import type { UserService } from '../services/auth/user.service.js';
import type { MFAService } from '../services/auth/mfa.service.js';
import type { CacheManager } from '../cache/manager.js';
import type { UnifiedEmailService } from '../services/email/index.js';
import type { AuthUser } from '../types/auth.types.js';
import crypto from 'crypto';

const ADMIN_ROLES = ['owner', 'admin', 'tenant-admin', 'super-admin'];

interface ForceResetRequest {
  userId: string;
  sendEmail?: boolean;
}

interface RevokeSessionsRequest {
  userId: string;
}

interface DisableMFARequest {
  userId: string;
  method?: string;
}

interface LockAccountRequest {
  userId: string;
  reason?: string;
}

/**
 * User Security Controller
 */
export class UserSecurityController {
  constructor(
    private readonly userService: UserService,
    private readonly mfaService: MFAService,
    private readonly cacheManager: CacheManager,
    private readonly emailService: UnifiedEmailService,
    private readonly frontendUrl: string
  ) {}

  /**
   * POST /api/admin/users/:userId/force-password-reset
   * Force a password reset for a user
   */
  async forcePasswordReset(request: FastifyRequest, reply: FastifyReply) {
    try {
      const admin = (request as any).user as AuthUser | undefined;
      if (!admin) {
        return reply.code(401).send({
          error: 'Unauthorized',
          message: 'Authentication required',
        });
      }

      if (!this.isAdmin(admin)) {
        return reply.code(403).send({
          error: 'Forbidden',
          message: 'Admin role required',
        });
      }

      const { userId } = request.params as { userId: string };
      const { sendEmail = true } = request.body as ForceResetRequest || {};

      // Get the target user
      const user = await this.userService.findById(userId);
      if (!user) {
        return reply.code(404).send({
          error: 'NotFound',
          message: 'User not found',
        });
      }

      // Check tenant access
      if (user.tenantId !== admin.tenantId && !admin.roles?.includes('super-admin')) {
        return reply.code(403).send({
          error: 'Forbidden',
          message: 'Cannot manage users from other tenants',
        });
      }

      // Generate reset token
      const resetToken = crypto.randomBytes(32).toString('hex');
      const resetExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

      // Update user with reset token and require password change
      await this.userService.update(userId, {
        passwordResetToken: resetToken,
        passwordResetExpiry: resetExpiry.toISOString(),
        mustChangePassword: true,
      });

      // Revoke all existing sessions
      await this.cacheManager.sessions.revokeAllUserSessions(userId);

      // Send password reset email if requested
      if (sendEmail && user.email) {
        const resetUrl = `${this.frontendUrl}/reset-password?token=${resetToken}`;
        await this.emailService.sendPasswordResetEmail(user.email, resetUrl);
      }

      request.log.info({ userId, adminId: admin.id }, 'Password reset forced by admin');

      return reply.code(200).send({
        success: true,
        message: 'Password reset initiated',
        resetToken: sendEmail ? undefined : resetToken, // Only return token if not sending email
      });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to force password reset');
      return reply.code(500).send({
        error: 'InternalError',
        message: 'Failed to force password reset',
      });
    }
  }

  /**
   * POST /api/admin/users/:userId/revoke-sessions
   * Revoke all sessions for a user
   */
  async revokeSessions(request: FastifyRequest, reply: FastifyReply) {
    try {
      const admin = (request as any).user as AuthUser | undefined;
      if (!admin) {
        return reply.code(401).send({
          error: 'Unauthorized',
          message: 'Authentication required',
        });
      }

      if (!this.isAdmin(admin)) {
        return reply.code(403).send({
          error: 'Forbidden',
          message: 'Admin role required',
        });
      }

      const { userId } = request.params as { userId: string };

      // Get the target user
      const user = await this.userService.findById(userId);
      if (!user) {
        return reply.code(404).send({
          error: 'NotFound',
          message: 'User not found',
        });
      }

      // Check tenant access
      if (user.tenantId !== admin.tenantId && !admin.roles?.includes('super-admin')) {
        return reply.code(403).send({
          error: 'Forbidden',
          message: 'Cannot manage users from other tenants',
        });
      }

      // Revoke all sessions
      await this.cacheManager.sessions.revokeAllUserSessions(userId);

      // Also invalidate refresh tokens
      await this.cacheManager.refreshTokens.revokeAllUserTokens(userId);

      request.log.info({ userId, adminId: admin.id }, 'All sessions revoked by admin');

      return reply.code(200).send({
        success: true,
        message: 'All sessions revoked',
      });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to revoke sessions');
      return reply.code(500).send({
        error: 'InternalError',
        message: 'Failed to revoke sessions',
      });
    }
  }

  /**
   * POST /api/admin/users/:userId/disable-mfa
   * Disable MFA for a user (admin action)
   */
  async disableMFA(request: FastifyRequest, reply: FastifyReply) {
    try {
      const admin = (request as any).user as AuthUser | undefined;
      if (!admin) {
        return reply.code(401).send({
          error: 'Unauthorized',
          message: 'Authentication required',
        });
      }

      if (!this.isAdmin(admin)) {
        return reply.code(403).send({
          error: 'Forbidden',
          message: 'Admin role required',
        });
      }

      const { userId } = request.params as { userId: string };
      const { method } = request.body as DisableMFARequest || {};

      // Get the target user
      const user = await this.userService.findById(userId);
      if (!user) {
        return reply.code(404).send({
          error: 'NotFound',
          message: 'User not found',
        });
      }

      // Check tenant access
      if (user.tenantId !== admin.tenantId && !admin.roles?.includes('super-admin')) {
        return reply.code(403).send({
          error: 'Forbidden',
          message: 'Cannot manage users from other tenants',
        });
      }

      // Disable MFA
      if (method) {
        // Disable specific method
        await this.mfaService.disableMethod(userId, method as any);
      } else {
        // Disable all MFA
        await this.userService.update(userId, {
          mfaEnabled: false,
          mfaSecret: undefined,
          mfaBackupCodes: undefined,
          mfaMethods: [],
        });
      }

      request.log.info({ userId, adminId: admin.id, method }, 'MFA disabled by admin');

      return reply.code(200).send({
        success: true,
        message: method ? `MFA method ${method} disabled` : 'All MFA disabled',
      });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to disable MFA');
      return reply.code(500).send({
        error: 'InternalError',
        message: 'Failed to disable MFA',
      });
    }
  }

  /**
   * POST /api/admin/users/:userId/lock
   * Lock a user account
   */
  async lockAccount(request: FastifyRequest, reply: FastifyReply) {
    try {
      const admin = (request as any).user as AuthUser | undefined;
      if (!admin) {
        return reply.code(401).send({
          error: 'Unauthorized',
          message: 'Authentication required',
        });
      }

      if (!this.isAdmin(admin)) {
        return reply.code(403).send({
          error: 'Forbidden',
          message: 'Admin role required',
        });
      }

      const { userId } = request.params as { userId: string };
      const { reason } = request.body as LockAccountRequest || {};

      // Get the target user
      const user = await this.userService.findById(userId);
      if (!user) {
        return reply.code(404).send({
          error: 'NotFound',
          message: 'User not found',
        });
      }

      // Check tenant access
      if (user.tenantId !== admin.tenantId && !admin.roles?.includes('super-admin')) {
        return reply.code(403).send({
          error: 'Forbidden',
          message: 'Cannot manage users from other tenants',
        });
      }

      // Don't allow locking yourself or other super admins
      if (userId === admin.id) {
        return reply.code(400).send({
          error: 'BadRequest',
          message: 'Cannot lock your own account',
        });
      }

      if (user.roles?.includes('super-admin')) {
        return reply.code(403).send({
          error: 'Forbidden',
          message: 'Cannot lock super admin accounts',
        });
      }

      // Lock the account
      await this.userService.update(userId, {
        status: 'suspended',
        lockedAt: new Date().toISOString(),
        lockedBy: admin.id,
        lockReason: reason || 'Locked by administrator',
      });

      // Revoke all sessions
      await this.cacheManager.sessions.revokeAllUserSessions(userId);
      await this.cacheManager.refreshTokens.revokeAllUserTokens(userId);

      request.log.info({ userId, adminId: admin.id, reason }, 'Account locked by admin');

      return reply.code(200).send({
        success: true,
        message: 'Account locked',
      });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to lock account');
      return reply.code(500).send({
        error: 'InternalError',
        message: 'Failed to lock account',
      });
    }
  }

  /**
   * POST /api/admin/users/:userId/unlock
   * Unlock a user account
   */
  async unlockAccount(request: FastifyRequest, reply: FastifyReply) {
    try {
      const admin = (request as any).user as AuthUser | undefined;
      if (!admin) {
        return reply.code(401).send({
          error: 'Unauthorized',
          message: 'Authentication required',
        });
      }

      if (!this.isAdmin(admin)) {
        return reply.code(403).send({
          error: 'Forbidden',
          message: 'Admin role required',
        });
      }

      const { userId } = request.params as { userId: string };

      // Get the target user
      const user = await this.userService.findById(userId);
      if (!user) {
        return reply.code(404).send({
          error: 'NotFound',
          message: 'User not found',
        });
      }

      // Check tenant access
      if (user.tenantId !== admin.tenantId && !admin.roles?.includes('super-admin')) {
        return reply.code(403).send({
          error: 'Forbidden',
          message: 'Cannot manage users from other tenants',
        });
      }

      // Unlock the account
      await this.userService.update(userId, {
        status: 'active',
        lockedAt: undefined,
        lockedBy: undefined,
        lockReason: undefined,
        failedLoginAttempts: 0,
        lastFailedLogin: undefined,
      });

      request.log.info({ userId, adminId: admin.id }, 'Account unlocked by admin');

      return reply.code(200).send({
        success: true,
        message: 'Account unlocked',
      });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to unlock account');
      return reply.code(500).send({
        error: 'InternalError',
        message: 'Failed to unlock account',
      });
    }
  }

  /**
   * GET /api/admin/users/:userId/security
   * Get user security status
   */
  async getUserSecurity(request: FastifyRequest, reply: FastifyReply) {
    try {
      const admin = (request as any).user as AuthUser | undefined;
      if (!admin) {
        return reply.code(401).send({
          error: 'Unauthorized',
          message: 'Authentication required',
        });
      }

      if (!this.isAdmin(admin)) {
        return reply.code(403).send({
          error: 'Forbidden',
          message: 'Admin role required',
        });
      }

      const { userId } = request.params as { userId: string };

      // Get the target user
      const user = await this.userService.findById(userId);
      if (!user) {
        return reply.code(404).send({
          error: 'NotFound',
          message: 'User not found',
        });
      }

      // Check tenant access
      if (user.tenantId !== admin.tenantId && !admin.roles?.includes('super-admin')) {
        return reply.code(403).send({
          error: 'Forbidden',
          message: 'Cannot access users from other tenants',
        });
      }

      // Get active sessions count
      const sessions = await this.cacheManager.sessions.getUserSessions(userId);

      return reply.code(200).send({
        userId: user.id,
        email: user.email,
        status: user.status,
        mfaEnabled: user.mfaEnabled || false,
        mfaMethods: user.mfaMethods || [],
        activeSessions: sessions?.length || 0,
        lastLogin: user.lastLogin,
        failedLoginAttempts: user.failedLoginAttempts || 0,
        lockedAt: user.lockedAt,
        lockReason: user.lockReason,
        mustChangePassword: user.mustChangePassword || false,
        passwordLastChanged: user.passwordLastChanged,
        createdAt: user.createdAt,
      });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to get user security');
      return reply.code(500).send({
        error: 'InternalError',
        message: 'Failed to get user security status',
      });
    }
  }

  private isAdmin(user: AuthUser): boolean {
    return ADMIN_ROLES.some((role) => user.roles?.includes(role));
  }
}


