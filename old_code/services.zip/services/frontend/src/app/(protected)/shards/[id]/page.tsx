"use client"

import { use } from "react"
import { useRouter } from "next/navigation"
import { useTranslation } from "react-i18next"
import { Pencil, Trash2, FileText, Calendar, User } from "lucide-react"
import { format } from "date-fns"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useShard, useDeleteShard } from "@/hooks/use-shards"
import { toast } from "sonner"
import { JsonViewer } from "@/components/json-editor"

interface ShardDetailPageProps {
  params: Promise<{ id: string }>
}

export default function ShardDetailPage({ params }: ShardDetailPageProps) {
  const { t } = useTranslation('shards')
  const { id } = use(params)
  const router = useRouter()
  const { data: shard, isLoading } = useShard(id)
  const deleteShard = useDeleteShard()

  const handleDelete = async () => {
    if (confirm(t('deleteConfirm.message', { name: shard?.name }))) {
      try {
        await deleteShard.mutateAsync(id)
        toast.success(t('messages.deleteSuccess'))
        router.push("/shards")
      } catch (error) {
        toast.error(t('messages.deleteFailed'))
      }
    }
  }

  if (isLoading) {
    return (
      <div className="flex flex-col gap-6 p-6">
        <div className="h-8 w-64 animate-pulse bg-muted rounded" />
        <div className="h-4 w-96 animate-pulse bg-muted rounded" />
        <div className="grid gap-6 md:grid-cols-3">
          <div className="md:col-span-2 h-96 animate-pulse bg-muted rounded" />
          <div className="h-96 animate-pulse bg-muted rounded" />
        </div>
      </div>
    )
  }

  if (!shard) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] gap-4">
        <FileText className="h-16 w-16 text-muted-foreground" />
        <h2 className="text-2xl font-semibold">{t('detail.notFound')}</h2>
        <p className="text-muted-foreground">
          {t('detail.notFoundDescription')}
        </p>
        <Button onClick={() => router.push("/shards")}>
          {t('backToShards')}
        </Button>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold tracking-tight">{shard.name}</h1>
          {shard.description && (
            <p className="text-muted-foreground">{shard.description}</p>
          )}
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => router.push(`/shards/${id}/edit`)}
          >
            <Pencil className="mr-2 h-4 w-4" />
            {t('common:edit')}
          </Button>
          <Button
            variant="destructive"
            onClick={handleDelete}
            disabled={deleteShard.isPending}
          >
            <Trash2 className="mr-2 h-4 w-4" />
            {deleteShard.isPending ? t('detail.deleting') : t('common:delete')}
          </Button>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid gap-6 md:grid-cols-3">
        {/* Content Card (2/3 width) */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>{t('detail.content')}</CardTitle>
            <CardDescription>
              {t('detail.contentDescription')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="content" className="w-full">
              <TabsList>
                <TabsTrigger value="content">{t('detail.content')}</TabsTrigger>
                <TabsTrigger value="metadata">{t('detail.metadata')}</TabsTrigger>
                <TabsTrigger value="json">{t('detail.jsonData')}</TabsTrigger>
                {shard.attachments && shard.attachments.length > 0 && (
                  <TabsTrigger value="attachments">
                    {t('detail.attachments')} ({shard.attachments.length})
                  </TabsTrigger>
                )}
              </TabsList>

              <TabsContent value="content" className="space-y-4 mt-4">
                {shard.content ? (
                  <div className="prose prose-sm max-w-none dark:prose-invert">
                    <pre className="whitespace-pre-wrap text-sm bg-muted p-4 rounded-lg">
                      {shard.content}
                    </pre>
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground italic">
                    {t('detail.noContent')}
                  </p>
                )}
              </TabsContent>

              <TabsContent value="metadata" className="mt-4">
                {shard.metadata && Object.keys(shard.metadata).length > 0 ? (
                  <div className="space-y-2">
                    {Object.entries(shard.metadata).map(([key, value]) => (
                      <div
                        key={key}
                        className="flex justify-between items-start py-2 border-b last:border-0"
                      >
                        <span className="font-medium text-sm">{key}:</span>
                        <span className="text-sm text-muted-foreground text-right max-w-[60%]">
                          {typeof value === "object"
                            ? JSON.stringify(value, null, 2)
                            : String(value)}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground italic">
                    {t('detail.noMetadata')}
                  </p>
                )}
              </TabsContent>

              <TabsContent value="json" className="mt-4">
                {shard.unstructuredData &&
                Object.keys(shard.unstructuredData).length > 0 ? (
                  <JsonViewer data={shard.unstructuredData} title="" height="500px" />
                ) : (
                  <p className="text-sm text-muted-foreground italic">
                    {t('detail.noJsonData')}
                  </p>
                )}
              </TabsContent>

              {shard.attachments && shard.attachments.length > 0 && (
                <TabsContent value="attachments" className="mt-4">
                  <div className="space-y-2">
                    {shard.attachments.map((attachment) => (
                      <div
                        key={attachment.id}
                        className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <FileText className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <p className="text-sm font-medium">
                              {attachment.filename}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {attachment.mimeType} •{" "}
                              {(attachment.size / 1024).toFixed(2)} KB
                            </p>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm">
                          {t('detail.download')}
                        </Button>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              )}
            </Tabs>
          </CardContent>
        </Card>

        {/* Details Sidebar (1/3 width) */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('detail.details')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm font-medium mb-2">{t('detail.type')}</p>
                <Badge variant="outline">
                  {shard.shardType?.name || t('detail.unknown')}
                </Badge>
              </div>

              <Separator />

              <div>
                <p className="text-sm font-medium mb-2">{t('table.visibility')}</p>
                <Badge variant={shard.isPublic ? "default" : "secondary"}>
                  {shard.isPublic ? t('visibility.public') : t('visibility.private')}
                </Badge>
              </div>

              {shard.tags && shard.tags.length > 0 && (
                <>
                  <Separator />
                  <div>
                    <p className="text-sm font-medium mb-2">{t('table.tags')}</p>
                    <div className="flex flex-wrap gap-1">
                      {shard.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </>
              )}

              <Separator />

              <div className="space-y-3">
                <div className="flex items-start gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-xs text-muted-foreground">{t('detail.created')}</p>
                    <p className="text-sm">
                      {format(new Date(shard.createdAt), "PPp")}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-xs text-muted-foreground">{t('detail.updated')}</p>
                    <p className="text-sm">
                      {format(new Date(shard.updatedAt), "PPp")}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2">
                  <User className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-xs text-muted-foreground">{t('detail.createdBy')}</p>
                    <p className="text-sm">{shard.createdBy}</p>
                  </div>
                </div>

                {shard.updatedBy && (
                  <div className="flex items-start gap-2">
                    <User className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-xs text-muted-foreground">
                        {t('detail.updatedBy')}
                      </p>
                      <p className="text-sm">{shard.updatedBy}</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Statistics Card */}
          <Card>
            <CardHeader>
              <CardTitle>{t('detail.statistics')}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">
                  {t('detail.shardId')}
                </span>
                <span className="text-sm font-mono">
                  {shard.id.slice(0, 8)}...
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
