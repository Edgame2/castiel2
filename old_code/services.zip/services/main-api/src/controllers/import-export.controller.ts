/**
 * Import/Export Controller
 * 
 * HTTP handlers for shard import and export operations
 */

import type { FastifyRequest, FastifyReply } from 'fastify';
import type { ImportExportService } from '../services/import-export.service.js';
import type { AuthUser } from '../types/auth.types.js';
import type {
  CreateExportRequest,
  CreateImportRequest,
  ExportFormat,
} from '../types/import-export.types.js';

/**
 * Import/Export Controller
 */
export class ImportExportController {
  constructor(private readonly importExportService: ImportExportService) {}

  /**
   * POST /api/v1/exports
   * Create a new export job
   */
  async createExport(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      const body = request.body as CreateExportRequest;

      const job = await this.importExportService.createExportJob(
        user.tenantId,
        user.id,
        body
      );

      request.log.info({ jobId: job.id }, 'Export job created');

      return reply.code(202).send({ job });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to create export');
      return reply.code(500).send({ error: 'Failed to create export job' });
    }
  }

  /**
   * GET /api/v1/exports/:id
   * Get export job status
   */
  async getExportJob(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      const { id } = request.params as { id: string };

      const job = await this.importExportService.getExportJob(user.tenantId, id);

      if (!job) {
        return reply.code(404).send({ error: 'Export job not found' });
      }

      return reply.code(200).send({ job });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to get export job');
      return reply.code(500).send({ error: 'Failed to get export job' });
    }
  }

  /**
   * GET /api/v1/exports/:id/download
   * Download export file
   */
  async downloadExport(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      const { id } = request.params as { id: string };

      const job = await this.importExportService.getExportJob(user.tenantId, id);

      if (!job) {
        return reply.code(404).send({ error: 'Export job not found' });
      }

      if (job.status !== 'completed') {
        return reply.code(400).send({ error: 'Export not ready for download' });
      }

      const content = await this.importExportService.getExportFileContent(
        user.tenantId,
        id
      );

      if (!content) {
        return reply.code(404).send({ error: 'Export file not found or expired' });
      }

      // Set appropriate content type
      const contentTypes: Record<ExportFormat, string> = {
        json: 'application/json',
        csv: 'text/csv',
        xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ndjson: 'application/x-ndjson',
      };

      const contentType = contentTypes[job.options.format] || 'application/octet-stream';

      return reply
        .code(200)
        .header('Content-Type', contentType)
        .header('Content-Disposition', `attachment; filename="${job.fileName}"`)
        .send(content);
    } catch (error: any) {
      request.log.error({ error }, 'Failed to download export');
      return reply.code(500).send({ error: 'Failed to download export' });
    }
  }

  /**
   * POST /api/v1/imports
   * Create a new import job
   */
  async createImport(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      const body = request.body as CreateImportRequest;

      // Validate file size (max 10MB)
      const fileSize = Buffer.byteLength(body.fileContent, 'base64');
      if (fileSize > 10 * 1024 * 1024) {
        return reply.code(400).send({ error: 'File too large. Maximum size is 10MB.' });
      }

      const job = await this.importExportService.createImportJob(
        user.tenantId,
        user.id,
        body
      );

      request.log.info({ jobId: job.id }, 'Import job created');

      return reply.code(202).send({ job });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to create import');
      return reply.code(500).send({ error: 'Failed to create import job' });
    }
  }

  /**
   * GET /api/v1/imports/:id
   * Get import job status
   */
  async getImportJob(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      const { id } = request.params as { id: string };

      const job = await this.importExportService.getImportJob(user.tenantId, id);

      if (!job) {
        return reply.code(404).send({ error: 'Import job not found' });
      }

      return reply.code(200).send({ job });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to get import job');
      return reply.code(500).send({ error: 'Failed to get import job' });
    }
  }

  /**
   * POST /api/v1/imports/validate
   * Validate import data without creating shards
   */
  async validateImport(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      const body = request.body as CreateImportRequest & { previewRows?: number };

      const result = await this.importExportService.validateImport(
        user.tenantId,
        body,
        body.previewRows || 10
      );

      return reply.code(200).send({ validation: result });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to validate import');
      return reply.code(500).send({ error: 'Failed to validate import' });
    }
  }
}


