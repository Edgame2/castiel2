module.exports=[67393,(a,b,c)=>{}];

//# sourceMappingURL=services_frontend__next-internal_server_app_%28dashboard%29_page_actions_e8b82e28.js.map