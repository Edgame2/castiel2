module.exports=[54522,(a,b,c)=>{}];

//# sourceMappingURL=services_frontend__next-internal_server_app__global-error_page_actions_cd42474d.js.map