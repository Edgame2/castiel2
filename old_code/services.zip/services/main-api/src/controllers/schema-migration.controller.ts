/**
 * Schema Migration Controller
 * 
 * HTTP handlers for schema migration management
 */

import type { FastifyRequest, FastifyReply } from 'fastify';
import type { SchemaMigrationService } from '../services/schema-migration.service.js';
import type { AuthUser } from '../types/auth.types.js';
import type { CreateMigrationInput, MigrationExecutionOptions } from '../types/schema-migration.types.js';

const ADMIN_ROLES = ['owner', 'admin', 'tenant-admin'];

/**
 * Schema Migration Controller
 */
export class SchemaMigrationController {
  constructor(private readonly migrationService: SchemaMigrationService) {}

  /**
   * POST /api/v1/schema-migrations
   * Create a new migration
   */
  async createMigration(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      if (!this.isAdmin(user)) {
        return reply.code(403).send({ error: 'Admin role required' });
      }

      const input = request.body as CreateMigrationInput;

      const migration = await this.migrationService.createMigration(
        user.tenantId,
        user.id,
        input
      );

      request.log.info({ migrationId: migration.id }, 'Migration created');

      return reply.code(201).send({ migration });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to create migration');
      return reply.code(500).send({ error: 'Failed to create migration' });
    }
  }

  /**
   * GET /api/v1/schema-migrations/:shardTypeId
   * List migrations for a shard type
   */
  async listMigrations(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      const { shardTypeId } = request.params as { shardTypeId: string };

      const migrations = await this.migrationService.listMigrations(
        user.tenantId,
        shardTypeId
      );

      return reply.code(200).send({ migrations });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to list migrations');
      return reply.code(500).send({ error: 'Failed to list migrations' });
    }
  }

  /**
   * GET /api/v1/schema-migrations/:shardTypeId/:migrationId
   * Get a migration by ID
   */
  async getMigration(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      const { shardTypeId, migrationId } = request.params as {
        shardTypeId: string;
        migrationId: string;
      };

      const migration = await this.migrationService.getMigration(
        user.tenantId,
        shardTypeId,
        migrationId
      );

      if (!migration) {
        return reply.code(404).send({ error: 'Migration not found' });
      }

      return reply.code(200).send({ migration });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to get migration');
      return reply.code(500).send({ error: 'Failed to get migration' });
    }
  }

  /**
   * POST /api/v1/schema-migrations/:shardTypeId/:migrationId/execute
   * Execute a migration
   */
  async executeMigration(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      if (!this.isAdmin(user)) {
        return reply.code(403).send({ error: 'Admin role required' });
      }

      const { shardTypeId, migrationId } = request.params as {
        shardTypeId: string;
        migrationId: string;
      };

      const options = request.body as MigrationExecutionOptions | undefined;

      const result = await this.migrationService.executeMigration(
        user.tenantId,
        migrationId,
        shardTypeId,
        options
      );

      request.log.info({ result }, 'Migration executed');

      return reply.code(200).send({ result });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to execute migration');
      return reply.code(500).send({ error: error.message || 'Failed to execute migration' });
    }
  }

  /**
   * GET /api/v1/schema-migrations/:shardTypeId/version-info
   * Get version info for a shard type
   */
  async getVersionInfo(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      const { shardTypeId } = request.params as { shardTypeId: string };

      const versionInfo = await this.migrationService.getVersionInfo(
        user.tenantId,
        shardTypeId
      );

      return reply.code(200).send({ versionInfo });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to get version info');
      return reply.code(500).send({ error: 'Failed to get version info' });
    }
  }

  /**
   * GET /api/v1/schema-migrations/:shardTypeId/path
   * Get migration path between versions
   */
  async getMigrationPath(request: FastifyRequest, reply: FastifyReply) {
    try {
      const user = (request as any).user as AuthUser | undefined;
      if (!user) {
        return reply.code(401).send({ error: 'Unauthorized' });
      }

      const { shardTypeId } = request.params as { shardTypeId: string };
      const { fromVersion, toVersion } = request.query as {
        fromVersion: string;
        toVersion: string;
      };

      const path = await this.migrationService.getMigrationPath(
        user.tenantId,
        shardTypeId,
        parseInt(fromVersion, 10),
        parseInt(toVersion, 10)
      );

      return reply.code(200).send({ path });
    } catch (error: any) {
      request.log.error({ error }, 'Failed to get migration path');
      return reply.code(400).send({ error: error.message || 'Failed to get migration path' });
    }
  }

  private isAdmin(user: AuthUser): boolean {
    return ADMIN_ROLES.some((role) => user.roles?.includes(role));
  }
}


