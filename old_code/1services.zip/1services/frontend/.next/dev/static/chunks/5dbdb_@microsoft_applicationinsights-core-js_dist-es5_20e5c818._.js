(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ // @skip-file-minify
// ##############################################################
// AUTO GENERATED FILE: This file is Auto Generated during build.
// ##############################################################
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// Note: DON'T Export these const from the package as we are still targeting ES5 which can result in a mutable variables that someone could change!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
__turbopack_context__.s([
    "_DYN_ADD_NOTIFICATION_LIS1",
    ()=>_DYN_ADD_NOTIFICATION_LIS1,
    "_DYN_APPLY",
    ()=>_DYN_APPLY,
    "_DYN_CANCEL",
    ()=>_DYN_CANCEL,
    "_DYN_CREATE_NEW",
    ()=>_DYN_CREATE_NEW,
    "_DYN_DATA",
    ()=>_DYN_DATA,
    "_DYN_DIAG_LOG",
    ()=>_DYN_DIAG_LOG,
    "_DYN_ENABLED",
    ()=>_DYN_ENABLED,
    "_DYN_EVT_NAME",
    ()=>_DYN_EVT_NAME,
    "_DYN_EXCEPTION",
    ()=>_DYN_EXCEPTION,
    "_DYN_FAILURE",
    ()=>_DYN_FAILURE,
    "_DYN_GET_ALL_RESPONSE_HEA5",
    ()=>_DYN_GET_ALL_RESPONSE_HEA5,
    "_DYN_GET_ATTRIBUTE",
    ()=>_DYN_GET_ATTRIBUTE,
    "_DYN_GET_CTX",
    ()=>_DYN_GET_CTX,
    "_DYN_GET_NEXT",
    ()=>_DYN_GET_NEXT,
    "_DYN_GET_NOTIFY_MGR",
    ()=>_DYN_GET_NOTIFY_MGR,
    "_DYN_GET_PLUGIN",
    ()=>_DYN_GET_PLUGIN,
    "_DYN_GET_PROCESS_TEL_CONT2",
    ()=>_DYN_GET_PROCESS_TEL_CONT2,
    "_DYN_HEADERS",
    ()=>_DYN_HEADERS,
    "_DYN_IDENTIFIER",
    ()=>_DYN_IDENTIFIER,
    "_DYN_INDEX_OF",
    ()=>_DYN_INDEX_OF,
    "_DYN_INITIALIZE",
    ()=>_DYN_INITIALIZE,
    "_DYN_IS_CHILD_EVT",
    ()=>_DYN_IS_CHILD_EVT,
    "_DYN_IS_INITIALIZED",
    ()=>_DYN_IS_INITIALIZED,
    "_DYN_ITEMS_RECEIVED",
    ()=>_DYN_ITEMS_RECEIVED,
    "_DYN_LENGTH",
    ()=>_DYN_LENGTH,
    "_DYN_LOGGER",
    ()=>_DYN_LOGGER,
    "_DYN_LOGGING_LEVEL_CONSOL4",
    ()=>_DYN_LOGGING_LEVEL_CONSOL4,
    "_DYN_MESSAGE",
    ()=>_DYN_MESSAGE,
    "_DYN_MESSAGE_ID",
    ()=>_DYN_MESSAGE_ID,
    "_DYN_NAME",
    ()=>_DYN_NAME,
    "_DYN_ON_COMPLETE",
    ()=>_DYN_ON_COMPLETE,
    "_DYN_PROCESS_NEXT",
    ()=>_DYN_PROCESS_NEXT,
    "_DYN_PUSH",
    ()=>_DYN_PUSH,
    "_DYN_REMOVE_NOTIFICATION_0",
    ()=>_DYN_REMOVE_NOTIFICATION_0,
    "_DYN_REPLACE",
    ()=>_DYN_REPLACE,
    "_DYN_REQUEST_DURATION",
    ()=>_DYN_REQUEST_DURATION,
    "_DYN_SET_CTX",
    ()=>_DYN_SET_CTX,
    "_DYN_SET_NEXT_PLUGIN",
    ()=>_DYN_SET_NEXT_PLUGIN,
    "_DYN_SPLICE",
    ()=>_DYN_SPLICE,
    "_DYN_SPLIT",
    ()=>_DYN_SPLIT,
    "_DYN_STATUS",
    ()=>_DYN_STATUS,
    "_DYN_STOP_POLLING_INTERNA3",
    ()=>_DYN_STOP_POLLING_INTERNA3,
    "_DYN_SUBSTRING",
    ()=>_DYN_SUBSTRING,
    "_DYN_TEARDOWN",
    ()=>_DYN_TEARDOWN,
    "_DYN_THROTTLE",
    ()=>_DYN_THROTTLE,
    "_DYN_THROW_INTERNAL",
    ()=>_DYN_THROW_INTERNAL,
    "_DYN_TIMEOUT",
    ()=>_DYN_TIMEOUT,
    "_DYN_TOTAL_REQUEST",
    ()=>_DYN_TOTAL_REQUEST,
    "_DYN_TO_LOWER_CASE",
    ()=>_DYN_TO_LOWER_CASE,
    "_DYN_TRACE_FLAGS",
    ()=>_DYN_TRACE_FLAGS,
    "_DYN_TYPE",
    ()=>_DYN_TYPE,
    "_DYN_UNLOAD",
    ()=>_DYN_UNLOAD,
    "_DYN_UPDATE",
    ()=>_DYN_UPDATE,
    "_DYN_URL_STRING",
    ()=>_DYN_URL_STRING,
    "_DYN_USER_AGENT",
    ()=>_DYN_USER_AGENT,
    "_DYN_VALUE",
    ()=>_DYN_VALUE,
    "_DYN_VERSION",
    ()=>_DYN_VERSION,
    "_DYN_WARN_TO_CONSOLE",
    ()=>_DYN_WARN_TO_CONSOLE,
    "_DYN_WATCH",
    ()=>_DYN_WATCH,
    "_DYN__DO_TEARDOWN",
    ()=>_DYN__DO_TEARDOWN
]);
var _DYN_TO_LOWER_CASE = "toLowerCase"; // Count: 11
var _DYN_LENGTH = "length"; // Count: 64
var _DYN_WARN_TO_CONSOLE = "warnToConsole"; // Count: 4
var _DYN_THROW_INTERNAL = "throwInternal"; // Count: 5
var _DYN_WATCH = "watch"; // Count: 7
var _DYN_APPLY = "apply"; // Count: 7
var _DYN_PUSH = "push"; // Count: 42
var _DYN_SPLICE = "splice"; // Count: 9
var _DYN_LOGGER = "logger"; // Count: 20
var _DYN_CANCEL = "cancel"; // Count: 9
var _DYN_INITIALIZE = "initialize"; // Count: 5
var _DYN_IDENTIFIER = "identifier"; // Count: 8
var _DYN_REMOVE_NOTIFICATION_0 = "removeNotificationListener"; // Count: 4
var _DYN_ADD_NOTIFICATION_LIS1 = "addNotificationListener"; // Count: 4
var _DYN_IS_INITIALIZED = "isInitialized"; // Count: 11
var _DYN_GET_NOTIFY_MGR = "getNotifyMgr"; // Count: 5
var _DYN_GET_PLUGIN = "getPlugin"; // Count: 5
var _DYN_NAME = "name"; // Count: 9
var _DYN_PROCESS_NEXT = "processNext"; // Count: 15
var _DYN_GET_PROCESS_TEL_CONT2 = "getProcessTelContext"; // Count: 2
var _DYN_VALUE = "value"; // Count: 7
var _DYN_ENABLED = "enabled"; // Count: 6
var _DYN_STOP_POLLING_INTERNA3 = "stopPollingInternalLogs"; // Count: 2
var _DYN_UNLOAD = "unload"; // Count: 7
var _DYN_ON_COMPLETE = "onComplete"; // Count: 4
var _DYN_VERSION = "version"; // Count: 4
var _DYN_LOGGING_LEVEL_CONSOL4 = "loggingLevelConsole"; // Count: 2
var _DYN_CREATE_NEW = "createNew"; // Count: 7
var _DYN_TEARDOWN = "teardown"; // Count: 9
var _DYN_MESSAGE_ID = "messageId"; // Count: 4
var _DYN_MESSAGE = "message"; // Count: 7
var _DYN_DIAG_LOG = "diagLog"; // Count: 9
var _DYN__DO_TEARDOWN = "_doTeardown"; // Count: 5
var _DYN_UPDATE = "update"; // Count: 5
var _DYN_GET_NEXT = "getNext"; // Count: 10
var _DYN_SET_NEXT_PLUGIN = "setNextPlugin"; // Count: 5
var _DYN_USER_AGENT = "userAgent"; // Count: 5
var _DYN_SPLIT = "split"; // Count: 8
var _DYN_REPLACE = "replace"; // Count: 9
var _DYN_SUBSTRING = "substring"; // Count: 4
var _DYN_INDEX_OF = "indexOf"; // Count: 5
var _DYN_TYPE = "type"; // Count: 17
var _DYN_EVT_NAME = "evtName"; // Count: 4
var _DYN_STATUS = "status"; // Count: 9
var _DYN_GET_ALL_RESPONSE_HEA5 = "getAllResponseHeaders"; // Count: 2
var _DYN_IS_CHILD_EVT = "isChildEvt"; // Count: 3
var _DYN_DATA = "data"; // Count: 11
var _DYN_GET_CTX = "getCtx"; // Count: 6
var _DYN_SET_CTX = "setCtx"; // Count: 10
var _DYN_ITEMS_RECEIVED = "itemsReceived"; // Count: 3
var _DYN_HEADERS = "headers"; // Count: 6
var _DYN_URL_STRING = "urlString"; // Count: 5
var _DYN_TIMEOUT = "timeout"; // Count: 6
var _DYN_TOTAL_REQUEST = "totalRequest"; // Count: 4
var _DYN_REQUEST_DURATION = "requestDuration"; // Count: 3
var _DYN_FAILURE = "failure"; // Count: 4
var _DYN_EXCEPTION = "exception"; // Count: 4
var _DYN_THROTTLE = "throttle"; // Count: 4
var _DYN_TRACE_FLAGS = "traceFlags"; // Count: 5
var _DYN_GET_ATTRIBUTE = "getAttribute"; // Count: 3
 //# sourceMappingURL=__DynamicConstants.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ // ###################################################################################################################################################
// Note: DON'T Export these const from the package as we are still targeting IE/ES5 this will export a mutable variables that someone could change ###
// ###################################################################################################################################################
__turbopack_context__.s([
    "DEFAULT_SENSITIVE_PARAMS",
    ()=>DEFAULT_SENSITIVE_PARAMS,
    "STR_CHANNELS",
    ()=>STR_CHANNELS,
    "STR_CORE",
    ()=>STR_CORE,
    "STR_CREATE_PERF_MGR",
    ()=>STR_CREATE_PERF_MGR,
    "STR_DISABLED",
    ()=>STR_DISABLED,
    "STR_DOMAIN",
    ()=>STR_DOMAIN,
    "STR_EMPTY",
    ()=>STR_EMPTY,
    "STR_EVENTS_DISCARDED",
    ()=>STR_EVENTS_DISCARDED,
    "STR_EVENTS_SEND_REQUEST",
    ()=>STR_EVENTS_SEND_REQUEST,
    "STR_EVENTS_SENT",
    ()=>STR_EVENTS_SENT,
    "STR_EXTENSIONS",
    ()=>STR_EXTENSIONS,
    "STR_EXTENSION_CONFIG",
    ()=>STR_EXTENSION_CONFIG,
    "STR_GET_PERF_MGR",
    ()=>STR_GET_PERF_MGR,
    "STR_NOT_DYNAMIC_ERROR",
    ()=>STR_NOT_DYNAMIC_ERROR,
    "STR_OFFLINE_DROP",
    ()=>STR_OFFLINE_DROP,
    "STR_OFFLINE_SENT",
    ()=>STR_OFFLINE_SENT,
    "STR_OFFLINE_STORE",
    ()=>STR_OFFLINE_STORE,
    "STR_PATH",
    ()=>STR_PATH,
    "STR_PERF_EVENT",
    ()=>STR_PERF_EVENT,
    "STR_PRIORITY",
    ()=>STR_PRIORITY,
    "STR_PROCESS_TELEMETRY",
    ()=>STR_PROCESS_TELEMETRY,
    "STR_REDACTED",
    ()=>STR_REDACTED,
    "UNDEFINED_VALUE",
    ()=>UNDEFINED_VALUE
]);
var UNDEFINED_VALUE = undefined;
var STR_EMPTY = "";
var STR_CHANNELS = "channels";
var STR_CORE = "core";
var STR_CREATE_PERF_MGR = "createPerfMgr";
var STR_DISABLED = "disabled";
var STR_EXTENSION_CONFIG = "extensionConfig";
var STR_EXTENSIONS = "extensions";
var STR_PROCESS_TELEMETRY = "processTelemetry";
var STR_PRIORITY = "priority";
var STR_EVENTS_SENT = "eventsSent";
var STR_EVENTS_DISCARDED = "eventsDiscarded";
var STR_EVENTS_SEND_REQUEST = "eventsSendRequest";
var STR_PERF_EVENT = "perfEvent";
var STR_OFFLINE_STORE = "offlineEventsStored";
var STR_OFFLINE_SENT = "offlineBatchSent";
var STR_OFFLINE_DROP = "offlineBatchDrop";
var STR_GET_PERF_MGR = "getPerfMgr";
var STR_DOMAIN = "domain";
var STR_PATH = "path";
var STR_NOT_DYNAMIC_ERROR = "Not dynamic - ";
var STR_REDACTED = "REDACTED";
var DEFAULT_SENSITIVE_PARAMS = [
    "sig",
    "Signature",
    "AWSAccessKeyId",
    "X-Goog-Signature"
]; //# sourceMappingURL=InternalConstants.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "_appendHeader",
    ()=>_appendHeader,
    "_getAllResponseHeaders",
    ()=>_getAllResponseHeaders,
    "_getObjProto",
    ()=>_getObjProto,
    "asString",
    ()=>asString,
    "convertAllHeadersToMap",
    ()=>convertAllHeadersToMap,
    "createClassFromInterface",
    ()=>createClassFromInterface,
    "deepFreeze",
    ()=>deepFreeze,
    "formatErrorMessageXdr",
    ()=>formatErrorMessageXdr,
    "formatErrorMessageXhr",
    ()=>formatErrorMessageXhr,
    "getExceptionName",
    ()=>getExceptionName,
    "getResponseText",
    ()=>getResponseText,
    "getSetValue",
    ()=>getSetValue,
    "isFeatureEnabled",
    ()=>isFeatureEnabled,
    "isNotNullOrUndefined",
    ()=>isNotNullOrUndefined,
    "isNotUndefined",
    ()=>isNotUndefined,
    "normalizeJsName",
    ()=>normalizeJsName,
    "objExtend",
    ()=>objExtend,
    "openXhr",
    ()=>openXhr,
    "optimizeObject",
    ()=>optimizeObject,
    "prependTransports",
    ()=>prependTransports,
    "proxyAssign",
    ()=>proxyAssign,
    "proxyFunctionAs",
    ()=>proxyFunctionAs,
    "proxyFunctions",
    ()=>proxyFunctions,
    "setValue",
    ()=>setValue,
    "strContains",
    ()=>strContains,
    "toISOString",
    ()=>toISOString
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__objAssign__as__ObjAssign$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript) <export objAssign as ObjAssign>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-shims@3.0.1/node_modules/@microsoft/applicationinsights-shims/dist-es5/Constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
;
;
;
;
// RESTRICT and AVOID circular dependencies you should not import other contained modules or export the contents of this file directly
// Added to help with minification
var strGetPrototypeOf = "getPrototypeOf";
var rCamelCase = /-([a-z])/g;
var rNormalizeInvalid = /([^\w\d_$])/g;
var rLeadingNumeric = /^(\d+[\w\d_$])/;
var _getObjProto = Object[strGetPrototypeOf];
function isNotUndefined(value) {
    return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"])(value);
}
function isNotNullOrUndefined(value) {
    return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(value);
}
function normalizeJsName(name) {
    var value = name;
    if (value && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(value)) {
        // CamelCase everything after the "-" and remove the dash
        value = value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REPLACE"] /* @min:%2ereplace */ ](rCamelCase, function(_all, letter) {
            return letter.toUpperCase();
        });
        value = value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REPLACE"] /* @min:%2ereplace */ ](rNormalizeInvalid, "_");
        value = value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REPLACE"] /* @min:%2ereplace */ ](rLeadingNumeric, function(_all, match) {
            return "_" + match;
        });
    }
    return value;
}
function strContains(value, search) {
    if (value && search) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strIndexOf"])(value, search) !== -1;
    }
    return false;
}
function toISOString(date) {
    return date && date.toISOString() || "";
}
var deepFreeze = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDeepFreeze"];
function getExceptionName(object) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isError"])(object)) {
        return object[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ];
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"];
}
function setValue(target, field, value, valChk, srcChk) {
    var theValue = value;
    if (target) {
        theValue = target[field];
        if (theValue !== value && (!srcChk || srcChk(theValue)) && (!valChk || valChk(value))) {
            theValue = value;
            target[field] = theValue;
        }
    }
    return theValue;
}
function getSetValue(target, field, defValue) {
    var theValue;
    if (target) {
        theValue = target[field];
        if (!theValue && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(theValue)) {
            // Supports having the default as null
            theValue = !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"])(defValue) ? defValue : {};
            target[field] = theValue;
        }
    } else {
        // Expanded for performance so we only check defValue if required
        theValue = !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"])(defValue) ? defValue : {};
    }
    return theValue;
}
function _createProxyFunction(source, funcName) {
    var srcFunc = null;
    var src = null;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(source)) {
        srcFunc = source;
    } else {
        src = source;
    }
    return function() {
        // Capture the original arguments passed to the method
        var originalArguments = arguments;
        if (srcFunc) {
            src = srcFunc();
        }
        if (src) {
            return src[funcName][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY"] /* @min:%2eapply */ ](src, originalArguments);
        }
    };
}
function proxyAssign(target, source, chkSet) {
    if (target && source && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(target) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(source)) {
        var _loop_1 = function(field) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(field)) {
                var value = source[field];
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(value)) {
                    if (!chkSet || chkSet(field, true, source, target)) {
                        // Create a proxy function rather than just copying the (possible) prototype to the new object as an instance function
                        target[field] = _createProxyFunction(source, field);
                    }
                } else if (!chkSet || chkSet(field, false, source, target)) {
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objHasOwn"])(target, field)) {
                        // Remove any previous instance property
                        delete target[field];
                    }
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(target, field, {
                        g: function() {
                            return source[field];
                        },
                        s: function(theValue) {
                            source[field] = theValue;
                        }
                    });
                }
            }
        };
        // effectively apply/proxy full source to the target instance
        for(var field in source){
            _loop_1(field);
        }
    }
    return target;
}
function proxyFunctionAs(target, name, source, theFunc, overwriteTarget) {
    if (target && name && source) {
        if (overwriteTarget !== false || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"])(target[name])) {
            target[name] = _createProxyFunction(source, theFunc);
        }
    }
}
function proxyFunctions(target, source, functionsToProxy, overwriteTarget) {
    if (target && source && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(target) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(functionsToProxy)) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(functionsToProxy, function(theFuncName) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(theFuncName)) {
                proxyFunctionAs(target, theFuncName, source, theFuncName, overwriteTarget);
            }
        });
    }
    return target;
}
function createClassFromInterface(defaults) {
    return function() {
        function class_1() {
            var _this = this;
            if (defaults) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(defaults, function(field, value) {
                    _this[field] = value;
                });
            }
        }
        return class_1;
    }();
}
function optimizeObject(theObject) {
    // V8 Optimization to cause the JIT compiler to create a new optimized object for looking up the own properties
    // primarily for object with <= 19 properties for >= 20 the effect is reduced or non-existent
    if (theObject && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__objAssign__as__ObjAssign$3e$__["ObjAssign"]) {
        theObject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ObjClass"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__objAssign__as__ObjAssign$3e$__["ObjAssign"])({}, theObject));
    }
    return theObject;
}
function objExtend(obj1, obj2, obj3, obj4, obj5, obj6) {
    // Variables
    var theArgs = arguments;
    var extended = theArgs[0] || {};
    var argLen = theArgs[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
    var deep = false;
    var idx = 1;
    // Check for "Deep" flag
    if (argLen > 0 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isBoolean"])(extended)) {
        deep = extended;
        extended = theArgs[idx] || {};
        idx++;
    }
    // Handle case when target is a string or something (possible in deep copy)
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(extended)) {
        extended = {};
    }
    // Loop through each remaining object and conduct a merge
    for(; idx < argLen; idx++){
        var arg = theArgs[idx];
        var isArgArray = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(arg);
        var isArgObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(arg);
        for(var prop in arg){
            var propOk = isArgArray && prop in arg || isArgObj && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objHasOwn"])(arg, prop);
            if (!propOk) {
                continue;
            }
            var newValue = arg[prop];
            var isNewArray = void 0;
            // If deep merge and property is an object, merge properties
            if (deep && newValue && ((isNewArray = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(newValue)) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPlainObject"])(newValue))) {
                // Grab the current value of the extended object
                var clone = extended[prop];
                if (isNewArray) {
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(clone)) {
                        // We can't "merge" an array with a non-array so overwrite the original
                        clone = [];
                    }
                } else if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPlainObject"])(clone)) {
                    // We can't "merge" an object with a non-object
                    clone = {};
                }
                // Never move the original objects always clone them
                newValue = objExtend(deep, clone, newValue);
            }
            // Assign the new (or previous) value (unless undefined)
            if (newValue !== undefined) {
                extended[prop] = newValue;
            }
        }
    }
    return extended;
}
var asString = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asString"];
function isFeatureEnabled(feature, cfg, sdkDefaultState) {
    var ft = cfg && cfg.featureOptIn && cfg.featureOptIn[feature];
    if (feature && ft) {
        var mode = ft.mode;
        // NOTE: None will be considered as true
        if (mode === 3 /* FeatureOptInMode.enable */ ) {
            return true;
        } else if (mode === 2 /* FeatureOptInMode.disable */ ) {
            return false;
        }
    }
    // Return the default state if provided or undefined
    return sdkDefaultState;
}
function getResponseText(xhr) {
    try {
        return xhr.responseText;
    } catch (e) {
    // Best effort, as XHR may throw while XDR wont so just ignore
    }
    return null;
}
function formatErrorMessageXdr(xdr, message) {
    if (xdr) {
        return "XDomainRequest,Response:" + getResponseText(xdr) || "";
    }
    return message;
}
function formatErrorMessageXhr(xhr, message) {
    if (xhr) {
        return "XMLHttpRequest,Status:" + xhr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ] + ",Response:" + getResponseText(xhr) || xhr.response || "";
    }
    return message;
}
function prependTransports(theTransports, newTransports) {
    if (newTransports) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNumber"])(newTransports)) {
            theTransports = [
                newTransports
            ].concat(theTransports);
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(newTransports)) {
            theTransports = newTransports.concat(theTransports);
        }
    }
    return theTransports;
}
var strDisabledPropertyName = "Microsoft_ApplicationInsights_BypassAjaxInstrumentation";
var strWithCredentials = "withCredentials";
var strTimeout = "timeout";
function openXhr(method, urlString, withCredentials, disabled, isSync, timeout) {
    if (disabled === void 0) {
        disabled = false;
    }
    if (isSync === void 0) {
        isSync = false;
    }
    function _wrapSetXhrProp(xhr, prop, value) {
        try {
            xhr[prop] = value;
        } catch (e) {
        // - Wrapping as depending on the environment setting the property may fail (non-terminally)
        }
    }
    var xhr = new XMLHttpRequest();
    if (disabled) {
        // Tag the instance so it's not tracked (trackDependency)
        // If the environment has locked down the XMLHttpRequest (preventExtensions and/or freeze), this would
        // cause the request to fail and we no telemetry would be sent
        _wrapSetXhrProp(xhr, strDisabledPropertyName, disabled);
    }
    if (withCredentials) {
        // Some libraries require that the withCredentials flag is set "before" open and
        // - Wrapping as IE 10 has started throwing when setting before open
        _wrapSetXhrProp(xhr, strWithCredentials, withCredentials);
    }
    xhr.open(method, urlString, !isSync);
    if (withCredentials) {
        // withCredentials should be set AFTER open (https://xhr.spec.whatwg.org/#the-withcredentials-attribute)
        // And older firefox instances from 11+ will throw for sync events (current versions don't) which happens during unload processing
        _wrapSetXhrProp(xhr, strWithCredentials, withCredentials);
    }
    // Only set the timeout for asynchronous requests as
    // "Timeout shouldn't be used for synchronous XMLHttpRequests requests used in a document environment or it will throw an InvalidAccessError exception.""
    // https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest/timeout
    if (!isSync && timeout) {
        _wrapSetXhrProp(xhr, strTimeout, timeout);
    }
    return xhr;
}
function convertAllHeadersToMap(headersString) {
    var headers = {};
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(headersString)) {
        var headersArray = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strTrim"])(headersString)[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPLIT"] /* @min:%2esplit */ ](/[\r\n]+/);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(headersArray, function(headerEntry) {
            if (headerEntry) {
                var idx = headerEntry[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INDEX_OF"] /* @min:%2eindexOf */ ](": ");
                if (idx !== -1) {
                    // The new spec has the headers returning all as lowercase -- but not all browsers do this yet
                    var header = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strTrim"])(headerEntry.substring(0, idx))[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ]();
                    var value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strTrim"])(headerEntry[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SUBSTRING"] /* @min:%2esubstring */ ](idx + 1));
                    headers[header] = value;
                } else {
                    headers[(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strTrim"])(headerEntry)] = 1;
                }
            }
        });
    }
    return headers;
}
function _appendHeader(theHeaders, xhr, name) {
    if (!theHeaders[name] && xhr && xhr.getResponseHeader) {
        var value = xhr.getResponseHeader(name);
        if (value) {
            theHeaders[name] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strTrim"])(value);
        }
    }
    return theHeaders;
}
var STR_KILL_DURATION_HEADER = "kill-duration";
var STR_KILL_DURATION_SECONDS_HEADER = "kill-duration-seconds";
var STR_TIME_DELTA_HEADER = "time-delta-millis";
function _getAllResponseHeaders(xhr, isOneDs) {
    var theHeaders = {};
    if (!xhr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_ALL_RESPONSE_HEA5"] /* @min:%2egetAllResponseHeaders */ ]) {
        // Firefox 2-63 doesn't have getAllResponseHeaders function but it does have getResponseHeader
        // Only call these if getAllResponseHeaders doesn't exist, otherwise we can get invalid response errors
        // as collector is not currently returning the correct header to allow JS to access these headers
        if (!!isOneDs) {
            theHeaders = _appendHeader(theHeaders, xhr, STR_TIME_DELTA_HEADER);
            theHeaders = _appendHeader(theHeaders, xhr, STR_KILL_DURATION_HEADER);
            theHeaders = _appendHeader(theHeaders, xhr, STR_KILL_DURATION_SECONDS_HEADER);
        }
    } else {
        theHeaders = convertAllHeadersToMap(xhr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_ALL_RESPONSE_HEA5"] /* @min:%2egetAllResponseHeaders */ ]());
    }
    return theHeaders;
} //# sourceMappingURL=HelperFuncs.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EnvUtils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "createCustomDomEvent",
    ()=>createCustomDomEvent,
    "dispatchEvent",
    ()=>dispatchEvent,
    "fieldRedaction",
    ()=>fieldRedaction,
    "findMetaTag",
    ()=>findMetaTag,
    "findNamedServerTiming",
    ()=>findNamedServerTiming,
    "getConsole",
    ()=>getConsole,
    "getCrypto",
    ()=>getCrypto,
    "getIEVersion",
    ()=>getIEVersion,
    "getJSON",
    ()=>getJSON,
    "getLocation",
    ()=>getLocation,
    "getMsCrypto",
    ()=>getMsCrypto,
    "hasJSON",
    ()=>hasJSON,
    "isBeaconsSupported",
    ()=>isBeaconsSupported,
    "isFetchSupported",
    ()=>isFetchSupported,
    "isIE",
    ()=>isIE,
    "isReactNative",
    ()=>isReactNative,
    "isSafari",
    ()=>isSafari,
    "isXhrSupported",
    ()=>isXhrSupported,
    "sendCustomEvent",
    ()=>sendCustomEvent,
    "setEnableEnvMocks",
    ()=>setEnableEnvMocks,
    "useXDomainRequest",
    ()=>useXDomainRequest
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-shims@3.0.1/node_modules/@microsoft/applicationinsights-shims/dist-es5/Constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
"use strict";
;
;
;
;
;
/**
 * This file exists to hold environment utilities that are required to check and
 * validate the current operating environment. Unless otherwise required, please
 * only use defined methods (functions) in this class so that users of these
 * functions/properties only need to include those that are used within their own modules.
 */ var strDocumentMode = "documentMode";
var strLocation = "location";
var strConsole = "console";
var strJSON = "JSON";
var strCrypto = "crypto";
var strMsCrypto = "msCrypto";
var strReactNative = "ReactNative";
var strMsie = "msie";
var strTrident = "trident/";
var strXMLHttpRequest = "XMLHttpRequest";
var _isTrident = null;
var _navUserAgentCheck = null;
var _enableMocks = false;
var _useXDomainRequest = null;
var _beaconsSupported = null;
function _hasProperty(theClass, property) {
    var supported = false;
    if (theClass) {
        try {
            supported = property in theClass;
            if (!supported) {
                var proto = theClass[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strShimPrototype"]];
                if (proto) {
                    supported = property in proto;
                }
            }
        } catch (e) {
        // Do Nothing
        }
        if (!supported) {
            try {
                var tmp = new theClass();
                supported = !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"])(tmp[property]);
            } catch (e) {
            // Do Nothing
            }
        }
    }
    return supported;
}
function setEnableEnvMocks(enabled) {
    _enableMocks = enabled;
}
function getLocation(checkForMock) {
    if (checkForMock && _enableMocks) {
        var mockLocation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInst"])("__mockLocation");
        if (mockLocation) {
            return mockLocation;
        }
    }
    if (typeof location === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strShimObject"] && location) {
        return location;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInst"])(strLocation);
}
function getConsole() {
    if (typeof console !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strShimUndefined"]) {
        return console;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInst"])(strConsole);
}
function hasJSON() {
    return Boolean(typeof JSON === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strShimObject"] && JSON || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInst"])(strJSON) !== null);
}
function getJSON() {
    if (hasJSON()) {
        return JSON || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInst"])(strJSON);
    }
    return null;
}
function getCrypto() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInst"])(strCrypto);
}
function getMsCrypto() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInst"])(strMsCrypto);
}
function isReactNative() {
    // If running in React Native, navigator.product will be populated
    var nav = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNavigator"])();
    if (nav && nav.product) {
        return nav.product === strReactNative;
    }
    return false;
}
function isIE() {
    var nav = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNavigator"])();
    if (nav && (nav[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_USER_AGENT"] /* @min:%2euserAgent */ ] !== _navUserAgentCheck || _isTrident === null)) {
        // Added to support test mocking of the user agent
        _navUserAgentCheck = nav[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_USER_AGENT"] /* @min:%2euserAgent */ ];
        var userAgent = (_navUserAgentCheck || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"])[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ]();
        _isTrident = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strContains"])(userAgent, strMsie) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strContains"])(userAgent, strTrident);
    }
    return _isTrident;
}
function getIEVersion(userAgentStr) {
    if (userAgentStr === void 0) {
        userAgentStr = null;
    }
    if (!userAgentStr) {
        var navigator_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNavigator"])() || {};
        userAgentStr = navigator_1 ? (navigator_1.userAgent || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"])[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ]() : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"];
    }
    var ua = (userAgentStr || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"])[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ]();
    // Also check for documentMode in case X-UA-Compatible meta tag was included in HTML.
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strContains"])(ua, strMsie)) {
        var doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])() || {};
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mathMax"])(parseInt(ua[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPLIT"] /* @min:%2esplit */ ](strMsie)[1]), doc[strDocumentMode] || 0);
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strContains"])(ua, strTrident)) {
        var tridentVer = parseInt(ua[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPLIT"] /* @min:%2esplit */ ](strTrident)[1]);
        if (tridentVer) {
            return tridentVer + 4;
        }
    }
    return null;
}
function isSafari(userAgentStr) {
    if (!userAgentStr || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(userAgentStr)) {
        var navigator_2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNavigator"])() || {};
        userAgentStr = navigator_2 ? (navigator_2.userAgent || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"])[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ]() : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"];
    }
    var ua = (userAgentStr || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"])[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ]();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strIndexOf"])(ua, "safari") >= 0;
}
function isBeaconsSupported(useCached) {
    if (_beaconsSupported === null || useCached === false) {
        _beaconsSupported = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasNavigator"])() && Boolean((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNavigator"])().sendBeacon);
    }
    return _beaconsSupported;
}
function isFetchSupported(withKeepAlive) {
    var isSupported = false;
    try {
        isSupported = !!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInst"])("fetch");
        var request = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInst"])("Request");
        if (isSupported && withKeepAlive && request) {
            isSupported = _hasProperty(request, "keepalive");
        }
    } catch (e) {
    // Just Swallow any failure during availability checks
    }
    return isSupported;
}
function useXDomainRequest() {
    if (_useXDomainRequest === null) {
        _useXDomainRequest = typeof XDomainRequest !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strShimUndefined"];
        if (_useXDomainRequest && isXhrSupported()) {
            _useXDomainRequest = _useXDomainRequest && !_hasProperty((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInst"])(strXMLHttpRequest), "withCredentials");
        }
    }
    return _useXDomainRequest;
}
function isXhrSupported() {
    var isSupported = false;
    try {
        var xmlHttpRequest = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInst"])(strXMLHttpRequest);
        isSupported = !!xmlHttpRequest;
    } catch (e) {
    // Just Swallow any failure during availability checks
    }
    return isSupported;
}
function _getNamedValue(values, name) {
    if (values) {
        for(var i = 0; i < values[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; i++){
            var value = values[i];
            if (value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ]) {
                if (value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ] === name) {
                    return value;
                }
            }
        }
    }
    return {};
}
function findMetaTag(name) {
    var doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])();
    if (doc && name) {
        // Look for a meta-tag
        return _getNamedValue(doc.querySelectorAll("meta"), name).content;
    }
    return null;
}
function findNamedServerTiming(name) {
    var value;
    var perf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPerformance"])();
    if (perf) {
        // Try looking for a server-timing header
        var navPerf = perf.getEntriesByType("navigation") || [];
        value = _getNamedValue((navPerf[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0 ? navPerf[0] : {}).serverTiming, name).description;
    }
    return value;
}
function dispatchEvent(target, evnt) {
    if (target && target.dispatchEvent && evnt) {
        target.dispatchEvent(evnt);
        return true;
    }
    return false;
}
function createCustomDomEvent(eventName, details) {
    var event = null;
    var detail = {
        detail: details || null
    };
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(CustomEvent)) {
        event = new CustomEvent(eventName, detail);
    } else {
        var doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])();
        if (doc && doc.createEvent) {
            event = doc.createEvent("CustomEvent");
            event.initCustomEvent(eventName, true, true, detail);
        }
    }
    return event;
}
function sendCustomEvent(evtName, cfg, customDetails) {
    var global = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobal"])();
    if (global && global.CustomEvent) {
        try {
            var details = {
                cfg: cfg || null,
                customDetails: customDetails || null
            };
            return dispatchEvent(global, createCustomDomEvent(evtName, details));
        } catch (e) {
        // eslint-disable-next-line no-empty
        }
    }
    return false;
}
/**
 * Redacts user information from a URL
 * @param url - The URL string to redact
 * @returns The URL with user information redacted
 */ function redactUserInfo(url) {
    return url.replace(/^([a-zA-Z][a-zA-Z0-9+.-]*:\/\/)([^:@]{1,200}):([^@]{1,200})@(.*)$/, "$1REDACTED:REDACTED@$4");
}
/**
 * Redacts sensitive query parameters from a URL
 * @param url - The URL string to redact
 * @returns The URL with sensitive query parameters redacted
 */ function redactQueryParameters(url, config) {
    var sensitiveParams;
    var questionMarkIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strIndexOf"])(url, "?");
    if (questionMarkIndex === -1) {
        return url;
    }
    if (config && config.redactQueryParams) {
        sensitiveParams = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SENSITIVE_PARAMS"].concat(config.redactQueryParams);
    } else {
        sensitiveParams = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SENSITIVE_PARAMS"];
    }
    var baseUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstring"])(url, 0, questionMarkIndex + 1);
    var queryString = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstring"])(url, questionMarkIndex + 1);
    var fragment = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"];
    var hashIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strIndexOf"])(queryString, "#");
    if (hashIndex !== -1) {
        fragment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstring"])(queryString, hashIndex);
        queryString = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstring"])(queryString, 0, hashIndex);
    }
    var hasPotentialSensitiveParam = false;
    for(var i = 0; i < sensitiveParams[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; i++){
        var paramCheck = sensitiveParams[i] + "=";
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strIndexOf"])(queryString, paramCheck) !== -1) {
            hasPotentialSensitiveParam = true;
            break;
        }
    }
    if (!hasPotentialSensitiveParam) {
        return url;
    }
    var resultParts = [];
    var anyParamRedacted = false;
    if (queryString && queryString[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]) {
        var pairs = queryString[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPLIT"] /* @min:%2esplit */ ]("&");
        for(var i = 0; i < pairs[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; i++){
            var pair = pairs[i];
            if (!pair) {
                continue;
            }
            var equalsIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strIndexOf"])(pair, "=");
            if (equalsIndex === -1) {
                // Parameter without value
                resultParts[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](pair);
            } else {
                var paramName = pair[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SUBSTRING"] /* @min:%2esubstring */ ](0, equalsIndex);
                var paramValue = pair[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SUBSTRING"] /* @min:%2esubstring */ ](equalsIndex + 1);
                if (paramValue === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"]) {
                    resultParts[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](pair);
                } else {
                    var shouldRedact = false;
                    for(var j = 0; j < sensitiveParams[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; j++){
                        if (paramName === sensitiveParams[j]) {
                            shouldRedact = true;
                            anyParamRedacted = true;
                            break;
                        }
                    }
                    if (shouldRedact) {
                        resultParts[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](paramName + "=" + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_REDACTED"]);
                    } else {
                        resultParts[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](pair);
                    }
                }
            }
        }
    }
    // If no parameters were redacted, return the original URL
    if (!anyParamRedacted) {
        return url;
    }
    return baseUrl + resultParts.join("&") + fragment;
}
function fieldRedaction(input, config) {
    if (!input || input[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INDEX_OF"] /* @min:%2eindexOf */ ](" ") !== -1) {
        return input;
    }
    var isRedactionDisabled = config && config.redactUrls === false;
    if (isRedactionDisabled) {
        return input;
    }
    var hasCredentials = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strIndexOf"])(input, "@") !== -1;
    var hasQueryParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strIndexOf"])(input, "?") !== -1;
    // If no credentials and no query params, return original
    if (!hasCredentials && !hasQueryParams) {
        return input;
    }
    try {
        var result = input;
        if (hasCredentials) {
            result = redactUserInfo(input);
        }
        if (hasQueryParams) {
            result = redactQueryParameters(result, config);
        }
        return result;
    } catch (e) {
        return input;
    }
} //# sourceMappingURL=EnvUtils.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/RandomHelper.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "mwcRandom32",
    ()=>mwcRandom32,
    "mwcRandomSeed",
    ()=>mwcRandomSeed,
    "newId",
    ()=>newId,
    "random32",
    ()=>random32,
    "randomValue",
    ()=>randomValue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EnvUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
;
;
;
;
var UInt32Mask = 0x100000000;
var MaxUInt32 = 0xffffffff;
var SEED1 = 123456789;
var SEED2 = 987654321;
// MWC based Random generator (for IE)
var _mwcSeeded = false;
var _mwcW = SEED1;
var _mwcZ = SEED2;
// Takes any integer
function _mwcSeed(seedValue) {
    if (seedValue < 0) {
        // Make sure we end up with a positive number and not -ve one.
        seedValue >>>= 0;
    }
    _mwcW = SEED1 + seedValue & MaxUInt32;
    _mwcZ = SEED2 - seedValue & MaxUInt32;
    _mwcSeeded = true;
}
function _autoSeedMwc() {
    // Simple initialization using default Math.random() - So we inherit any entropy from the browser
    // and bitwise XOR with the current milliseconds
    try {
        var now = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utcNow"])() & 0x7fffffff;
        _mwcSeed((Math.random() * UInt32Mask ^ now) + now);
    } catch (e) {
    // Don't crash if something goes wrong
    }
}
function randomValue(maxValue) {
    if (maxValue > 0) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mathFloor"])(random32() / MaxUInt32 * (maxValue + 1)) >>> 0;
    }
    return 0;
}
function random32(signed) {
    var value = 0;
    var c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCrypto"])() || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMsCrypto"])();
    if (c && c.getRandomValues) {
        // Make sure the number is converted into the specified range (-0x80000000..0x7FFFFFFF)
        value = c.getRandomValues(new Uint32Array(1))[0] & MaxUInt32;
    }
    if (value === 0 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isIE"])()) {
        // For IE 6, 7, 8 (especially on XP) Math.random is not very random
        if (!_mwcSeeded) {
            // Set the seed for the Mwc algorithm
            _autoSeedMwc();
        }
        // Don't use Math.random for IE
        // Make sure the number is converted into the specified range (-0x80000000..0x7FFFFFFF)
        value = mwcRandom32() & MaxUInt32;
    }
    if (value === 0) {
        // Make sure the number is converted into the specified range (-0x80000000..0x7FFFFFFF)
        value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mathFloor"])(UInt32Mask * Math.random() | 0);
    }
    if (!signed) {
        // Make sure we end up with a positive number and not -ve one.
        value >>>= 0;
    }
    return value;
}
function mwcRandomSeed(value) {
    if (!value) {
        _autoSeedMwc();
    } else {
        _mwcSeed(value);
    }
}
function mwcRandom32(signed) {
    _mwcZ = 36969 * (_mwcZ & 0xFFFF) + (_mwcZ >> 16) & MaxUInt32;
    _mwcW = 18000 * (_mwcW & 0xFFFF) + (_mwcW >> 16) & MaxUInt32;
    var value = (_mwcZ << 16) + (_mwcW & 0xFFFF) >>> 0 & MaxUInt32 | 0;
    if (!signed) {
        // Make sure we end up with a positive number and not -ve one.
        value >>>= 0;
    }
    return value;
}
function newId(maxLength) {
    if (maxLength === void 0) {
        maxLength = 22;
    }
    var base64chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    // Start with an initial random number, consuming the value in reverse byte order
    var number = random32() >>> 0; // Make sure it's a +ve number
    var chars = 0;
    var result = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"];
    while(result[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] < maxLength){
        chars++;
        result += base64chars.charAt(number & 0x3F);
        number >>>= 6; // Zero fill with right shift
        if (chars === 5) {
            // 5 base64 characters === 30 bits so we don't have enough bits for another base64 char
            // So add on another 30 bits and make sure it's +ve
            number = (random32() << 2 & 0xFFFFFFFF | number & 0x03) >>> 0;
            chars = 0; // We need to reset the number every 5 chars (30 bits)
        }
    }
    return result;
} //# sourceMappingURL=RandomHelper.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DataCacheHelper.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "createElmNodeData",
    ()=>createElmNodeData,
    "createUniqueNamespace",
    ()=>createUniqueNamespace
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$RandomHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/RandomHelper.js [app-client] (ecmascript)");
;
;
;
;
var version = '3.3.10';
var instanceName = "." + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$RandomHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newId"])(6);
var _dataUid = 0;
// Accepts only:
//  - Node
//    - Node.ELEMENT_NODE
//    - Node.DOCUMENT_NODE
//  - Object
//    - Any
function _canAcceptData(target) {
    return target.nodeType === 1 || target.nodeType === 9 || !+target.nodeType;
}
function _getCache(data, target) {
    var theCache = target[data.id];
    if (!theCache) {
        theCache = {};
        try {
            if (_canAcceptData(target)) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(target, data.id, {
                    e: false,
                    v: theCache
                });
            }
        } catch (e) {
        // Not all environments allow extending all objects, so just ignore the cache in those cases
        }
    }
    return theCache;
}
function createUniqueNamespace(name, includeVersion) {
    if (includeVersion === void 0) {
        includeVersion = false;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeJsName"])(name + _dataUid++ + (includeVersion ? "." + version : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"]) + instanceName);
}
function createElmNodeData(name) {
    var data = {
        id: createUniqueNamespace("_aiData-" + (name || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"]) + "." + version),
        accept: function(target) {
            return _canAcceptData(target);
        },
        get: function(target, name, defValue, addDefault) {
            var theCache = target[data.id];
            if (!theCache) {
                if (addDefault) {
                    // Side effect is adds the cache
                    theCache = _getCache(data, target);
                    theCache[(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeJsName"])(name)] = defValue;
                }
                return defValue;
            }
            return theCache[(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeJsName"])(name)];
        },
        kill: function(target, name) {
            if (target && target[name]) {
                try {
                    delete target[name];
                } catch (e) {
                // Just cleaning up, so if this fails -- ignore
                }
            }
        }
    };
    return data;
} //# sourceMappingURL=DataCacheHelper.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/ConfigDefaults.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "_applyDefaultValue",
    ()=>_applyDefaultValue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
;
function _isConfigDefaults(value) {
    return value && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(value) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(value) && (value.isVal || value.fb || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objHasOwn"])(value, "v") || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objHasOwn"])(value, "mrg") || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objHasOwn"])(value, "ref") || value.set);
}
function _getDefault(dynamicHandler, theConfig, cfgDefaults) {
    var defValue;
    var isDefaultValid = cfgDefaults.dfVal || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isDefined"];
    // There is a fallback config key so try and grab that first
    if (theConfig && cfgDefaults.fb) {
        var fallbacks = cfgDefaults.fb;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(fallbacks)) {
            fallbacks = [
                fallbacks
            ];
        }
        for(var lp = 0; lp < fallbacks[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; lp++){
            var fallback = fallbacks[lp];
            var fbValue = theConfig[fallback];
            if (isDefaultValid(fbValue)) {
                defValue = fbValue;
            } else if (dynamicHandler) {
                // Needed to ensure that the fallback value (and potentially) new field is also dynamic even if null/undefined
                fbValue = dynamicHandler.cfg[fallback];
                if (isDefaultValid(fbValue)) {
                    defValue = fbValue;
                }
                // Needed to ensure that the fallback value (and potentially) new field is also dynamic even if null/undefined
                dynamicHandler.set(dynamicHandler.cfg, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asString"])(fallback), fbValue);
            }
            if (isDefaultValid(defValue)) {
                break;
            }
        }
    }
    // If the value is still not defined and we have a default value then use that
    if (!isDefaultValid(defValue) && isDefaultValid(cfgDefaults.v)) {
        defValue = cfgDefaults.v;
    }
    return defValue;
}
/**
 * Recursively resolve the default value
 * @param dynamicHandler
 * @param theConfig
 * @param cfgDefaults
 * @returns
 */ function _resolveDefaultValue(dynamicHandler, theConfig, cfgDefaults) {
    var theValue = cfgDefaults;
    if (cfgDefaults && _isConfigDefaults(cfgDefaults)) {
        theValue = _getDefault(dynamicHandler, theConfig, cfgDefaults);
    }
    if (theValue) {
        if (_isConfigDefaults(theValue)) {
            theValue = _resolveDefaultValue(dynamicHandler, theConfig, theValue);
        }
        var newValue_1;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(theValue)) {
            newValue_1 = [];
            newValue_1[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] = theValue[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPlainObject"])(theValue)) {
            newValue_1 = {};
        }
        if (newValue_1) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(theValue, function(key, value) {
                if (value && _isConfigDefaults(value)) {
                    value = _resolveDefaultValue(dynamicHandler, theConfig, value);
                }
                newValue_1[key] = value;
            });
            theValue = newValue_1;
        }
    }
    return theValue;
}
function _applyDefaultValue(dynamicHandler, theConfig, name, defaultValue) {
    // Resolve the initial config value from the provided value or use the defined default
    var isValid;
    var setFn;
    var defValue;
    var cfgDefaults = defaultValue;
    var mergeDf;
    var reference;
    var readOnly;
    var blkDynamicValue;
    if (_isConfigDefaults(cfgDefaults)) {
        // looks like a IConfigDefault
        isValid = cfgDefaults.isVal;
        setFn = cfgDefaults.set;
        readOnly = cfgDefaults.rdOnly;
        blkDynamicValue = cfgDefaults.blkVal;
        mergeDf = cfgDefaults.mrg;
        reference = cfgDefaults.ref;
        if (!reference && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"])(reference)) {
            reference = !!mergeDf;
        }
        defValue = _getDefault(dynamicHandler, theConfig, cfgDefaults);
    } else {
        defValue = defaultValue;
    }
    if (blkDynamicValue) {
        // Mark the property so that any value assigned will be blocked from conversion, we need to do this
        // before assigning or fetching the value to ensure it's not converted
        dynamicHandler.blkVal(theConfig, name);
    }
    // Set the value to the default value;
    var theValue;
    var usingDefault = true;
    var cfgValue = theConfig[name];
    // try and get and user provided values
    if (cfgValue || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(cfgValue)) {
        // Use the defined theConfig[name] value
        theValue = cfgValue;
        usingDefault = false;
        // The values are different and we have a special default value check, which is used to
        // override config values like empty strings to continue using the default
        if (isValid && theValue !== defValue && !isValid(theValue)) {
            theValue = defValue;
            usingDefault = true;
        }
        if (setFn) {
            theValue = setFn(theValue, defValue, theConfig);
            usingDefault = theValue === defValue;
        }
    }
    if (!usingDefault) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPlainObject"])(theValue) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(defValue)) {
            // we are using the user supplied value and it's an object
            if (mergeDf && defValue && ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPlainObject"])(defValue) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(defValue))) {
                // Resolve/apply the defaults
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(defValue, function(dfName, dfValue) {
                    // Sets the value and makes it dynamic (if it doesn't already exist)
                    _applyDefaultValue(dynamicHandler, theValue, dfName, dfValue);
                });
            }
        }
    } else if (defValue) {
        // Just resolve the default
        theValue = _resolveDefaultValue(dynamicHandler, theConfig, defValue);
    } else {
        theValue = defValue;
    }
    // if (theValue && usingDefault && (isPlainObject(theValue) || isArray(theValue))) {
    //     theValue = _cfgDeepCopy(theValue);
    // }
    // Needed to ensure that the (potentially) new field is dynamic even if null/undefined
    dynamicHandler.set(theConfig, name, theValue);
    if (reference) {
        dynamicHandler.ref(theConfig, name);
    }
    if (readOnly) {
        dynamicHandler.rdOnly(theConfig, name);
    }
} //# sourceMappingURL=ConfigDefaults.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicSupport.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "CFG_HANDLER_LINK",
    ()=>CFG_HANDLER_LINK,
    "_canMakeDynamic",
    ()=>_canMakeDynamic,
    "_cfgDeepCopy",
    ()=>_cfgDeepCopy,
    "blockDynamicConversion",
    ()=>blockDynamicConversion,
    "forceDynamicConversion",
    ()=>forceDynamicConversion,
    "getDynamicConfigHandler",
    ()=>getDynamicConfigHandler,
    "throwInvalidAccess",
    ()=>throwInvalidAccess
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
;
var CFG_HANDLER_LINK = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["symbolFor"])("[[ai_dynCfg_1]]");
/**
 * @internal
 * @ignore
 * The symbol to tag objects / arrays with if they should not be converted
 */ var BLOCK_DYNAMIC = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["symbolFor"])("[[ai_blkDynCfg_1]]");
/**
 * @internal
 * @ignore
 * The symbol to tag objects to indicate that when included into the configuration that
 * they should be converted into a trackable dynamic object.
 */ var FORCE_DYNAMIC = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["symbolFor"])("[[ai_frcDynCfg_1]]");
function _cfgDeepCopy(source) {
    if (source) {
        var target_1;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(source)) {
            target_1 = [];
            target_1[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] = source[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPlainObject"])(source)) {
            target_1 = {};
        }
        if (target_1) {
            // Copying index values by property name as the extensionConfig can be an array or object
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(source, function(key, value) {
                // Perform a deep copy of the object
                target_1[key] = _cfgDeepCopy(value);
            });
            return target_1;
        }
    }
    return source;
}
function getDynamicConfigHandler(value) {
    if (value) {
        var handler = value[CFG_HANDLER_LINK] || value;
        if (handler.cfg && (handler.cfg === value || handler.cfg[CFG_HANDLER_LINK] === handler)) {
            return handler;
        }
    }
    return null;
}
function blockDynamicConversion(value) {
    if (value && ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPlainObject"])(value) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(value))) {
        try {
            value[BLOCK_DYNAMIC] = true;
        } catch (e) {
        // Don't throw for this case as it's an ask only
        }
    }
    return value;
}
function forceDynamicConversion(value) {
    if (value) {
        try {
            value[FORCE_DYNAMIC] = true;
        } catch (e) {
        // Don't throw for this case as it's an ask only
        }
    }
    return value;
}
function _canMakeDynamic(getFunc, state, value) {
    var result = false;
    // Object must exist and be truthy
    if (value && !getFunc[state.blkVal]) {
        // Tagged as always convert
        result = value[FORCE_DYNAMIC];
        // Check that it's not explicitly tagged as blocked
        if (!result && !value[BLOCK_DYNAMIC]) {
            // Only convert plain objects or arrays by default
            result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPlainObject"])(value) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(value);
        }
    }
    return result;
}
function throwInvalidAccess(message) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throwTypeError"])("InvalidAccess:" + message);
} //# sourceMappingURL=DynamicSupport.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicProperty.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "_makeDynamicObject",
    ()=>_makeDynamicObject,
    "_setDynamicProperty",
    ()=>_setDynamicProperty,
    "_setDynamicPropertyState",
    ()=>_setDynamicPropertyState,
    "_throwDynamicError",
    ()=>_throwDynamicError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicSupport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicSupport.js [app-client] (ecmascript)");
;
;
;
;
var arrayMethodsToPatch = [
    "push",
    "pop",
    "shift",
    "unshift",
    "splice"
];
var _throwDynamicError = function(logger, name, desc, e) {
    logger && logger[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_THROW_INTERNAL"] /* @min:%2ethrowInternal */ ](3 /* eLoggingSeverity.DEBUG */ , 108 /* _eInternalMessageId.DynamicConfigException */ , "".concat(desc, " [").concat(name, "] failed - ") + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e));
};
function _patchArray(state, target, name) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(target)) {
        // Monkey Patch the methods that might change the array
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(arrayMethodsToPatch, function(method) {
            var orgMethod = target[method];
            target[method] = function() {
                var args = [];
                for(var _i = 0; _i < arguments.length; _i++){
                    args[_i] = arguments[_i];
                }
                var result = orgMethod[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY"] /* @min:%2eapply */ ](this, args);
                // items may be added, removed or moved so need to make some new dynamic properties
                _makeDynamicObject(state, target, name, "Patching");
                return result;
            };
        });
    }
}
function _getOwnPropGetter(target, name) {
    var propDesc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objGetOwnPropertyDescriptor"])(target, name);
    return propDesc && propDesc.get;
}
function _createDynamicProperty(state, theConfig, name, value) {
    // Does not appear to be dynamic so lets make it so
    var detail = {
        n: name,
        h: [],
        trk: function(handler) {
            if (handler && handler.fn) {
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrIndexOf"])(detail.h, handler) === -1) {
                    // Add this handler to the collection that should be notified when the value changes
                    detail.h[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](handler);
                }
                state.trk(handler, detail);
            }
        },
        clr: function(handler) {
            var idx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrIndexOf"])(detail.h, handler);
            if (idx !== -1) {
                detail.h[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPLICE"] /* @min:%2esplice */ ](idx, 1);
            }
        }
    };
    // Flag to optimize lookup response time by avoiding additional function calls
    var checkDynamic = true;
    var isObjectOrArray = false;
    function _getProperty() {
        if (checkDynamic) {
            isObjectOrArray = isObjectOrArray || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicSupport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_canMakeDynamic"])(_getProperty, state, value);
            // Make sure that if it's an object that we make it dynamic
            if (value && !value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicSupport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CFG_HANDLER_LINK"]] && isObjectOrArray) {
                // It doesn't look like it's already dynamic so lets make sure it's converted the object into a dynamic Config as well
                value = _makeDynamicObject(state, value, name, "Converting");
            }
            // If it needed to be converted it now has been
            checkDynamic = false;
        }
        // If there is an active handler then add it to the tracking set of handlers
        var activeHandler = state.act;
        if (activeHandler) {
            detail.trk(activeHandler);
        }
        return value;
    }
    // Tag this getter as our dynamic property and provide shortcut for notifying a change
    _getProperty[state.prop] = {
        chng: function() {
            state.add(detail);
        }
    };
    function _setProperty(newValue) {
        if (value !== newValue) {
            if (!!_getProperty[state.ro] && !state.upd) {
                // field is marked as readonly so return false
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicSupport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throwInvalidAccess"])("[" + name + "] is read-only:" + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(theConfig));
            }
            if (checkDynamic) {
                isObjectOrArray = isObjectOrArray || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicSupport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_canMakeDynamic"])(_getProperty, state, value);
                checkDynamic = false;
            }
            // The value must be a plain object or an array to enforce the reference (in-place updates)
            var isReferenced = isObjectOrArray && _getProperty[state.rf];
            if (isObjectOrArray) {
                // We are about to replace a plain object or an array
                if (isReferenced) {
                    // Reassign the properties from the current value to the same properties from the newValue
                    // This will set properties not in the newValue to undefined
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(value, function(key) {
                        value[key] = newValue ? newValue[key] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNDEFINED_VALUE"];
                    });
                    // Now assign / re-assign value with all of the keys from newValue
                    try {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(newValue, function(key, theValue) {
                            _setDynamicProperty(state, value, key, theValue);
                        });
                        // Now drop newValue so when we assign value later it keeps the existing reference
                        newValue = value;
                    } catch (e) {
                        // Unable to convert to dynamic property so just leave as non-dynamic
                        _throwDynamicError((state.hdlr || {})[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ], name, "Assigning", e);
                        // Mark as not an object or array so we don't try and do this again
                        isObjectOrArray = false;
                    }
                } else if (value && value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicSupport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CFG_HANDLER_LINK"]]) {
                    // As we are replacing the value, if it's already dynamic then we need to notify the listeners
                    // for every property it has already
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(value, function(key) {
                        // Check if the value is dynamic
                        var getter = _getOwnPropGetter(value, key);
                        if (getter) {
                            // And if it is tell it's listeners that the value has changed
                            var valueState = getter[state.prop];
                            valueState && valueState.chng();
                        }
                    });
                }
            }
            if (newValue !== value) {
                var newIsObjectOrArray = newValue && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicSupport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_canMakeDynamic"])(_getProperty, state, newValue);
                if (!isReferenced && newIsObjectOrArray) {
                    // As the newValue is an object/array lets preemptively make it dynamic
                    newValue = _makeDynamicObject(state, newValue, name, "Converting");
                }
                // Now assign the internal "value" to the newValue
                value = newValue;
                isObjectOrArray = newIsObjectOrArray;
            }
            // Cause any listeners to be scheduled for notification
            state.add(detail);
        }
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(theConfig, detail.n, {
        g: _getProperty,
        s: _setProperty
    });
}
function _setDynamicProperty(state, target, name, value) {
    if (target) {
        // To be a dynamic property it needs to have a get function
        var getter = _getOwnPropGetter(target, name);
        var isDynamic = getter && !!getter[state.prop];
        if (!isDynamic) {
            _createDynamicProperty(state, target, name, value);
        } else {
            // Looks like it's already dynamic just assign the new value
            target[name] = value;
        }
    }
    return target;
}
function _setDynamicPropertyState(state, target, name, flags) {
    if (target) {
        // To be a dynamic property it needs to have a get function
        var getter = _getOwnPropGetter(target, name);
        var isDynamic = getter && !!getter[state.prop];
        var inPlace = flags && flags[0 /* _eSetDynamicPropertyFlags.inPlace */ ];
        var rdOnly = flags && flags[1 /* _eSetDynamicPropertyFlags.readOnly */ ];
        var blkProp = flags && flags[2 /* _eSetDynamicPropertyFlags.blockDynamicProperty */ ];
        if (!isDynamic) {
            if (blkProp) {
                try {
                    // Attempt to mark the target as blocked from conversion
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicSupport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["blockDynamicConversion"])(target);
                } catch (e) {
                    _throwDynamicError((state.hdlr || {})[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ], name, "Blocking", e);
                }
            }
            try {
                // Make sure it's dynamic so that we can tag the property as per the state
                _setDynamicProperty(state, target, name, target[name]);
                getter = _getOwnPropGetter(target, name);
            } catch (e) {
                // Unable to convert to dynamic property so just leave as non-dynamic
                _throwDynamicError((state.hdlr || {})[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ], name, "State", e);
            }
        }
        // Assign the optional flags if true
        if (inPlace) {
            getter[state.rf] = inPlace;
        }
        if (rdOnly) {
            getter[state.ro] = rdOnly;
        }
        if (blkProp) {
            getter[state.blkVal] = true;
        }
    }
    return target;
}
function _makeDynamicObject(state, target, name, desc) {
    try {
        // Assign target with new value properties (converting into dynamic properties in the process)
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(target, function(key, value) {
            // Assign and/or make the property dynamic
            _setDynamicProperty(state, target, key, value);
        });
        if (!target[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicSupport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CFG_HANDLER_LINK"]]) {
            // Link the config back to the dynamic config details
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefineProp"])(target, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicSupport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CFG_HANDLER_LINK"], {
                get: function() {
                    return state.hdlr;
                }
            });
            _patchArray(state, target, name);
        }
    } catch (e) {
        // Unable to convert to dynamic property so just leave as non-dynamic
        _throwDynamicError((state.hdlr || {})[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ], name, desc, e);
    }
    return target;
} //# sourceMappingURL=DynamicProperty.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/AggregationError.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "throwAggregationError",
    ()=>throwAggregationError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
;
var aggregationErrorType;
function throwAggregationError(message, sourceErrors) {
    if (!aggregationErrorType) {
        aggregationErrorType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCustomError"])("AggregationError", function(self, args) {
            if (args[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 1) {
                // Save the provided errors
                self.errors = args[1];
            }
        });
    }
    var theMessage = message || "One or more errors occurred.";
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(sourceErrors, function(srcError, idx) {
        theMessage += "\n".concat(idx, " > ").concat((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(srcError));
    });
    throw new aggregationErrorType(theMessage, sourceErrors || []);
} //# sourceMappingURL=AggregationError.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicState.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "_createState",
    ()=>_createState
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$AggregationError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/AggregationError.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
;
;
var symPrefix = "[[ai_";
var symPostfix = "]]";
function _createState(cfgHandler) {
    var dynamicPropertySymbol = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newSymbol"])(symPrefix + "get" + cfgHandler.uid + symPostfix);
    var dynamicPropertyReadOnly = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newSymbol"])(symPrefix + "ro" + cfgHandler.uid + symPostfix);
    var dynamicPropertyReferenced = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newSymbol"])(symPrefix + "rf" + cfgHandler.uid + symPostfix);
    var dynamicPropertyBlockValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newSymbol"])(symPrefix + "blkVal" + cfgHandler.uid + symPostfix);
    var dynamicPropertyDetail = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newSymbol"])(symPrefix + "dtl" + cfgHandler.uid + symPostfix);
    var _waitingHandlers = null;
    var _watcherTimer = null;
    var theState;
    function _useHandler(activeHandler, callback) {
        var prevWatcher = theState.act;
        try {
            theState.act = activeHandler;
            if (activeHandler && activeHandler[dynamicPropertyDetail]) {
                // Clear out the previously tracked details for this handler, so that access are re-evaluated
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(activeHandler[dynamicPropertyDetail], function(detail) {
                    detail.clr(activeHandler);
                });
                activeHandler[dynamicPropertyDetail] = [];
            }
            callback({
                cfg: cfgHandler.cfg,
                set: cfgHandler.set.bind(cfgHandler),
                setDf: cfgHandler.setDf.bind(cfgHandler),
                ref: cfgHandler.ref.bind(cfgHandler),
                rdOnly: cfgHandler.rdOnly.bind(cfgHandler)
            });
        } catch (e) {
            var logger = cfgHandler[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ];
            if (logger) {
                // Don't let one individual failure break everyone
                logger[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_THROW_INTERNAL"] /* @min:%2ethrowInternal */ ](1 /* eLoggingSeverity.CRITICAL */ , 107 /* _eInternalMessageId.ConfigWatcherException */ , (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e));
            }
            // Re-throw the exception so that any true "error" is reported back to the called
            throw e;
        } finally{
            theState.act = prevWatcher || null;
        }
    }
    function _notifyWatchers() {
        if (_waitingHandlers) {
            var notifyHandlers = _waitingHandlers;
            _waitingHandlers = null;
            // Stop any timer as we are running them now anyway
            _watcherTimer && _watcherTimer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CANCEL"] /* @min:%2ecancel */ ]();
            _watcherTimer = null;
            var watcherFailures_1 = [];
            // Now run the handlers
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(notifyHandlers, function(handler) {
                if (handler) {
                    if (handler[dynamicPropertyDetail]) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(handler[dynamicPropertyDetail], function(detail) {
                            // Clear out this handler from  previously tracked details, so that access are re-evaluated
                            detail.clr(handler);
                        });
                        handler[dynamicPropertyDetail] = null;
                    }
                    // The handler may have self removed as part of another handler so re-check
                    if (handler.fn) {
                        try {
                            _useHandler(handler, handler.fn);
                        } catch (e) {
                            // Don't let a single failing watcher cause other watches to fail
                            watcherFailures_1[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](e);
                        }
                    }
                }
            });
            // During notification we may have had additional updates -- so notify those updates as well
            if (_waitingHandlers) {
                try {
                    _notifyWatchers();
                } catch (e) {
                    watcherFailures_1[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](e);
                }
            }
            if (watcherFailures_1[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$AggregationError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throwAggregationError"])("Watcher error(s): ", watcherFailures_1);
            }
        }
    }
    function _addWatcher(detail) {
        if (detail && detail.h[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
            if (!_waitingHandlers) {
                _waitingHandlers = [];
            }
            if (!_watcherTimer) {
                _watcherTimer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["scheduleTimeout"])(function() {
                    _watcherTimer = null;
                    _notifyWatchers();
                }, 0);
            }
            // Add all of the handlers for this detail (if not already present) - using normal for-loop for performance
            for(var idx = 0; idx < detail.h[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; idx++){
                var handler = detail.h[idx];
                // Add this handler to the collection of handlers to re-execute
                if (handler && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrIndexOf"])(_waitingHandlers, handler) === -1) {
                    _waitingHandlers[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](handler);
                }
            }
        }
    }
    function _trackHandler(handler, detail) {
        if (handler) {
            var details = handler[dynamicPropertyDetail] = handler[dynamicPropertyDetail] || [];
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrIndexOf"])(details, detail) === -1) {
                // If this detail is not already listed as tracked then add it so that we re-evaluate it's usage
                details[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](detail);
            }
        }
    }
    theState = {
        prop: dynamicPropertySymbol,
        ro: dynamicPropertyReadOnly,
        rf: dynamicPropertyReferenced,
        blkVal: dynamicPropertyBlockValue,
        hdlr: cfgHandler,
        add: _addWatcher,
        notify: _notifyWatchers,
        use: _useHandler,
        trk: _trackHandler
    };
    return theState;
} //# sourceMappingURL=DynamicState.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicConfig.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "createDynamicConfig",
    ()=>createDynamicConfig,
    "onConfigChange",
    ()=>onConfigChange
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DataCacheHelper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaults$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/ConfigDefaults.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicProperty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicProperty.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicSupport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicSupport.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
/**
 * Identifies a function which will be re-called whenever any of it's accessed configuration values
 * change.
 * @param configHandler - The callback that will be called for the initial request and then whenever any
 * accessed configuration changes are identified.
 */ function _createAndUseHandler(state, configHandler) {
    var handler = {
        fn: configHandler,
        rm: function() {
            // Clear all references to the handler so it can be garbage collected
            // This will also cause this handler to never get called and eventually removed
            handler.fn = null;
            state = null;
            configHandler = null;
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(handler, "toJSON", {
        v: function() {
            return "WatcherHandler" + (handler.fn ? "" : "[X]");
        }
    });
    state.use(handler, configHandler);
    return handler;
}
/**
 * Creates the dynamic config handler and associates with the target config as the root object
 * @param target - The config that you want to be root of the dynamic config
 * @param inPlace - Should the passed config be converted in-place or a new proxy returned
 * @returns The existing dynamic handler or a new instance with the provided config values
 */ function _createDynamicHandler(logger, target, inPlace) {
    var dynamicHandler = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicSupport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDynamicConfigHandler"])(target);
    if (dynamicHandler) {
        // The passed config is already dynamic so return it's tracker
        return dynamicHandler;
    }
    var uid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUniqueNamespace"])("dyncfg", true);
    var newTarget = target && inPlace !== false ? target : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicSupport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_cfgDeepCopy"])(target);
    var theState;
    function _notifyWatchers() {
        theState.notify();
    }
    function _setValue(target, name, value) {
        try {
            target = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicProperty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_setDynamicProperty"])(theState, target, name, value);
        } catch (e) {
            // Unable to convert to dynamic property so just leave as non-dynamic
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicProperty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwDynamicError"])(logger, name, "Setting value", e);
        }
        return target[name];
    }
    function _watch(configHandler) {
        return _createAndUseHandler(theState, configHandler);
    }
    function _block(configHandler, allowUpdate) {
        theState.use(null, {
            "_createDynamicHandler._block.use": function(details) {
                var prevUpd = theState.upd;
                try {
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"])(allowUpdate)) {
                        theState.upd = allowUpdate;
                    }
                    configHandler(details);
                } finally{
                    theState.upd = prevUpd;
                }
            }
        }["_createDynamicHandler._block.use"]);
    }
    function _ref(target, name) {
        var _a;
        // Make sure it's dynamic and mark as referenced with it's current value
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicProperty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_setDynamicPropertyState"])(theState, target, name, (_a = {}, _a[0 /* _eSetDynamicPropertyFlags.inPlace */ ] = true, _a))[name];
    }
    function _rdOnly(target, name) {
        var _a;
        // Make sure it's dynamic and mark as readonly with it's current value
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicProperty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_setDynamicPropertyState"])(theState, target, name, (_a = {}, _a[1 /* _eSetDynamicPropertyFlags.readOnly */ ] = true, _a))[name];
    }
    function _blkPropValue(target, name) {
        var _a;
        // Make sure it's dynamic and mark as readonly with it's current value
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicProperty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_setDynamicPropertyState"])(theState, target, name, (_a = {}, _a[2 /* _eSetDynamicPropertyFlags.blockDynamicProperty */ ] = true, _a))[name];
    }
    function _applyDefaults(theConfig, defaultValues) {
        if (defaultValues) {
            // Resolve/apply the defaults
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(defaultValues, function(name, value) {
                // Sets the value and makes it dynamic (if it doesn't already exist)
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaults$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_applyDefaultValue"])(cfgHandler, theConfig, name, value);
            });
        }
        return theConfig;
    }
    var cfgHandler = {
        uid: null,
        cfg: newTarget,
        logger: logger,
        notify: _notifyWatchers,
        set: _setValue,
        setDf: _applyDefaults,
        watch: _watch,
        ref: _ref,
        rdOnly: _rdOnly,
        blkVal: _blkPropValue,
        _block: _block
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(cfgHandler, "uid", {
        c: false,
        e: false,
        w: false,
        v: uid
    });
    theState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_createState"])(cfgHandler);
    // Setup tracking for all defined default keys
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicProperty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_makeDynamicObject"])(theState, newTarget, "config", "Creating");
    return cfgHandler;
}
/**
 * Log an invalid access message to the console
 */ function _logInvalidAccess(logger, message) {
    if (logger) {
        logger[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_WARN_TO_CONSOLE"] /* @min:%2ewarnToConsole */ ](message);
        logger[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_THROW_INTERNAL"] /* @min:%2ethrowInternal */ ](2 /* eLoggingSeverity.WARNING */ , 108 /* _eInternalMessageId.DynamicConfigException */ , message);
    } else {
        // We don't have a logger so just throw an exception
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicSupport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throwInvalidAccess"])(message);
    }
}
function createDynamicConfig(config, defaultConfig, logger, inPlace) {
    var dynamicHandler = _createDynamicHandler(logger, config || {}, inPlace);
    if (defaultConfig) {
        dynamicHandler.setDf(dynamicHandler.cfg, defaultConfig);
    }
    return dynamicHandler;
}
function onConfigChange(config, configHandler, logger) {
    var handler = config[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicSupport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CFG_HANDLER_LINK"]] || config;
    if (handler.cfg && (handler.cfg === config || handler.cfg[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicSupport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CFG_HANDLER_LINK"]] === handler)) {
        return handler[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_WATCH"] /* @min:%2ewatch */ ](configHandler);
    }
    _logInvalidAccess(logger, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_NOT_DYNAMIC_ERROR"] + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(config));
    return createDynamicConfig(config, null, logger)[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_WATCH"] /* @min:%2ewatch */ ](configHandler);
} //# sourceMappingURL=DynamicConfig.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DbgExtensionUtils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "getDebugExt",
    ()=>getDebugExt,
    "getDebugListener",
    ()=>getDebugListener
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
;
;
;
var listenerFuncs = [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EVENTS_SENT"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EVENTS_DISCARDED"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EVENTS_SEND_REQUEST"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PERF_EVENT"]
];
var _aiNamespace = null;
var _debugListener;
function _listenerProxyFunc(name, config) {
    return function() {
        var args = arguments;
        var dbgExt = getDebugExt(config);
        if (dbgExt) {
            var listener = dbgExt.listener;
            if (listener && listener[name]) {
                listener[name][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY"] /* @min:%2eapply */ ](listener, args);
            }
        }
    };
}
function _getExtensionNamespace() {
    // Cache the lookup of the global namespace object
    var target = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInst"])("Microsoft");
    if (target) {
        _aiNamespace = target["ApplicationInsights"];
    }
    return _aiNamespace;
}
function getDebugExt(config) {
    var ns = _aiNamespace;
    if (!ns && config.disableDbgExt !== true) {
        ns = _aiNamespace || _getExtensionNamespace();
    }
    return ns ? ns["ChromeDbgExt"] : null;
}
function getDebugListener(config) {
    if (!_debugListener) {
        _debugListener = {};
        for(var lp = 0; lp < listenerFuncs[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; lp++){
            _debugListener[listenerFuncs[lp]] = _listenerProxyFunc(listenerFuncs[lp], config);
        }
    }
    return _debugListener;
} //# sourceMappingURL=DbgExtensionUtils.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "DiagnosticLogger",
    ()=>DiagnosticLogger,
    "_InternalLogMessage",
    ()=>_InternalLogMessage,
    "_logInternalMessage",
    ()=>_logInternalMessage,
    "_throwInternal",
    ()=>_throwInternal,
    "_warnToConsole",
    ()=>_warnToConsole,
    "safeGetLogger",
    ()=>safeGetLogger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicConfig.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DbgExtensionUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DbgExtensionUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EnvUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
"use strict";
var _a;
;
;
;
;
;
;
;
var STR_WARN_TO_CONSOLE = "warnToConsole";
/**
 * For user non actionable traces use AI Internal prefix.
 */ var AiNonUserActionablePrefix = "AI (Internal): ";
/**
 * Prefix of the traces in portal.
 */ var AiUserActionablePrefix = "AI: ";
/**
 *  Session storage key for the prefix for the key indicating message type already logged
 */ var AIInternalMessagePrefix = "AITR_";
var defaultValues = {
    loggingLevelConsole: 0,
    loggingLevelTelemetry: 1,
    maxMessageLimit: 25,
    enableDebug: false
};
var _logFuncs = (_a = {}, _a[0 /* eLoggingSeverity.DISABLED */ ] = null, _a[1 /* eLoggingSeverity.CRITICAL */ ] = "errorToConsole", _a[2 /* eLoggingSeverity.WARNING */ ] = STR_WARN_TO_CONSOLE, _a[3 /* eLoggingSeverity.DEBUG */ ] = "debugToConsole", _a);
function _sanitizeDiagnosticText(text) {
    if (text) {
        return "\"" + text[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REPLACE"] /* @min:%2ereplace */ ](/\"/g, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"]) + "\"";
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"];
}
function _logToConsole(func, message) {
    var theConsole = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getConsole"])();
    if (!!theConsole) {
        var logFunc = "log";
        if (theConsole[func]) {
            logFunc = func;
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(theConsole[logFunc])) {
            theConsole[logFunc](message);
        }
    }
}
var _InternalLogMessage = function() {
    function _InternalLogMessage(msgId, msg, isUserAct, properties) {
        if (isUserAct === void 0) {
            isUserAct = false;
        }
        var _self = this;
        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MESSAGE_ID"] /* @min:%2emessageId */ ] = msgId;
        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MESSAGE"] /* @min:%2emessage */ ] = (isUserAct ? AiUserActionablePrefix : AiNonUserActionablePrefix) + msgId;
        var strProps = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"];
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasJSON"])()) {
            strProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getJSON"])().stringify(properties);
        }
        var diagnosticText = (msg ? " message:" + _sanitizeDiagnosticText(msg) : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"]) + (properties ? " props:" + _sanitizeDiagnosticText(strProps) : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"]);
        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MESSAGE"] /* @min:%2emessage */ ] += diagnosticText;
    }
    _InternalLogMessage.dataType = "MessageData";
    return _InternalLogMessage;
}();
;
function safeGetLogger(core, config) {
    return (core || {})[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ] || new DiagnosticLogger(config);
}
var DiagnosticLogger = function() {
    function DiagnosticLogger(config) {
        this.identifier = "DiagnosticLogger";
        /**
         * The internal logging queue
         */ this.queue = [];
        /**
         * Count of internal messages sent
         */ var _messageCount = 0;
        /**
         * Holds information about what message types were already logged to console or sent to server.
         */ var _messageLogged = {};
        var _loggingLevelConsole;
        var _loggingLevelTelemetry;
        var _maxInternalMessageLimit;
        var _enableDebug;
        var _unloadHandler;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(DiagnosticLogger, this, function(_self) {
            _unloadHandler = _setDefaultsFromConfig(config || {});
            _self.consoleLoggingLevel = function() {
                return _loggingLevelConsole;
            };
            /**
             * This method will throw exceptions in debug mode or attempt to log the error as a console warning.
             * @param severity - The severity of the log message
             * @param message  - The log message.
             */ _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_THROW_INTERNAL"] /* @min:%2ethrowInternal */ ] = function(severity, msgId, msg, properties, isUserAct) {
                if (isUserAct === void 0) {
                    isUserAct = false;
                }
                var message = new _InternalLogMessage(msgId, msg, isUserAct, properties);
                if (_enableDebug) {
                    throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(message);
                } else {
                    // Get the logging function and fallback to warnToConsole of for some reason errorToConsole doesn't exist
                    var logFunc = _logFuncs[severity] || STR_WARN_TO_CONSOLE;
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"])(message[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MESSAGE"] /* @min:%2emessage */ ])) {
                        if (isUserAct) {
                            // check if this message type was already logged to console for this page view and if so, don't log it again
                            var messageKey = +message[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MESSAGE_ID"] /* @min:%2emessageId */ ];
                            if (!_messageLogged[messageKey] && _loggingLevelConsole >= severity) {
                                _self[logFunc](message[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MESSAGE"] /* @min:%2emessage */ ]);
                                _messageLogged[messageKey] = true;
                            }
                        } else {
                            // Only log traces if the console Logging Level is >= the throwInternal severity level
                            if (_loggingLevelConsole >= severity) {
                                _self[logFunc](message[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MESSAGE"] /* @min:%2emessage */ ]);
                            }
                        }
                        _logInternalMessage(severity, message);
                    } else {
                        _debugExtMsg("throw" + (severity === 1 /* eLoggingSeverity.CRITICAL */  ? "Critical" : "Warning"), message);
                    }
                }
            };
            _self.debugToConsole = function(message) {
                _logToConsole("debug", message);
                _debugExtMsg("warning", message);
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_WARN_TO_CONSOLE"] /* @min:%2ewarnToConsole */ ] = function(message) {
                _logToConsole("warn", message);
                _debugExtMsg("warning", message);
            };
            _self.errorToConsole = function(message) {
                _logToConsole("error", message);
                _debugExtMsg("error", message);
            };
            _self.resetInternalMessageCount = function() {
                _messageCount = 0;
                _messageLogged = {};
            };
            _self.logInternalMessage = _logInternalMessage;
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_UNLOAD"] /* @min:%2eunload */ ] = function(isAsync) {
                _unloadHandler && _unloadHandler.rm();
                _unloadHandler = null;
            };
            function _logInternalMessage(severity, message) {
                if (_areInternalMessagesThrottled()) {
                    return;
                }
                // check if this message type was already logged for this session and if so, don't log it again
                var logMessage = true;
                var messageKey = AIInternalMessagePrefix + message[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MESSAGE_ID"] /* @min:%2emessageId */ ];
                // if the session storage is not available, limit to only one message type per page view
                if (_messageLogged[messageKey]) {
                    logMessage = false;
                } else {
                    _messageLogged[messageKey] = true;
                }
                if (logMessage) {
                    // Push the event in the internal queue
                    if (severity <= _loggingLevelTelemetry) {
                        _self.queue[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](message);
                        _messageCount++;
                        _debugExtMsg(severity === 1 /* eLoggingSeverity.CRITICAL */  ? "error" : "warn", message);
                    }
                    // When throttle limit reached, send a special event
                    if (_messageCount === _maxInternalMessageLimit) {
                        var throttleLimitMessage = "Internal events throttle limit per PageView reached for this app.";
                        var throttleMessage = new _InternalLogMessage(23 /* _eInternalMessageId.MessageLimitPerPVExceeded */ , throttleLimitMessage, false);
                        _self.queue[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](throttleMessage);
                        if (severity === 1 /* eLoggingSeverity.CRITICAL */ ) {
                            _self.errorToConsole(throttleLimitMessage);
                        } else {
                            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_WARN_TO_CONSOLE"] /* @min:%2ewarnToConsole */ ](throttleLimitMessage);
                        }
                    }
                }
            }
            function _setDefaultsFromConfig(config) {
                // make sure the config is dynamic
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onConfigChange"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDynamicConfig"])(config, defaultValues, _self).cfg, function(details) {
                    var config = details.cfg;
                    _loggingLevelConsole = config[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGING_LEVEL_CONSOL4"] /* @min:%2eloggingLevelConsole */ ];
                    _loggingLevelTelemetry = config.loggingLevelTelemetry;
                    _maxInternalMessageLimit = config.maxMessageLimit;
                    _enableDebug = config.enableDebug;
                });
            }
            function _areInternalMessagesThrottled() {
                return _messageCount >= _maxInternalMessageLimit;
            }
            function _debugExtMsg(name, data) {
                var dbgExt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DbgExtensionUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDebugExt"])(config || {});
                if (dbgExt && dbgExt[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ]) {
                    dbgExt[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](name, data);
                }
            }
        });
    }
    // Removed Stub for DiagnosticLogger.prototype.consoleLoggingLevel.
    // Removed Stub for DiagnosticLogger.prototype.throwInternal.
    // Removed Stub for DiagnosticLogger.prototype.debugToConsole.
    // Removed Stub for DiagnosticLogger.prototype.warnToConsole.
    // Removed Stub for DiagnosticLogger.prototype.errorToConsole.
    // Removed Stub for DiagnosticLogger.prototype.resetInternalMessageCount.
    // Removed Stub for DiagnosticLogger.prototype.logInternalMessage.
    // Removed Stub for DiagnosticLogger.prototype.unload.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    DiagnosticLogger.__ieDyn = 1;
    return DiagnosticLogger;
}();
;
function _getLogger(logger) {
    return logger || new DiagnosticLogger();
}
function _throwInternal(logger, severity, msgId, msg, properties, isUserAct) {
    if (isUserAct === void 0) {
        isUserAct = false;
    }
    _getLogger(logger)[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_THROW_INTERNAL"] /* @min:%2ethrowInternal */ ](severity, msgId, msg, properties, isUserAct);
}
function _warnToConsole(logger, message) {
    _getLogger(logger)[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_WARN_TO_CONSOLE"] /* @min:%2ewarnToConsole */ ](message);
}
function _logInternalMessage(logger, severity, message) {
    _getLogger(logger).logInternalMessage(severity, message);
} //# sourceMappingURL=DiagnosticLogger.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/CoreUtils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "Undefined",
    ()=>Undefined,
    "generateW3CId",
    ()=>generateW3CId,
    "newGuid",
    ()=>newGuid,
    "strEndsWith",
    ()=>strEndsWith
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-shims@3.0.1/node_modules/@microsoft/applicationinsights-shims/dist-es5/Constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$RandomHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/RandomHelper.js [app-client] (ecmascript)");
"use strict";
;
;
;
;
;
var Undefined = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strShimUndefined"];
function newGuid() {
    var uuid = generateW3CId();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstring"])(uuid, 0, 8) + "-" + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstring"])(uuid, 8, 12) + "-" + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstring"])(uuid, 12, 16) + "-" + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstring"])(uuid, 16, 20) + "-" + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstring"])(uuid, 20);
}
function strEndsWith(value, search) {
    if (value && search) {
        var len = value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
        var start = len - search[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstring"])(value, start >= 0 ? start : 0, len) === search;
    }
    return false;
}
function generateW3CId() {
    var hexValues = [
        "0",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "a",
        "b",
        "c",
        "d",
        "e",
        "f"
    ];
    // rfc4122 version 4 UUID without dashes and with lowercase letters
    var oct = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"], tmp;
    for(var a = 0; a < 4; a++){
        tmp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$RandomHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["random32"])();
        oct += hexValues[tmp & 0xF] + hexValues[tmp >> 4 & 0xF] + hexValues[tmp >> 8 & 0xF] + hexValues[tmp >> 12 & 0xF] + hexValues[tmp >> 16 & 0xF] + hexValues[tmp >> 20 & 0xF] + hexValues[tmp >> 24 & 0xF] + hexValues[tmp >> 28 & 0xF];
    }
    // "Set the two most significant bits (bits 6 and 7) of the clock_seq_hi_and_reserved to zero and one, respectively"
    var clockSequenceHi = hexValues[8 + ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$RandomHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["random32"])() & 0x03) | 0];
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstr"])(oct, 0, 8) + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstr"])(oct, 9, 4) + "4" + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstr"])(oct, 13, 3) + clockSequenceHi + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstr"])(oct, 16, 3) + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstr"])(oct, 19, 12);
} //# sourceMappingURL=CoreUtils.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/W3cTraceParent.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "createTraceParent",
    ()=>createTraceParent,
    "findAllScripts",
    ()=>findAllScripts,
    "findW3cTraceParent",
    ()=>findW3cTraceParent,
    "formatTraceParent",
    ()=>formatTraceParent,
    "isSampledFlag",
    ()=>isSampledFlag,
    "isValidSpanId",
    ()=>isValidSpanId,
    "isValidTraceId",
    ()=>isValidTraceId,
    "isValidTraceParent",
    ()=>isValidTraceParent,
    "parseTraceParent",
    ()=>parseTraceParent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CoreUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/CoreUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EnvUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
;
;
;
;
;
// using {0,16} for leading and trailing whitespace just to constrain the possible runtime of a random string
var TRACE_PARENT_REGEX = /^([\da-f]{2})-([\da-f]{32})-([\da-f]{16})-([\da-f]{2})(-[^\s]{1,64})?$/i;
var DEFAULT_VERSION = "00";
var INVALID_VERSION = "ff";
var INVALID_TRACE_ID = "00000000000000000000000000000000";
var INVALID_SPAN_ID = "0000000000000000";
var SAMPLED_FLAG = 0x01;
function _isValid(value, len, invalidValue) {
    if (value && value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] === len && value !== invalidValue) {
        return !!value.match(/^[\da-f]*$/i);
    }
    return false;
}
function _formatValue(value, len, defValue) {
    if (_isValid(value, len)) {
        return value;
    }
    return defValue;
}
function _formatFlags(value) {
    if (isNaN(value) || value < 0 || value > 255) {
        value = 0x01;
    }
    var result = value.toString(16);
    while(result[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] < 2){
        result = "0" + result;
    }
    return result;
}
function createTraceParent(traceId, spanId, flags, version) {
    return {
        version: _isValid(version, 2, INVALID_VERSION) ? version : DEFAULT_VERSION,
        traceId: isValidTraceId(traceId) ? traceId : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CoreUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateW3CId"])(),
        spanId: isValidSpanId(spanId) ? spanId : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strLeft"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CoreUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateW3CId"])(), 16),
        traceFlags: flags >= 0 && flags <= 0xFF ? flags : 1
    };
}
function parseTraceParent(value, selectIdx) {
    if (!value) {
        // Don't pass a null/undefined or empty string
        return null;
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(value)) {
        // The value may have been encoded on the page into an array so handle this automatically
        value = value[0] || "";
    }
    if (!value || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(value) || value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 8192) {
        // limit potential processing based on total length
        return null;
    }
    if (value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INDEX_OF"] /* @min:%2eindexOf */ ](",") !== -1) {
        var values = value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPLIT"] /* @min:%2esplit */ ](",");
        value = values[selectIdx > 0 && values[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > selectIdx ? selectIdx : 0];
    }
    // See https://www.w3.org/TR/trace-context/#versioning-of-traceparent
    var match = TRACE_PARENT_REGEX.exec((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strTrim"])(value));
    if (!match || // No match
    match[1] === INVALID_VERSION || // version ff is forbidden
    match[2] === INVALID_TRACE_ID || // All zeros is considered to be invalid
    match[3] === INVALID_SPAN_ID) {
        return null;
    }
    return {
        version: (match[1] || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"])[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ](),
        traceId: (match[2] || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"])[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ](),
        spanId: (match[3] || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"])[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ](),
        traceFlags: parseInt(match[4], 16)
    };
}
function isValidTraceId(value) {
    return _isValid(value, 32, INVALID_TRACE_ID);
}
function isValidSpanId(value) {
    return _isValid(value, 16, INVALID_SPAN_ID);
}
function isValidTraceParent(value) {
    if (!value || !_isValid(value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_VERSION"] /* @min:%2eversion */ ], 2, INVALID_VERSION) || !_isValid(value.traceId, 32, INVALID_TRACE_ID) || !_isValid(value.spanId, 16, INVALID_SPAN_ID) || !_isValid(_formatFlags(value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_FLAGS"] /* @min:%2etraceFlags */ ]), 2)) {
        // Each known field must contain a valid value
        return false;
    }
    return true;
}
function isSampledFlag(value) {
    if (isValidTraceParent(value)) {
        return (value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_FLAGS"] /* @min:%2etraceFlags */ ] & SAMPLED_FLAG) === SAMPLED_FLAG;
    }
    return false;
}
function formatTraceParent(value) {
    if (value) {
        // Special Note: This only supports formatting as version 00, future versions should encode any known supported version
        // So parsing a future version will populate the correct version value but reformatting will reduce it to version 00.
        var flags = _formatFlags(value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_FLAGS"] /* @min:%2etraceFlags */ ]);
        if (!_isValid(flags, 2)) {
            flags = "01";
        }
        var version = value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_VERSION"] /* @min:%2eversion */ ] || DEFAULT_VERSION;
        if (version !== "00" && version !== "ff") {
            // Reduce version to "00"
            version = DEFAULT_VERSION;
        }
        // Format as version 00
        return "".concat(version.toLowerCase(), "-").concat(_formatValue(value.traceId, 32, INVALID_TRACE_ID).toLowerCase(), "-").concat(_formatValue(value.spanId, 16, INVALID_SPAN_ID).toLowerCase(), "-").concat(flags.toLowerCase());
    }
    return "";
}
function findW3cTraceParent(selectIdx) {
    var name = "traceparent";
    var traceParent = parseTraceParent((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findMetaTag"])(name), selectIdx);
    if (!traceParent) {
        traceParent = parseTraceParent((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findNamedServerTiming"])(name), selectIdx);
    }
    return traceParent;
}
function findAllScripts(doc) {
    var scripts = doc.getElementsByTagName("script");
    var result = [];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(scripts, function(script) {
        var src = script[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_ATTRIBUTE"] /* @min:%2egetAttribute */ ]("src");
        if (src) {
            var crossOrigin = script[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_ATTRIBUTE"] /* @min:%2egetAttribute */ ]("crossorigin");
            var async = script.hasAttribute("async") === true;
            var defer = script.hasAttribute("defer") === true;
            var referrerPolicy = script[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_ATTRIBUTE"] /* @min:%2egetAttribute */ ]("referrerpolicy");
            var info = {
                url: src
            };
            if (crossOrigin) {
                info.crossOrigin = crossOrigin;
            }
            if (async) {
                info.async = async;
            }
            if (defer) {
                info.defer = defer;
            }
            if (referrerPolicy) {
                info.referrerPolicy = referrerPolicy;
            }
            result[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](info);
        }
    });
    return result;
} //# sourceMappingURL=W3cTraceParent.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK.Enums/EnumHelperFuncs.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "createEnumStyle",
    ()=>createEnumStyle,
    "createValueMap",
    ()=>createValueMap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
;
var createEnumStyle = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEnum"];
var createValueMap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTypeMap"]; //# sourceMappingURL=EnumHelperFuncs.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/PerfManager.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "PerfEvent",
    ()=>PerfEvent,
    "PerfManager",
    ()=>PerfManager,
    "doPerf",
    ()=>doPerf,
    "getGblPerfMgr",
    ()=>getGblPerfMgr,
    "setGblPerfMgr",
    ()=>setGblPerfMgr
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
;
;
;
;
var strExecutionContextKey = "ctx";
var strParentContextKey = "ParentContextKey";
var strChildrenContextKey = "ChildrenContextKey";
var _defaultPerfManager = null;
var PerfEvent = function() {
    function PerfEvent(name, payloadDetails, isAsync) {
        var _self = this;
        _self.start = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utcNow"])();
        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ] = name;
        _self.isAsync = isAsync;
        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_CHILD_EVT"] /* @min:%2eisChildEvt */ ] = function() {
            return false;
        };
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(payloadDetails)) {
            // Create an accessor to minimize the potential performance impact of executing the payloadDetails callback
            var theDetails_1;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "payload", {
                g: function() {
                    // Delay the execution of the payloadDetails until needed
                    if (!theDetails_1 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(payloadDetails)) {
                        theDetails_1 = payloadDetails();
                        // clear it out now so the referenced objects can be garbage collected
                        payloadDetails = null;
                    }
                    return theDetails_1;
                }
            });
        }
        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_CTX"] /* @min:%2egetCtx */ ] = function(key) {
            if (key) {
                // The parent and child links are located directly on the object (for better viewing in the DebugPlugin)
                if (key === PerfEvent[strParentContextKey] || key === PerfEvent[strChildrenContextKey]) {
                    return _self[key];
                }
                return (_self[strExecutionContextKey] || {})[key];
            }
            return null;
        };
        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_CTX"] /* @min:%2esetCtx */ ] = function(key, value) {
            if (key) {
                // Put the parent and child links directly on the object (for better viewing in the DebugPlugin)
                if (key === PerfEvent[strParentContextKey]) {
                    // Simple assumption, if we are setting a parent then we must be a child
                    if (!_self[key]) {
                        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_CHILD_EVT"] /* @min:%2eisChildEvt */ ] = function() {
                            return true;
                        };
                    }
                    _self[key] = value;
                } else if (key === PerfEvent[strChildrenContextKey]) {
                    _self[key] = value;
                } else {
                    var ctx = _self[strExecutionContextKey] = _self[strExecutionContextKey] || {};
                    ctx[key] = value;
                }
            }
        };
        _self.complete = function() {
            var childTime = 0;
            var childEvts = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_CTX"] /* @min:%2egetCtx */ ](PerfEvent[strChildrenContextKey]);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(childEvts)) {
                for(var lp = 0; lp < childEvts[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; lp++){
                    var childEvt = childEvts[lp];
                    if (childEvt) {
                        childTime += childEvt.time;
                    }
                }
            }
            _self.time = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utcNow"])() - _self.start;
            _self.exTime = _self.time - childTime;
            _self.complete = function() {};
        };
    }
    PerfEvent.ParentContextKey = "parent";
    PerfEvent.ChildrenContextKey = "childEvts";
    return PerfEvent;
}();
;
var PerfManager = function() {
    function PerfManager(manager) {
        /**
         * General bucket used for execution context set and retrieved via setCtx() and getCtx.
         * Defined as private so it can be visualized via the DebugPlugin
         */ this.ctx = {};
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(PerfManager, this, function(_self) {
            _self.create = function(src, payloadDetails, isAsync) {
                // TODO (@MSNev): at some point we will want to add additional configuration to "select" which events to instrument
                // for now this is just a simple do everything.
                return new PerfEvent(src, payloadDetails, isAsync);
            };
            _self.fire = function(perfEvent) {
                if (perfEvent) {
                    perfEvent.complete();
                    if (manager && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(manager[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PERF_EVENT"] /* @min:%2eperfEvent */ ])) {
                        manager[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PERF_EVENT"] /* @min:%2eperfEvent */ ](perfEvent);
                    }
                }
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_CTX"] /* @min:%2esetCtx */ ] = function(key, value) {
                if (key) {
                    var ctx = _self[strExecutionContextKey] = _self[strExecutionContextKey] || {};
                    ctx[key] = value;
                }
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_CTX"] /* @min:%2egetCtx */ ] = function(key) {
                return (_self[strExecutionContextKey] || {})[key];
            };
        });
    }
    // Removed Stub for PerfManager.prototype.create.
    // Removed Stub for PerfManager.prototype.fire.
    // Removed Stub for PerfManager.prototype.setCtx.
    // Removed Stub for PerfManager.prototype.getCtx.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    PerfManager.__ieDyn = 1;
    return PerfManager;
}();
;
var doPerfActiveKey = "CoreUtils.doPerf";
function doPerf(mgrSource, getSource, func, details, isAsync) {
    if (mgrSource) {
        var perfMgr = mgrSource;
        if (perfMgr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_GET_PERF_MGR"]]) {
            // Looks like a perf manager provider object
            perfMgr = perfMgr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_GET_PERF_MGR"]]();
        }
        if (perfMgr) {
            var perfEvt = void 0;
            var currentActive = perfMgr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_CTX"] /* @min:%2egetCtx */ ](doPerfActiveKey);
            try {
                perfEvt = perfMgr.create(getSource(), details, isAsync);
                if (perfEvt) {
                    if (currentActive && perfEvt[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_CTX"] /* @min:%2esetCtx */ ]) {
                        perfEvt[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_CTX"] /* @min:%2esetCtx */ ](PerfEvent[strParentContextKey], currentActive);
                        if (currentActive[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_CTX"] /* @min:%2egetCtx */ ] && currentActive[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_CTX"] /* @min:%2esetCtx */ ]) {
                            var children = currentActive[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_CTX"] /* @min:%2egetCtx */ ](PerfEvent[strChildrenContextKey]);
                            if (!children) {
                                children = [];
                                currentActive[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_CTX"] /* @min:%2esetCtx */ ](PerfEvent[strChildrenContextKey], children);
                            }
                            children[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](perfEvt);
                        }
                    }
                    // Set this event as the active event now
                    perfMgr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_CTX"] /* @min:%2esetCtx */ ](doPerfActiveKey, perfEvt);
                    return func(perfEvt);
                }
            } catch (ex) {
                if (perfEvt && perfEvt[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_CTX"] /* @min:%2esetCtx */ ]) {
                    perfEvt[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_CTX"] /* @min:%2esetCtx */ ]("exception", ex);
                }
            } finally{
                // fire the perf event
                if (perfEvt) {
                    perfMgr.fire(perfEvt);
                }
                // Reset the active event to the previous value
                perfMgr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_CTX"] /* @min:%2esetCtx */ ](doPerfActiveKey, currentActive);
            }
        }
    }
    return func();
}
function setGblPerfMgr(perfManager) {
    _defaultPerfManager = perfManager;
}
function getGblPerfMgr() {
    return _defaultPerfManager;
} //# sourceMappingURL=PerfManager.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/TelemetryHelpers.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "_getPluginState",
    ()=>_getPluginState,
    "createDistributedTraceContext",
    ()=>createDistributedTraceContext,
    "initializePlugins",
    ()=>initializePlugins,
    "sortPlugins",
    ()=>sortPlugins,
    "unloadComponents",
    ()=>unloadComponents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DataCacheHelper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$W3cTraceParent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/W3cTraceParent.js [app-client] (ecmascript)");
;
;
;
;
;
var pluginStateData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElmNodeData"])("plugin");
function _getPluginState(plugin) {
    return pluginStateData.get(plugin, "state", {}, true);
}
function initializePlugins(processContext, extensions) {
    // Set the next plugin and identified the uninitialized plugins
    var initPlugins = [];
    var lastPlugin = null;
    var proxy = processContext[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_NEXT"] /* @min:%2egetNext */ ]();
    var pluginState;
    while(proxy){
        var thePlugin = proxy[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_PLUGIN"] /* @min:%2egetPlugin */ ]();
        if (thePlugin) {
            if (lastPlugin && lastPlugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_NEXT_PLUGIN"] /* @min:%2esetNextPlugin */ ] && thePlugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PROCESS_TELEMETRY"] /* @min:%2eprocessTelemetry */ ]) {
                // Set this plugin as the next for the previous one
                lastPlugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_NEXT_PLUGIN"] /* @min:%2esetNextPlugin */ ](thePlugin);
            }
            pluginState = _getPluginState(thePlugin);
            var isInitialized = !!pluginState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_INITIALIZED"] /* @min:%2eisInitialized */ ];
            if (thePlugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_INITIALIZED"] /* @min:%2eisInitialized */ ]) {
                isInitialized = thePlugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_INITIALIZED"] /* @min:%2eisInitialized */ ]();
            }
            if (!isInitialized) {
                initPlugins[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](thePlugin);
            }
            lastPlugin = thePlugin;
            proxy = proxy[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_NEXT"] /* @min:%2egetNext */ ]();
        }
    }
    // Now initialize the plugins
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(initPlugins, function(thePlugin) {
        var core = processContext[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"] /* @min:%2ecore */ ]();
        thePlugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INITIALIZE"] /* @min:%2einitialize */ ](processContext.getCfg(), core, extensions, processContext[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_NEXT"] /* @min:%2egetNext */ ]());
        pluginState = _getPluginState(thePlugin);
        // Only add the core to the state if the plugin didn't set it (doesn't extend from BaseTelemetryPlugin)
        if (!thePlugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"]] && !pluginState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"]]) {
            pluginState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"]] = core;
        }
        pluginState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_INITIALIZED"] /* @min:%2eisInitialized */ ] = true;
        delete pluginState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TEARDOWN"] /* @min:%2eteardown */ ];
    });
}
function sortPlugins(plugins) {
    // Sort by priority
    return plugins.sort(function(extA, extB) {
        var result = 0;
        if (extB) {
            var bHasProcess = extB[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PROCESS_TELEMETRY"]];
            if (extA[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PROCESS_TELEMETRY"]]) {
                result = bHasProcess ? extA[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PRIORITY"]] - extB[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PRIORITY"]] : 1;
            } else if (bHasProcess) {
                result = -1;
            }
        } else {
            result = extA ? 1 : -1;
        }
        return result;
    });
// sort complete
}
function unloadComponents(components, unloadCtx, unloadState, asyncCallback) {
    var idx = 0;
    function _doUnload() {
        while(idx < components[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]){
            var component = components[idx++];
            if (component) {
                var func = component._doUnload || component[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__DO_TEARDOWN"] /* @min:%2e_doTeardown */ ];
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(func)) {
                    if (func.call(component, unloadCtx, unloadState, _doUnload) === true) {
                        return true;
                    }
                }
            }
        }
    }
    return _doUnload();
}
function createDistributedTraceContext(parentCtx) {
    var trace = {};
    return {
        getName: function() {
            return trace[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ];
        },
        setName: function(newValue) {
            parentCtx && parentCtx.setName(newValue);
            trace[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ] = newValue;
        },
        getTraceId: function() {
            return trace.traceId;
        },
        setTraceId: function(newValue) {
            parentCtx && parentCtx.setTraceId(newValue);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$W3cTraceParent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidTraceId"])(newValue)) {
                trace.traceId = newValue;
            }
        },
        getSpanId: function() {
            return trace.spanId;
        },
        setSpanId: function(newValue) {
            parentCtx && parentCtx.setSpanId(newValue);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$W3cTraceParent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidSpanId"])(newValue)) {
                trace.spanId = newValue;
            }
        },
        getTraceFlags: function() {
            return trace[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_FLAGS"] /* @min:%2etraceFlags */ ];
        },
        setTraceFlags: function(newTraceFlags) {
            parentCtx && parentCtx.setTraceFlags(newTraceFlags);
            trace[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TRACE_FLAGS"] /* @min:%2etraceFlags */ ] = newTraceFlags;
        }
    };
} //# sourceMappingURL=TelemetryHelpers.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/ProcessTelemetryContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "ProcessTelemetryContext",
    ()=>ProcessTelemetryContext,
    "createProcessTelemetryContext",
    ()=>createProcessTelemetryContext,
    "createProcessTelemetryUnloadContext",
    ()=>createProcessTelemetryUnloadContext,
    "createProcessTelemetryUpdateContext",
    ()=>createProcessTelemetryUpdateContext,
    "createTelemetryPluginProxy",
    ()=>createTelemetryPluginProxy,
    "createTelemetryProxyChain",
    ()=>createTelemetryProxyChain
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaults$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/ConfigDefaults.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicConfig.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$PerfManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/PerfManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$TelemetryHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/TelemetryHelpers.js [app-client] (ecmascript)");
"use strict";
;
;
;
;
;
;
;
;
;
var strTelemetryPluginChain = "TelemetryPluginChain";
var strHasRunFlags = "_hasRun";
var strGetTelCtx = "_getTelCtx";
var _chainId = 0;
function _getNextProxyStart(proxy, core, startAt) {
    while(proxy){
        if (proxy[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_PLUGIN"] /* @min:%2egetPlugin */ ]() === startAt) {
            return proxy;
        }
        proxy = proxy[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_NEXT"] /* @min:%2egetNext */ ]();
    }
    // This wasn't found in the existing chain so create an isolated one with just this plugin
    return createTelemetryProxyChain([
        startAt
    ], core.config || {}, core);
}
/**
 * @ignore
 * @param telemetryChain
 * @param dynamicHandler
 * @param core
 * @param startAt - Identifies the next plugin to execute, if null there is no "next" plugin and if undefined it should assume the start of the chain
 * @returns
 */ function _createInternalContext(telemetryChain, dynamicHandler, core, startAt) {
    // We have a special case where we want to start execution from this specific plugin
    // or we simply reuse the existing telemetry plugin chain (normal execution case)
    var _nextProxy = null; // By Default set as no next plugin
    var _onComplete = [];
    if (!dynamicHandler) {
        dynamicHandler = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDynamicConfig"])({}, null, core[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ]);
    }
    if (startAt !== null) {
        // There is no next element (null) vs not defined (undefined) so use the full chain
        _nextProxy = startAt ? _getNextProxyStart(telemetryChain, core, startAt) : telemetryChain;
    }
    var context = {
        _next: _moveNext,
        ctx: {
            core: function() {
                return core;
            },
            diagLog: function() {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeGetLogger"])(core, dynamicHandler.cfg);
            },
            getCfg: function() {
                return dynamicHandler.cfg;
            },
            getExtCfg: _resolveExtCfg,
            getConfig: _getConfig,
            hasNext: function() {
                return !!_nextProxy;
            },
            getNext: function() {
                return _nextProxy;
            },
            setNext: function(nextPlugin) {
                _nextProxy = nextPlugin;
            },
            iterate: _iterateChain,
            onComplete: _addOnComplete
        }
    };
    function _addOnComplete(onComplete, that) {
        var args = [];
        for(var _i = 2; _i < arguments.length; _i++){
            args[_i - 2] = arguments[_i];
        }
        if (onComplete) {
            _onComplete[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ]({
                func: onComplete,
                self: !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"])(that) ? that : context.ctx,
                args: args
            });
        }
    }
    function _moveNext() {
        var nextProxy = _nextProxy;
        // Automatically move to the next plugin
        _nextProxy = nextProxy ? nextProxy[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_NEXT"] /* @min:%2egetNext */ ]() : null;
        if (!nextProxy) {
            var onComplete = _onComplete;
            if (onComplete && onComplete[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(onComplete, function(completeDetails) {
                    try {
                        completeDetails.func.call(completeDetails.self, completeDetails.args);
                    } catch (e) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(core[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ], 2 /* eLoggingSeverity.WARNING */ , 73 /* _eInternalMessageId.PluginException */ , "Unexpected Exception during onComplete - " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e));
                    }
                });
                _onComplete = [];
            }
        }
        return nextProxy;
    }
    function _getExtCfg(identifier, createIfMissing) {
        var idCfg = null;
        var cfg = dynamicHandler.cfg;
        if (cfg && identifier) {
            var extCfg = cfg[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EXTENSION_CONFIG"] /* @min:%2eextensionConfig */ ];
            if (!extCfg && createIfMissing) {
                extCfg = {};
            }
            // Always set the value so that the property always exists
            cfg[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EXTENSION_CONFIG"]] = extCfg; // Note: it is valid for the "value" to be undefined
            // Calling `ref()` has a side effect of causing the referenced property to become dynamic  (if not already)
            extCfg = dynamicHandler.ref(cfg, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EXTENSION_CONFIG"]);
            if (extCfg) {
                idCfg = extCfg[identifier];
                if (!idCfg && createIfMissing) {
                    idCfg = {};
                }
                // Always set the value so that the property always exists
                extCfg[identifier] = idCfg; // Note: it is valid for the "value" to be undefined
                // Calling `ref()` has a side effect of causing the referenced property to become dynamic  (if not already)
                idCfg = dynamicHandler.ref(extCfg, identifier);
            }
        }
        return idCfg;
    }
    function _resolveExtCfg(identifier, defaultValues) {
        var newConfig = _getExtCfg(identifier, true);
        if (defaultValues) {
            // Enumerate over the defaultValues and if not already populated attempt to
            // find a value from the root config or use the default value
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(defaultValues, function(field, defaultValue) {
                // for each unspecified field, set the default value
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(newConfig[field])) {
                    var cfgValue = dynamicHandler.cfg[field];
                    if (cfgValue || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(cfgValue)) {
                        newConfig[field] = cfgValue;
                    }
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaults$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_applyDefaultValue"])(dynamicHandler, newConfig, field, defaultValue);
            });
        }
        return dynamicHandler.setDf(newConfig, defaultValues);
    }
    function _getConfig(identifier, field, defaultValue) {
        if (defaultValue === void 0) {
            defaultValue = false;
        }
        var theValue;
        var extConfig = _getExtCfg(identifier, false);
        var rootConfig = dynamicHandler.cfg;
        if (extConfig && (extConfig[field] || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(extConfig[field]))) {
            theValue = extConfig[field];
        } else if (rootConfig[field] || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(rootConfig[field])) {
            theValue = rootConfig[field];
        }
        return theValue || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(theValue) ? theValue : defaultValue;
    }
    function _iterateChain(cb) {
        // Keep processing until we reach the end of the chain
        var nextPlugin;
        while(!!(nextPlugin = context._next())){
            var plugin = nextPlugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_PLUGIN"] /* @min:%2egetPlugin */ ]();
            if (plugin) {
                // callback with the current on
                cb(plugin);
            }
        }
    }
    return context;
}
function createProcessTelemetryContext(telemetryChain, cfg, core, startAt) {
    var config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDynamicConfig"])(cfg);
    var internalContext = _createInternalContext(telemetryChain, config, core, startAt);
    var context = internalContext.ctx;
    function _processNext(env) {
        var nextPlugin = internalContext._next();
        if (nextPlugin) {
            // Run the next plugin which will call "processNext()"
            nextPlugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PROCESS_TELEMETRY"] /* @min:%2eprocessTelemetry */ ](env, context);
        }
        return !nextPlugin;
    }
    function _createNew(plugins, startAt) {
        if (plugins === void 0) {
            plugins = null;
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(plugins)) {
            plugins = createTelemetryProxyChain(plugins, config.cfg, core, startAt);
        }
        return createProcessTelemetryContext(plugins || context[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_NEXT"] /* @min:%2egetNext */ ](), config.cfg, core, startAt);
    }
    context[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROCESS_NEXT"] /* @min:%2eprocessNext */ ] = _processNext;
    context[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CREATE_NEW"] /* @min:%2ecreateNew */ ] = _createNew;
    return context;
}
function createProcessTelemetryUnloadContext(telemetryChain, core, startAt) {
    var config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDynamicConfig"])(core.config);
    var internalContext = _createInternalContext(telemetryChain, config, core, startAt);
    var context = internalContext.ctx;
    function _processNext(unloadState) {
        var nextPlugin = internalContext._next();
        nextPlugin && nextPlugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_UNLOAD"] /* @min:%2eunload */ ](context, unloadState);
        return !nextPlugin;
    }
    function _createNew(plugins, startAt) {
        if (plugins === void 0) {
            plugins = null;
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(plugins)) {
            plugins = createTelemetryProxyChain(plugins, config.cfg, core, startAt);
        }
        return createProcessTelemetryUnloadContext(plugins || context[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_NEXT"] /* @min:%2egetNext */ ](), core, startAt);
    }
    context[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROCESS_NEXT"] /* @min:%2eprocessNext */ ] = _processNext;
    context[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CREATE_NEW"] /* @min:%2ecreateNew */ ] = _createNew;
    return context;
}
function createProcessTelemetryUpdateContext(telemetryChain, core, startAt) {
    var config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDynamicConfig"])(core.config);
    var internalContext = _createInternalContext(telemetryChain, config, core, startAt);
    var context = internalContext.ctx;
    function _processNext(updateState) {
        return context.iterate(function(plugin) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_UPDATE"] /* @min:%2eupdate */ ])) {
                plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_UPDATE"] /* @min:%2eupdate */ ](context, updateState);
            }
        });
    }
    function _createNew(plugins, startAt) {
        if (plugins === void 0) {
            plugins = null;
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(plugins)) {
            plugins = createTelemetryProxyChain(plugins, config.cfg, core, startAt);
        }
        return createProcessTelemetryUpdateContext(plugins || context[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_NEXT"] /* @min:%2egetNext */ ](), core, startAt);
    }
    context[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROCESS_NEXT"] /* @min:%2eprocessNext */ ] = _processNext;
    context[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CREATE_NEW"] /* @min:%2ecreateNew */ ] = _createNew;
    return context;
}
function createTelemetryProxyChain(plugins, config, core, startAt) {
    var firstProxy = null;
    var add = startAt ? false : true;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(plugins) && plugins[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
        // Create the proxies and wire up the next plugin chain
        var lastProxy_1 = null;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(plugins, function(thePlugin) {
            if (!add && startAt === thePlugin) {
                add = true;
            }
            if (add && thePlugin && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(thePlugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PROCESS_TELEMETRY"] /* @min:%2eprocessTelemetry */ ])) {
                // Only add plugins that are processors
                var newProxy = createTelemetryPluginProxy(thePlugin, config, core);
                if (!firstProxy) {
                    firstProxy = newProxy;
                }
                if (lastProxy_1) {
                    // Set this new proxy as the next for the previous one
                    lastProxy_1._setNext(newProxy);
                }
                lastProxy_1 = newProxy;
            }
        });
    }
    if (startAt && !firstProxy) {
        // Special case where the "startAt" was not in the original list of plugins
        return createTelemetryProxyChain([
            startAt
        ], config, core);
    }
    return firstProxy;
}
function createTelemetryPluginProxy(plugin, config, core) {
    var nextProxy = null;
    var hasProcessTelemetry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PROCESS_TELEMETRY"] /* @min:%2eprocessTelemetry */ ]);
    var hasSetNext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_NEXT_PLUGIN"] /* @min:%2esetNextPlugin */ ]);
    var chainId;
    if (plugin) {
        chainId = plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IDENTIFIER"] /* @min:%2eidentifier */ ] + "-" + plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PRIORITY"] /* @min:%2epriority */ ] + "-" + _chainId++;
    } else {
        chainId = "Unknown-0-" + _chainId++;
    }
    var proxyChain = {
        getPlugin: function() {
            return plugin;
        },
        getNext: function() {
            return nextProxy;
        },
        processTelemetry: _processTelemetry,
        unload: _unloadPlugin,
        update: _updatePlugin,
        _id: chainId,
        _setNext: function(nextPlugin) {
            nextProxy = nextPlugin;
        }
    };
    function _getTelCtx() {
        var itemCtx;
        // Looks like a plugin didn't pass the (optional) context, so create a new one
        if (plugin && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(plugin[strGetTelCtx])) {
            // This plugin extends from the BaseTelemetryPlugin so lets use it
            itemCtx = plugin[strGetTelCtx]();
        }
        if (!itemCtx) {
            // Create a temporary one
            itemCtx = createProcessTelemetryContext(proxyChain, config, core);
        }
        return itemCtx;
    }
    function _processChain(itemCtx, processPluginFn, name, details, isAsync) {
        var hasRun = false;
        var identifier = plugin ? plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IDENTIFIER"] /* @min:%2eidentifier */ ] : strTelemetryPluginChain;
        var hasRunContext = itemCtx[strHasRunFlags];
        if (!hasRunContext) {
            // Assign and populate
            hasRunContext = itemCtx[strHasRunFlags] = {};
        }
        // Ensure that we keep the context in sync
        itemCtx.setNext(nextProxy);
        if (plugin) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$PerfManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doPerf"])(itemCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"] /* @min:%2ecore */ ](), function() {
                return identifier + ":" + name;
            }, function() {
                // Mark this component as having run
                hasRunContext[chainId] = true;
                try {
                    // Set a flag on the next plugin so we know if it was attempted to be executed
                    var nextId = nextProxy ? nextProxy._id : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"];
                    if (nextId) {
                        hasRunContext[nextId] = false;
                    }
                    hasRun = processPluginFn(itemCtx);
                } catch (error) {
                    var hasNextRun = nextProxy ? hasRunContext[nextProxy._id] : true;
                    if (hasNextRun) {
                        // The next plugin after us has already run so set this one as complete
                        hasRun = true;
                    }
                    if (!nextProxy || !hasNextRun) {
                        // Either we have no next plugin or the current one did not attempt to call the next plugin
                        // Which means the current one is the root of the failure so log/report this failure
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(itemCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), 1 /* eLoggingSeverity.CRITICAL */ , 73 /* _eInternalMessageId.PluginException */ , "Plugin [" + identifier + "] failed during " + name + " - " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(error) + ", run flags: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(hasRunContext));
                    }
                }
            }, details, isAsync);
        }
        return hasRun;
    }
    function _processTelemetry(env, itemCtx) {
        itemCtx = itemCtx || _getTelCtx();
        function _callProcessTelemetry(itemCtx) {
            if (!plugin || !hasProcessTelemetry) {
                return false;
            }
            var pluginState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$TelemetryHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getPluginState"])(plugin);
            if (pluginState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TEARDOWN"] /* @min:%2eteardown */ ] || pluginState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_DISABLED"]]) {
                return false;
            }
            // Ensure that we keep the context in sync (for processNext()), just in case a plugin
            // doesn't calls processTelemetry() instead of itemContext.processNext() or some
            // other form of error occurred
            if (hasSetNext) {
                // Backward compatibility setting the next plugin on the instance
                plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_NEXT_PLUGIN"] /* @min:%2esetNextPlugin */ ](nextProxy);
            }
            plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PROCESS_TELEMETRY"] /* @min:%2eprocessTelemetry */ ](env, itemCtx);
            // Process Telemetry is expected to call itemCtx.processNext() or nextPlugin.processTelemetry()
            return true;
        }
        if (!_processChain(itemCtx, _callProcessTelemetry, "processTelemetry", function() {
            return {
                item: env
            };
        }, !env.sync)) {
            // The underlying plugin is either not defined, not enabled or does not have a processTelemetry implementation
            // so we still want the next plugin to be executed.
            itemCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROCESS_NEXT"] /* @min:%2eprocessNext */ ](env);
        }
    }
    function _unloadPlugin(unloadCtx, unloadState) {
        function _callTeardown() {
            // Setting default of hasRun as false so the proxyProcessFn() is called as teardown() doesn't have to exist or call unloadNext().
            var hasRun = false;
            if (plugin) {
                var pluginState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$TelemetryHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getPluginState"])(plugin);
                var pluginCore = plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"]] || pluginState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"] /* @min:%2ecore */ ];
                // Only teardown the plugin if it was initialized by the current core (i.e. It's not a shared plugin)
                if (plugin && (!pluginCore || pluginCore === unloadCtx.core()) && !pluginState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TEARDOWN"] /* @min:%2eteardown */ ]) {
                    // Handle plugins that don't extend from the BaseTelemetryPlugin
                    pluginState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"] /* @min:%2ecore */ ] = null;
                    pluginState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TEARDOWN"] /* @min:%2eteardown */ ] = true;
                    pluginState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_INITIALIZED"] /* @min:%2eisInitialized */ ] = false;
                    if (plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TEARDOWN"] /* @min:%2eteardown */ ] && plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TEARDOWN"] /* @min:%2eteardown */ ](unloadCtx, unloadState) === true) {
                        // plugin told us that it was going to (or has) call unloadCtx.processNext()
                        hasRun = true;
                    }
                }
            }
            return hasRun;
        }
        if (!_processChain(unloadCtx, _callTeardown, "unload", function() {}, unloadState.isAsync)) {
            // Only called if we hasRun was not true
            unloadCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROCESS_NEXT"] /* @min:%2eprocessNext */ ](unloadState);
        }
    }
    function _updatePlugin(updateCtx, updateState) {
        function _callUpdate() {
            // Setting default of hasRun as false so the proxyProcessFn() is called as teardown() doesn't have to exist or call unloadNext().
            var hasRun = false;
            if (plugin) {
                var pluginState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$TelemetryHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getPluginState"])(plugin);
                var pluginCore = plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"]] || pluginState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"] /* @min:%2ecore */ ];
                // Only update the plugin if it was initialized by the current core (i.e. It's not a shared plugin)
                if (plugin && (!pluginCore || pluginCore === updateCtx.core()) && !pluginState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TEARDOWN"] /* @min:%2eteardown */ ]) {
                    if (plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_UPDATE"] /* @min:%2eupdate */ ] && plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_UPDATE"] /* @min:%2eupdate */ ](updateCtx, updateState) === true) {
                        // plugin told us that it was going to (or has) call unloadCtx.processNext()
                        hasRun = true;
                    }
                }
            }
            return hasRun;
        }
        if (!_processChain(updateCtx, _callUpdate, "update", function() {}, false)) {
            // Only called if we hasRun was not true
            updateCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROCESS_NEXT"] /* @min:%2eprocessNext */ ](updateState);
        }
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objFreeze"])(proxyChain);
}
/**
 * This class will be removed!
 * @deprecated use createProcessTelemetryContext() instead
 */ var ProcessTelemetryContext = function() {
    /**
     * Creates a new Telemetry Item context with the current config, core and plugin execution chain
     * @param plugins - The plugin instances that will be executed
     * @param config - The current config
     * @param core - The current core instance
     */ function ProcessTelemetryContext(pluginChain, config, core, startAt) {
        var _self = this;
        var context = createProcessTelemetryContext(pluginChain, config, core, startAt);
        // Proxy all functions of the context to this object
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["proxyFunctions"])(_self, context, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objKeys"])(context));
    }
    return ProcessTelemetryContext;
}();
;
 //# sourceMappingURL=ProcessTelemetryContext.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/UnloadHandlerContainer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "createUnloadHandlerContainer",
    ()=>createUnloadHandlerContainer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
;
;
;
function createUnloadHandlerContainer() {
    var handlers = [];
    function _addHandler(handler) {
        if (handler) {
            handlers[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](handler);
        }
    }
    function _runHandlers(unloadCtx, unloadState) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(handlers, function(handler) {
            try {
                handler(unloadCtx, unloadState);
            } catch (e) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(unloadCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ](), 2 /* eLoggingSeverity.WARNING */ , 73 /* _eInternalMessageId.PluginException */ , "Unexpected error calling unload handler - " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e));
            }
        });
        handlers = [];
    }
    return {
        add: _addHandler,
        run: _runHandlers
    };
} //# sourceMappingURL=UnloadHandlerContainer.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/UnloadHookContainer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "_testHookMaxUnloadHooksCb",
    ()=>_testHookMaxUnloadHooksCb,
    "createUnloadHookContainer",
    ()=>createUnloadHookContainer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
;
;
;
var _maxHooks;
var _hookAddMonitor;
function _testHookMaxUnloadHooksCb(maxHooks, addMonitor) {
    _maxHooks = maxHooks;
    _hookAddMonitor = addMonitor;
}
function createUnloadHookContainer() {
    var _hooks = [];
    function _doUnload(logger) {
        var oldHooks = _hooks;
        _hooks = [];
        // Remove all registered unload hooks
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(oldHooks, function(fn) {
            // allow either rm or remove callback function
            try {
                (fn.rm || fn.remove).call(fn);
            } catch (e) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 2 /* eLoggingSeverity.WARNING */ , 73 /* _eInternalMessageId.PluginException */ , "Unloading:" + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e));
            }
        });
        if (_maxHooks && oldHooks[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > _maxHooks) {
            _hookAddMonitor ? _hookAddMonitor("doUnload", oldHooks) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(null, 1 /* eLoggingSeverity.CRITICAL */ , 48 /* _eInternalMessageId.MaxUnloadHookExceeded */ , "Max unload hooks exceeded. An excessive number of unload hooks has been detected.");
        }
    }
    function _addHook(hooks) {
        if (hooks) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrAppend"])(_hooks, hooks);
            if (_maxHooks && _hooks[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > _maxHooks) {
                _hookAddMonitor ? _hookAddMonitor("Add", _hooks) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(null, 1 /* eLoggingSeverity.CRITICAL */ , 48 /* _eInternalMessageId.MaxUnloadHookExceeded */ , "Max unload hooks exceeded. An excessive number of unload hooks has been detected.");
            }
        }
    }
    return {
        run: _doUnload,
        add: _addHook
    };
} //# sourceMappingURL=UnloadHookContainer.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/BaseTelemetryPlugin.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "BaseTelemetryPlugin",
    ()=>BaseTelemetryPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicConfig.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/ProcessTelemetryContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$UnloadHandlerContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/UnloadHandlerContainer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$UnloadHookContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/UnloadHookContainer.js [app-client] (ecmascript)");
"use strict";
var _a;
;
;
;
;
;
;
;
;
;
;
var strGetPlugin = "getPlugin";
var defaultValues = (_a = {}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EXTENSION_CONFIG"]] = {
    isVal: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNotNullOrUndefined"],
    v: {}
}, _a);
/**
 * BaseTelemetryPlugin provides a basic implementation of the ITelemetryPlugin interface so that plugins
 * can avoid implementation the same set of boiler plate code as well as provide a base
 * implementation so that new default implementations can be added without breaking all plugins.
 */ var BaseTelemetryPlugin = function() {
    function BaseTelemetryPlugin() {
        var _self = this; // Setting _self here as it's used outside of the dynamicProto as well
        // NOTE!: DON'T set default values here, instead set them in the _initDefaults() function as it is also called during teardown()
        var _isinitialized;
        var _rootCtx; // Used as the root context, holding the current config and initialized core
        var _nextPlugin; // Used for backward compatibility where plugins don't call the main pipeline
        var _unloadHandlerContainer;
        var _hookContainer;
        _initDefaults();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(BaseTelemetryPlugin, _self, function(_self) {
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INITIALIZE"] /* @min:%2einitialize */ ] = function(config, core, extensions, pluginChain) {
                _setDefaults(config, core, pluginChain);
                _isinitialized = true;
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TEARDOWN"] /* @min:%2eteardown */ ] = function(unloadCtx, unloadState) {
                // If this plugin has already been torn down (not operational) or is not initialized (core is not set)
                // or the core being used for unload was not the same core used for initialization.
                var core = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"] /* @min:%2ecore */ ];
                if (!core || unloadCtx && core !== unloadCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"] /* @min:%2ecore */ ]()) {
                    // Do Nothing as either the plugin is not initialized or was not initialized by the current core
                    return;
                }
                var result;
                var unloadDone = false;
                var theUnloadCtx = unloadCtx || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProcessTelemetryUnloadContext"])(null, core, _nextPlugin && _nextPlugin[strGetPlugin] ? _nextPlugin[strGetPlugin]() : _nextPlugin);
                var theUnloadState = unloadState || {
                    reason: 0 /* TelemetryUnloadReason.ManualTeardown */ ,
                    isAsync: false
                };
                function _unloadCallback() {
                    if (!unloadDone) {
                        unloadDone = true;
                        _unloadHandlerContainer.run(theUnloadCtx, unloadState);
                        _hookContainer.run(theUnloadCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ]());
                        if (result === true) {
                            theUnloadCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROCESS_NEXT"] /* @min:%2eprocessNext */ ](theUnloadState);
                        }
                        _initDefaults();
                    }
                }
                if (!_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__DO_TEARDOWN"] /* @min:%2e_doTeardown */ ] || _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__DO_TEARDOWN"] /* @min:%2e_doTeardown */ ](theUnloadCtx, theUnloadState, _unloadCallback) !== true) {
                    _unloadCallback();
                } else {
                    // Tell the caller that we will be calling processNext()
                    result = true;
                }
                return result;
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_UPDATE"] /* @min:%2eupdate */ ] = function(updateCtx, updateState) {
                // If this plugin has already been torn down (not operational) or is not initialized (core is not set)
                // or the core being used for unload was not the same core used for initialization.
                var core = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"] /* @min:%2ecore */ ];
                if (!core || updateCtx && core !== updateCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"] /* @min:%2ecore */ ]()) {
                    // Do Nothing
                    return;
                }
                var result;
                var updateDone = false;
                var theUpdateCtx = updateCtx || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProcessTelemetryUpdateContext"])(null, core, _nextPlugin && _nextPlugin[strGetPlugin] ? _nextPlugin[strGetPlugin]() : _nextPlugin);
                var theUpdateState = updateState || {
                    reason: 0 /* TelemetryUpdateReason.Unknown */ 
                };
                function _updateCallback() {
                    if (!updateDone) {
                        updateDone = true;
                        _setDefaults(theUpdateCtx.getCfg(), theUpdateCtx.core(), theUpdateCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_NEXT"] /* @min:%2egetNext */ ]());
                    }
                }
                if (!_self._doUpdate || _self._doUpdate(theUpdateCtx, theUpdateState, _updateCallback) !== true) {
                    _updateCallback();
                } else {
                    result = true;
                }
                return result;
            };
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["proxyFunctionAs"])(_self, "_addUnloadCb", function() {
                return _unloadHandlerContainer;
            }, "add");
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["proxyFunctionAs"])(_self, "_addHook", function() {
                return _hookContainer;
            }, "add");
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "_unloadHooks", {
                g: function() {
                    return _hookContainer;
                }
            });
        });
        // These are added after the dynamicProto so that are not moved to the prototype
        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ] = function(itemCtx) {
            return _getTelCtx(itemCtx)[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ]();
        };
        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_INITIALIZED"] /* @min:%2eisInitialized */ ] = function() {
            return _isinitialized;
        };
        _self.setInitialized = function(isInitialized) {
            _isinitialized = isInitialized;
        };
        // _self.getNextPlugin = () => DO NOT IMPLEMENT
        // Sub-classes of this base class *should* not be relying on this value and instead
        // should use processNext() function. If you require access to the plugin use the
        // IProcessTelemetryContext.getNext().getPlugin() while in the pipeline, Note getNext() may return null.
        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SET_NEXT_PLUGIN"] /* @min:%2esetNextPlugin */ ] = function(next) {
            _nextPlugin = next;
        };
        _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROCESS_NEXT"] /* @min:%2eprocessNext */ ] = function(env, itemCtx) {
            if (itemCtx) {
                // Normal core execution sequence
                itemCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROCESS_NEXT"] /* @min:%2eprocessNext */ ](env);
            } else if (_nextPlugin && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(_nextPlugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PROCESS_TELEMETRY"] /* @min:%2eprocessTelemetry */ ])) {
                // Looks like backward compatibility or out of band processing. And as it looks
                // like a ITelemetryPlugin or ITelemetryPluginChain, just call processTelemetry
                _nextPlugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PROCESS_TELEMETRY"] /* @min:%2eprocessTelemetry */ ](env, null);
            }
        };
        _self._getTelCtx = _getTelCtx;
        function _getTelCtx(currentCtx) {
            if (currentCtx === void 0) {
                currentCtx = null;
            }
            var itemCtx = currentCtx;
            if (!itemCtx) {
                var rootCtx = _rootCtx || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProcessTelemetryContext"])(null, {}, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"] /* @min:%2ecore */ ]);
                // tslint:disable-next-line: prefer-conditional-expression
                if (_nextPlugin && _nextPlugin[strGetPlugin]) {
                    // Looks like a chain object
                    itemCtx = rootCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CREATE_NEW"] /* @min:%2ecreateNew */ ](null, _nextPlugin[strGetPlugin]);
                } else {
                    itemCtx = rootCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CREATE_NEW"] /* @min:%2ecreateNew */ ](null, _nextPlugin);
                }
            }
            return itemCtx;
        }
        function _setDefaults(config, core, pluginChain) {
            // Make sure the extensionConfig exists and the config is dynamic
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDynamicConfig"])(config, defaultValues, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeGetLogger"])(core));
            if (!pluginChain && core) {
                // Get the first plugin from the core
                pluginChain = core[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_PROCESS_TEL_CONT2"] /* @min:%2egetProcessTelContext */ ]()[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_NEXT"] /* @min:%2egetNext */ ]();
            }
            var nextPlugin = _nextPlugin;
            if (_nextPlugin && _nextPlugin[strGetPlugin]) {
                // If it looks like a proxy/chain then get the plugin
                nextPlugin = _nextPlugin[strGetPlugin]();
            }
            // Support legacy plugins where core was defined as a property
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"] /* @min:%2ecore */ ] = core;
            _rootCtx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProcessTelemetryContext"])(pluginChain, config, core, nextPlugin);
        }
        function _initDefaults() {
            _isinitialized = false;
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"] /* @min:%2ecore */ ] = null;
            _rootCtx = null;
            _nextPlugin = null;
            _hookContainer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$UnloadHookContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUnloadHookContainer"])();
            _unloadHandlerContainer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$UnloadHandlerContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUnloadHandlerContainer"])();
        }
    }
    // Removed Stub for BaseTelemetryPlugin.prototype.initialize.
    // Removed Stub for BaseTelemetryPlugin.prototype.teardown.
    // Removed Stub for BaseTelemetryPlugin.prototype.update.
    // Removed Stub for BaseTelemetryPlugin.prototype._addUnloadCb.
    // Removed Stub for BaseTelemetryPlugin.prototype._addHook.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    BaseTelemetryPlugin.__ieDyn = 1;
    return BaseTelemetryPlugin;
}();
;
 //# sourceMappingURL=BaseTelemetryPlugin.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InstrumentHooks.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "InstrumentEvent",
    ()=>InstrumentEvent,
    "InstrumentFunc",
    ()=>InstrumentFunc,
    "InstrumentFuncs",
    ()=>InstrumentFuncs,
    "InstrumentProto",
    ()=>InstrumentProto,
    "InstrumentProtos",
    ()=>InstrumentProtos
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-shims@3.0.1/node_modules/@microsoft/applicationinsights-shims/dist-es5/Constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
;
;
;
;
var aiInstrumentHooks = "_aiHooks";
var cbNames = [
    "req",
    "rsp",
    "hkErr",
    "fnErr"
];
/** @ignore */ function _arrLoop(arr, fn) {
    if (arr) {
        for(var lp = 0; lp < arr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]; lp++){
            if (fn(arr[lp], lp)) {
                break;
            }
        }
    }
}
/** @ignore */ function _doCallbacks(hooks, callDetails, cbArgs, hookCtx, type) {
    if (type >= 0 /* CallbackType.Request */  && type <= 2 /* CallbackType.HookError */ ) {
        _arrLoop(hooks, function(hook, idx) {
            var cbks = hook.cbks;
            var cb = cbks[cbNames[type]];
            if (cb) {
                // Set the specific hook context implementation using a lazy creation pattern
                callDetails.ctx = function() {
                    var ctx = hookCtx[idx] = hookCtx[idx] || {};
                    return ctx;
                };
                try {
                    cb[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY"] /* @min:%2eapply */ ](callDetails.inst, cbArgs);
                } catch (err) {
                    var orgEx = callDetails.err;
                    try {
                        // Report Hook error via the callback
                        var hookErrorCb = cbks[cbNames[2 /* CallbackType.HookError */ ]];
                        if (hookErrorCb) {
                            callDetails.err = err;
                            hookErrorCb[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY"] /* @min:%2eapply */ ](callDetails.inst, cbArgs);
                        }
                    } catch (e) {
                    // Not much we can do here -- swallowing the exception to avoid crashing the hosting app
                    } finally{
                        // restore the original exception (if any)
                        callDetails.err = orgEx;
                    }
                }
            }
        });
    }
}
/** @ignore */ function _createFunctionHook(aiHook) {
    // Define a temporary method that queues-up a the real method call
    return function() {
        var funcThis = this;
        // Capture the original arguments passed to the method
        var orgArgs = arguments;
        var hooks = aiHook.h;
        var funcArgs = {
            name: aiHook.n,
            inst: funcThis,
            ctx: null,
            set: _replaceArg
        };
        var hookCtx = [];
        var cbArgs = _createArgs([
            funcArgs
        ], orgArgs);
        funcArgs.evt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInst"])("event");
        function _createArgs(target, theArgs) {
            _arrLoop(theArgs, function(arg) {
                target[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](arg);
            });
            return target;
        }
        function _replaceArg(idx, value) {
            orgArgs = _createArgs([], orgArgs);
            orgArgs[idx] = value;
            cbArgs = _createArgs([
                funcArgs
            ], orgArgs);
        }
        // Call the pre-request hooks
        _doCallbacks(hooks, funcArgs, cbArgs, hookCtx, 0 /* CallbackType.Request */ );
        // Call the original function was called
        var theFunc = aiHook.f;
        if (theFunc) {
            try {
                funcArgs.rslt = theFunc[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY"] /* @min:%2eapply */ ](funcThis, orgArgs);
            } catch (err) {
                // Report the request callback
                funcArgs.err = err;
                _doCallbacks(hooks, funcArgs, cbArgs, hookCtx, 3 /* CallbackType.FunctionError */ );
                // rethrow the original exception so anyone listening for it can catch the exception
                throw err;
            }
        }
        // Call the post-request hooks
        _doCallbacks(hooks, funcArgs, cbArgs, hookCtx, 1 /* CallbackType.Response */ );
        return funcArgs.rslt;
    };
}
/** @ignore */ function _getOwner(target, name, checkPrototype, checkParentProto) {
    var owner = null;
    if (target) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objHasOwnProperty"])(target, name)) {
            owner = target;
        } else if (checkPrototype) {
            owner = _getOwner((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getObjProto"])(target), name, checkParentProto, false);
        }
    }
    return owner;
}
function InstrumentProto(target, funcName, callbacks) {
    if (target) {
        return InstrumentFunc(target[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strShimPrototype"]], funcName, callbacks, false);
    }
    return null;
}
function InstrumentProtos(target, funcNames, callbacks) {
    if (target) {
        return InstrumentFuncs(target[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strShimPrototype"]], funcNames, callbacks, false);
    }
    return null;
}
function _createInstrumentHook(owner, funcName, fn, callbacks) {
    var aiHook = fn && fn[aiInstrumentHooks];
    if (!aiHook) {
        // Only hook the function once
        aiHook = {
            i: 0,
            n: funcName,
            f: fn,
            h: []
        };
        // Override (hook) the original function
        var newFunc = _createFunctionHook(aiHook);
        newFunc[aiInstrumentHooks] = aiHook; // Tag and store the function hooks
        owner[funcName] = newFunc;
    }
    var theHook = {
        // tslint:disable:object-literal-shorthand
        id: aiHook.i,
        cbks: callbacks,
        rm: function() {
            // DO NOT Use () => { shorthand for the function as the this gets replaced
            // with the outer this and not the this for theHook instance.
            var id = this.id;
            _arrLoop(aiHook.h, function(hook, idx) {
                if (hook.id === id) {
                    aiHook.h[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPLICE"] /* @min:%2esplice */ ](idx, 1);
                    return 1;
                }
            });
        }
    };
    aiHook.i++;
    aiHook.h[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](theHook);
    return theHook;
}
function InstrumentFunc(target, funcName, callbacks, checkPrototype, checkParentProto) {
    if (checkPrototype === void 0) {
        checkPrototype = true;
    }
    if (target && funcName && callbacks) {
        var owner = _getOwner(target, funcName, checkPrototype, checkParentProto);
        if (owner) {
            var fn = owner[funcName];
            if (typeof fn === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strShimFunction"]) {
                return _createInstrumentHook(owner, funcName, fn, callbacks);
            }
        }
    }
    return null;
}
function InstrumentFuncs(target, funcNames, callbacks, checkPrototype, checkParentProto) {
    if (checkPrototype === void 0) {
        checkPrototype = true;
    }
    var hooks = null;
    _arrLoop(funcNames, function(funcName) {
        var hook = InstrumentFunc(target, funcName, callbacks, checkPrototype, checkParentProto);
        if (hook) {
            if (!hooks) {
                hooks = [];
            }
            hooks[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](hook);
        }
    });
    return hooks;
}
function InstrumentEvent(target, evtName, callbacks, checkPrototype, checkParentProto) {
    if (target && evtName && callbacks) {
        var owner = _getOwner(target, evtName, checkPrototype, checkParentProto) || target;
        if (owner) {
            return _createInstrumentHook(owner, evtName, owner[evtName], callbacks);
        }
    }
    return null;
} //# sourceMappingURL=InstrumentHooks.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/ConfigDefaultHelpers.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "cfgDfBlockPropValue",
    ()=>cfgDfBlockPropValue,
    "cfgDfBoolean",
    ()=>cfgDfBoolean,
    "cfgDfFunc",
    ()=>cfgDfFunc,
    "cfgDfMerge",
    ()=>cfgDfMerge,
    "cfgDfSet",
    ()=>cfgDfSet,
    "cfgDfString",
    ()=>cfgDfString,
    "cfgDfValidate",
    ()=>cfgDfValidate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
;
;
/**
 * @internal
 * @ignore
 * @param str
 * @param defaultValue
 * @returns
 */ function _stringToBoolOrDefault(theValue, defaultValue, theConfig) {
    if (!theValue && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(theValue)) {
        return defaultValue;
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isBoolean"])(theValue)) {
        return theValue;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asString"])(theValue)[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ]() === "true";
}
function cfgDfMerge(defaultValue) {
    return {
        mrg: true,
        v: defaultValue
    };
}
function cfgDfSet(setter, defaultValue) {
    return {
        set: setter,
        v: defaultValue
    };
}
function cfgDfValidate(validator, defaultValue, fallBackName) {
    return {
        fb: fallBackName,
        isVal: validator,
        v: defaultValue
    };
}
function cfgDfBoolean(defaultValue, fallBackName) {
    return {
        fb: fallBackName,
        set: _stringToBoolOrDefault,
        v: !!defaultValue
    };
}
function cfgDfFunc(defaultValue) {
    return {
        isVal: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"],
        v: defaultValue || null
    };
}
function cfgDfString(defaultValue) {
    return {
        isVal: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"],
        v: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asString"])(defaultValue || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"])
    };
}
function cfgDfBlockPropValue(defaultValue) {
    return {
        blkVal: true,
        v: defaultValue
    };
} //# sourceMappingURL=ConfigDefaultHelpers.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EventHelpers.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "__getRegisteredEvents",
    ()=>__getRegisteredEvents,
    "addEventHandler",
    ()=>addEventHandler,
    "addEventListeners",
    ()=>addEventListeners,
    "addPageHideEventListener",
    ()=>addPageHideEventListener,
    "addPageShowEventListener",
    ()=>addPageShowEventListener,
    "addPageUnloadEventListener",
    ()=>addPageUnloadEventListener,
    "attachEvent",
    ()=>attachEvent,
    "detachEvent",
    ()=>detachEvent,
    "eventOff",
    ()=>eventOff,
    "eventOn",
    ()=>eventOn,
    "mergeEvtNamespace",
    ()=>mergeEvtNamespace,
    "removeEventHandler",
    ()=>removeEventHandler,
    "removeEventListeners",
    ()=>removeEventListeners,
    "removePageHideEventListener",
    ()=>removePageHideEventListener,
    "removePageShowEventListener",
    ()=>removePageShowEventListener,
    "removePageUnloadEventListener",
    ()=>removePageUnloadEventListener
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DataCacheHelper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
;
;
;
;
// Added to help with minfication
var strOnPrefix = "on";
var strAttachEvent = "attachEvent";
var strAddEventHelper = "addEventListener";
var strDetachEvent = "detachEvent";
var strRemoveEventListener = "removeEventListener";
var strEvents = "events";
var strVisibilityChangeEvt = "visibilitychange";
var strPageHide = "pagehide";
var strPageShow = "pageshow";
var strUnload = "unload";
var strBeforeUnload = "beforeunload";
var strPageHideNamespace = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUniqueNamespace"])("aiEvtPageHide");
var strPageShowNamespace = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUniqueNamespace"])("aiEvtPageShow");
var rRemoveEmptyNs = /\.[\.]+/g;
var rRemoveTrailingEmptyNs = /[\.]+$/;
var _guid = 1;
var elmNodeData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElmNodeData"])("events");
var eventNamespace = /^([^.]*)(?:\.(.+)|)/;
function _normalizeNamespace(name) {
    if (name && name[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REPLACE"] /* @min:%2ereplace */ ]) {
        return name[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REPLACE"] /* @min:%2ereplace */ ](/^[\s\.]+|(?=[\s\.])[\.\s]+$/g, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"]);
    }
    return name;
}
function _getEvtNamespace(eventName, evtNamespace) {
    if (evtNamespace) {
        var theNamespace_1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"];
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(evtNamespace)) {
            theNamespace_1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"];
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(evtNamespace, function(name) {
                name = _normalizeNamespace(name);
                if (name) {
                    if (name[0] !== ".") {
                        name = "." + name;
                    }
                    theNamespace_1 += name;
                }
            });
        } else {
            theNamespace_1 = _normalizeNamespace(evtNamespace);
        }
        if (theNamespace_1) {
            if (theNamespace_1[0] !== ".") {
                theNamespace_1 = "." + theNamespace_1;
            }
            // We may only have the namespace and not an eventName
            eventName = (eventName || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"]) + theNamespace_1;
        }
    }
    var parsedEvent = eventNamespace.exec(eventName || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"]) || [];
    return {
        type: parsedEvent[1],
        ns: (parsedEvent[2] || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"]).replace(rRemoveEmptyNs, ".").replace(rRemoveTrailingEmptyNs, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"])[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPLIT"] /* @min:%2esplit */ ](".").sort().join(".")
    };
}
function __getRegisteredEvents(target, eventName, evtNamespace) {
    var theEvents = [];
    var eventCache = elmNodeData.get(target, strEvents, {}, false);
    var evtName = _getEvtNamespace(eventName, evtNamespace);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(eventCache, function(evtType, registeredEvents) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(registeredEvents, function(value) {
            if (!evtName[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TYPE"] /* @min:%2etype */ ] || evtName[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TYPE"] /* @min:%2etype */ ] === value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_EVT_NAME"] /* @min:%2eevtName */ ][__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TYPE"] /* @min:%2etype */ ]) {
                if (!evtName.ns || evtName.ns === evtName.ns) {
                    theEvents[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ]({
                        name: value.evtName[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TYPE"] /* @min:%2etype */ ] + (value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_EVT_NAME"] /* @min:%2eevtName */ ].ns ? "." + value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_EVT_NAME"] /* @min:%2eevtName */ ].ns : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"]),
                        handler: value.handler
                    });
                }
            }
        });
    });
    return theEvents;
}
// Exported for internal unit testing only
function _getRegisteredEvents(target, evtName, addDefault) {
    if (addDefault === void 0) {
        addDefault = true;
    }
    var aiEvts = elmNodeData.get(target, strEvents, {}, addDefault);
    var registeredEvents = aiEvts[evtName];
    if (!registeredEvents) {
        registeredEvents = aiEvts[evtName] = [];
    }
    return registeredEvents;
}
function _doDetach(obj, evtName, handlerRef, useCapture) {
    if (obj && evtName && evtName[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TYPE"] /* @min:%2etype */ ]) {
        if (obj[strRemoveEventListener]) {
            obj[strRemoveEventListener](evtName[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TYPE"] /* @min:%2etype */ ], handlerRef, useCapture);
        } else if (obj[strDetachEvent]) {
            obj[strDetachEvent](strOnPrefix + evtName[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TYPE"] /* @min:%2etype */ ], handlerRef);
        }
    }
}
function _doAttach(obj, evtName, handlerRef, useCapture) {
    var result = false;
    if (obj && evtName && evtName[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TYPE"] /* @min:%2etype */ ] && handlerRef) {
        if (obj[strAddEventHelper]) {
            // all browsers except IE before version 9
            obj[strAddEventHelper](evtName[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TYPE"] /* @min:%2etype */ ], handlerRef, useCapture);
            result = true;
        } else if (obj[strAttachEvent]) {
            // IE before version 9
            obj[strAttachEvent](strOnPrefix + evtName[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TYPE"] /* @min:%2etype */ ], handlerRef);
            result = true;
        }
    }
    return result;
}
function _doUnregister(target, events, evtName, unRegFn) {
    var idx = events[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
    while(idx--){
        var theEvent = events[idx];
        if (theEvent) {
            if (!evtName.ns || evtName.ns === theEvent[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_EVT_NAME"] /* @min:%2eevtName */ ].ns) {
                if (!unRegFn || unRegFn(theEvent)) {
                    _doDetach(target, theEvent[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_EVT_NAME"] /* @min:%2eevtName */ ], theEvent.handler, theEvent.capture);
                    // Remove the registered event
                    events[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPLICE"] /* @min:%2esplice */ ](idx, 1);
                }
            }
        }
    }
}
function _unregisterEvents(target, evtName, unRegFn) {
    if (evtName[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TYPE"] /* @min:%2etype */ ]) {
        _doUnregister(target, _getRegisteredEvents(target, evtName[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TYPE"] /* @min:%2etype */ ]), evtName, unRegFn);
    } else {
        var eventCache = elmNodeData.get(target, strEvents, {});
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(eventCache, function(evtType, events) {
            _doUnregister(target, events, evtName, unRegFn);
        });
        // Cleanup
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objKeys"])(eventCache)[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] === 0) {
            elmNodeData.kill(target, strEvents);
        }
    }
}
function mergeEvtNamespace(theNamespace, namespaces) {
    var newNamespaces;
    if (namespaces) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(namespaces)) {
            newNamespaces = [
                theNamespace
            ].concat(namespaces);
        } else {
            newNamespaces = [
                theNamespace,
                namespaces
            ];
        }
        // resort the namespaces so they are always in order
        newNamespaces = _getEvtNamespace("xx", newNamespaces).ns[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPLIT"] /* @min:%2esplit */ ](".");
    } else {
        newNamespaces = theNamespace;
    }
    return newNamespaces;
}
function eventOn(target, eventName, handlerRef, evtNamespace, useCapture) {
    if (useCapture === void 0) {
        useCapture = false;
    }
    var result = false;
    if (target) {
        try {
            var evtName = _getEvtNamespace(eventName, evtNamespace);
            result = _doAttach(target, evtName, handlerRef, useCapture);
            if (result && elmNodeData.accept(target)) {
                var registeredEvent = {
                    guid: _guid++,
                    evtName: evtName,
                    handler: handlerRef,
                    capture: useCapture
                };
                _getRegisteredEvents(target, evtName.type)[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](registeredEvent);
            }
        } catch (e) {
        // Just Ignore any error so that we don't break any execution path
        }
    }
    return result;
}
function eventOff(target, eventName, handlerRef, evtNamespace, useCapture) {
    if (useCapture === void 0) {
        useCapture = false;
    }
    if (target) {
        try {
            var evtName_1 = _getEvtNamespace(eventName, evtNamespace);
            var found_1 = false;
            _unregisterEvents(target, evtName_1, function(regEvent) {
                if (evtName_1.ns && !handlerRef || regEvent.handler === handlerRef) {
                    found_1 = true;
                    return true;
                }
                return false;
            });
            if (!found_1) {
                // fallback to try and remove as requested
                _doDetach(target, evtName_1, handlerRef, useCapture);
            }
        } catch (e) {
        // Just Ignore any error so that we don't break any execution path
        }
    }
}
function attachEvent(obj, eventNameWithoutOn, handlerRef, useCapture) {
    if (useCapture === void 0) {
        useCapture = false;
    }
    return eventOn(obj, eventNameWithoutOn, handlerRef, null, useCapture);
}
function detachEvent(obj, eventNameWithoutOn, handlerRef, useCapture) {
    if (useCapture === void 0) {
        useCapture = false;
    }
    eventOff(obj, eventNameWithoutOn, handlerRef, null, useCapture);
}
function addEventHandler(eventName, callback, evtNamespace) {
    var result = false;
    var w = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWindow"])();
    if (w) {
        result = eventOn(w, eventName, callback, evtNamespace);
        result = eventOn(w["body"], eventName, callback, evtNamespace) || result;
    }
    var doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])();
    if (doc) {
        result = eventOn(doc, eventName, callback, evtNamespace) || result;
    }
    return result;
}
function removeEventHandler(eventName, callback, evtNamespace) {
    var w = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWindow"])();
    if (w) {
        eventOff(w, eventName, callback, evtNamespace);
        eventOff(w["body"], eventName, callback, evtNamespace);
    }
    var doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])();
    if (doc) {
        eventOff(doc, eventName, callback, evtNamespace);
    }
}
/**
 * Bind the listener to the array of events
 * @param events - An string array of event names to bind the listener to
 * @param listener - The event callback to call when the event is triggered
 * @param excludeEvents - [Optional] An array of events that should not be hooked (if possible), unless no other events can be.
 * @param evtNamespace - [Optional] Namespace(s) to append to the event listeners so they can be uniquely identified and removed based on this namespace.
 * @returns true - when at least one of the events was registered otherwise false
 */ function _addEventListeners(events, listener, excludeEvents, evtNamespace) {
    var added = false;
    if (listener && events && events[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(events, function(name) {
            if (name) {
                if (!excludeEvents || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrIndexOf"])(excludeEvents, name) === -1) {
                    added = addEventHandler(name, listener, evtNamespace) || added;
                }
            }
        });
    }
    return added;
}
function addEventListeners(events, listener, excludeEvents, evtNamespace) {
    var added = false;
    if (listener && events && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(events)) {
        added = _addEventListeners(events, listener, excludeEvents, evtNamespace);
        if (!added && excludeEvents && excludeEvents[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
            // Failed to add any listeners and we excluded some, so just attempt to add the excluded events
            added = _addEventListeners(events, listener, null, evtNamespace);
        }
    }
    return added;
}
function removeEventListeners(events, listener, evtNamespace) {
    if (events && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(events)) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(events, function(name) {
            if (name) {
                removeEventHandler(name, listener, evtNamespace);
            }
        });
    }
}
function addPageUnloadEventListener(listener, excludeEvents, evtNamespace) {
    // Hook the unload event for the document, window and body to ensure that the client events are flushed to the server
    // As just hooking the window does not always fire (on chrome) for page navigation's.
    return addEventListeners([
        strBeforeUnload,
        strUnload,
        strPageHide
    ], listener, excludeEvents, evtNamespace);
}
function removePageUnloadEventListener(listener, evtNamespace) {
    removeEventListeners([
        strBeforeUnload,
        strUnload,
        strPageHide
    ], listener, evtNamespace);
}
function addPageHideEventListener(listener, excludeEvents, evtNamespace) {
    function _handlePageVisibility(evt) {
        var doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])();
        if (listener && doc && doc.visibilityState === "hidden") {
            listener(evt);
        }
    }
    // add the unique page show namespace to any provided namespace so we can only remove the ones added by "pagehide"
    var newNamespaces = mergeEvtNamespace(strPageHideNamespace, evtNamespace);
    var pageUnloadAdded = _addEventListeners([
        strPageHide
    ], listener, excludeEvents, newNamespaces);
    if (!excludeEvents || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrIndexOf"])(excludeEvents, strVisibilityChangeEvt) === -1) {
        pageUnloadAdded = _addEventListeners([
            strVisibilityChangeEvt
        ], _handlePageVisibility, excludeEvents, newNamespaces) || pageUnloadAdded;
    }
    if (!pageUnloadAdded && excludeEvents) {
        // Failed to add any listeners and we where requested to exclude some, so just call again without excluding anything
        pageUnloadAdded = addPageHideEventListener(listener, null, evtNamespace);
    }
    return pageUnloadAdded;
}
function removePageHideEventListener(listener, evtNamespace) {
    // add the unique page show namespace to any provided namespace so we only remove the ones added by "pagehide"
    var newNamespaces = mergeEvtNamespace(strPageHideNamespace, evtNamespace);
    removeEventListeners([
        strPageHide
    ], listener, newNamespaces);
    removeEventListeners([
        strVisibilityChangeEvt
    ], null, newNamespaces);
}
function addPageShowEventListener(listener, excludeEvents, evtNamespace) {
    function _handlePageVisibility(evt) {
        var doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])();
        if (listener && doc && doc.visibilityState === "visible") {
            listener(evt);
        }
    }
    // add the unique page show namespace to any provided namespace so we can only remove the ones added by "pageshow"
    var newNamespaces = mergeEvtNamespace(strPageShowNamespace, evtNamespace);
    var pageShowAdded = _addEventListeners([
        strPageShow
    ], listener, excludeEvents, newNamespaces);
    pageShowAdded = _addEventListeners([
        strVisibilityChangeEvt
    ], _handlePageVisibility, excludeEvents, newNamespaces) || pageShowAdded;
    if (!pageShowAdded && excludeEvents) {
        // Failed to add any listeners and we where requested to exclude some, so just call again without excluding anything
        pageShowAdded = addPageShowEventListener(listener, null, evtNamespace);
    }
    return pageShowAdded;
}
function removePageShowEventListener(listener, evtNamespace) {
    // add the unique page show namespace to any provided namespace so we only remove the ones added by "pageshow"
    var newNamespaces = mergeEvtNamespace(strPageShowNamespace, evtNamespace);
    removeEventListeners([
        strPageShow
    ], listener, newNamespaces);
    removeEventListeners([
        strVisibilityChangeEvt
    ], null, newNamespaces);
} //# sourceMappingURL=EventHelpers.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/CookieMgr.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "areCookiesSupported",
    ()=>areCookiesSupported,
    "createCookieMgr",
    ()=>createCookieMgr,
    "safeGetCookieMgr",
    ()=>safeGetCookieMgr,
    "uaDisallowsSameSiteNone",
    ()=>uaDisallowsSameSiteNone
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/ConfigDefaultHelpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicConfig.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EnvUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
var _a, _b;
;
;
;
;
;
;
;
;
var strToGMTString = "toGMTString";
var strToUTCString = "toUTCString";
var strCookie = "cookie";
var strExpires = "expires";
var strIsCookieUseDisabled = "isCookieUseDisabled";
var strDisableCookiesUsage = "disableCookiesUsage";
var strConfigCookieMgr = "_ckMgr";
var _supportsCookies = null;
var _allowUaSameSite = null;
var _parsedCookieValue = null;
var _doc;
var _cookieCache = {};
var _globalCookieConfig = {};
// // `isCookieUseDisabled` is deprecated, so explicitly casting as a key of IConfiguration to avoid typing error
// // when both isCookieUseDisabled and disableCookiesUsage are used disableCookiesUsage will take precedent, which is
// // why its listed first
/**
 * Set the supported dynamic config values as undefined (or an empty object) so that
 * any listeners will be informed of any changes.
 * Explicitly NOT including the deprecated `isCookieUseDisabled` as we don't want to support
 * the v1 deprecated field as dynamic for updates
 */ var rootDefaultConfig = (_a = {
    cookieCfg: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$ConfigDefaultHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cfgDfMerge"])((_b = {}, _b[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_DOMAIN"]] = {
        fb: "cookieDomain",
        dfVal: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNotNullOrUndefined"]
    }, _b.path = {
        fb: "cookiePath",
        dfVal: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNotNullOrUndefined"]
    }, _b.enabled = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNDEFINED_VALUE"], _b.ignoreCookies = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNDEFINED_VALUE"], _b.blockedCookies = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNDEFINED_VALUE"], _b.disableCookieDefer = false, _b)),
    cookieDomain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNDEFINED_VALUE"],
    cookiePath: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNDEFINED_VALUE"]
}, _a[strDisableCookiesUsage] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNDEFINED_VALUE"], _a);
function _getDoc() {
    !_doc && (_doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLazy"])(function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])();
    }));
}
/**
 * @ignore
 * DO NOT USE or export from the module, this is exposed as public to support backward compatibility of previous static utility methods only.
 * If you want to manager cookies either use the ICookieMgr available from the core instance via getCookieMgr() or create
 * your own instance of the CookieMgr and use that.
 * Using this directly for enabling / disabling cookie handling will not only affect your usage but EVERY user of cookies.
 * Example, if you are using a shared component that is also using Application Insights you will affect their cookie handling.
 * @param logger - The DiagnosticLogger to use for reporting errors.
 */ function _gblCookieMgr(config, logger) {
    // Stash the global instance against the BaseCookieMgr class
    var inst = createCookieMgr[strConfigCookieMgr] || _globalCookieConfig[strConfigCookieMgr];
    if (!inst) {
        // Note: not using the getSetValue() helper as that would require always creating a temporary cookieMgr
        // that ultimately is never used
        inst = createCookieMgr[strConfigCookieMgr] = createCookieMgr(config, logger);
        _globalCookieConfig[strConfigCookieMgr] = inst;
    }
    return inst;
}
function _isMgrEnabled(cookieMgr) {
    if (cookieMgr) {
        return cookieMgr.isEnabled();
    }
    return true;
}
function _isIgnoredCookie(cookieMgrCfg, name) {
    if (name && cookieMgrCfg && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(cookieMgrCfg.ignoreCookies)) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrIndexOf"])(cookieMgrCfg.ignoreCookies, name) !== -1;
    }
    return false;
}
function _isBlockedCookie(cookieMgrCfg, name) {
    if (name && cookieMgrCfg && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArray"])(cookieMgrCfg.blockedCookies)) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrIndexOf"])(cookieMgrCfg.blockedCookies, name) !== -1) {
            return true;
        }
    }
    return _isIgnoredCookie(cookieMgrCfg, name);
}
function _isCfgEnabled(rootConfig, cookieMgrConfig) {
    var isCfgEnabled = cookieMgrConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLED"] /* @min:%2eenabled */ ];
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(isCfgEnabled)) {
        // Set the enabled from the provided setting or the legacy root values
        var cookieEnabled = void 0;
        // This field is deprecated and dynamic updates will not be fully supported
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"])(rootConfig[strIsCookieUseDisabled])) {
            cookieEnabled = !rootConfig[strIsCookieUseDisabled];
        }
        // If this value is defined it takes precedent over the above
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"])(rootConfig[strDisableCookiesUsage])) {
            cookieEnabled = !rootConfig[strDisableCookiesUsage];
        }
        // Not setting the cookieMgrConfig.enabled as that will update (set) the global dynamic config
        // So future "updates" then may not be as expected
        isCfgEnabled = cookieEnabled;
    }
    return isCfgEnabled;
}
function safeGetCookieMgr(core, config) {
    var cookieMgr;
    if (core) {
        // Always returns an instance
        cookieMgr = core.getCookieMgr();
    } else if (config) {
        var cookieCfg = config.cookieCfg;
        if (cookieCfg && cookieCfg[strConfigCookieMgr]) {
            cookieMgr = cookieCfg[strConfigCookieMgr];
        } else {
            cookieMgr = createCookieMgr(config);
        }
    }
    if (!cookieMgr) {
        // Get or initialize the default global (legacy) cookie manager if we couldn't find one
        cookieMgr = _gblCookieMgr(config, (core || {})[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ]);
    }
    return cookieMgr;
}
function createCookieMgr(rootConfig, logger) {
    var cookieMgrConfig;
    var _path;
    var _domain;
    var unloadHandler;
    // Explicitly checking against false, so that setting to undefined will === true
    var _enabled;
    var _getCookieFn;
    var _setCookieFn;
    var _delCookieFn;
    // Buffer for storing cookie operations when cookies are disabled
    // null = deferral disabled, array = deferral enabled with pending operations
    var _pendingCookies = [];
    // Helper function to format deletion cookie value
    function _formatDeletionValue(path) {
        var _a;
        var values = (_a = {}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PATH"]] = path ? path : "/", _a[strExpires] = "Thu, 01 Jan 1970 00:00:01 GMT", _a);
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isIE"])()) {
            // Set max age to expire now
            values["max-age"] = "0";
        }
        return _formatCookieValue(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"], values);
    }
    // Helper function to format a cookie value with all attributes
    function _formatSetCookieValue(value, maxAgeSec, domain, path) {
        var values = {};
        var theValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strTrim"])(value || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"]);
        var idx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strIndexOf"])(theValue, ";");
        if (idx !== -1) {
            theValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strTrim"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strLeft"])(value, idx));
            values = _extractParts((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstring"])(value, idx + 1));
        }
        // Only update domain if not already present (isUndefined) and the value is truthy (not null, undefined or empty string)
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(values, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_DOMAIN"], domain || _domain, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTruthy"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"]);
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(maxAgeSec)) {
            var _isIE = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isIE"])();
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"])(values[strExpires])) {
                var nowMs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utcNow"])();
                // Only add expires if not already present
                var expireMs = nowMs + maxAgeSec * 1000;
                // Sanity check, if zero or -ve then ignore
                if (expireMs > 0) {
                    var expiry = new Date();
                    expiry.setTime(expireMs);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(values, strExpires, _formatDate(expiry, !_isIE ? strToUTCString : strToGMTString) || _formatDate(expiry, _isIE ? strToGMTString : strToUTCString) || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTruthy"]);
                }
            }
            if (!_isIE) {
                // Only replace if not already present
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(values, "max-age", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"] + maxAgeSec, null, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"]);
            }
        }
        var location = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLocation"])();
        if (location && location.protocol === "https:") {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(values, "secure", null, null, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"]);
            // Only set same site if not also secure
            if (_allowUaSameSite === null) {
                _allowUaSameSite = !uaDisallowsSameSiteNone(((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNavigator"])() || {})[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_USER_AGENT"] /* @min:%2euserAgent */ ]);
            }
            if (_allowUaSameSite) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(values, "SameSite", "None", null, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"]);
            }
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setValue"])(values, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PATH"], path || _path, null, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"]);
        return _formatCookieValue(theValue, values);
    }
    // Helper function to remove any existing pending operations for a cookie name
    function _removePendingCookie(name) {
        if (_pendingCookies) {
            // Remove all existing entries for this cookie name (iterate backwards to handle multiple entries safely)
            for(var i = _pendingCookies[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] - 1; i >= 0; i--){
                if (_pendingCookies[i].n === name) {
                    _pendingCookies[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPLICE"] /* @min:%2esplice */ ](i, 1);
                }
            }
        }
    }
    // Helper function to flush pending cookies when cookies become enabled
    function _flushPendingCookies() {
        if (areCookiesSupported(logger) && _pendingCookies) {
            // Process all pending cookie operations in order
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(_pendingCookies, function(pendingData) {
                if (!_isBlockedCookie(cookieMgrConfig, pendingData.n)) {
                    if (pendingData.o === 0 /* ePendingOp.Set */ ) {
                        // Apply the cached cookie value directly
                        _setCookieFn(pendingData.n, pendingData.v);
                    } else if (pendingData.o === 1 /* ePendingOp.Purge */ ) {
                        // Apply the cached deletion
                        _delCookieFn(pendingData.n, pendingData.v);
                    }
                }
            });
            // Clear the cache after flushing
            _pendingCookies = [];
        }
    }
    // Make sure the root config is dynamic as it may be the global config
    rootConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDynamicConfig"])(rootConfig || _globalCookieConfig, null, logger).cfg;
    // Will get recalled if the referenced configuration is changed
    unloadHandler = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onConfigChange"])(rootConfig, function(details) {
        // Make sure the root config has all of the the defaults to the root config to ensure they are dynamic
        details.setDf(details.cfg, rootDefaultConfig);
        // Create and apply the defaults to the cookieCfg element
        cookieMgrConfig = details.ref(details.cfg, "cookieCfg"); // details.setDf(details.cfg.cookieCfg, defaultConfig);
        _path = cookieMgrConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PATH"] /* @min:%2epath */ ] || "/";
        _domain = cookieMgrConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_DOMAIN"] /* @min:%2edomain */ ];
        // Handle deferral state changes based on disableCookieDefer setting
        if (cookieMgrConfig.disableCookieDefer) {
            // When deferral is disabled, set to null to disable any deferral behavior
            // All pending operations are dropped
            _pendingCookies = null;
        } else if (_pendingCookies === null) {
            // When deferral is enabled and was previously disabled, initialize empty buffer
            _pendingCookies = [];
        }
        // Check if enabled state is changing
        var wasEnabled = _enabled;
        // Explicitly checking against false, so that setting to undefined will === true
        _enabled = _isCfgEnabled(rootConfig, cookieMgrConfig) !== false;
        _getCookieFn = cookieMgrConfig.getCookie || _getCookieValue;
        _setCookieFn = cookieMgrConfig.setCookie || _setCookieValue;
        _delCookieFn = cookieMgrConfig.delCookie || _setCookieValue;
        // If cookies were just enabled via config change and we have pending cookies, flush them
        if (!wasEnabled && _enabled && _pendingCookies) {
            _flushPendingCookies();
        }
    }, logger);
    var cookieMgr = {
        isEnabled: function() {
            var enabled = _isCfgEnabled(rootConfig, cookieMgrConfig) !== false && _enabled && areCookiesSupported(logger);
            // Using an indirect lookup for any global cookie manager to support tree shaking for SDK's
            // that don't use the "applicationinsights-core" version of the default cookie function
            var gblManager = _globalCookieConfig[strConfigCookieMgr];
            if (enabled && gblManager && cookieMgr !== gblManager) {
                // Make sure the GlobalCookie Manager instance (if not this instance) is also enabled.
                // As the global (deprecated) functions may have been called (for backward compatibility)
                enabled = _isMgrEnabled(gblManager);
            }
            return enabled;
        },
        setEnabled: function(value) {
            // Change the default config and allow the asynchronous dynamic config logic
            // to process all of the changes at once (like handling change to the enabled and
            // disabling caching at the same time)
            cookieMgrConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLED"] /* @min:%2eenabled */ ] = value;
            // If this value is defined someone else might be listening to it so also update it,
            // this also handles the edge case if the default above is not dynamic
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUndefined"])(rootConfig[strDisableCookiesUsage])) {
                rootConfig[strDisableCookiesUsage] = !value;
            }
        },
        set: function(name, value, maxAgeSec, domain, path) {
            var result = false;
            var isBlocked = _isBlockedCookie(cookieMgrConfig, name);
            if (!isBlocked) {
                var cookieValue = _formatSetCookieValue(value, maxAgeSec, domain, path);
                if (_isMgrEnabled(cookieMgr)) {
                    _setCookieFn(name, cookieValue);
                    result = true;
                } else if (_pendingCookies) {
                    // Defer the fully formatted cookie value if cookies are disabled and deferral is enabled
                    // Remove any previous operation for this cookie name (latest operation wins)
                    _removePendingCookie(name);
                    // Append new operation to the array
                    _pendingCookies[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ]({
                        n: name,
                        o: 0 /* ePendingOp.Set */ ,
                        v: cookieValue
                    });
                    result = true; // Return true to indicate the operation was "successful" (deferred)
                }
            }
            return result;
        },
        get: function(name) {
            var value = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"];
            var isIgnored = _isIgnoredCookie(cookieMgrConfig, name);
            if (!isIgnored) {
                if (_isMgrEnabled(cookieMgr)) {
                    value = _getCookieFn(name);
                } else if (_pendingCookies) {
                    // Search for the most recent operation for this cookie (search backwards through array)
                    for(var i = _pendingCookies[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] - 1; i >= 0; i--){
                        var pendingData = _pendingCookies[i];
                        if (pendingData.n === name) {
                            // Found the most recent operation for this cookie name
                            if (pendingData.o === 0 /* ePendingOp.Set */ ) {
                                // Return deferred value if it was a set operation
                                // Extract the value part from the formatted cookie string (before first semicolon)
                                var cookieValue = pendingData.v;
                                var idx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strIndexOf"])(cookieValue, ";");
                                value = idx !== -1 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strTrim"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strLeft"])(cookieValue, idx)) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strTrim"])(cookieValue);
                            }
                            break;
                        }
                    }
                }
            }
            return value;
        },
        del: function(name, path) {
            var result = false;
            if (_isMgrEnabled(cookieMgr)) {
                // Only remove the cookie if the manager and cookie support has not been disabled
                result = cookieMgr.purge(name, path);
            } else if (_pendingCookies) {
                // Defer the deletion operation when cookies are disabled and deferral is enabled
                // Remove any previous operation for this cookie name (latest operation wins)
                _removePendingCookie(name);
                // Append new deletion operation to the array
                _pendingCookies[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ]({
                    n: name,
                    o: 1 /* ePendingOp.Purge */ ,
                    v: _formatDeletionValue(path)
                });
                result = true;
            }
            return result;
        },
        purge: function(name, path) {
            var result = false;
            if (areCookiesSupported(logger)) {
                // Setting the expiration date in the past immediately removes the cookie
                _delCookieFn(name, _formatDeletionValue(path));
                result = true;
            }
            return result;
        },
        unload: function(isAsync) {
            unloadHandler && unloadHandler.rm();
            unloadHandler = null;
            // Clear any pending cookies on unload
            _pendingCookies = null;
        }
    };
    // Associated this cookie manager with the config
    cookieMgr[strConfigCookieMgr] = cookieMgr;
    return cookieMgr;
}
function areCookiesSupported(logger) {
    if (_supportsCookies === null) {
        _supportsCookies = false;
        !_doc && _getDoc();
        try {
            var doc = _doc.v || {};
            _supportsCookies = doc[strCookie] !== undefined;
        } catch (e) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 2 /* eLoggingSeverity.WARNING */ , 68 /* _eInternalMessageId.CannotAccessCookie */ , "Cannot access document.cookie - " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
            });
        }
    }
    return _supportsCookies;
}
function _extractParts(theValue) {
    var values = {};
    if (theValue && theValue[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]) {
        var parts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strTrim"])(theValue)[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPLIT"] /* @min:%2esplit */ ](";");
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(parts, function(thePart) {
            thePart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strTrim"])(thePart || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"]);
            if (thePart) {
                var idx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strIndexOf"])(thePart, "=");
                if (idx === -1) {
                    values[thePart] = null;
                } else {
                    values[(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strTrim"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strLeft"])(thePart, idx))] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strTrim"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strSubstring"])(thePart, idx + 1));
                }
            }
        });
    }
    return values;
}
function _formatDate(theDate, func) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(theDate[func])) {
        return theDate[func]();
    }
    return null;
}
function _formatCookieValue(value, values) {
    var cookieValue = value || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(values, function(name, theValue) {
        cookieValue += "; " + name + (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(theValue) ? "=" + theValue : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"]);
    });
    return cookieValue;
}
function _getCookieValue(name) {
    var cookieValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"];
    !_doc && _getDoc();
    if (_doc.v) {
        var theCookie = _doc.v[strCookie] || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"];
        if (_parsedCookieValue !== theCookie) {
            _cookieCache = _extractParts(theCookie);
            _parsedCookieValue = theCookie;
        }
        cookieValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strTrim"])(_cookieCache[name] || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"]);
    }
    return cookieValue;
}
function _setCookieValue(name, cookieValue) {
    !_doc && _getDoc();
    if (_doc.v) {
        _doc.v[strCookie] = name + "=" + cookieValue;
    }
}
function uaDisallowsSameSiteNone(userAgent) {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(userAgent)) {
        return false;
    }
    // Cover all iOS based browsers here. This includes:
    // - Safari on iOS 12 for iPhone, iPod Touch, iPad
    // - WkWebview on iOS 12 for iPhone, iPod Touch, iPad
    // - Chrome on iOS 12 for iPhone, iPod Touch, iPad
    // All of which are broken by SameSite=None, because they use the iOS networking stack
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strContains"])(userAgent, "CPU iPhone OS 12") || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strContains"])(userAgent, "iPad; CPU OS 12")) {
        return true;
    }
    // Cover Mac OS X based browsers that use the Mac OS networking stack. This includes:
    // - Safari on Mac OS X
    // This does not include:
    // - Internal browser on Mac OS X
    // - Chrome on Mac OS X
    // - Chromium on Mac OS X
    // Because they do not use the Mac OS networking stack.
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strContains"])(userAgent, "Macintosh; Intel Mac OS X 10_14") && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strContains"])(userAgent, "Version/") && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strContains"])(userAgent, "Safari")) {
        return true;
    }
    // Cover Mac OS X internal browsers that use the Mac OS networking stack. This includes:
    // - Internal browser on Mac OS X
    // This does not include:
    // - Safari on Mac OS X
    // - Chrome on Mac OS X
    // - Chromium on Mac OS X
    // Because they do not use the Mac OS networking stack.
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strContains"])(userAgent, "Macintosh; Intel Mac OS X 10_14") && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strEndsWith"])(userAgent, "AppleWebKit/605.1.15 (KHTML, like Gecko)")) {
        return true;
    }
    // Cover Chrome 50-69, because some versions are broken by SameSite=None, and none in this range require it.
    // Note: this covers some pre-Chromium Edge versions, but pre-Chromim Edge does not require SameSite=None, so this is fine.
    // Note: this regex applies to Windows, Mac OS X, and Linux, deliberately.
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strContains"])(userAgent, "Chrome/5") || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strContains"])(userAgent, "Chrome/6")) {
        return true;
    }
    // Unreal Engine runs Chromium 59, but does not advertise as Chrome until 4.23. Treat versions of Unreal
    // that don't specify their Chrome version as lacking support for SameSite=None.
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strContains"])(userAgent, "UnrealEngine") && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strContains"])(userAgent, "Chrome")) {
        return true;
    }
    // UCBrowser < 12.13.2 ignores Set-Cookie headers with SameSite=None
    // NB: this rule isn't complete - you need regex to make a complete rule.
    // See: https://www.chromium.org/updates/same-site/incompatible-clients
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strContains"])(userAgent, "UCBrowser/12") || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strContains"])(userAgent, "UCBrowser/11")) {
        return true;
    }
    return false;
} //# sourceMappingURL=CookieMgr.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK.Enums/InitActiveStatusEnum.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "ActiveStatus",
    ()=>ActiveStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2e$Enums$2f$EnumHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK.Enums/EnumHelperFuncs.js [app-client] (ecmascript)");
;
var ActiveStatus = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2e$Enums$2f$EnumHelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEnumStyle"])({
    NONE: 0 /* eActiveStatus.NONE */ ,
    PENDING: 3 /* eActiveStatus.PENDING */ ,
    INACTIVE: 1 /* eActiveStatus.INACTIVE */ ,
    ACTIVE: 2 /* eActiveStatus.ACTIVE */ 
}); //# sourceMappingURL=InitActiveStatusEnum.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/Constants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "ChannelControllerPriority",
    ()=>ChannelControllerPriority,
    "DisabledPropertyName",
    ()=>DisabledPropertyName
]);
var ChannelControllerPriority = 500;
var DisabledPropertyName = "Microsoft_ApplicationInsights_BypassAjaxInstrumentation"; // export const SampleRate = "sampleRate";
 // export const ProcessLegacy = "ProcessLegacy";
 // export const HttpMethod = "http.method";
 // export const DEFAULT_BREEZE_ENDPOINT = "https://dc.services.visualstudio.com";
 // export const DEFAULT_BREEZE_PATH = "/v2/track";
 // export const strNotSpecified = "not_specified";
 // export const strIkey = "iKey";
 //# sourceMappingURL=Constants.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/SenderPostManager.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "SenderPostManager",
    ()=>SenderPostManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-async@0.5.4/node_modules/@nevware21/ts-async/dist/es5/mod/ts-async.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/Constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EnvUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
var STR_EMPTY = "";
var STR_NO_RESPONSE_BODY = "NoResponseBody";
var _noResponseQs = "&" + STR_NO_RESPONSE_BODY + "=true";
var STR_POST_METHOD = "POST";
/**
 * This Internal component
 * Manager SendPost functions
 * SendPostManger
 * @internal for internal use only
 */ var SenderPostManager = function() {
    function SenderPostManager() {
        var _syncFetchPayload = 0; // Keep track of the outstanding sync fetch payload total (as sync fetch has limits)
        var _enableSendPromise;
        var _isInitialized;
        var _diagLog;
        var _isOneDs;
        var _onCompleteFuncs;
        var _disableCredentials;
        var _fetchCredentials;
        var _fallbackInst;
        var _disableXhr;
        var _disableBeacon;
        var _disableBeaconSync;
        var _disableFetchKeepAlive;
        var _addNoResponse;
        var _timeoutWrapper;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(SenderPostManager, this, function(_self, _base) {
            var _sendCredentials = true; // for 1ds
            _initDefaults();
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INITIALIZE"] /* @min:%2einitialize */ ] = function(config, diagLog) {
                _diagLog = diagLog;
                if (_isInitialized) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_diagLog, 1 /* eLoggingSeverity.CRITICAL */ , 28 /* _eInternalMessageId.SenderNotInitialized */ , "Sender is already initialized");
                }
                _self.SetConfig(config);
                _isInitialized = true;
            };
            _self["_getDbgPlgTargets"] = function() {
                return [
                    _isInitialized,
                    _isOneDs,
                    _disableCredentials,
                    _enableSendPromise
                ];
            };
            // This componet might get its config from sender, offline sender, 1ds post
            // so set this function to mock dynamic changes
            _self.SetConfig = function(config) {
                try {
                    _onCompleteFuncs = config.senderOnCompleteCallBack || {};
                    _disableCredentials = !!config.disableCredentials;
                    _fetchCredentials = config.fetchCredentials;
                    _isOneDs = !!config.isOneDs;
                    _enableSendPromise = !!config.enableSendPromise;
                    _disableXhr = !!config.disableXhr;
                    _disableBeacon = !!config.disableBeacon;
                    _disableBeaconSync = !!config.disableBeaconSync;
                    _timeoutWrapper = config.timeWrapper;
                    _addNoResponse = !!config.addNoResponse;
                    _disableFetchKeepAlive = !!config.disableFetchKeepAlive;
                    _fallbackInst = {
                        sendPOST: _xhrSender
                    };
                    if (!_isOneDs) {
                        _sendCredentials = false; // for appInsights, set it to false always
                    }
                    if (_disableCredentials) {
                        var location_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLocation"])();
                        if (location_1 && location_1.protocol && location_1.protocol[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TO_LOWER_CASE"] /* @min:%2etoLowerCase */ ]() === "file:") {
                            // Special case where a local html file fails with a CORS error on Chromium browsers
                            _sendCredentials = false;
                        }
                    }
                    return true;
                } catch (e) {
                // eslint-disable-next-line no-empty
                }
                return false;
            };
            _self.getSyncFetchPayload = function() {
                return _syncFetchPayload;
            };
            _self.getSenderInst = function(transports, sync) {
                if (transports && transports[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]) {
                    return _getSenderInterface(transports, sync);
                }
                return null;
            };
            _self.getFallbackInst = function() {
                return _fallbackInst;
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__DO_TEARDOWN"] /* @min:%2e_doTeardown */ ] = function(unloadCtx, unloadState) {
                _initDefaults();
            };
            _self.preparePayload = function(callback, zipPayload, payload, isSync) {
                if (!zipPayload || isSync || !payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ]) {
                    // If the request is synchronous, the body is null or undefined or Compression is not supported, we don't need to compress it
                    callback(payload);
                    return;
                }
                try {
                    var csStream = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInst"])("CompressionStream");
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(csStream)) {
                        callback(payload);
                        return;
                    }
                    // Create a readable stream from the uint8 data
                    var body = new ReadableStream({
                        start: function(controller) {
                            controller.enqueue((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isString"])(payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ]) ? new TextEncoder().encode(payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ]) : payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ]);
                            controller.close();
                        }
                    });
                    var compressedStream = body.pipeThrough(new csStream("gzip"));
                    var reader_1 = compressedStream.getReader();
                    var chunks_1 = [];
                    var totalLength_1 = 0;
                    var callbackCalled_1 = false;
                    // Process each chunk from the compressed stream reader
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doAwaitResponse"])(reader_1.read(), function processChunk(response) {
                        if (!callbackCalled_1 && !response.rejected) {
                            // Process the chunk and continue reading
                            var result = response[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_VALUE"] /* @min:%2evalue */ ];
                            if (!result.done) {
                                // Add current chunk and continue reading
                                chunks_1[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](result[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_VALUE"] /* @min:%2evalue */ ]);
                                totalLength_1 += result.value[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
                                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doAwaitResponse"])(reader_1.read(), processChunk);
                            }
                            // We are complete so combine all chunks
                            var combined = new Uint8Array(totalLength_1);
                            var offset = 0;
                            for(var _i = 0, chunks_2 = chunks_1; _i < chunks_2.length; _i++){
                                var chunk = chunks_2[_i];
                                combined.set(chunk, offset);
                                offset += chunk[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
                            }
                            // Update payload with compressed data
                            payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ] = combined;
                            payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HEADERS"] /* @min:%2eheaders */ ]["Content-Encoding"] = "gzip";
                            payload._chunkCount = chunks_1[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
                        }
                        if (!callbackCalled_1) {
                            // Send the processed payload to the callback, if not already called
                            // If the response was rejected, we will call the callback with the original payload
                            // As it only gets "replaced" if the compression was successful
                            callbackCalled_1 = true;
                            callback(payload);
                        }
                    // We don't need to return anything as this will cause the calling chain to be resolved and closed
                    });
                    // returning the reader to allow the caller to cancel the stream if needed
                    // This is not a requirement but allows for better control over the stream, like if we detect that we are unloading
                    // we could use reader.cancel() to stop the stream and avoid sending the request, but this may still be an asynchronous operation
                    // and may not be possible to cancel the stream in time
                    return reader_1;
                } catch (error) {
                    // CompressionStream is not available at all
                    callback(payload);
                    return;
                }
            };
            /**
             * success handler
             */ function _onSuccess(res, onComplete) {
                _doOnComplete(onComplete, 200, {}, res);
            }
            /**
             * error handler
             */ function _onError(message, onComplete) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_diagLog, 2 /* eLoggingSeverity.WARNING */ , 26 /* _eInternalMessageId.OnError */ , "Failed to send telemetry.", {
                    message: message
                });
                _doOnComplete(onComplete, 400, {});
            }
            function _onNoPayloadUrl(onComplete) {
                _onError("No endpoint url is provided for the batch", onComplete);
            }
            function _getSenderInterface(transports, syncSupport) {
                var transportType = 0 /* TransportType.NotSet */ ;
                var sendPostFunc = null;
                var lp = 0;
                while(sendPostFunc == null && lp < transports[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]){
                    transportType = transports[lp];
                    if (!_disableXhr && transportType === 1 /* TransportType.Xhr */ ) {
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useXDomainRequest"])()) {
                            // IE 8 and 9
                            sendPostFunc = _xdrSender;
                        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isXhrSupported"])()) {
                            sendPostFunc = _xhrSender;
                        }
                    } else if (transportType === 2 /* TransportType.Fetch */  && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFetchSupported"])(syncSupport) && (!syncSupport || !_disableFetchKeepAlive)) {
                        sendPostFunc = _doFetchSender;
                    } else if (transportType === 3 /* TransportType.Beacon */  && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isBeaconsSupported"])() && (syncSupport ? !_disableBeaconSync : !_disableBeacon)) {
                        sendPostFunc = _beaconSender;
                    }
                    lp++;
                }
                if (sendPostFunc) {
                    return {
                        _transport: transportType,
                        _isSync: syncSupport,
                        sendPOST: sendPostFunc
                    };
                }
                return null;
            }
            function _doOnComplete(oncomplete, status, headers, response) {
                try {
                    oncomplete && oncomplete(status, headers, response);
                } catch (e) {
                // eslint-disable-next-line no-empty
                }
            }
            function _doBeaconSend(payload, oncomplete) {
                var nav = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNavigator"])();
                var url = payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_URL_STRING"] /* @min:%2eurlString */ ];
                if (!url) {
                    _onNoPayloadUrl(oncomplete);
                    // return true here, because we don't want to retry it with fallback sender
                    return true;
                }
                url = payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_URL_STRING"] /* @min:%2eurlString */ ] + (_addNoResponse ? _noResponseQs : STR_EMPTY);
                var data = payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ];
                // Chrome only allows CORS-safelisted values for the sendBeacon data argument
                // see: https://bugs.chromium.org/p/chromium/issues/detail?id=720283
                // Chrome only allows CORS-safelisted values for the sendBeacon data argument
                // see: https://bugs.chromium.org/p/chromium/issues/detail?id=720283
                var plainTextBatch = _isOneDs ? data : new Blob([
                    data
                ], {
                    type: "text/plain;charset=UTF-8"
                });
                // The sendBeacon method returns true if the user agent is able to successfully queue the data for transfer. Otherwise it returns false.
                var queued = nav.sendBeacon(url, plainTextBatch);
                return queued;
            }
            /**
             * Send Beacon API request
             * @param payload - The data payload to be sent.
             * @param sync - not used
             * Note: Beacon API does not support custom headers and we are not able to get
             * appId from the backend for the correct correlation.
             */ function _beaconSender(payload, oncomplete, sync) {
                var data = payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ];
                try {
                    if (data) {
                        // The sendBeacon method returns true if the user agent is able to successfully queue the data for transfer. Otherwise it returns false.
                        if (!_doBeaconSend(payload, oncomplete)) {
                            var onRetry = _onCompleteFuncs && _onCompleteFuncs.beaconOnRetry;
                            if (onRetry && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(onRetry)) {
                                onRetry(payload, oncomplete, _doBeaconSend);
                            } else {
                                _fallbackInst && _fallbackInst.sendPOST(payload, oncomplete, true);
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_diagLog, 2 /* eLoggingSeverity.WARNING */ , 40 /* _eInternalMessageId.TransmissionFailed */ , ". " + "Failed to send telemetry with Beacon API, retried with normal sender.");
                            }
                        } else {
                            // if can send
                            _onSuccess(STR_EMPTY, oncomplete); // if success, onComplete is called with status code 200
                        }
                    }
                } catch (e) {
                    _isOneDs && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_warnToConsole"])(_diagLog, "Failed to send telemetry using sendBeacon API. Ex:" + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e));
                    _doOnComplete(oncomplete, _isOneDs ? 0 : 400, {}, STR_EMPTY);
                }
                return;
            }
            /**
             * Send XMLHttpRequest
             * @param payload - The data payload to be sent.
             * @param sync - Indicates if the request should be sent synchronously
             */ function _xhrSender(payload, oncomplete, sync) {
                //let  internalPayload = payload as IInternalPayloadData;
                var thePromise;
                var resolveFunc;
                var rejectFunc;
                var headers = payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HEADERS"] /* @min:%2eheaders */ ] || {};
                if (!sync && _enableSendPromise) {
                    thePromise = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPromise"])(function(resolve, reject) {
                        resolveFunc = resolve;
                        rejectFunc = reject;
                    });
                }
                if (_isOneDs && sync && payload.disableXhrSync) {
                    sync = false;
                }
                //const xhr = new XMLHttpRequest();
                var endPointUrl = payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_URL_STRING"] /* @min:%2eurlString */ ];
                if (!endPointUrl) {
                    _onNoPayloadUrl(oncomplete);
                    resolveFunc && resolveFunc(false);
                    return;
                }
                var xhr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["openXhr"])(STR_POST_METHOD, endPointUrl, _sendCredentials, true, sync, payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TIMEOUT"] /* @min:%2etimeout */ ]);
                if (!_isOneDs) {
                    // application/json should NOT add to 1ds post by default
                    xhr.setRequestHeader("Content-type", "application/json");
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objKeys"])(headers), function(headerName) {
                    xhr.setRequestHeader(headerName, headers[headerName]);
                });
                xhr.onreadystatechange = function() {
                    if (!_isOneDs) {
                        _doOnReadyFunc(xhr);
                        if (xhr.readyState === 4) {
                            resolveFunc && resolveFunc(true);
                        }
                    }
                };
                xhr.onload = function() {
                    if (_isOneDs) {
                        _doOnReadyFunc(xhr);
                    }
                };
                function _doOnReadyFunc(xhr) {
                    var onReadyFunc = _onCompleteFuncs && _onCompleteFuncs.xhrOnComplete;
                    var onReadyFuncExist = onReadyFunc && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(onReadyFunc);
                    if (onReadyFuncExist) {
                        onReadyFunc(xhr, oncomplete, payload);
                    } else {
                        var response = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getResponseText"])(xhr);
                        _doOnComplete(oncomplete, xhr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getAllResponseHeaders"])(xhr, _isOneDs), response);
                    }
                }
                xhr.onerror = function(event) {
                    _doOnComplete(oncomplete, _isOneDs ? xhr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ] : 400, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getAllResponseHeaders"])(xhr, _isOneDs), _isOneDs ? STR_EMPTY : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatErrorMessageXhr"])(xhr));
                    rejectFunc && rejectFunc(event);
                };
                xhr.ontimeout = function() {
                    _doOnComplete(oncomplete, _isOneDs ? xhr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ] : 500, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getAllResponseHeaders"])(xhr, _isOneDs), _isOneDs ? STR_EMPTY : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatErrorMessageXhr"])(xhr));
                    resolveFunc && resolveFunc(false);
                };
                xhr.send(payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ]);
                return thePromise;
            }
            /**
             * Send fetch API request
             * @param payload - The data payload to be sent.
             * @param sync - For fetch this identifies whether we are "unloading" (false) or a normal request
             */ function _doFetchSender(payload, oncomplete, sync) {
                var _a;
                var endPointUrl = payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_URL_STRING"] /* @min:%2eurlString */ ];
                var batch = payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ];
                var plainTextBatch = _isOneDs ? batch : new Blob([
                    batch
                ], {
                    type: "application/json"
                });
                var thePromise;
                var resolveFunc;
                var rejectFunc;
                var requestHeaders = new Headers();
                var batchLength = batch[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
                var ignoreResponse = false;
                var responseHandled = false;
                var headers = payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HEADERS"] /* @min:%2eheaders */ ] || {};
                //TODO: handle time out for 1ds
                var init = (_a = {
                    method: STR_POST_METHOD,
                    body: plainTextBatch
                }, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DisabledPropertyName"]] = true // Mark so we don't attempt to track this request
                , _a);
                // Only add headers if there are headers to add, due to issue with some polyfills
                if (payload.headers && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objKeys"])(payload.headers)[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objKeys"])(headers), function(headerName) {
                        requestHeaders.append(headerName, headers[headerName]);
                    });
                    init[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_HEADERS"] /* @min:%2eheaders */ ] = requestHeaders;
                }
                if (_fetchCredentials) {
                    init.credentials = _fetchCredentials;
                } else if (_sendCredentials && _isOneDs) {
                    // for 1ds, Don't send credentials when URL is file://
                    init.credentials = "include";
                }
                if (sync) {
                    init.keepalive = true;
                    _syncFetchPayload += batchLength;
                    if (_isOneDs) {
                        if (payload["_sendReason"] === 2 /* SendRequestReason.Unload */ ) {
                            // As a sync request (during unload), it is unlikely that we will get a chance to process the response so
                            // just like beacon send assume that the events have been accepted and processed
                            ignoreResponse = true;
                            if (_addNoResponse) {
                                endPointUrl += _noResponseQs;
                            }
                        }
                    } else {
                        // for appinsights, set to true for all sync request
                        ignoreResponse = true;
                    }
                }
                var request = new Request(endPointUrl, init);
                try {
                    // Also try and tag the request (just in case the value in init is not copied over)
                    request[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DisabledPropertyName"]] = true;
                } catch (e) {
                // If the environment has locked down the XMLHttpRequest (preventExtensions and/or freeze), this would
                // cause the request to fail and we no telemetry would be sent
                }
                if (!sync && _enableSendPromise) {
                    thePromise = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPromise"])(function(resolve, reject) {
                        resolveFunc = resolve;
                        rejectFunc = reject;
                    });
                }
                if (!endPointUrl) {
                    _onNoPayloadUrl(oncomplete);
                    resolveFunc && resolveFunc(false);
                    return;
                }
                function _handleError(res, statusCode) {
                    // In case there is an error in the request. Set the status to 0 for 1ds and 400 for appInsights
                    // so that the events can be retried later.
                    if (statusCode) {
                        _doOnComplete(oncomplete, _isOneDs ? 0 : statusCode, {}, _isOneDs ? STR_EMPTY : res);
                    } else {
                        _doOnComplete(oncomplete, _isOneDs ? 0 : 400, {}, _isOneDs ? STR_EMPTY : res);
                    }
                }
                function _onFetchComplete(response, payload, value) {
                    var status = response[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ];
                    var onCompleteFunc = _onCompleteFuncs.fetchOnComplete;
                    if (onCompleteFunc && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(onCompleteFunc)) {
                        onCompleteFunc(response, oncomplete, value || STR_EMPTY, payload);
                    } else {
                        _doOnComplete(oncomplete, status, {}, value || STR_EMPTY);
                    }
                }
                try {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doAwaitResponse"])(fetch(_isOneDs ? endPointUrl : request, _isOneDs ? init : null), function(result) {
                        if (sync) {
                            _syncFetchPayload -= batchLength;
                            batchLength = 0;
                        }
                        if (!responseHandled) {
                            responseHandled = true;
                            if (!result.rejected) {
                                var response_1 = result[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_VALUE"] /* @min:%2evalue */ ];
                                try {
                                    /**
                                     * The Promise returned from fetch() won’t reject on HTTP error status even if the response is an HTTP 404 or 500.
                                     * Instead, it will resolve normally (with ok status set to false), and it will only reject on network failure
                                     * or if anything prevented the request from completing.
                                     */ if (!_isOneDs && !response_1.ok) {
                                        // this is for appInsights only
                                        if (response_1[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ]) {
                                            _handleError(response_1.statusText, response_1[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ]);
                                        } else {
                                            _handleError(response_1.statusText, 499);
                                        }
                                        resolveFunc && resolveFunc(false);
                                    } else {
                                        if (_isOneDs && !response_1.body) {
                                            _onFetchComplete(response_1, null, STR_EMPTY);
                                            resolveFunc && resolveFunc(true);
                                        } else {
                                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doAwaitResponse"])(response_1.text(), function(resp) {
                                                _onFetchComplete(response_1, payload, resp[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_VALUE"] /* @min:%2evalue */ ]);
                                                resolveFunc && resolveFunc(true);
                                            });
                                        }
                                    }
                                } catch (e) {
                                    if (response_1 && response_1[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ]) {
                                        _handleError((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e), response_1[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STATUS"] /* @min:%2estatus */ ]);
                                    } else {
                                        _handleError((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e), 499);
                                    }
                                    rejectFunc && rejectFunc(e);
                                }
                            } else {
                                _handleError(result.reason && result.reason[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MESSAGE"] /* @min:%2emessage */ ], 499);
                                rejectFunc && rejectFunc(result.reason);
                            }
                        }
                    });
                } catch (e) {
                    if (!responseHandled) {
                        _handleError((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e), 499);
                        rejectFunc && rejectFunc(e);
                    }
                }
                if (ignoreResponse && !responseHandled) {
                    // Assume success during unload processing as we most likely won't get the response
                    responseHandled = true;
                    _doOnComplete(oncomplete, 200, {});
                    resolveFunc && resolveFunc(true);
                }
                if (_isOneDs && !responseHandled && payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TIMEOUT"] /* @min:%2etimeout */ ] > 0) {
                    // Simulate timeout
                    _timeoutWrapper && _timeoutWrapper.set(function() {
                        if (!responseHandled) {
                            // Assume a 500 response (which will cause a retry)
                            responseHandled = true;
                            _doOnComplete(oncomplete, 500, {});
                            resolveFunc && resolveFunc(true);
                        }
                    }, payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TIMEOUT"] /* @min:%2etimeout */ ]);
                }
                return thePromise;
            }
            /**
             * Send XDomainRequest
             * @param payload - The data payload to be sent.
             * @param sync - Indicates if the request should be sent synchronously
             *
             * Note: XDomainRequest does not support sync requests. This 'isAsync' parameter is added
             * to maintain consistency with the xhrSender's contract
             * Note: XDomainRequest does not support custom headers and we are not able to get
             * appId from the backend for the correct correlation.
             */ function _xdrSender(payload, oncomplete, sync) {
                // It doesn't support custom headers, so no action is taken with current requestHeaders
                var _window = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWindow"])();
                var xdr = new XDomainRequest();
                var data = payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ];
                xdr.onload = function() {
                    var response = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getResponseText"])(xdr);
                    var onloadFunc = _onCompleteFuncs && _onCompleteFuncs.xdrOnComplete;
                    if (onloadFunc && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(onloadFunc)) {
                        onloadFunc(xdr, oncomplete, payload);
                    } else {
                        _doOnComplete(oncomplete, 200, {}, response);
                    }
                };
                xdr.onerror = function() {
                    _doOnComplete(oncomplete, 400, {}, _isOneDs ? STR_EMPTY : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatErrorMessageXdr"])(xdr));
                };
                xdr.ontimeout = function() {
                    _doOnComplete(oncomplete, 500, {});
                };
                xdr.onprogress = function() {};
                // XDomainRequest requires the same protocol as the hosting page.
                // If the protocol doesn't match, we can't send the telemetry :(.
                var hostingProtocol = _window && _window.location && _window.location.protocol || "";
                var endpoint = payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_URL_STRING"] /* @min:%2eurlString */ ];
                if (!endpoint) {
                    _onNoPayloadUrl(oncomplete);
                    return;
                }
                if (!_isOneDs && endpoint.lastIndexOf(hostingProtocol, 0) !== 0) {
                    var msg = "Cannot send XDomain request. The endpoint URL protocol doesn't match the hosting page protocol.";
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_diagLog, 2 /* eLoggingSeverity.WARNING */ , 40 /* _eInternalMessageId.TransmissionFailed */ , ". " + msg);
                    _onError(msg, oncomplete);
                    return;
                }
                var endpointUrl = _isOneDs ? endpoint : endpoint[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REPLACE"] /* @min:%2ereplace */ ](/^(https?:)/, "");
                xdr.open(STR_POST_METHOD, endpointUrl);
                if (payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TIMEOUT"] /* @min:%2etimeout */ ]) {
                    xdr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TIMEOUT"] /* @min:%2etimeout */ ] = payload[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TIMEOUT"] /* @min:%2etimeout */ ];
                }
                xdr.send(data);
                if (_isOneDs && sync) {
                    _timeoutWrapper && _timeoutWrapper.set(function() {
                        xdr.send(data);
                    }, 0);
                } else {
                    xdr.send(data);
                }
            }
            function _initDefaults() {
                _syncFetchPayload = 0;
                _isInitialized = false;
                _enableSendPromise = false;
                _diagLog = null;
                _isOneDs = null;
                _onCompleteFuncs = null;
                _disableCredentials = null;
                _fetchCredentials = null;
                _fallbackInst = null;
                _disableXhr = false;
                _disableBeacon = false;
                _disableBeaconSync = false;
                _disableFetchKeepAlive = false;
                _addNoResponse = false;
                _timeoutWrapper = null;
            }
        });
    }
    // Removed Stub for SenderPostManager.prototype.initialize.
    // Removed Stub for SenderPostManager.prototype.getSyncFetchPayload.
    // Removed Stub for SenderPostManager.prototype.SetConfig.
    // Removed Stub for SenderPostManager.prototype.getSenderInst.
    // Removed Stub for SenderPostManager.prototype.getFallbackInst.
    // Removed Stub for SenderPostManager.prototype._doTeardown.
    // Removed Stub for SenderPostManager.prototype.preparePayload.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    SenderPostManager.__ieDyn = 1;
    return SenderPostManager;
}();
;
 //# sourceMappingURL=SenderPostManager.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/ResponseHelpers.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "parseResponse",
    ()=>parseResponse
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/EnvUtils.js [app-client] (ecmascript)");
;
;
;
;
function parseResponse(response, diagLog) {
    try {
        if (response && response !== "") {
            var result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$EnvUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getJSON"])().parse(response);
            if (result && result[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ITEMS_RECEIVED"] /* @min:%2eitemsReceived */ ] && result[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ITEMS_RECEIVED"] /* @min:%2eitemsReceived */ ] >= result.itemsAccepted && result.itemsReceived - result.itemsAccepted === result.errors[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]) {
                return result;
            }
        }
    } catch (e) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(diagLog, 1 /* eLoggingSeverity.CRITICAL */ , 43 /* _eInternalMessageId.InvalidBackendResponse */ , "Cannot parse the response. " + (e[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ] || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)), {
            response: response
        });
    }
    return null;
} //# sourceMappingURL=ResponseHelpers.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/AsyncUtils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "doUnloadAll",
    ()=>doUnloadAll,
    "runTargetUnload",
    ()=>runTargetUnload
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-async@0.5.4/node_modules/@nevware21/ts-async/dist/es5/mod/ts-async.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
;
;
;
function runTargetUnload(target, isAsync) {
    if (target && target[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_UNLOAD"] /* @min:%2eunload */ ]) {
        return target[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_UNLOAD"] /* @min:%2eunload */ ](isAsync);
    }
}
function doUnloadAll(targets, isAsync, done) {
    var result;
    if (!done) {
        result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPromise"])(function(resolved) {
            done = resolved;
        });
    }
    if (targets && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLength"])(targets) > 0) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doAwaitResponse"])(runTargetUnload(targets[0], isAsync), function() {
            doUnloadAll((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrSlice"])(targets, 1), isAsync, done);
        });
    } else {
        done();
    }
    return result;
} //# sourceMappingURL=AsyncUtils.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/NotificationManager.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "NotificationManager",
    ()=>NotificationManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-async@0.5.4/node_modules/@nevware21/ts-async/dist/es5/mod/ts-async.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicConfig.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
;
;
;
;
;
;
var defaultValues = {
    perfEvtsSendAll: false
};
function _runScheduledListeners(asyncNotifications) {
    asyncNotifications.h = null;
    var callbacks = asyncNotifications.cb;
    asyncNotifications.cb = [];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(callbacks, function(cb) {
        // Run the listener in a try-catch to ensure that a single listener failing doesn't prevent the others from running
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safe"])(cb.fn, [
            cb.arg
        ]);
    });
}
// This function is used to combine the logic of running the listeners and handling the async notifications so that they don't
// create multiple timers if there are multiple async listeners.
function _runListeners(listeners, name, asyncNotifications, callback) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(listeners, function(listener) {
        if (listener && listener[name]) {
            if (asyncNotifications) {
                // Schedule the callback to be called after the current call stack has cleared.
                asyncNotifications.cb[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ]({
                    fn: callback,
                    arg: listener
                });
                asyncNotifications.h = asyncNotifications.h || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["scheduleTimeout"])(_runScheduledListeners, 0, asyncNotifications);
            } else {
                // Run the listener in a try-catch to ensure that a single listener failing doesn't prevent the others from running
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safe"])(callback, [
                    listener
                ]);
            }
        }
    });
}
/**
 * Class to manage sending notifications to all the listeners.
 */ var NotificationManager = function() {
    function NotificationManager(config) {
        this.listeners = [];
        var perfEvtsSendAll;
        var unloadHandler;
        var _listeners = [];
        var _asyncNotifications = {
            h: null,
            cb: []
        };
        var cfgHandler = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDynamicConfig"])(config, defaultValues);
        unloadHandler = cfgHandler[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_WATCH"] /* @min:%2ewatch */ ](function(details) {
            perfEvtsSendAll = !!details.cfg.perfEvtsSendAll;
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(NotificationManager, this, function(_self) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "listeners", {
                g: function() {
                    return _listeners;
                }
            });
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ADD_NOTIFICATION_LIS1"] /* @min:%2eaddNotificationListener */ ] = function(listener) {
                _listeners[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](listener);
            };
            /**
             * Removes all instances of the listener.
             * @param listener - AWTNotificationListener to remove.
             */ _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REMOVE_NOTIFICATION_0"] /* @min:%2eremoveNotificationListener */ ] = function(listener) {
                var index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrIndexOf"])(_listeners, listener);
                while(index > -1){
                    _listeners[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPLICE"] /* @min:%2esplice */ ](index, 1);
                    index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrIndexOf"])(_listeners, listener);
                }
            };
            /**
             * Notification for events sent.
             * @param events - The array of events that have been sent.
             */ _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EVENTS_SENT"] /* @min:%2eeventsSent */ ] = function(events) {
                _runListeners(_listeners, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EVENTS_SENT"], _asyncNotifications, function(listener) {
                    listener[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EVENTS_SENT"] /* @min:%2eeventsSent */ ](events);
                });
            };
            /**
             * Notification for events being discarded.
             * @param events - The array of events that have been discarded by the SDK.
             * @param reason - The reason for which the SDK discarded the events. The EventsDiscardedReason
             * constant should be used to check the different values.
             */ _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EVENTS_DISCARDED"] /* @min:%2eeventsDiscarded */ ] = function(events, reason) {
                _runListeners(_listeners, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EVENTS_DISCARDED"], _asyncNotifications, function(listener) {
                    listener[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EVENTS_DISCARDED"] /* @min:%2eeventsDiscarded */ ](events, reason);
                });
            };
            /**
             * [Optional] A function called when the events have been requested to be sent to the sever.
             * @param sendReason - The reason why the event batch is being sent.
             * @param isAsync - A flag which identifies whether the requests are being sent in an async or sync manner.
             */ _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EVENTS_SEND_REQUEST"] /* @min:%2eeventsSendRequest */ ] = function(sendReason, isAsync) {
                _runListeners(_listeners, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EVENTS_SEND_REQUEST"], isAsync ? _asyncNotifications : null, function(listener) {
                    listener[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EVENTS_SEND_REQUEST"] /* @min:%2eeventsSendRequest */ ](sendReason, isAsync);
                });
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PERF_EVENT"] /* @min:%2eperfEvent */ ] = function(perfEvent) {
                if (perfEvent) {
                    // Send all events or only parent events
                    if (perfEvtsSendAll || !perfEvent[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_CHILD_EVT"] /* @min:%2eisChildEvt */ ]()) {
                        _runListeners(_listeners, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PERF_EVENT"], null, function(listener) {
                            if (perfEvent.isAsync) {
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["scheduleTimeout"])(function() {
                                    return listener[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PERF_EVENT"] /* @min:%2eperfEvent */ ](perfEvent);
                                }, 0);
                            } else {
                                listener[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PERF_EVENT"] /* @min:%2eperfEvent */ ](perfEvent);
                            }
                        });
                    }
                }
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_OFFLINE_STORE"] /* @min:%2eofflineEventsStored */ ] = function(events) {
                if (events && events[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]) {
                    _runListeners(_listeners, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_OFFLINE_STORE"], _asyncNotifications, function(listener) {
                        listener[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_OFFLINE_STORE"] /* @min:%2eofflineEventsStored */ ](events);
                    });
                }
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_OFFLINE_SENT"] /* @min:%2eofflineBatchSent */ ] = function(batch) {
                if (batch && batch[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DATA"] /* @min:%2edata */ ]) {
                    _runListeners(_listeners, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_OFFLINE_SENT"], _asyncNotifications, function(listener) {
                        listener[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_OFFLINE_SENT"] /* @min:%2eofflineBatchSent */ ](batch);
                    });
                }
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_OFFLINE_DROP"] /* @min:%2eofflineBatchDrop */ ] = function(cnt, reason) {
                if (cnt > 0) {
                    var rn_1 = reason || 0; // default is unknown
                    _runListeners(_listeners, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_OFFLINE_DROP"], _asyncNotifications, function(listener) {
                        listener[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_OFFLINE_DROP"] /* @min:%2eofflineBatchDrop */ ](cnt, rn_1);
                    });
                }
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_UNLOAD"] /* @min:%2eunload */ ] = function(isAsync) {
                var _finishUnload = function() {
                    unloadHandler && unloadHandler.rm();
                    unloadHandler = null;
                    _listeners = [];
                    // Clear any async listener
                    _asyncNotifications.h && _asyncNotifications.h[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CANCEL"] /* @min:%2ecancel */ ]();
                    _asyncNotifications.h = null;
                    _asyncNotifications.cb = [];
                };
                var waiting;
                _runListeners(_listeners, "unload", null, function(listener) {
                    var asyncUnload = listener[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_UNLOAD"] /* @min:%2eunload */ ](isAsync);
                    if (asyncUnload) {
                        if (!waiting) {
                            waiting = [];
                        }
                        waiting[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](asyncUnload);
                    }
                });
                if (waiting) {
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPromise"])(function(resolve) {
                        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doAwaitResponse"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createAllPromise"])(waiting), function() {
                            _finishUnload();
                            resolve();
                        });
                    });
                } else {
                    _finishUnload();
                }
            };
        });
    }
    // Removed Stub for NotificationManager.prototype.addNotificationListener.
    // Removed Stub for NotificationManager.prototype.removeNotificationListener.
    // Removed Stub for NotificationManager.prototype.eventsSent.
    // Removed Stub for NotificationManager.prototype.eventsDiscarded.
    // Removed Stub for NotificationManager.prototype.eventsSendRequest.
    // Removed Stub for NotificationManager.prototype.perfEvent.
    // Removed Stub for NotificationManager.prototype.unload.
    // Removed Stub for NotificationManager.prototype.offlineEventsStored.
    // Removed Stub for NotificationManager.prototype.offlineBatchSent.
    // Removed Stub for NotificationManager.prototype.offlineBatchDrop.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    NotificationManager.__ieDyn = 1;
    return NotificationManager;
}();
;
 //# sourceMappingURL=NotificationManager.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/TelemetryInitializerPlugin.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ // 
// 
__turbopack_context__.s([
    "TelemetryInitializerPlugin",
    ()=>TelemetryInitializerPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-shims@3.0.1/node_modules/@microsoft/applicationinsights-shims/dist-es5/TsLibShims.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$BaseTelemetryPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/BaseTelemetryPlugin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
function _addInitializer(_initializers, id, telemetryInitializer) {
    var theInitializer = {
        id: id,
        fn: telemetryInitializer
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrAppend"])(_initializers, theInitializer);
    var handler = {
        remove: function() {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(_initializers, function(initializer, idx) {
                if (initializer.id === theInitializer.id) {
                    _initializers[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPLICE"] /* @min:%2esplice */ ](idx, 1);
                    return -1;
                }
            });
        }
    };
    return handler;
}
function _runInitializers(_initializers, item, logger) {
    var doNotSendItem = false;
    var telemetryInitializersCount = _initializers[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
    for(var i = 0; i < telemetryInitializersCount; ++i){
        var telemetryInitializer = _initializers[i];
        if (telemetryInitializer) {
            try {
                if (telemetryInitializer.fn[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_APPLY"] /* @min:%2eapply */ ](null, [
                    item
                ]) === false) {
                    doNotSendItem = true;
                    break;
                }
            } catch (e) {
                // log error but dont stop executing rest of the telemetry initializers
                // doNotSendItem = true;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 2 /* eLoggingSeverity.WARNING */ , 64 /* _eInternalMessageId.TelemetryInitializerFailed */ , "Telemetry initializer failed: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExceptionName"])(e), {
                    exception: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dumpObj"])(e)
                }, true);
            }
        }
    }
    return !doNotSendItem;
}
var TelemetryInitializerPlugin = function(_super) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__extendsFn"])(TelemetryInitializerPlugin, _super);
    function TelemetryInitializerPlugin() {
        var _this = _super.call(this) || this;
        _this.identifier = "TelemetryInitializerPlugin";
        _this.priority = 199;
        // NOTE!: DON'T set default values here, instead set them in the _initDefaults() function as it is also called during teardown()
        var _id;
        var _initializers;
        _initDefaults();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(TelemetryInitializerPlugin, _this, function(_self, _base) {
            _self.addTelemetryInitializer = function(telemetryInitializer) {
                return _addInitializer(_initializers, _id++, telemetryInitializer);
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PROCESS_TELEMETRY"] /* @min:%2eprocessTelemetry */ ] = function(item, itemCtx) {
                if (_runInitializers(_initializers, item, itemCtx ? itemCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ]() : _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_DIAG_LOG"] /* @min:%2ediagLog */ ]())) {
                    _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROCESS_NEXT"] /* @min:%2eprocessNext */ ](item, itemCtx);
                }
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN__DO_TEARDOWN"] /* @min:%2e_doTeardown */ ] = function() {
                _initDefaults();
            };
        });
        function _initDefaults() {
            _id = 0;
            _initializers = [];
        }
        return _this;
    }
    // Removed Stub for TelemetryInitializerPlugin.prototype.addTelemetryInitializer.
    // Removed Stub for TelemetryInitializerPlugin.prototype.processTelemetry.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    TelemetryInitializerPlugin.__ieDyn = 1;
    return TelemetryInitializerPlugin;
}(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$BaseTelemetryPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseTelemetryPlugin"]);
;
 //# sourceMappingURL=TelemetryInitializerPlugin.js.map
}),
"[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/AppInsightsCore.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Application Insights JavaScript SDK - Core, 3.3.10
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */ __turbopack_context__.s([
    "AppInsightsCore",
    ()=>AppInsightsCore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-shims@3.0.1/node_modules/@microsoft/applicationinsights-shims/dist-es5/TsLibShims.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+dynamicproto-js@2.0.3/node_modules/@microsoft/dynamicproto-js/dist-es5/DynamicProto.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-async@0.5.4/node_modules/@nevware21/ts-async/dist/es5/mod/ts-async.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@nevware21+ts-utils@0.12.5/node_modules/@nevware21/ts-utils/dist/es5/mod/ts-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/Config/DynamicConfig.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2e$Enums$2f$InitActiveStatusEnum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK.Enums/InitActiveStatusEnum.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/__DynamicConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$AsyncUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/AsyncUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/Constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CookieMgr$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/CookieMgr.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DataCacheHelper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DbgExtensionUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DbgExtensionUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/DiagnosticLogger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/HelperFuncs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/InternalConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$NotificationManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/NotificationManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$PerfManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/PerfManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/ProcessTelemetryContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$TelemetryHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/TelemetryHelpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$TelemetryInitializerPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/TelemetryInitializerPlugin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$UnloadHandlerContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/UnloadHandlerContainer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$UnloadHookContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@microsoft+applicationinsights-core-js@3.3.10_tslib@2.8.1/node_modules/@microsoft/applicationinsights-core-js/dist-es5/JavaScriptSDK/UnloadHookContainer.js [app-client] (ecmascript)");
var _a;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// import { IStatsBeat, IStatsBeatConfig, IStatsBeatState } from "../JavaScriptSDK.Interfaces/IStatsBeat";
// import { IStatsMgr } from "../JavaScriptSDK.Interfaces/IStatsMgr";
var strValidationError = "Plugins must provide initialize method";
var strNotificationManager = "_notificationManager";
var strSdkUnloadingError = "SDK is still unloading...";
var strSdkNotInitialized = "SDK is not initialized";
var maxInitQueueSize = 100;
var maxInitTimeout = 50000;
// const strPluginUnloadFailed = "Failed to unload plugin";
// /**
//  * Default StatsBeatMgr configuration
//  * @internal
//  */
// const defaultStatsCfg: IConfigDefaults<IStatsBeatConfig> = objDeepFreeze({
//     shrtInt: UNDEFINED_VALUE,
//     endCfg: cfgDfMerge([])
// });
// /**
//  * Default SDK initialization configuration
//  * @internal
//  */
// const defaultSdkConfig: IConfigDefaults<IInternalSdkConfiguration> = objDeepFreeze({
//     stats: { rdOnly: true, mrg: true, v: defaultStatsCfg }
// });
/**
 * The default settings for the config.
 * WE MUST include all defaults here to ensure that the config is created with all of the properties
 * defined as dynamic.
 */ var defaultConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDeepFreeze"])((_a = {
    cookieCfg: {}
}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EXTENSIONS"]] = {
    rdOnly: true,
    ref: true,
    v: []
}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CHANNELS"]] = {
    rdOnly: true,
    ref: true,
    v: []
}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EXTENSION_CONFIG"]] = {
    ref: true,
    v: {}
}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CREATE_PERF_MGR"]] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNDEFINED_VALUE"], _a.loggingLevelConsole = 0 /* eLoggingSeverity.DISABLED */ , _a.diagnosticLogInterval = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNDEFINED_VALUE"], _a));
/**
 * Helper to create the default performance manager
 * @param core - The AppInsightsCore instance
 * @param notificationMgr - The notification manager
 */ function _createPerfManager(core, notificationMgr) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$PerfManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PerfManager"](notificationMgr);
}
function _validateExtensions(logger, channelPriority, allExtensions) {
    // Concat all available extensions
    var coreExtensions = [];
    var channels = [];
    // Check if any two extensions have the same priority, then warn to console
    // And extract the local extensions from the
    var extPriorities = {};
    // Extension validation
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(allExtensions, function(ext) {
        // Check for ext.initialize
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(ext) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(ext[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INITIALIZE"] /* @min:%2einitialize */ ])) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throwError"])(strValidationError);
        }
        var extPriority = ext[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_PRIORITY"] /* @min:%2epriority */ ];
        var identifier = ext[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IDENTIFIER"] /* @min:%2eidentifier */ ];
        if (ext && extPriority) {
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(extPriorities[extPriority])) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_warnToConsole"])(logger, "Two extensions have same priority #" + extPriority + " - " + extPriorities[extPriority] + ", " + identifier);
            } else {
                // set a value
                extPriorities[extPriority] = identifier;
            }
        }
        // Split extensions to core and channels
        if (!extPriority || extPriority < channelPriority) {
            // Add to core extension that will be managed by AppInsightsCore
            coreExtensions[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](ext);
        } else {
            channels[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](ext);
        }
    });
    return {
        core: coreExtensions,
        channels: channels
    };
}
function _isPluginPresent(thePlugin, plugins) {
    var exists = false;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(plugins, function(plugin) {
        if (plugin === thePlugin) {
            exists = true;
            return -1;
        }
    });
    return exists;
}
function _deepMergeConfig(details, target, newValues, merge) {
    // Lets assign the new values to the existing config
    if (newValues) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(newValues, function(key, value) {
            if (merge) {
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPlainObject"])(value) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPlainObject"])(target[key])) {
                    // The target is an object and it has a value
                    _deepMergeConfig(details, target[key], value, merge);
                }
            }
            if (merge && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPlainObject"])(value) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPlainObject"])(target[key])) {
                // The target is an object and it has a value
                _deepMergeConfig(details, target[key], value, merge);
            } else {
                // Just Assign (replace) and/or make the property dynamic
                details.set(target, key, value);
            }
        });
    }
}
function _findWatcher(listeners, newWatcher) {
    var theListener = null;
    var idx = -1;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(listeners, function(listener, lp) {
        if (listener.w === newWatcher) {
            theListener = listener;
            idx = lp;
            return -1;
        }
    });
    return {
        i: idx,
        l: theListener
    };
}
function _addDelayedCfgListener(listeners, newWatcher) {
    var theListener = _findWatcher(listeners, newWatcher).l;
    if (!theListener) {
        theListener = {
            w: newWatcher,
            rm: function() {
                var fnd = _findWatcher(listeners, newWatcher);
                if (fnd.i !== -1) {
                    listeners[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_SPLICE"] /* @min:%2esplice */ ](fnd.i, 1);
                }
            }
        };
        listeners[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](theListener);
    }
    return theListener;
}
function _registerDelayedCfgListener(config, listeners, logger) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(listeners, function(listener) {
        var unloadHdl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onConfigChange"])(config, listener.w, logger);
        delete listener.w; // Clear the listener reference so it will get garbage collected.
        // replace the remove function
        listener.rm = function() {
            unloadHdl.rm();
        };
    });
}
// Moved this outside of the closure to reduce the retained memory footprint
function _initDebugListener(configHandler, unloadContainer, notificationManager, debugListener) {
    // Will get recalled if any referenced config values are changed
    unloadContainer.add(configHandler[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_WATCH"] /* @min:%2ewatch */ ](function(details) {
        var disableDbgExt = details.cfg.disableDbgExt;
        if (disableDbgExt === true && debugListener) {
            // Remove any previously loaded debug listener
            notificationManager[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REMOVE_NOTIFICATION_0"] /* @min:%2eremoveNotificationListener */ ](debugListener);
            debugListener = null;
        }
        if (notificationManager && !debugListener && disableDbgExt !== true) {
            debugListener = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DbgExtensionUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDebugListener"])(details.cfg);
            notificationManager[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ADD_NOTIFICATION_LIS1"] /* @min:%2eaddNotificationListener */ ](debugListener);
        }
    }));
    return debugListener;
}
// Moved this outside of the closure to reduce the retained memory footprint
function _createUnloadHook(unloadHook) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])({
        rm: function() {
            unloadHook.rm();
        }
    }, "toJSON", {
        v: function() {
            return "aicore::onCfgChange<" + JSON.stringify(unloadHook) + ">";
        }
    });
}
/**
 * @group Classes
 * @group Entrypoint
 */ var AppInsightsCore = function() {
    function AppInsightsCore() {
        // NOTE!: DON'T set default values here, instead set them in the _initDefaults() function as it is also called during teardown()
        var _configHandler;
        var _isInitialized;
        var _logger;
        var _eventQueue;
        var _notificationManager;
        // let _statsBeat: IStatsBeat | null;
        // let _statsMgr: IStatsMgr | null;
        var _perfManager;
        var _cfgPerfManager;
        var _cookieManager;
        var _pluginChain;
        var _configExtensions;
        var _channelConfig;
        var _channels;
        var _isUnloading;
        var _telemetryInitializerPlugin;
        var _internalLogsEventName;
        var _evtNamespace;
        var _unloadHandlers;
        var _hookContainer;
        var _debugListener;
        var _traceCtx;
        var _instrumentationKey;
        var _cfgListeners;
        var _extensions;
        var _pluginVersionStringArr;
        var _pluginVersionString;
        var _activeStatus; // to indicate if ikey or endpoint url promised is resolved or not
        var _endpoint;
        var _initInMemoMaxSize; // max event count limit during wait for init promises to be resolved
        var _isStatusSet; // track if active status is set in case of init timeout and init promises setting the status twice
        var _initTimer;
        /**
         * Internal log poller
         */ var _internalLogPoller;
        var _internalLogPollerListening;
        var _forceStopInternalLogPoller;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$dynamicproto$2d$js$40$2$2e$0$2e$3$2f$node_modules$2f40$microsoft$2f$dynamicproto$2d$js$2f$dist$2d$es5$2f$DynamicProto$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(AppInsightsCore, this, function(_self) {
            // Set the default values (also called during teardown)
            _initDefaults();
            // Special internal method to allow the unit tests and DebugPlugin to hook embedded objects
            _self["_getDbgPlgTargets"] = function() {
                return [
                    _extensions,
                    _eventQueue
                ];
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_INITIALIZED"] /* @min:%2eisInitialized */ ] = function() {
                return _isInitialized;
            };
            // since version 3.3.0
            _self.activeStatus = function() {
                return _activeStatus;
            };
            // since version 3.3.0
            // internal
            _self._setPendingStatus = function() {
                _activeStatus = 3 /* eActiveStatus.PENDING */ ;
            };
            // Creating the self.initialize = ()
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_INITIALIZE"] /* @min:%2einitialize */ ] = function(config, extensions, logger, notificationManager) {
                if (_isUnloading) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throwError"])(strSdkUnloadingError);
                }
                // Make sure core is only initialized once
                if (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_INITIALIZED"] /* @min:%2eisInitialized */ ]()) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throwError"])("Core cannot be initialized more than once");
                }
                _configHandler = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDynamicConfig"])(config, defaultConfig, logger || _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ], false);
                // Re-assigning the local config property so we don't have any references to the passed value and it can be garbage collected
                config = _configHandler.cfg;
                // This will be "re-run" if the referenced config properties are changed
                _addUnloadHook(_configHandler[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_WATCH"] /* @min:%2ewatch */ ](function(details) {
                    var rootCfg = details.cfg;
                    _initInMemoMaxSize = rootCfg.initInMemoMaxSize || maxInitQueueSize;
                    _handleIKeyEndpointPromises(rootCfg);
                    // Mark the extensionConfig and all first level keys as referenced
                    // This is so that calls to getExtCfg() will always return the same object
                    // Even when a user may "re-assign" the plugin properties (or it's unloaded/reloaded)
                    var extCfg = details.ref(details.cfg, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EXTENSION_CONFIG"]);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(extCfg, function(key) {
                        details.ref(extCfg, key);
                    });
                }));
                _notificationManager = notificationManager;
                // Initialize the debug listener outside of the closure to reduce the retained memory footprint
                _debugListener = _initDebugListener(_configHandler, _hookContainer, _notificationManager && _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_NOTIFY_MGR"] /* @min:%2egetNotifyMgr */ ](), _debugListener);
                _initPerfManager();
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ] = logger;
                var cfgExtensions = config[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EXTENSIONS"] /* @min:%2eextensions */ ];
                // Extension validation
                _configExtensions = [];
                _configExtensions[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ].apply(_configExtensions, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArrayFn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$shims$40$3$2e$0$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$shims$2f$dist$2d$es5$2f$TsLibShims$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArrayFn"])([], extensions, false), cfgExtensions, false));
                _channelConfig = config[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CHANNELS"] /* @min:%2echannels */ ];
                _initPluginChain(null);
                if (!_channels || _channels[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] === 0) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throwError"])("No " + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CHANNELS"] + " available");
                }
                if (_channelConfig && _channelConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 1) {
                    var teeController = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_PLUGIN"] /* @min:%2egetPlugin */ ]("TeeChannelController");
                    if (!teeController || !teeController.plugin) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_logger, 1 /* eLoggingSeverity.CRITICAL */ , 28 /* _eInternalMessageId.SenderNotInitialized */ , "TeeChannel required");
                    }
                }
                _registerDelayedCfgListener(config, _cfgListeners, _logger);
                _cfgListeners = null;
                _isInitialized = true;
                if (_activeStatus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2e$Enums$2f$InitActiveStatusEnum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActiveStatus"].ACTIVE) {
                    _releaseQueues();
                }
            };
            _self.getChannels = function() {
                var controls = [];
                if (_channels) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(_channels, function(channel) {
                        controls[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](channel);
                    });
                }
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objFreeze"])(controls);
            };
            _self.track = function(telemetryItem) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$PerfManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doPerf"])(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_GET_PERF_MGR"] /* @min:%2egetPerfMgr */ ](), function() {
                    return "AppInsightsCore:track";
                }, function() {
                    if (telemetryItem === null) {
                        _notifyInvalidEvent(telemetryItem);
                        // throw error
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throwError"])("Invalid telemetry item");
                    }
                    // do basic validation before sending it through the pipeline
                    if (!telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ] && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(telemetryItem[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_NAME"] /* @min:%2ename */ ])) {
                        _notifyInvalidEvent(telemetryItem);
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throwError"])("telemetry name required");
                    }
                    // setup default iKey if not passed in
                    telemetryItem.iKey = telemetryItem.iKey || _instrumentationKey;
                    // add default timestamp if not passed in
                    telemetryItem.time = telemetryItem.time || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toISOString"])(new Date());
                    // Common Schema 4.0
                    telemetryItem.ver = telemetryItem.ver || "4.0";
                    if (!_isUnloading && _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_INITIALIZED"] /* @min:%2eisInitialized */ ]() && _activeStatus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2e$Enums$2f$InitActiveStatusEnum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActiveStatus"].ACTIVE) {
                        // Process the telemetry plugin chain
                        _createTelCtx()[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROCESS_NEXT"] /* @min:%2eprocessNext */ ](telemetryItem);
                    } else if (_activeStatus !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2e$Enums$2f$InitActiveStatusEnum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActiveStatus"].INACTIVE) {
                        // Queue events until all extensions are initialized
                        if (_eventQueue[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] <= _initInMemoMaxSize) {
                            // set limit, if full, stop adding new events
                            _eventQueue[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](telemetryItem);
                        }
                    }
                }, function() {
                    return {
                        item: telemetryItem
                    };
                }, !telemetryItem.sync);
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_PROCESS_TEL_CONT2"] /* @min:%2egetProcessTelContext */ ] = _createTelCtx;
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_NOTIFY_MGR"] /* @min:%2egetNotifyMgr */ ] = function() {
                if (!_notificationManager) {
                    _notificationManager = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$NotificationManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NotificationManager"](_configHandler.cfg);
                    // For backward compatibility only
                    _self[strNotificationManager] = _notificationManager;
                }
                return _notificationManager;
            };
            /**
             * Adds a notification listener. The SDK calls methods on the listener when an appropriate notification is raised.
             * The added plugins must raise notifications. If the plugins do not implement the notifications, then no methods will be
             * called.
             * @param listener - An INotificationListener object.
             */ _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ADD_NOTIFICATION_LIS1"] /* @min:%2eaddNotificationListener */ ] = function(listener) {
                _self.getNotifyMgr()[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ADD_NOTIFICATION_LIS1"] /* @min:%2eaddNotificationListener */ ](listener);
            };
            /**
             * Removes all instances of the listener.
             * @param listener - INotificationListener to remove.
             */ _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REMOVE_NOTIFICATION_0"] /* @min:%2eremoveNotificationListener */ ] = function(listener) {
                if (_notificationManager) {
                    _notificationManager[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_REMOVE_NOTIFICATION_0"] /* @min:%2eremoveNotificationListener */ ](listener);
                }
            };
            _self.getCookieMgr = function() {
                if (!_cookieManager) {
                    _cookieManager = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$CookieMgr$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCookieMgr"])(_configHandler.cfg, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ]);
                }
                return _cookieManager;
            };
            _self.setCookieMgr = function(cookieMgr) {
                if (_cookieManager !== cookieMgr) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$AsyncUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["runTargetUnload"])(_cookieManager, false);
                    _cookieManager = cookieMgr;
                }
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_GET_PERF_MGR"] /* @min:%2egetPerfMgr */ ] = function() {
                return _perfManager || _cfgPerfManager || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$PerfManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGblPerfMgr"])();
            };
            _self.setPerfMgr = function(perfMgr) {
                _perfManager = perfMgr;
            };
            // _self.getStatsBeat = (statsBeatState: IStatsBeatState) => {
            //     // create a new statsbeat if not initialize yet or the endpoint is different
            //     // otherwise, return the existing one, or null
            //     if (statsBeatState) {
            //         if (_statsMgr && _statsMgr.enabled) {
            //             if (_statsBeat && _statsBeat.endpoint !== statsBeatState.endpoint) {
            //                 // Different endpoint, so unload the existing and create a new one
            //                 _statsBeat.enabled = false;
            //                 _statsBeat = null;
            //             }
            //             if (!_statsBeat) {
            //                 // Create a new statsbeat instance
            //                 _statsBeat = _statsMgr.newInst(statsBeatState);
            //             }
            //         } else if (_statsBeat) {
            //             // Disable and remove any previously created statsbeat instance
            //             _statsBeat.enabled = false;
            //             _statsBeat = null;
            //         }
            //         // Return the current statsbeat instance or null if not created
            //         return _statsBeat;
            //     }
            //     // Return null as no statsbeat state was provided
            //     return null;
            // };
            // _self.setStatsMgr = (statsMgr: IStatsMgr) => {
            //     if (_statsMgr && _statsMgr !== statsMgr) {
            //         // Disable any previously created statsbeat instance
            //         if (_statsBeat) {
            //             _statsBeat.enabled = false;
            //             _statsBeat = null;
            //         }
            //     }
            //     _statsMgr = statsMgr;
            // };
            _self.eventCnt = function() {
                return _eventQueue[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ];
            };
            _self.releaseQueue = function() {
                if (_isInitialized && _eventQueue[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                    var eventQueue = _eventQueue;
                    _eventQueue = [];
                    if (_activeStatus === 2 /* eActiveStatus.ACTIVE */ ) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(eventQueue, function(event) {
                            event.iKey = event.iKey || _instrumentationKey;
                            _createTelCtx()[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROCESS_NEXT"] /* @min:%2eprocessNext */ ](event);
                        });
                    } else {
                        // new one for msg ikey
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_logger, 2 /* eLoggingSeverity.WARNING */ , 20 /* _eInternalMessageId.FailedToSendQueuedTelemetry */ , "core init status is not active");
                    }
                }
            };
            _self.pollInternalLogs = function(eventName) {
                _internalLogsEventName = eventName || null;
                _forceStopInternalLogPoller = false;
                _internalLogPoller && _internalLogPoller[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CANCEL"] /* @min:%2ecancel */ ]();
                return _startLogPoller(true);
            };
            function _handleIKeyEndpointPromises(theConfig) {
                // app Insights core only handle ikey and endpointurl, aisku will handle cs
                // But we want to reference these config values so that if any future changes are made
                // this will trigger the re-run of the watch function
                // and the ikey and endpointUrl will be set to the new values
                var ikey = theConfig.instrumentationKey;
                var endpointUrl = theConfig.endpointUrl; // do not need to validate endpoint url, if it is null, default one will be set by sender
                // Check if we are waiting for previous promises to be resolved, won't apply new changes
                if (_activeStatus !== 3 /* eActiveStatus.PENDING */ ) {
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(ikey)) {
                        _instrumentationKey = null;
                        // if new ikey is null, set status to be inactive, all new events will be saved in memory or dropped
                        _activeStatus = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2e$Enums$2f$InitActiveStatusEnum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActiveStatus"].INACTIVE;
                        var msg = "Please provide instrumentation key";
                        if (!_isInitialized) {
                            // only throw error during initialization
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throwError"])(msg);
                        } else {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_logger, 1 /* eLoggingSeverity.CRITICAL */ , 100 /* _eInternalMessageId.InvalidInstrumentationKey */ , msg);
                            _releaseQueues();
                        }
                        return;
                    }
                    var promises = [];
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPromiseLike"])(ikey)) {
                        promises[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](ikey);
                        _instrumentationKey = null; // reset current local ikey variable (otherwise it will always be the previous ikeys if timeout is called before promise cb)
                    } else {
                        // string
                        _instrumentationKey = ikey;
                    }
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPromiseLike"])(endpointUrl)) {
                        promises[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](endpointUrl);
                        _endpoint = null; // reset current local endpoint variable (otherwise it will always be the previous urls if timeout is called before promise cb)
                    } else {
                        // string or null
                        _endpoint = endpointUrl;
                    }
                    // at least have one promise
                    if (promises[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]) {
                        _waitForInitPromises(theConfig, promises);
                    } else {
                        // means no promises
                        _setStatus();
                    }
                }
            }
            function _waitForInitPromises(theConfig, promises) {
                // reset to false for new dynamic changes
                _isStatusSet = false;
                _activeStatus = 3 /* eActiveStatus.PENDING */ ;
                var initTimeout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNotNullOrUndefined"])(theConfig.initTimeOut) ? theConfig.initTimeOut : maxInitTimeout; // theConfig.initTimeOut could be 0
                var allPromises = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSyncAllSettledPromise"])(promises);
                if (_initTimer) {
                    // Stop any previous timer
                    _initTimer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CANCEL"] /* @min:%2ecancel */ ]();
                }
                _initTimer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["scheduleTimeout"])(function() {
                    // set _isStatusSet to true
                    // set active status
                    // release queues
                    _initTimer = null;
                    if (!_isStatusSet) {
                        _setStatus();
                    }
                }, initTimeout);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doAwaitResponse"])(allPromises, function(response) {
                    try {
                        if (_isStatusSet) {
                            // promises take too long to resolve, ignore them
                            // active status should be set by timeout already
                            return;
                        }
                        if (!response.rejected) {
                            var values = response[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_VALUE"] /* @min:%2evalue */ ];
                            if (values && values[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]) {
                                // ikey
                                var ikeyRes = values[0];
                                _instrumentationKey = ikeyRes && ikeyRes[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_VALUE"] /* @min:%2evalue */ ];
                                // endpoint
                                if (values[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 1) {
                                    var endpointRes = values[1];
                                    _endpoint = endpointRes && endpointRes[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_VALUE"] /* @min:%2evalue */ ];
                                }
                            }
                            if (_instrumentationKey) {
                                // if ikey is null, no need to trigger extra dynamic changes for extensions
                                theConfig.instrumentationKey = _instrumentationKey; // set config.instrumentationKey for extensions to consume
                                theConfig.endpointUrl = _endpoint; // set config.endpointUrl for extensions to consume
                            }
                        }
                        // set _isStatusSet to true
                        // set active status
                        // release queues
                        _setStatus();
                    } catch (e) {
                        if (!_isStatusSet) {
                            _setStatus();
                        }
                    }
                });
            }
            function _setStatus() {
                _isStatusSet = true;
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNullOrUndefined"])(_instrumentationKey)) {
                    _activeStatus = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2e$Enums$2f$InitActiveStatusEnum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActiveStatus"].INACTIVE;
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(_logger, 1 /* eLoggingSeverity.CRITICAL */ , 112 /* _eInternalMessageId.InitPromiseException */ , "ikey can't be resolved from promises");
                } else {
                    _activeStatus = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2e$Enums$2f$InitActiveStatusEnum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActiveStatus"].ACTIVE;
                }
                _releaseQueues();
            }
            function _releaseQueues() {
                if (_isInitialized) {
                    _self.releaseQueue();
                    _self.pollInternalLogs();
                }
            }
            function _startLogPoller(alwaysStart) {
                if ((!_internalLogPoller || !_internalLogPoller[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLED"] /* @min:%2eenabled */ ]) && !_forceStopInternalLogPoller) {
                    var shouldStart = alwaysStart || _logger && _logger.queue[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0;
                    if (shouldStart) {
                        if (!_internalLogPollerListening) {
                            _internalLogPollerListening = true;
                            // listen for any configuration changes so that changes to the
                            // interval will cause the timer to be re-initialized
                            _addUnloadHook(_configHandler[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_WATCH"] /* @min:%2ewatch */ ](function(details) {
                                var interval = details.cfg.diagnosticLogInterval;
                                if (!interval || !(interval > 0)) {
                                    interval = 10000;
                                }
                                var isRunning = false;
                                if (_internalLogPoller) {
                                    // It was already created so remember it's running and cancel
                                    isRunning = _internalLogPoller[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLED"] /* @min:%2eenabled */ ];
                                    _internalLogPoller[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CANCEL"] /* @min:%2ecancel */ ]();
                                }
                                // Create / reconfigure
                                _internalLogPoller = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTimeout"])(_flushInternalLogs, interval);
                                _internalLogPoller.unref();
                                // Restart if previously running
                                _internalLogPoller[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLED"] /* @min:%2eenabled */ ] = isRunning;
                            }));
                        }
                        _internalLogPoller[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ENABLED"] /* @min:%2eenabled */ ] = true;
                    }
                }
                return _internalLogPoller;
            }
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STOP_POLLING_INTERNA3"] /* @min:%2estopPollingInternalLogs */ ] = function() {
                _forceStopInternalLogPoller = true;
                _internalLogPoller && _internalLogPoller[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CANCEL"] /* @min:%2ecancel */ ]();
                _flushInternalLogs();
            };
            // Add addTelemetryInitializer
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["proxyFunctions"])(_self, function() {
                return _telemetryInitializerPlugin;
            }, [
                "addTelemetryInitializer"
            ]);
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_UNLOAD"] /* @min:%2eunload */ ] = function(isAsync, unloadComplete, cbTimeout) {
                if (isAsync === void 0) {
                    isAsync = true;
                }
                if (!_isInitialized) {
                    // The SDK is not initialized
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throwError"])(strSdkNotInitialized);
                }
                // Check if the SDK still unloading so throw
                if (_isUnloading) {
                    // The SDK is already unloading
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throwError"])(strSdkUnloadingError);
                }
                var unloadState = {
                    reason: 50 /* TelemetryUnloadReason.SdkUnload */ ,
                    isAsync: isAsync,
                    flushComplete: false
                };
                var result;
                if (isAsync && !unloadComplete) {
                    result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$async$40$0$2e$5$2e$4$2f$node_modules$2f40$nevware21$2f$ts$2d$async$2f$dist$2f$es5$2f$mod$2f$ts$2d$async$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPromise"])(function(resolve) {
                        // Set the callback to the promise resolve callback
                        unloadComplete = resolve;
                    });
                }
                var processUnloadCtx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProcessTelemetryUnloadContext"])(_getPluginChain(), _self);
                processUnloadCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ON_COMPLETE"] /* @min:%2eonComplete */ ](function() {
                    // if (_statsBeat) {
                    //     // Disable any statsbeat instance
                    //     _statsBeat.enabled = false;
                    //     _statsBeat = null;
                    // }
                    _hookContainer.run(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ]);
                    // Run any "unload" functions for the _cookieManager, _notificationManager and _logger
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$AsyncUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doUnloadAll"])([
                        _cookieManager,
                        _notificationManager,
                        _logger
                    ], isAsync, function() {
                        _initDefaults();
                        unloadComplete && unloadComplete(unloadState);
                    });
                }, _self);
                function _doUnload(flushComplete) {
                    unloadState.flushComplete = flushComplete;
                    _isUnloading = true;
                    // Run all of the unload handlers first (before unloading the plugins)
                    _unloadHandlers.run(processUnloadCtx, unloadState);
                    // Stop polling the internal logs
                    _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_STOP_POLLING_INTERNA3"] /* @min:%2estopPollingInternalLogs */ ]();
                    // Start unloading the components, from this point onwards the SDK should be considered to be in an unstable state
                    processUnloadCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROCESS_NEXT"] /* @min:%2eprocessNext */ ](unloadState);
                }
                _flushInternalLogs();
                if (!_flushChannels(isAsync, _doUnload, 6 /* SendRequestReason.SdkUnload */ , cbTimeout)) //TURBOPACK unreachable
                ;
                return result;
            };
            _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_PLUGIN"] /* @min:%2egetPlugin */ ] = _getPlugin;
            _self.addPlugin = function(plugin, replaceExisting, isAsync, addCb) {
                if (!plugin) {
                    addCb && addCb(false);
                    _logOrThrowError(strValidationError);
                    return;
                }
                var existingPlugin = _getPlugin(plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IDENTIFIER"] /* @min:%2eidentifier */ ]);
                if (existingPlugin && !replaceExisting) {
                    addCb && addCb(false);
                    _logOrThrowError("Plugin [" + plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IDENTIFIER"] /* @min:%2eidentifier */ ] + "] is already loaded!");
                    return;
                }
                var updateState = {
                    reason: 16 /* TelemetryUpdateReason.PluginAdded */ 
                };
                function _addPlugin(removed) {
                    _configExtensions[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](plugin);
                    updateState.added = [
                        plugin
                    ];
                    // Re-Initialize the plugin chain
                    _initPluginChain(updateState);
                    addCb && addCb(true);
                }
                if (existingPlugin) {
                    var removedPlugins_1 = [
                        existingPlugin.plugin
                    ];
                    var unloadState = {
                        reason: 2 /* TelemetryUnloadReason.PluginReplace */ ,
                        isAsync: !!isAsync
                    };
                    _removePlugins(removedPlugins_1, unloadState, function(removed) {
                        if (!removed) {
                            // Previous plugin was successfully removed or was not installed
                            addCb && addCb(false);
                        } else {
                            updateState.removed = removedPlugins_1;
                            updateState.reason |= 32 /* TelemetryUpdateReason.PluginRemoved */ ;
                            _addPlugin(true);
                        }
                    });
                } else {
                    _addPlugin(false);
                }
            };
            _self.updateCfg = function(newConfig, mergeExisting) {
                if (mergeExisting === void 0) {
                    mergeExisting = true;
                }
                var updateState;
                if (_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IS_INITIALIZED"] /* @min:%2eisInitialized */ ]()) {
                    updateState = {
                        reason: 1 /* TelemetryUpdateReason.ConfigurationChanged */ ,
                        cfg: _configHandler.cfg,
                        oldCfg: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deepExtend"])({}, _configHandler.cfg),
                        newConfig: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deepExtend"])({}, newConfig),
                        merge: mergeExisting
                    };
                    newConfig = updateState.newConfig;
                    var cfg = _configHandler.cfg;
                    // replace the immutable (if initialized) values
                    // We don't currently allow updating the extensions and channels via the update config
                    // So overwriting any user provided values to reuse the existing values
                    newConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EXTENSIONS"] /* @min:%2eextensions */ ] = cfg[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EXTENSIONS"] /* @min:%2eextensions */ ];
                    newConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CHANNELS"] /* @min:%2echannels */ ] = cfg[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CHANNELS"] /* @min:%2echannels */ ];
                }
                // Explicitly blocking any previous config watchers so that they don't get called because
                // of this bulk update (Probably not necessary)
                _configHandler._block(function(details) {
                    // Lets assign the new values to the existing config either overwriting or re-assigning
                    var theConfig = details.cfg;
                    _deepMergeConfig(details, theConfig, newConfig, mergeExisting);
                    if (!mergeExisting) {
                        // Remove (unassign) the values "missing" from the newConfig and also not in the default config
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objForEachKey"])(theConfig, function(key) {
                            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objHasOwn"])(newConfig, key)) {
                                // Set the value to undefined
                                details.set(theConfig, key, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNDEFINED_VALUE"]);
                            }
                        });
                    }
                    // Apply defaults to the new config
                    details.setDf(theConfig, defaultConfig);
                }, true);
                // Now execute all of the listeners (synchronously) so they update their values immediately
                _configHandler.notify();
                if (updateState) {
                    _doUpdate(updateState);
                }
            };
            _self.evtNamespace = function() {
                return _evtNamespace;
            };
            _self.flush = _flushChannels;
            _self.getTraceCtx = function(createNew) {
                if (!_traceCtx) {
                    _traceCtx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$TelemetryHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDistributedTraceContext"])();
                }
                return _traceCtx;
            };
            _self.setTraceCtx = function(traceCtx) {
                _traceCtx = traceCtx || null;
            };
            _self.addUnloadHook = _addUnloadHook;
            // Create the addUnloadCb
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["proxyFunctionAs"])(_self, "addUnloadCb", function() {
                return _unloadHandlers;
            }, "add");
            _self.onCfgChange = function(handler) {
                var unloadHook;
                if (!_isInitialized) {
                    unloadHook = _addDelayedCfgListener(_cfgListeners, handler);
                } else {
                    unloadHook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onConfigChange"])(_configHandler.cfg, handler, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ]);
                }
                return _createUnloadHook(unloadHook);
            };
            _self.getWParam = function() {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasDocument"])() || !!_configHandler.cfg.enableWParam ? 0 : -1;
            };
            function _setPluginVersions() {
                var thePlugins = {};
                _pluginVersionStringArr = [];
                var _addPluginVersions = function(plugins) {
                    if (plugins) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(plugins, function(plugin) {
                            if (plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IDENTIFIER"] /* @min:%2eidentifier */ ] && plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_VERSION"] /* @min:%2eversion */ ] && !thePlugins[plugin.identifier]) {
                                var ver = plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IDENTIFIER"] /* @min:%2eidentifier */ ] + "=" + plugin[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_VERSION"] /* @min:%2eversion */ ];
                                _pluginVersionStringArr[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](ver);
                                thePlugins[plugin.identifier] = plugin;
                            }
                        });
                    }
                };
                _addPluginVersions(_channels);
                if (_channelConfig) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(_channelConfig, function(channels) {
                        _addPluginVersions(channels);
                    });
                }
                _addPluginVersions(_configExtensions);
            }
            function _initDefaults() {
                _isInitialized = false;
                // Use a default logger so initialization errors are not dropped on the floor with full logging
                _configHandler = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$Config$2f$DynamicConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDynamicConfig"])({}, defaultConfig, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ]);
                // Set the logging level to critical so that any critical initialization failures are displayed on the console
                _configHandler.cfg[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGING_LEVEL_CONSOL4"] /* @min:%2eloggingLevelConsole */ ] = 1 /* eLoggingSeverity.CRITICAL */ ;
                // Define _self.config
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "config", {
                    g: function() {
                        return _configHandler.cfg;
                    },
                    s: function(newValue) {
                        _self.updateCfg(newValue, false);
                    }
                });
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "pluginVersionStringArr", {
                    g: function() {
                        if (!_pluginVersionStringArr) {
                            _setPluginVersions();
                        }
                        return _pluginVersionStringArr;
                    }
                });
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "pluginVersionString", {
                    g: function() {
                        if (!_pluginVersionString) {
                            if (!_pluginVersionStringArr) {
                                _setPluginVersions();
                            }
                            _pluginVersionString = _pluginVersionStringArr.join(";");
                        }
                        return _pluginVersionString || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EMPTY"];
                    }
                });
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objDefine"])(_self, "logger", {
                    g: function() {
                        if (!_logger) {
                            _logger = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DiagnosticLogger"](_configHandler.cfg);
                            _configHandler[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ] = _logger;
                        }
                        return _logger;
                    },
                    s: function(newLogger) {
                        _configHandler[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ] = newLogger;
                        if (_logger !== newLogger) {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$AsyncUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["runTargetUnload"])(_logger, false);
                            _logger = newLogger;
                        }
                    }
                });
                _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ] = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DiagnosticLogger"](_configHandler.cfg);
                _extensions = [];
                var cfgExtensions = _self.config[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EXTENSIONS"] /* @min:%2eextensions */ ] || [];
                cfgExtensions.splice(0, cfgExtensions[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrAppend"])(cfgExtensions, _extensions);
                _telemetryInitializerPlugin = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$TelemetryInitializerPlugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TelemetryInitializerPlugin"]();
                _eventQueue = [];
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$AsyncUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["runTargetUnload"])(_notificationManager, false);
                _notificationManager = null;
                _perfManager = null;
                // _statsBeat = null;
                _cfgPerfManager = null;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$AsyncUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["runTargetUnload"])(_cookieManager, false);
                _cookieManager = null;
                _pluginChain = null;
                _configExtensions = [];
                _channelConfig = null;
                _channels = null;
                _isUnloading = false;
                _internalLogsEventName = null;
                _evtNamespace = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DataCacheHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUniqueNamespace"])("AIBaseCore", true);
                _unloadHandlers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$UnloadHandlerContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUnloadHandlerContainer"])();
                _traceCtx = null;
                _instrumentationKey = null;
                _hookContainer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$UnloadHookContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUnloadHookContainer"])();
                _cfgListeners = [];
                _pluginVersionString = null;
                _pluginVersionStringArr = null;
                _forceStopInternalLogPoller = false;
                _internalLogPoller = null;
                _internalLogPollerListening = false;
                _activeStatus = 0 /* eActiveStatus.NONE */ ; // default is None
                _endpoint = null;
                _initInMemoMaxSize = null;
                _isStatusSet = false;
                _initTimer = null;
            // if (_statsBeat) {
            //     // Unload and disable any statsbeat instance
            //     _statsBeat.enabled = false;
            // }
            // _statsBeat = null;
            }
            function _createTelCtx() {
                var theCtx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProcessTelemetryContext"])(_getPluginChain(), _configHandler.cfg, _self);
                theCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ON_COMPLETE"] /* @min:%2eonComplete */ ](_startLogPoller);
                return theCtx;
            }
            // Initialize or Re-initialize the plugins
            function _initPluginChain(updateState) {
                // Extension validation
                var theExtensions = _validateExtensions(_self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChannelControllerPriority"], _configExtensions);
                _pluginChain = null;
                _pluginVersionString = null;
                _pluginVersionStringArr = null;
                // Get the primary channel queue and include as part of the normal extensions
                _channels = (_channelConfig || [])[0] || [];
                // Add any channels provided in the extensions and sort them
                _channels = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$TelemetryHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortPlugins"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrAppend"])(_channels, theExtensions[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CHANNELS"] /* @min:%2echannels */ ]));
                // Create an array of all extensions, including the _channels
                var allExtensions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrAppend"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$TelemetryHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortPlugins"])(theExtensions[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CORE"] /* @min:%2ecore */ ]), _channels);
                // Required to allow plugins to call core.getPlugin() during their own initialization
                _extensions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["objFreeze"])(allExtensions);
                // This has a side effect of adding the extensions passed during initialization
                // into the config.extensions, so you can see all of the extensions loaded.
                // This will also get updated by the addPlugin() and remove plugin code.
                var cfgExtensions = _self.config[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EXTENSIONS"] /* @min:%2eextensions */ ] || [];
                cfgExtensions.splice(0, cfgExtensions[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ]);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrAppend"])(cfgExtensions, _extensions);
                var rootCtx = _createTelCtx();
                // Initializing the channels first
                if (_channels && _channels[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$TelemetryHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initializePlugins"])(rootCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CREATE_NEW"] /* @min:%2ecreateNew */ ](_channels), allExtensions);
                }
                // Now initialize the normal extensions (explicitly not including the _channels as this can cause duplicate initialization)
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$TelemetryHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initializePlugins"])(rootCtx, allExtensions);
                if (updateState) {
                    _doUpdate(updateState);
                }
            }
            function _getPlugin(pluginIdentifier) {
                var theExt = null;
                var thePlugin = null;
                var channelHosts = [];
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(_extensions, function(ext) {
                    if (ext[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_IDENTIFIER"] /* @min:%2eidentifier */ ] === pluginIdentifier && ext !== _telemetryInitializerPlugin) {
                        thePlugin = ext;
                        return -1;
                    }
                    if (ext.getChannel) {
                        channelHosts[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](ext);
                    }
                });
                if (!thePlugin && channelHosts[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(channelHosts, function(host) {
                        thePlugin = host.getChannel(pluginIdentifier);
                        if (!thePlugin) {
                            return -1;
                        }
                    });
                }
                if (thePlugin) {
                    theExt = {
                        plugin: thePlugin,
                        setEnabled: function(enabled) {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$TelemetryHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getPluginState"])(thePlugin)[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_DISABLED"]] = !enabled;
                        },
                        isEnabled: function() {
                            var pluginState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$TelemetryHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getPluginState"])(thePlugin);
                            return !pluginState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_TEARDOWN"] /* @min:%2eteardown */ ] && !pluginState[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_DISABLED"]];
                        },
                        remove: function(isAsync, removeCb) {
                            if (isAsync === void 0) {
                                isAsync = true;
                            }
                            var pluginsToRemove = [
                                thePlugin
                            ];
                            var unloadState = {
                                reason: 1 /* TelemetryUnloadReason.PluginUnload */ ,
                                isAsync: isAsync
                            };
                            _removePlugins(pluginsToRemove, unloadState, function(removed) {
                                if (removed) {
                                    // Re-Initialize the plugin chain
                                    _initPluginChain({
                                        reason: 32 /* TelemetryUpdateReason.PluginRemoved */ ,
                                        removed: pluginsToRemove
                                    });
                                }
                                removeCb && removeCb(removed);
                            });
                        }
                    };
                }
                return theExt;
            }
            function _getPluginChain() {
                if (!_pluginChain) {
                    // copy the collection of extensions
                    var extensions = (_extensions || []).slice();
                    // During add / remove this may get called again, so don't read if already present
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrIndexOf"])(extensions, _telemetryInitializerPlugin) === -1) {
                        extensions[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](_telemetryInitializerPlugin);
                    }
                    _pluginChain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTelemetryProxyChain"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$TelemetryHelpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortPlugins"])(extensions), _configHandler.cfg, _self);
                }
                return _pluginChain;
            }
            function _removePlugins(thePlugins, unloadState, removeComplete) {
                if (thePlugins && thePlugins[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                    var unloadChain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTelemetryProxyChain"])(thePlugins, _configHandler.cfg, _self);
                    var unloadCtx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProcessTelemetryUnloadContext"])(unloadChain, _self);
                    unloadCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ON_COMPLETE"] /* @min:%2eonComplete */ ](function() {
                        var removed = false;
                        // Remove the listed config extensions
                        var newConfigExtensions = [];
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(_configExtensions, function(plugin, idx) {
                            if (!_isPluginPresent(plugin, thePlugins)) {
                                newConfigExtensions[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](plugin);
                            } else {
                                removed = true;
                            }
                        });
                        _configExtensions = newConfigExtensions;
                        _pluginVersionString = null;
                        _pluginVersionStringArr = null;
                        // Re-Create the channel config
                        var newChannelConfig = [];
                        if (_channelConfig) {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(_channelConfig, function(queue, idx) {
                                var newQueue = [];
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(queue, function(channel) {
                                    if (!_isPluginPresent(channel, thePlugins)) {
                                        newQueue[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](channel);
                                    } else {
                                        removed = true;
                                    }
                                });
                                newChannelConfig[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PUSH"] /* @min:%2epush */ ](newQueue);
                            });
                            _channelConfig = newChannelConfig;
                        }
                        removeComplete && removeComplete(removed);
                        _startLogPoller();
                    });
                    unloadCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROCESS_NEXT"] /* @min:%2eprocessNext */ ](unloadState);
                } else {
                    removeComplete(false);
                }
            }
            function _flushInternalLogs() {
                if (_logger && _logger.queue) {
                    var queue = _logger.queue.slice(0);
                    _logger.queue[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] = 0;
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrForEach"])(queue, function(logMessage) {
                        var item = {
                            name: _internalLogsEventName ? _internalLogsEventName : "InternalMessageId: " + logMessage[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MESSAGE_ID"] /* @min:%2emessageId */ ],
                            iKey: _instrumentationKey,
                            time: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toISOString"])(new Date()),
                            baseType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_InternalLogMessage"].dataType,
                            baseData: {
                                message: logMessage[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_MESSAGE"] /* @min:%2emessage */ ]
                            }
                        };
                        _self.track(item);
                    });
                }
            }
            function _flushChannels(isAsync, callBack, sendReason, cbTimeout) {
                // Setting waiting to one so that we don't call the callBack until we finish iterating
                var waiting = 1;
                var doneIterating = false;
                var cbTimer = null;
                cbTimeout = cbTimeout || 5000;
                function doCallback() {
                    waiting--;
                    if (doneIterating && waiting === 0) {
                        cbTimer && cbTimer[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CANCEL"] /* @min:%2ecancel */ ]();
                        cbTimer = null;
                        callBack && callBack(doneIterating);
                        callBack = null;
                    }
                }
                if (_channels && _channels[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LENGTH"] /* @min:%2elength */ ] > 0) {
                    var flushCtx = _createTelCtx()[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_CREATE_NEW"] /* @min:%2ecreateNew */ ](_channels);
                    flushCtx.iterate(function(plugin) {
                        if (plugin.flush) {
                            waiting++;
                            var handled_1 = false;
                            // Not all channels will call this callback for every scenario
                            if (!plugin.flush(isAsync, function() {
                                handled_1 = true;
                                doCallback();
                            }, sendReason)) {
                                if (!handled_1) {
                                    // If any channel doesn't return true and it didn't call the callback, then we should assume that the callback
                                    // will never be called, so use a timeout to allow the channel(s) some time to "finish" before triggering any
                                    // followup function (such as unloading)
                                    if (isAsync && cbTimer == null) {
                                        cbTimer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["scheduleTimeout"])(function() {
                                            cbTimer = null;
                                            doCallback();
                                        }, cbTimeout);
                                    } else {
                                        doCallback();
                                    }
                                }
                            }
                        }
                    });
                }
                doneIterating = true;
                doCallback();
                return true;
            }
            function _initPerfManager() {
                // Save the previous config based performance manager creator to avoid creating new perf manager instances if unchanged
                var prevCfgPerfMgr;
                // Will get recalled if any referenced config values are changed
                _addUnloadHook(_configHandler[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_WATCH"] /* @min:%2ewatch */ ](function(details) {
                    var enablePerfMgr = details.cfg.enablePerfMgr;
                    if (enablePerfMgr) {
                        var createPerfMgr = details.cfg[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CREATE_PERF_MGR"] /* @min:%2ecreatePerfMgr */ ];
                        // for preCfgPerfMgr = createPerfMgr = null
                        // initial createPerfMgr function should be _createPerfManager
                        if (prevCfgPerfMgr !== createPerfMgr || !prevCfgPerfMgr) {
                            if (!createPerfMgr) {
                                createPerfMgr = _createPerfManager;
                            }
                            // Set the performance manager creation function if not defined
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$HelperFuncs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSetValue"])(details.cfg, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_CREATE_PERF_MGR"], createPerfMgr);
                            prevCfgPerfMgr = createPerfMgr;
                            // Remove any existing config based performance manager
                            _cfgPerfManager = null;
                        }
                        // Only create the performance manager if it's not already created or manually set
                        if (!_perfManager && !_cfgPerfManager && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFunction"])(createPerfMgr)) {
                            // Create a new config based performance manager
                            _cfgPerfManager = createPerfMgr(_self, _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_NOTIFY_MGR"] /* @min:%2egetNotifyMgr */ ]());
                        }
                    } else {
                        // Remove any existing config based performance manager
                        _cfgPerfManager = null;
                        // Clear the previous cached value so it can be GC'd
                        prevCfgPerfMgr = null;
                    }
                }));
            }
            function _doUpdate(updateState) {
                var updateCtx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$ProcessTelemetryContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProcessTelemetryUpdateContext"])(_getPluginChain(), _self);
                updateCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_ON_COMPLETE"] /* @min:%2eonComplete */ ](_startLogPoller);
                if (!_self._updateHook || _self._updateHook(updateCtx, updateState) !== true) {
                    updateCtx[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_PROCESS_NEXT"] /* @min:%2eprocessNext */ ](updateState);
                }
            }
            function _logOrThrowError(message) {
                var logger = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_LOGGER"] /* @min:%2elogger */ ];
                if (logger) {
                    // there should always be a logger
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$DiagnosticLogger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_throwInternal"])(logger, 2 /* eLoggingSeverity.WARNING */ , 73 /* _eInternalMessageId.PluginException */ , message);
                    _startLogPoller();
                } else {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$nevware21$2b$ts$2d$utils$40$0$2e$12$2e$5$2f$node_modules$2f40$nevware21$2f$ts$2d$utils$2f$dist$2f$es5$2f$mod$2f$ts$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["throwError"])(message);
                }
            }
            function _notifyInvalidEvent(telemetryItem) {
                var manager = _self[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$_$5f$DynamicConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_DYN_GET_NOTIFY_MGR"] /* @min:%2egetNotifyMgr */ ]();
                if (manager) {
                    manager[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$microsoft$2b$applicationinsights$2d$core$2d$js$40$3$2e$3$2e$10_tslib$40$2$2e$8$2e$1$2f$node_modules$2f40$microsoft$2f$applicationinsights$2d$core$2d$js$2f$dist$2d$es5$2f$JavaScriptSDK$2f$InternalConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STR_EVENTS_DISCARDED"] /* @min:%2eeventsDiscarded */ ]([
                        telemetryItem
                    ], 2 /* eEventsDiscardedReason.InvalidEvent */ );
                }
            }
            function _addUnloadHook(hooks) {
                _hookContainer.add(hooks);
            }
        });
    }
    // Removed Stub for AppInsightsCore.prototype.initialize.
    // Removed Stub for AppInsightsCore.prototype.getChannels.
    // Removed Stub for AppInsightsCore.prototype.track.
    // Removed Stub for AppInsightsCore.prototype.getProcessTelContext.
    // Removed Stub for AppInsightsCore.prototype.getNotifyMgr.
    // Removed Stub for AppInsightsCore.prototype.addNotificationListener.
    // Removed Stub for AppInsightsCore.prototype.removeNotificationListener.
    // Removed Stub for AppInsightsCore.prototype.getCookieMgr.
    // Removed Stub for AppInsightsCore.prototype.setCookieMgr.
    // Removed Stub for AppInsightsCore.prototype.getPerfMgr.
    // public getStatsBeat(statsBeatState: IStatsBeatState): IStatsBeat {
    //     // @ DynamicProtoStub -- DO NOT add any code as this will be removed during packaging
    //     return null;
    // }
    // public setStatsMgr(statsMgr?: IStatsMgr): void {
    //     // @ DynamicProtoStub -- DO NOT add any code as this will be removed during packaging
    // }
    // Removed Stub for AppInsightsCore.prototype.setPerfMgr.
    // Removed Stub for AppInsightsCore.prototype.eventCnt.
    // Removed Stub for AppInsightsCore.prototype.pollInternalLogs.
    // Removed Stub for AppInsightsCore.prototype.stopPollingInternalLogs.
    // Removed Stub for AppInsightsCore.prototype.addTelemetryInitializer.
    // Removed Stub for AppInsightsCore.prototype.unload.
    // Removed Stub for AppInsightsCore.prototype.getPlugin.
    // Removed Stub for AppInsightsCore.prototype.addPlugin.
    // Removed Stub for AppInsightsCore.prototype.updateCfg.
    // Removed Stub for AppInsightsCore.prototype.evtNamespace.
    // Removed Stub for AppInsightsCore.prototype.addUnloadCb.
    // Removed Stub for AppInsightsCore.prototype.flush.
    // Removed Stub for AppInsightsCore.prototype.getTraceCtx.
    // Removed Stub for AppInsightsCore.prototype.setTraceCtx.
    // Removed Stub for AppInsightsCore.prototype.addUnloadHook.
    // Removed Stub for AppInsightsCore.prototype.onCfgChange.
    // Removed Stub for AppInsightsCore.prototype.activeStatus.
    // Removed Stub for AppInsightsCore.prototype._setPendingStatus.
    // Removed Stub for AppInsightsCore.prototype.releaseQueue.
    // Removed Stub for AppInsightsCore.prototype._updateHook.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    AppInsightsCore.__ieDyn = 1;
    return AppInsightsCore;
}();
;
 //# sourceMappingURL=AppInsightsCore.js.map
}),
]);

//# sourceMappingURL=5dbdb_%40microsoft_applicationinsights-core-js_dist-es5_20e5c818._.js.map